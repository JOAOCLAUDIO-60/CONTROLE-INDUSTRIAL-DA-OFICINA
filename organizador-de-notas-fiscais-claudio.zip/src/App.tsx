import React, { useState, useEffect, useRef } from 'react';
import { Invoice, InvoiceItem } from './types';
import InvoiceUploader from './components/InvoiceUploader';
import InvoiceList from './components/InvoiceList';
import ExcelGrid from './components/ExcelGrid';
import ChartsDashboard from './components/ChartsDashboard';
import GoogleSheetsSync from './components/GoogleSheetsSync';
import DashboardRecebidos from './components/DashboardRecebidos';
import {
  FileSpreadsheet,
  TrendingUp,
  Receipt,
  FileText,
  Clock,
  HelpCircle,
  Database,
  BarChart3,
  LayoutDashboard,
  Upload,
  CheckCircle,
  RefreshCw,
  Link2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Pre-populated sample data based exactly on the user's uploaded invoice (Supermercado Zona Sul)
const defaultInvoice: Invoice = {
  id: 'zona_sul_456837',
  fileName: 'danfe_zona_sul_456837.png',
  chaveAcesso: '3326.0633.3812.8600.1980.5505.5000.4568.3719.7769.6595',
  numeroNota: '456.837',
  serie: '55',
  dataEmissao: '03/06/2026',
  valorTotalProdutos: 403.63,
  valorTotalNota: 403.63,
  pesoBruto: 88.264,
  nomeEmitente: 'SUPERMERCADO ZONA SUL SA F07',
  cnpjEmitente: '33.381.286/0019-80',
  status: 'processed',
  extractedAt: new Date().toLocaleString('pt-BR'),
  itens: [
    { id: '1', codigo: '10553', descricao: 'BERINJELA KG', unidade: 'KG', quantidade: 6.0, valorUnitario: 6.437, valorTotal: 38.62 },
    { id: '2', codigo: '10570', descricao: 'CENOURA KG', unidade: 'KG', quantidade: 7.0, valorUnitario: 7.191, valorTotal: 50.34 },
    { id: '3', codigo: '10774', descricao: 'MARACUJA KG', unidade: 'KG', quantidade: 3.0, valorUnitario: 7.353, valorTotal: 22.06 },
    { id: '4', codigo: '36501', descricao: 'MANGA PALMER KG', unidade: 'KG', quantidade: 6.0, valorUnitario: 6.425, valorTotal: 38.55 },
    { id: '5', codigo: '37672', descricao: 'PEPINO JAPONES KG', unidade: 'KG', quantidade: 4.0, valorUnitario: 6.370, valorTotal: 25.48 },
    { id: '6', codigo: '200840', descricao: 'AGRIAO UN', unidade: 'UN', quantidade: 19.0, valorUnitario: 0.791, valorTotal: 15.03 },
    { id: '7', codigo: '200859', descricao: 'ALFACE AMERICANA UN', unidade: 'UN', quantidade: 35.0, valorUnitario: 2.095, valorTotal: 73.33 },
    { id: '8', codigo: '200867', descricao: 'ALFACE LISA UN', unidade: 'UN', quantidade: 8.0, valorUnitario: 0.853, valorTotal: 6.82 },
    { id: '9', codigo: '200875', descricao: 'ALFACE CRESPA UN', unidade: 'UN', quantidade: 10.0, valorUnitario: 0.806, valorTotal: 8.06 },
    { id: '10', codigo: '200883', descricao: 'ALFACE CRESPA ROXA UN', unidade: 'UN', quantidade: 10.0, valorUnitario: 1.139, valorTotal: 11.39 },
    { id: '11', codigo: '200891', descricao: 'BERTALHA UN', unidade: 'UN', quantidade: 2.0, valorUnitario: 1.000, valorTotal: 2.00 },
    { id: '12', codigo: '200905', descricao: 'BROCOLIS RAMOSO UN', unidade: 'UN', quantidade: 10.0, valorUnitario: 2.301, valorTotal: 23.01 },
    { id: '13', codigo: '200913', descricao: 'CEBOLINHA UN', unidade: 'UN', quantidade: 2.0, valorUnitario: 0.760, valorTotal: 1.52 },
    { id: '14', codigo: '200921', descricao: 'CHICORIA UN', unidade: 'UN', quantidade: 11.0, valorUnitario: 0.851, valorTotal: 9.36 },
    { id: '15', codigo: '201006', descricao: 'RUCULA UN', unidade: 'UN', quantidade: 6.0, valorUnitario: 1.102, valorTotal: 6.61 },
    { id: '16', codigo: '201049', descricao: 'CHEIRO VERDE UN', unidade: 'UN', quantidade: 17.0, valorUnitario: 0.818, valorTotal: 13.91 }
  ]
};

export default function App() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'grid' | 'dashboard' | 'charts'>('grid');
  const [isIframe, setIsIframe] = useState(false);
  const [isColetaMode, setIsColetaMode] = useState(false);
  const [coletaSuccessInvoice, setColetaSuccessInvoice] = useState<Invoice | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [syncToast, setSyncToast] = useState<{ show: boolean; message: string } | null>(null);

  // Clear syncToast automatically after 5 seconds
  useEffect(() => {
    if (syncToast) {
      const timer = setTimeout(() => {
        setSyncToast(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [syncToast]);

  // Check if current page is accessed via the development domain (ais-dev-)
  const isDevEnvironment = typeof window !== 'undefined' && window.location.origin.includes('ais-dev-');

  // Lock to prevent background polling from overwriting recent local updates
  const lastLocalUpdateRef = useRef<number>(0);

  // Synchronize invoices to backend server
  const syncInvoicesWithServer = async (updatedInvoices: Invoice[]) => {
    try {
      await fetch('/api/invoices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ invoices: updatedInvoices }),
      });
    } catch (e) {
      console.error("Erro ao sincronizar dados com o servidor:", e);
    }
  };

  // Load state from backend on mount
  useEffect(() => {
    try {
      setIsIframe(window.self !== window.top);
    } catch (e) {
      setIsIframe(true);
    }

    // Detect if we are in point of collection mode (Ponto de Coleta)
    const params = new URLSearchParams(window.location.search);
    const mode = params.get('mode') || params.get('ponto');
    if (mode === 'coleta' || mode === 'upload' || mode === 'ponto-coleta') {
      setIsColetaMode(true);
    }

    const fetchInvoices = async () => {
      try {
        const response = await fetch('/api/invoices');
        if (response.ok) {
          const serverInvoices = await response.json();
          if (Array.isArray(serverInvoices) && serverInvoices.length > 0) {
            setInvoices(serverInvoices);
            setSelectedInvoiceId(serverInvoices[0].id);
            localStorage.setItem('nota_fiscal_organizer_data', JSON.stringify(serverInvoices));
            return;
          }
        }
      } catch (err) {
        console.error("Erro ao buscar notas do servidor, usando localStorage:", err);
      }

      // Se o servidor está vazio ou a requisição falhou, verificamos o localStorage do navegador
      const saved = localStorage.getItem('nota_fiscal_organizer_data');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setInvoices(parsed);
            setSelectedInvoiceId(parsed[0].id);
            // Sincroniza os dados do localstorage de volta para o servidor para restaurar o banco de dados
            syncInvoicesWithServer(parsed);
            return;
          }
        } catch (e) {
          console.error("Erro ao carregar dados salvos do localStorage:", e);
        }
      }

      // Se não há dados no servidor nem no localStorage, popula com o exemplo inicial
      setInvoices([defaultInvoice]);
      setSelectedInvoiceId(defaultInvoice.id);
      localStorage.setItem('nota_fiscal_organizer_data', JSON.stringify([defaultInvoice]));
      
      // Sincroniza a nota inicial com o servidor
      syncInvoicesWithServer([defaultInvoice]);
    };

    fetchInvoices();
  }, []);

  // Poll the server for updates periodically (only for the main panel, not in Coleta mode)
  useEffect(() => {
    if (isColetaMode) return;

    const intervalId = setInterval(async () => {
      // If we recently updated locally (within 4 seconds), don't overwrite with old polling data
      if (Date.now() - lastLocalUpdateRef.current < 4000) {
        return;
      }
      try {
        const response = await fetch('/api/invoices');
        if (response.ok) {
          const serverInvoices = await response.json();
          // Double check the lock after fetch completes
          if (Date.now() - lastLocalUpdateRef.current < 4000) {
            return;
          }
          if (Array.isArray(serverInvoices)) {
            setInvoices(prevInvoices => {
              const hasNewInvoice = serverInvoices.some(
                serverInv => !prevInvoices.some(prevInv => prevInv.id === serverInv.id)
              );
              
              if (hasNewInvoice && prevInvoices.length > 0) {
                const newInv = serverInvoices.find(
                  serverInv => !prevInvoices.some(prevInv => prevInv.id === serverInv.id)
                );
                if (newInv) {
                  setSelectedInvoiceId(newInv.id);
                  setSyncToast({
                    show: true,
                    message: `Nova nota fiscal recebida de "${newInv.nomeEmitente || 'Supermercado'}" (Nota Nº ${newInv.numeroNota})!`
                  });
                }
              }
              return serverInvoices;
            });
            
            localStorage.setItem('nota_fiscal_organizer_data', JSON.stringify(serverInvoices));
            
            // Maintain stable selected invoice ID if no new invoice was selected
            setSelectedInvoiceId(prev => {
              if (serverInvoices.length === 0) return null;
              if (!prev || !serverInvoices.some(inv => inv.id === prev)) {
                return serverInvoices[0].id;
              }
              return prev;
            });
          }
        }
      } catch (err) {
        console.error("Erro de sincronização em segundo plano:", err);
      }
    }, 4000); // Sync every 4 seconds

    return () => clearInterval(intervalId);
  }, [isColetaMode]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      const response = await fetch('/api/invoices');
      if (response.ok) {
        const serverInvoices = await response.json();
        if (Array.isArray(serverInvoices)) {
          setInvoices(serverInvoices);
          if (serverInvoices.length > 0 && (!selectedInvoiceId || !serverInvoices.some(inv => inv.id === selectedInvoiceId))) {
            setSelectedInvoiceId(serverInvoices[0].id);
          }
          localStorage.setItem('nota_fiscal_organizer_data', JSON.stringify(serverInvoices));
        }
      }
    } catch (err) {
      console.error("Erro ao atualizar notas:", err);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Save changes to localstorage and backend
  const saveToLocalStorage = (updatedInvoices: Invoice[]) => {
    lastLocalUpdateRef.current = Date.now();
    setInvoices(updatedInvoices);
    localStorage.setItem('nota_fiscal_organizer_data', JSON.stringify(updatedInvoices));
    syncInvoicesWithServer(updatedInvoices);
  };

  // Handle addition of freshly extracted invoice from API
  const handleInvoiceExtracted = async (extractedData: any, fileName: string) => {
    const newInvoice: Invoice = {
      id: `invoice_${Date.now()}`,
      fileName,
      chaveAcesso: extractedData.chaveAcesso,
      numeroNota: extractedData.numeroNota || `N/A - ${Date.now().toString().slice(-4)}`,
      serie: extractedData.serie,
      dataEmissao: extractedData.dataEmissao || new Date().toLocaleDateString('pt-BR'),
      valorTotalProdutos: extractedData.valorTotalProdutos || 0,
      valorTotalNota: extractedData.valorTotalNota || 0,
      pesoBruto: extractedData.pesoBruto,
      nomeEmitente: extractedData.nomeEmitente || 'Supermercado Emitente',
      cnpjEmitente: extractedData.cnpjEmitente,
      status: 'processed',
      extractedAt: new Date().toLocaleString('pt-BR'),
      itens: (extractedData.itens || []).map((item: any, i: number) => ({
        id: `item_${Date.now()}_${i}`,
        codigo: item.codigo || '',
        descricao: (item.descricao || 'PRODUTO').toUpperCase(),
        unidade: item.unidade || 'UN',
        quantidade: item.quantidade || 1,
        valorUnitario: item.valorUnitario || 0,
        valorTotal: item.valorTotal || 0
      }))
    };

    if (isColetaMode) {
      // In collection point mode, save straight to backend and show success card ONLY if successful
      try {
        const response = await fetch('/api/add-invoice', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ invoice: newInvoice })
        });
        if (!response.ok) {
          const errText = await response.text();
          throw new Error(errText || `Erro do servidor ao salvar nota fiscal (${response.status})`);
        }
        setColetaSuccessInvoice(newInvoice);
      } catch (err: any) {
        console.error("Erro ao enviar nota fiscal para o servidor central:", err);
        throw new Error(`Não foi possível salvar a nota no servidor: ${err.message || err}`);
      }
    } else {
      const updated = [newInvoice, ...invoices];
      saveToLocalStorage(updated);
      setSelectedInvoiceId(newInvoice.id);
      setActiveTab('grid'); // switch to grid view to inspect items
    }
  };

  // Update a single invoice (e.g., changes made in ExcelGrid)
  const handleUpdateInvoice = (updated: Invoice) => {
    const index = invoices.findIndex(inv => inv.id === updated.id);
    if (index === -1) return;

    const updatedList = [...invoices];
    updatedList[index] = updated;
    saveToLocalStorage(updatedList);
  };

  // Delete an invoice
  const handleDeleteInvoice = (id: string) => {
    const updated = invoices.filter(inv => inv.id !== id);
    saveToLocalStorage(updated);

    if (selectedInvoiceId === id) {
      setSelectedInvoiceId(updated.length > 0 ? updated[0].id : null);
    }
  };

  const handleClearAll = () => {
    saveToLocalStorage([]);
    setSelectedInvoiceId(null);
  };

  // Copy Point of Collection Link helper
  const handleCopyColetaLink = () => {
    let origin = window.location.origin;
    // Automatically convert development domain (ais-dev-) to stable public domain (ais-pre-)
    if (origin.includes('ais-dev-')) {
      origin = origin.replace('ais-dev-', 'ais-pre-');
    }
    const link = `${origin}${window.location.pathname}?mode=coleta`;
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Currently active invoice object
  const activeInvoice = invoices.find(inv => inv.id === selectedInvoiceId) || null;

  if (isColetaMode) {
    return (
      <div className="min-h-screen bg-zinc-50 font-sans flex flex-col text-zinc-900 selection:bg-emerald-500/10 selection:text-emerald-900" id="app-root-coleta">
        {/* Simple Header */}
        <header className="bg-white border-b border-zinc-200 sticky top-0 z-40 select-none shadow-2xs" id="coleta-header">
          <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
                <Receipt className="w-5.5 h-5.5 stroke-[2]" />
              </div>
              <div>
                <h1 className="font-display font-bold text-base text-zinc-950 tracking-tight leading-none mb-1">
                  Ponto de Coleta e Distribuição
                </h1>
                <p className="text-[11px] font-medium text-emerald-600 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                  Conectado à Unidade Central
                </p>
              </div>
            </div>
          </div>
        </header>

        {/* Main Workspace */}
        <main className="flex-1 max-w-xl w-full mx-auto px-4 py-8 flex flex-col gap-6" id="coleta-main">
          <AnimatePresence mode="wait">
            {coletaSuccessInvoice ? (
              <motion.div
                key="success-card"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white border border-emerald-200 rounded-2xl p-6 shadow-sm flex flex-col items-center text-center"
                id="coleta-success-card"
              >
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mb-4 border border-emerald-100 shadow-2xs">
                  <CheckCircle className="w-8 h-8 stroke-[2.5]" />
                </div>
                
                <h2 className="font-display font-bold text-zinc-900 text-lg mb-1">
                  Nota Fiscal Enviada!
                </h2>
                <p className="text-sm text-zinc-500 mb-6 max-w-xs">
                  Os dados foram extraídos com inteligência artificial e sincronizados diretamente com a Unidade Central.
                </p>

                {/* Extracted Data Card */}
                <div className="w-full bg-zinc-50 border border-zinc-200/80 rounded-xl p-4 text-left mb-6 flex flex-col gap-3 text-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-zinc-200/60">
                    <span className="text-zinc-500 font-medium">Nome do Emitente (Loja)</span>
                    <span className="font-bold text-zinc-900 max-w-[200px] truncate text-right">
                      {coletaSuccessInvoice.nomeEmitente}
                    </span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-zinc-200/60">
                    <span className="text-zinc-500 font-medium">Número da Nota</span>
                    <span className="font-mono font-bold text-zinc-950">
                      {coletaSuccessInvoice.numeroNota}
                    </span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-zinc-200/60">
                    <span className="text-zinc-500 font-medium">Data de Emissão</span>
                    <span className="font-mono font-bold text-zinc-950">
                      {coletaSuccessInvoice.dataEmissao}
                    </span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-zinc-200/60">
                    <span className="text-zinc-500 font-medium">Peso Bruto (KG)</span>
                    <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 text-sm">
                      {coletaSuccessInvoice.pesoBruto !== undefined ? `${coletaSuccessInvoice.pesoBruto} KG` : 'Não localizado'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-zinc-200/60">
                    <span className="text-zinc-500 font-medium">Valor Total da Nota</span>
                    <span className="font-mono font-bold text-zinc-900 text-sm">
                      R$ {coletaSuccessInvoice.valorTotalNota.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-zinc-500 font-medium">Total de Itens</span>
                    <span className="font-bold text-zinc-900 bg-zinc-200/60 px-2 py-0.5 rounded">
                      {coletaSuccessInvoice.itens.length} itens
                    </span>
                  </div>
                </div>

                {/* Sincronização Google Sheets integrada no Ponto de Coleta */}
                <div className="w-full mb-6 border-t border-zinc-150 pt-5 text-left" id="coleta-sheets-sync-wrapper">
                  <div className="flex items-center gap-2 mb-3 px-1 select-none justify-center">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-widest">Sincronizar com Planilha</span>
                  </div>
                  <GoogleSheetsSync invoice={coletaSuccessInvoice} />
                </div>

                <button
                  onClick={() => setColetaSuccessInvoice(null)}
                  className="w-full bg-zinc-100 hover:bg-zinc-200 active:scale-[0.98] text-zinc-700 font-semibold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer text-sm border border-zinc-200"
                  id="coleta-reset-btn"
                >
                  <Upload className="w-4.5 h-4.5 text-zinc-500" />
                  <span>Escanear Outra Nota Fiscal</span>
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="uploader-card"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="flex flex-col gap-5"
                id="coleta-uploader-card"
              >
                {/* Instructions Card */}
                <div className="bg-white border border-zinc-200 rounded-2xl p-5 shadow-2xs">
                  <h3 className="font-display font-semibold text-zinc-900 text-sm mb-1.5">
                    Como enviar a nota:
                  </h3>
                  <ul className="text-xs text-zinc-500 space-y-1.5 list-disc pl-4 leading-relaxed">
                    <li>Centralize a nota fiscal ou DANFE na câmera do celular/tablet ou anexe o arquivo PDF.</li>
                    <li>Certifique-se de que a iluminação esteja boa e o texto esteja nítido.</li>
                    <li>Aguarde o processamento completo até a confirmação de envio.</li>
                  </ul>
                </div>

                {/* Uploader */}
                <InvoiceUploader onInvoiceExtracted={handleInvoiceExtracted} />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Footer */}
        <footer className="py-6 text-center text-zinc-400 text-[10px]" id="coleta-footer">
          Leitor de Notas Inteligente © {new Date().getFullYear()} - Pontos de Coleta
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50 font-sans flex flex-col text-zinc-900 selection:bg-emerald-500/10 selection:text-emerald-900" id="app-root">
      {/* Iframe Warning Banner */}
      {isIframe && (
        <div className="bg-amber-500 text-white py-2 px-4 text-center text-xs font-semibold flex items-center justify-center gap-2 flex-wrap shadow-sm select-none border-b border-amber-600" id="iframe-global-banner">
          <span>⚠️ <strong>Atenção:</strong> O Google bloqueia login e envio para o Google Sheets de dentro do painel do AI Studio por motivos de segurança.</span>
          <a
            href="/"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white text-amber-700 hover:bg-zinc-50 font-bold px-3 py-1 rounded shadow-xs hover:shadow-sm transition-all inline-flex items-center gap-1 cursor-pointer"
            id="iframe-banner-action"
          >
            Abrir Aplicativo em Nova Aba
          </a>
        </div>
      )}

      {/* Dev Environment Warning Banner (to ensure desktop and mobile share the same backend container) */}
      {isDevEnvironment && !isIframe && (
        <div className="bg-zinc-900 text-zinc-100 py-2.5 px-4 text-center text-xs flex items-center justify-center gap-3 flex-wrap shadow-sm select-none border-b border-zinc-800" id="dev-env-warning-banner">
          <span className="inline-flex items-center gap-1.5 font-medium text-zinc-300">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
            <strong>Ambiente de Desenvolvimento (ais-dev-):</strong> O link copiado para o celular usa o servidor compartilhado (ais-pre-). Para testar a sincronização em tempo real entre celular e computador, acesse a versão compartilhada em ambos!
          </span>
          <a
            href={window.location.origin.replace('ais-dev-', 'ais-pre-')}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-lg shadow-md shadow-emerald-700/10 hover:shadow-lg transition-all inline-flex items-center gap-1 cursor-pointer text-[11px]"
            id="dev-env-banner-action"
          >
            Mudar para a Versão Compartilhada (ais-pre-) no Computador
          </a>
        </div>
      )}

      {/* Top Header */}
      <header className="bg-white border-b border-zinc-200 sticky top-0 z-40 select-none shadow-2xs" id="app-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Logo & Branding */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
              <Receipt className="w-5.5 h-5.5 stroke-[2]" />
            </div>
            <div>
              <h1 className="font-display font-bold text-lg text-zinc-950 tracking-tight leading-none mb-1">
                Leitor de Notas Inteligente
              </h1>
              <p className="text-[11px] font-medium text-zinc-500">
                Organizador fiscal com OCR multimodal por <span className="font-semibold text-emerald-600">Gemini AI</span>
              </p>
            </div>
          </div>

          {/* Center Tabs Control */}
          <div className="flex items-center bg-zinc-100 border border-zinc-200/60 p-1 rounded-xl text-sm font-medium">
            <button
              onClick={() => setActiveTab('grid')}
              className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'grid'
                  ? 'bg-white text-zinc-950 shadow-xs font-semibold'
                  : 'text-zinc-500 hover:text-zinc-800'
              }`}
              id="tab-grid"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Itens & Planilha</span>
            </button>
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-white text-zinc-950 shadow-xs font-semibold'
                  : 'text-zinc-500 hover:text-zinc-800'
              }`}
              id="tab-dashboard"
            >
              <LayoutDashboard className="w-4 h-4 text-emerald-600" />
              <span className="flex items-center gap-1">
                Dashboard Recebidos
                <span className="bg-emerald-100 text-emerald-800 text-[10px] px-1.5 py-0.2 rounded-full font-bold">Novo</span>
              </span>
            </button>
            <button
              onClick={() => setActiveTab('charts')}
              className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'charts'
                  ? 'bg-white text-zinc-950 shadow-xs font-semibold'
                  : 'text-zinc-500 hover:text-zinc-800'
              }`}
              id="tab-charts"
            >
              <BarChart3 className="w-4 h-4" />
              <span>Análises & Gráficos</span>
            </button>
          </div>

          {/* Right Status / Actions */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleCopyColetaLink}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 border rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                copiedLink 
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                  : 'bg-white text-zinc-700 hover:text-zinc-950 hover:bg-zinc-50 border-zinc-200 shadow-3xs'
              }`}
              title="Copiar link exclusivo para celulares/tablets nos pontos de coleta e distribuição"
            >
              <Link2 className="w-3.5 h-3.5" />
              <span>{copiedLink ? 'Link Copiado!' : 'Copiar Link Ponto de Coleta'}</span>
            </button>

            {/* Refresh Button */}
            <button
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="inline-flex items-center justify-center p-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-600 hover:text-zinc-900 border border-zinc-200/60 rounded-xl transition-all cursor-pointer disabled:opacity-50"
              title="Sincronizar dados do servidor central"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>

            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-zinc-100 border border-zinc-200 rounded-xl text-xs font-medium text-zinc-600">
              <Database className="w-3.5 h-3.5 text-zinc-400" />
              <span>Armazenamento Central Ativo</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col lg:flex-row gap-6 h-[calc(100vh-73px)] min-h-[500px]" id="app-main">
        {/* Left Hand Sidebar (Upload & History) */}
        <aside className="w-full lg:w-80 flex flex-col gap-5 shrink-0 h-full overflow-y-auto pr-1 pb-4" id="app-sidebar">
          {/* Uploader Block */}
          <InvoiceUploader onInvoiceExtracted={handleInvoiceExtracted} />

          {/* List Block - Placed in the middle for high visibility and interaction */}
          <div className="h-[340px] shrink-0">
            <InvoiceList
              invoices={invoices}
              selectedInvoiceId={selectedInvoiceId}
              onSelectInvoice={setSelectedInvoiceId}
              onDeleteInvoice={handleDeleteInvoice}
              onClearAll={handleClearAll}
            />
          </div>

          {/* Google Sheets Sync Block - Placed at the bottom of the scrollable sidebar */}
          <GoogleSheetsSync invoice={activeInvoice} />
        </aside>

        {/* Right Hand Work Area (Active View Tab) */}
        <section className="flex-1 h-full min-w-0" id="app-workspace">
          <AnimatePresence mode="wait">
            {activeTab === 'grid' ? (
              <motion.div
                key="grid-view"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.15 }}
                className="h-full"
              >
                <ExcelGrid
                  invoice={activeInvoice}
                  onUpdateInvoice={handleUpdateInvoice}
                />
              </motion.div>
            ) : activeTab === 'dashboard' ? (
              <motion.div
                key="dashboard-view"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.15 }}
                className="h-full overflow-y-auto pr-1"
              >
                <DashboardRecebidos invoices={invoices} />
              </motion.div>
            ) : (
              <motion.div
                key="charts-view"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.15 }}
                className="h-full overflow-y-auto pr-1"
              >
                <ChartsDashboard invoices={invoices} />
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>

      {/* Synchronization Floating Toast */}
      <AnimatePresence>
        {syncToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 bg-zinc-950 text-white px-5 py-4 rounded-2xl shadow-2xl border border-zinc-800 flex items-center gap-3.5 max-w-sm select-none"
            id="sync-toast-notification"
          >
            <div className="w-10 h-10 rounded-full bg-emerald-500/25 flex items-center justify-center text-emerald-400 shrink-0">
              <CheckCircle className="w-5.5 h-5.5 stroke-[2]" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold text-emerald-400 tracking-wider uppercase leading-none">Sincronização Ativa</h4>
              <p className="text-xs text-zinc-300 font-medium leading-relaxed mt-1">{syncToast.message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
