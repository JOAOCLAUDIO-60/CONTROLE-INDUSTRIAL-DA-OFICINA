import React, { useState, useMemo } from 'react';
import { Invoice } from '../types';
import { 
  Calendar, 
  Building2, 
  ShoppingBag, 
  Database, 
  Search, 
  RotateCcw, 
  FileDown,
  Printer,
  ChevronDown,
  Check
} from 'lucide-react';

interface DashboardRecebidosProps {
  invoices: Invoice[];
}

export default function DashboardRecebidos({ invoices }: DashboardRecebidosProps) {
  // Extract all items from processed invoices
  const allRecords = useMemo(() => {
    const records: Array<{
      id: string;
      data: string;
      loja: string;
      produto: string;
      qtd: number;
      un: string;
      parsedDate: Date | null;
    }> = [];

    invoices
      .filter(inv => inv.status === 'processed')
      .forEach(inv => {
        inv.itens.forEach((item, index) => {
          // Parse date DD/MM/YYYY for filtering
          let parsedDate: Date | null = null;
          if (inv.dataEmissao) {
            const parts = inv.dataEmissao.split('/');
            if (parts.length === 3) {
              parsedDate = new Date(
                parseInt(parts[2]), 
                parseInt(parts[1]) - 1, 
                parseInt(parts[0])
              );
            }
          }

          records.push({
            id: `${inv.id}_item_${index}`,
            data: inv.dataEmissao || '',
            loja: inv.nomeEmitente || '',
            produto: item.descricao || '',
            qtd: item.quantidade || 0,
            un: (item.unidade || 'UN').toUpperCase().trim(),
            parsedDate
          });
        });
      });

    // Sort records by date descending (newest first)
    return records.sort((a, b) => {
      if (a.parsedDate && b.parsedDate) {
        return b.parsedDate.getTime() - a.parsedDate.getTime();
      }
      return b.data.localeCompare(a.data);
    });
  }, [invoices]);

  // Unique lists for filters
  const uniqueLojas = useMemo(() => {
    const set = new Set<string>();
    allRecords.forEach(r => {
      if (r.loja) set.add(r.loja);
    });
    return Array.from(set).sort();
  }, [allRecords]);

  const uniqueProdutos = useMemo(() => {
    const set = new Set<string>();
    allRecords.forEach(r => {
      if (r.produto) set.add(r.produto);
    });
    return Array.from(set).sort();
  }, [allRecords]);

  const uniqueUnidades = useMemo(() => {
    const set = new Set<string>();
    allRecords.forEach(r => {
      if (r.un) set.add(r.un);
    });
    return Array.from(set).sort();
  }, [allRecords]);

  // Filter States
  const [dataInicio, setDataInicio] = useState<string>('');
  const [dataFim, setDataFim] = useState<string>('');
  const [selectedLoja, setSelectedLoja] = useState<string>('');
  const [selectedProduto, setSelectedProduto] = useState<string>('');
  const [selectedUnidade, setSelectedUnidade] = useState<string>('');

  // Active filter states applied on "GERAR RELATÓRIO"
  const [appliedFilters, setAppliedFilters] = useState({
    dataInicio: '',
    dataFim: '',
    loja: '',
    produto: '',
    unidade: ''
  });

  // Handle Generate Report action
  const handleGenerateReport = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setAppliedFilters({
      dataInicio,
      dataFim,
      loja: selectedLoja,
      produto: selectedProduto,
      unidade: selectedUnidade
    });
  };

  // Handle Clear Filters action
  const handleClearFilters = () => {
    setDataInicio('');
    setDataFim('');
    setSelectedLoja('');
    setSelectedProduto('');
    setSelectedUnidade('');
    setAppliedFilters({
      dataInicio: '',
      dataFim: '',
      loja: '',
      produto: '',
      unidade: ''
    });
  };

  // Filtered records based on applied filters
  const filteredRecords = useMemo(() => {
    return allRecords.filter(r => {
      // Date filter
      if (appliedFilters.dataInicio && r.parsedDate) {
        const start = new Date(appliedFilters.dataInicio + 'T00:00:00');
        if (r.parsedDate < start) return false;
      }
      if (appliedFilters.dataFim && r.parsedDate) {
        const end = new Date(appliedFilters.dataFim + 'T23:59:59');
        if (r.parsedDate > end) return false;
      }

      // Loja filter
      if (appliedFilters.loja && r.loja !== appliedFilters.loja) {
        return false;
      }

      // Produto filter
      if (appliedFilters.produto && r.produto !== appliedFilters.produto) {
        return false;
      }

      // Unidade filter
      if (appliedFilters.unidade && r.un !== appliedFilters.unidade) {
        return false;
      }

      return true;
    });
  }, [allRecords, appliedFilters]);

  // Compute stats on filtered records
  const stats = useMemo(() => {
    let totalKG = 0;
    let totalUN = 0;
    const uniqueLojasSet = new Set<string>();
    const uniqueInvoicesSet = new Set<string>();

    filteredRecords.forEach(r => {
      // Check if unit or description indicates kilogram (e.g. KG, KILO, KILOS, or containing kg)
      const isKG = 
        r.un === 'KG' || 
        r.un === 'KILOS' || 
        r.un === 'KILO' || 
        r.produto.toLowerCase().includes(' kg ') || 
        r.produto.toLowerCase().endsWith(' kg') ||
        r.produto.toLowerCase().includes('(kg)');

      if (isKG) {
        totalKG += r.qtd;
      } else {
        totalUN += r.qtd;
      }

      if (r.loja) {
        uniqueLojasSet.add(r.loja);
      }

      // Extract invoice ID from the record ID (format is invoiceId_item_index)
      const invoiceId = r.id.split('_item_')[0];
      if (invoiceId) {
        uniqueInvoicesSet.add(invoiceId);
      }
    });

    // Sum up the pesoBruto of the unique filtered invoices
    let totalPesoBruto = 0;
    uniqueInvoicesSet.forEach(invId => {
      const inv = invoices.find(i => i.id === invId);
      if (inv && inv.pesoBruto) {
        totalPesoBruto += Number(inv.pesoBruto);
      }
    });

    return {
      totalKG,
      totalUN,
      lojasCount: uniqueLojasSet.size,
      lancamentosCount: filteredRecords.length,
      totalPesoBruto
    };
  }, [filteredRecords, invoices]);

  // Trigger print view (optimized for PDF export)
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6" id="dashboard-recebidos-container">
      
      {/* 1. Header Card - Matching the deep blue banner in the screenshot */}
      <div 
        className="bg-[#1f4e79] text-white rounded-2xl p-6 text-center shadow-md border border-[#163a5a] relative overflow-hidden select-none print:bg-white print:text-black print:border-none print:shadow-none"
        id="dashboard-blue-header"
      >
        <div className="absolute inset-0 bg-radial-gradient from-white/10 to-transparent opacity-50 pointer-events-none" />
        <div className="relative z-10 flex flex-col items-center justify-center gap-1">
          <div className="text-3xl mb-1.5 animate-bounce">📦</div>
          <h2 className="font-display font-bold text-xl sm:text-2xl tracking-wider uppercase flex items-center justify-center gap-2">
            DASHBOARD PRODUTOS RECEBIDOS
          </h2>
          <p className="text-sm font-light text-zinc-100/90 tracking-widest uppercase">
            Banco de Alimentos
          </p>
        </div>
      </div>

      {/* 2. KPI Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 print:grid-cols-5 print:gap-2" id="dashboard-kpi-row">
        {/* Card 1: KG Recebidos */}
        <div className="bg-white border border-zinc-200 p-4 rounded-xl shadow-xs text-center flex flex-col justify-center min-h-[100px] print:border-zinc-300 print:shadow-none">
          <span className="font-display text-2xl sm:text-3xl font-extrabold text-[#1f4e79] block tracking-tight font-mono">
            {stats.totalKG.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
          <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mt-1 block">
            KG Recebidos
          </span>
          <span className="text-[10px] text-zinc-400 mt-0.5 block">Soma de itens em KG</span>
        </div>

        {/* Card 2: Peso Bruto Total */}
        <div className="bg-white border border-zinc-200 p-4 rounded-xl shadow-xs text-center flex flex-col justify-center min-h-[100px] print:border-zinc-300 print:shadow-none border-t-2 border-t-[#1f4e79]">
          <span className="font-display text-2xl sm:text-3xl font-extrabold text-[#1f4e79] block tracking-tight font-mono">
            {stats.totalPesoBruto.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
          <span className="text-xs font-semibold text-[#1f4e79] uppercase tracking-wider mt-1 block">
            Peso Bruto (KG)
          </span>
          <span className="text-[10px] text-zinc-400 mt-0.5 block">Total extraído das notas</span>
        </div>

        {/* Card 3: UN Recebidas */}
        <div className="bg-white border border-zinc-200 p-4 rounded-xl shadow-xs text-center flex flex-col justify-center min-h-[100px] print:border-zinc-300 print:shadow-none">
          <span className="font-display text-2xl sm:text-3xl font-extrabold text-[#1f4e79] block tracking-tight">
            {stats.totalUN.toLocaleString('pt-BR')}
          </span>
          <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mt-1 block">
            UN Recebidas
          </span>
          <span className="text-[10px] text-zinc-400 mt-0.5 block">Soma de itens em UN</span>
        </div>

        {/* Card 4: Lojas */}
        <div className="bg-white border border-zinc-200 p-4 rounded-xl shadow-xs text-center flex flex-col justify-center min-h-[100px] print:border-zinc-300 print:shadow-none">
          <span className="font-display text-2xl sm:text-3xl font-extrabold text-[#1f4e79] block tracking-tight">
            {stats.lojasCount}
          </span>
          <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mt-1 block">
            Lojas
          </span>
          <span className="text-[10px] text-zinc-400 mt-0.5 block">Estabelecimentos</span>
        </div>

        {/* Card 5: Lançamentos */}
        <div className="bg-white border border-zinc-200 p-4 rounded-xl shadow-xs text-center flex flex-col justify-center min-h-[100px] print:border-zinc-300 print:shadow-none">
          <span className="font-display text-2xl sm:text-3xl font-extrabold text-[#1f4e79] block tracking-tight">
            {stats.lancamentosCount}
          </span>
          <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mt-1 block">
            Lançamentos
          </span>
          <span className="text-[10px] text-zinc-400 mt-0.5 block">Produtos na lista</span>
        </div>
      </div>

      {/* 3. Filters Panel - Beautiful, simple form */}
      <div 
        className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 shadow-2xs select-none print:hidden"
        id="dashboard-filters-panel"
      >
        <form onSubmit={handleGenerateReport} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {/* Data Início */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-zinc-400" /> Data Início
              </label>
              <input 
                type="date" 
                value={dataInicio}
                onChange={(e) => setDataInicio(e.target.value)}
                className="w-full bg-white border border-zinc-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-hidden focus:border-[#1f4e79] focus:ring-1 focus:ring-[#1f4e79] transition-all cursor-pointer"
              />
            </div>

            {/* Data Fim */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-zinc-400" /> Data Fim
              </label>
              <input 
                type="date" 
                value={dataFim}
                onChange={(e) => setDataFim(e.target.value)}
                className="w-full bg-white border border-zinc-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-hidden focus:border-[#1f4e79] focus:ring-1 focus:ring-[#1f4e79] transition-all cursor-pointer"
              />
            </div>

            {/* Lojas Dropdown */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-zinc-400" /> Loja
              </label>
              <div className="relative">
                <select 
                  value={selectedLoja}
                  onChange={(e) => setSelectedLoja(e.target.value)}
                  className="w-full bg-white border border-zinc-200 rounded-xl pl-3 pr-8 py-2 text-xs font-medium appearance-none focus:outline-hidden focus:border-[#1f4e79] focus:ring-1 focus:ring-[#1f4e79] transition-all cursor-pointer truncate"
                >
                  <option value="">Todas as Lojas</option>
                  {uniqueLojas.map(loja => (
                    <option key={loja} value={loja}>{loja}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 pointer-events-none" />
              </div>
            </div>

            {/* Produtos Dropdown */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <ShoppingBag className="w-3.5 h-3.5 text-zinc-400" /> Produto
              </label>
              <div className="relative">
                <select 
                  value={selectedProduto}
                  onChange={(e) => setSelectedProduto(e.target.value)}
                  className="w-full bg-white border border-zinc-200 rounded-xl pl-3 pr-8 py-2 text-xs font-medium appearance-none focus:outline-hidden focus:border-[#1f4e79] focus:ring-1 focus:ring-[#1f4e79] transition-all cursor-pointer truncate"
                >
                  <option value="">Todos os Produtos</option>
                  {uniqueProdutos.map(prod => (
                    <option key={prod} value={prod}>{prod}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 pointer-events-none" />
              </div>
            </div>

            {/* Unidades Dropdown */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-zinc-400" /> Unidade
              </label>
              <div className="relative">
                <select 
                  value={selectedUnidade}
                  onChange={(e) => setSelectedUnidade(e.target.value)}
                  className="w-full bg-white border border-zinc-200 rounded-xl pl-3 pr-8 py-2 text-xs font-medium appearance-none focus:outline-hidden focus:border-[#1f4e79] focus:ring-1 focus:ring-[#1f4e79] transition-all cursor-pointer truncate"
                >
                  <option value="">Todas as Unidades</option>
                  {uniqueUnidades.map(un => (
                    <option key={un} value={un}>{un}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Action Buttons Row */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-zinc-200/60">
            <div className="flex items-center gap-2">
              <button
                type="submit"
                className="bg-[#1f4e79] hover:bg-[#153b5d] text-white font-semibold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 shadow-sm hover:shadow-md transition-all cursor-pointer active:scale-95"
                id="btn-gerar-relatorio"
              >
                <Search className="w-4 h-4" />
                <span>Gerar Relatório</span>
              </button>
              
              <button
                type="button"
                onClick={handleClearFilters}
                className="bg-zinc-200 hover:bg-zinc-300 text-zinc-700 font-semibold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
                id="btn-limpar-filtros"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Limpar Filtros</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handlePrint}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 shadow-sm hover:shadow-md transition-all cursor-pointer active:scale-95"
              id="btn-exportar-pdf"
            >
              <Printer className="w-4 h-4" />
              <span>Exportar PDF / Imprimir</span>
            </button>
          </div>
        </form>
      </div>

      {/* 4. Main Reports Table */}
      <div 
        className="bg-white border border-zinc-200 rounded-2xl shadow-sm overflow-hidden flex flex-col print:border-none print:shadow-none"
        id="dashboard-report-table-card"
      >
        <div className="p-4 border-b border-zinc-200 bg-zinc-50/50 flex items-center justify-between select-none print:hidden">
          <div>
            <h3 className="font-display font-semibold text-sm text-zinc-800">
              Registros Consolidados
            </h3>
            <p className="text-xs text-zinc-400">
              Exibindo {filteredRecords.length} lançamentos encontrados
            </p>
          </div>

          <span className="text-xs font-semibold bg-[#1f4e79]/10 text-[#1f4e79] px-2.5 py-1 rounded-full border border-[#1f4e79]/10 flex items-center gap-1">
            <Check className="w-3.5 h-3.5 stroke-[3]" /> Atualizado em tempo real
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse" id="dashboard-data-table">
            <thead>
              <tr className="bg-[#1f4e79] text-white text-xs font-bold uppercase select-none text-left print:bg-zinc-100 print:text-zinc-900 print:border-b print:border-zinc-300">
                <th className="px-4 py-3 font-semibold tracking-wider w-24">Data</th>
                <th className="px-4 py-3 font-semibold tracking-wider">Loja</th>
                <th className="px-4 py-3 font-semibold tracking-wider">Produto</th>
                <th className="px-4 py-3 font-semibold tracking-wider text-right w-24">Qtd</th>
                <th className="px-4 py-3 font-semibold tracking-wider text-center w-20">Un</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 text-xs">
              {filteredRecords.length > 0 ? (
                filteredRecords.map((rec) => (
                  <tr 
                    key={rec.id} 
                    className="hover:bg-zinc-50/50 transition-colors print:hover:bg-transparent"
                  >
                    <td className="px-4 py-3 font-medium text-zinc-500 font-mono whitespace-nowrap">{rec.data}</td>
                    <td className="px-4 py-3 font-semibold text-zinc-800 truncate max-w-[150px] sm:max-w-[200px]" title={rec.loja}>{rec.loja}</td>
                    <td className="px-4 py-3 text-zinc-600 font-medium truncate max-w-[200px] sm:max-w-[300px]" title={rec.produto}>{rec.produto}</td>
                    <td className="px-4 py-3 font-bold text-zinc-900 text-right font-mono">{rec.qtd.toLocaleString('pt-BR')}</td>
                    <td className="px-4 py-3 text-center whitespace-nowrap"><span className="inline-block px-2 py-0.5 rounded-sm font-bold bg-zinc-100 border border-zinc-200/80 text-zinc-600">{rec.un}</span></td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-4 py-12 text-center text-zinc-400 font-medium bg-zinc-50/20">
                    Nenhum produto ou lançamento foi encontrado com os filtros atuais.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
