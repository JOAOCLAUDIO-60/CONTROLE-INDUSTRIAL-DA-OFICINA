import React, { useState } from 'react';
import { Invoice } from '../types';
import { FileText, Calendar, Trash2, ArrowRight, DollarSign, Store, ShoppingCart, Check, X } from 'lucide-react';

interface InvoiceListProps {
  invoices: Invoice[];
  selectedInvoiceId: string | null;
  onSelectInvoice: (id: string) => void;
  onDeleteInvoice: (id: string) => void;
  onClearAll: () => void;
}

export default function InvoiceList({
  invoices,
  selectedInvoiceId,
  onSelectInvoice,
  onDeleteInvoice,
  onClearAll
}: InvoiceListProps) {
  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl shadow-sm flex flex-col h-full overflow-hidden" id="invoice-list-root">
      {/* Sidebar Header */}
      <div className="p-4 border-b border-zinc-200 bg-zinc-50 flex items-center justify-between select-none">
        <div>
          <h3 className="font-display font-semibold text-zinc-800 text-sm">Histórico de Notas</h3>
          <p className="text-xs text-zinc-500">{invoices.length} {invoices.length === 1 ? 'nota registrada' : 'notas registradas'}</p>
        </div>
        {invoices.length > 0 && (
          <div className="flex items-center gap-1.5" id="clear-container">
            {confirmClearAll ? (
              <div className="flex items-center gap-1 bg-red-50 border border-red-150 px-2 py-1 rounded">
                <span className="text-[10px] font-bold text-red-600 mr-1 animate-pulse">Apagar tudo?</span>
                <button
                  onClick={() => {
                    onClearAll();
                    setConfirmClearAll(false);
                  }}
                  className="p-0.5 bg-red-600 hover:bg-red-700 text-white rounded cursor-pointer"
                  title="Confirmar exclusão"
                >
                  <Check className="w-3 h-3 stroke-[2.5]" />
                </button>
                <button
                  onClick={() => setConfirmClearAll(false)}
                  className="p-0.5 bg-zinc-200 hover:bg-zinc-300 text-zinc-700 rounded cursor-pointer"
                  title="Cancelar"
                >
                  <X className="w-3 h-3 stroke-[2.5]" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmClearAll(true)}
                className="text-xs font-semibold text-red-500 hover:text-red-700 transition-colors cursor-pointer px-2 py-1 hover:bg-red-50 rounded"
                id="clear-all-button"
              >
                Limpar Tudo
              </button>
            )}
          </div>
        )}
      </div>

      {/* Sidebar List */}
      <div className="flex-1 overflow-y-auto divide-y divide-zinc-100" id="invoice-list-scroll">
        {invoices.length === 0 ? (
          <div className="p-8 text-center text-zinc-400 h-64 flex flex-col items-center justify-center">
            <FileText className="w-8 h-8 stroke-[1.5] text-zinc-300 mb-2" />
            <p className="text-sm">Nenhuma nota registrada no momento.</p>
            <p className="text-xs text-zinc-500 mt-1">Utilize o painel de upload para adicionar notas.</p>
          </div>
        ) : (
          invoices.map((inv) => {
            const isSelected = inv.id === selectedInvoiceId;
            const itemsCount = inv.itens.length;

            return (
              <div
                key={inv.id}
                className={`p-3.5 transition-all cursor-pointer relative group flex items-start gap-3 ${
                  isSelected
                    ? 'bg-emerald-50/50 border-r-4 border-emerald-500'
                    : 'hover:bg-zinc-50'
                }`}
                onClick={() => onSelectInvoice(inv.id)}
                id={`invoice-item-${inv.id}`}
              >
                {/* Visual Icon */}
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  isSelected ? 'bg-emerald-100 text-emerald-700' : 'bg-zinc-100 text-zinc-500'
                }`}>
                  <FileText className="w-4.5 h-4.5" />
                </div>

                {/* Info block */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-0.5">
                    <span className="font-mono text-[11px] font-bold text-zinc-500" title={`Série: ${inv.serie || '-'}`}>
                      NF Nº {inv.numeroNota || 'SEM NÚMERO'}
                    </span>
                    <span className="text-[10px] text-zinc-400 font-mono shrink-0 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {inv.dataEmissao}
                    </span>
                  </div>

                  <h4 className="font-sans text-xs font-semibold text-zinc-800 truncate flex items-center gap-1" title={inv.nomeEmitente}>
                    <Store className="w-3.5 h-3.5 text-zinc-400" />
                    <span>{inv.nomeEmitente || 'Supermercado'}</span>
                  </h4>

                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-3 text-[11px] text-zinc-500 font-medium">
                      <span className="flex items-center gap-0.5">
                        <ShoppingCart className="w-3.5 h-3.5 text-zinc-400" /> {itemsCount} {itemsCount === 1 ? 'item' : 'itens'}
                      </span>
                      <span className="font-mono font-semibold text-zinc-900">
                        R$ {inv.valorTotalNota.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>

                    {/* Delete button with inline confirmation */}
                    <div onClick={(e) => e.stopPropagation()} className="flex items-center gap-1.5">
                      {deletingId === inv.id ? (
                        <div className="flex items-center gap-1 bg-red-50 border border-red-200 p-1 rounded">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteInvoice(inv.id);
                              setDeletingId(null);
                            }}
                            className="p-0.5 bg-red-600 text-white rounded hover:bg-red-700 cursor-pointer"
                            title="Confirmar"
                          >
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeletingId(null);
                            }}
                            className="p-0.5 bg-zinc-200 text-zinc-700 rounded hover:bg-zinc-300 cursor-pointer"
                            title="Cancelar"
                          >
                            <X className="w-2.5 h-2.5 stroke-[3]" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setDeletingId(inv.id);
                          }}
                          className="text-zinc-400 hover:text-red-500 p-1 rounded hover:bg-zinc-100 transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100 cursor-pointer"
                          title="Apagar nota"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
