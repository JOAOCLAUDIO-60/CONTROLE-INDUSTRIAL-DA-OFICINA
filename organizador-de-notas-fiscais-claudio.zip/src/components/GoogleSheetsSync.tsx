import React, { useState, useEffect } from 'react';
import { Invoice } from '../types';
import { googleSignIn, logout, initAuth } from '../lib/firebase';
import { User } from 'firebase/auth';
import { FileSpreadsheet, LogIn, LogOut, CheckCircle2, AlertTriangle, Loader2, ArrowRight, Check, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GoogleSheetsSyncProps {
  invoice: Invoice | null;
}

export default function GoogleSheetsSync({ invoice }: GoogleSheetsSyncProps) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Default values requested by the user
  const [spreadsheetUrl, setSpreadsheetUrl] = useState(
    'https://docs.google.com/spreadsheets/d/1BAL3XW8O2FBEPoEOXO-W_O0qF0DQqAisPwfN471VTXU/edit?gid=1417981494#gid=1417981494'
  );
  const [tabName, setTabName] = useState('PRODUTOS_OCR');

  const [isIframe, setIsIframe] = useState(false);

  // Initialize Auth state and detect if in iframe on mount
  useEffect(() => {
    // Simple detection of iframe
    try {
      setIsIframe(window.self !== window.top);
    } catch (e) {
      setIsIframe(true);
    }

    const unsubscribe = initAuth(
      (currentUser, currentToken) => {
        setUser(currentUser);
        setToken(currentToken);
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setErrorMessage(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setToken(result.accessToken);
      }
    } catch (err: any) {
      console.error('Login failed:', err);
      setErrorMessage(err.message || 'Erro ao conectar com o Google.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
      setToken(null);
      setSyncStatus('idle');
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  // Helper to extract spreadsheet ID from the URL
  const getSpreadsheetId = (url: string) => {
    // Standard format: https://docs.google.com/spreadsheets/d/SPREADSHEET_ID/edit...
    const matches = url.match(/\/d\/([a-zA-Z0-9-_]+)/);
    return matches ? matches[1] : null;
  };

  const handleSync = async () => {
    if (!invoice) return;
    if (!token) {
      setErrorMessage('Por favor, conecte sua conta Google antes de exportar.');
      return;
    }

    const spreadsheetId = getSpreadsheetId(spreadsheetUrl);
    if (!spreadsheetId) {
      setErrorMessage('URL da planilha inválida. Certifique-se de que a URL contém o ID do documento (ex: /d/PLANILHA_ID/).');
      setSyncStatus('error');
      return;
    }

    // Require explicit user confirmation for data writing (as per security guidelines)
    const confirmMessage = `Deseja realmente adicionar os ${invoice.itens.length} itens da nota fiscal Nº ${invoice.numeroNota} à planilha "${tabName}" no Google Sheets?`;
    if (!window.confirm(confirmMessage)) {
      return;
    }

    setIsSyncing(true);
    setSyncStatus('idle');
    setErrorMessage(null);

    try {
      // Helper to format numbers with comma decimal separator for Portuguese-locale Google Sheets
      const formatPtBrNumber = (val: number | undefined | null): string => {
        if (val === undefined || val === null || isNaN(val)) return '0';
        if (Number.isInteger(val)) return val.toString();
        return val.toString().replace('.', ',');
      };

      // Clean access key to keep digits only (removes dots and spaces)
      const cleanChaveAcesso = (chave: string): string => {
        return (chave || '').replace(/\D/g, '');
      };

      // Build row data according to the target columns:
      // A: DATA | B: LOJA | C: CODIGO | D: PRODUTO | E: QTD | F: UN | G: VALOR UNITARIO | H: VALOR TOTAL | I: Nº NOTA | J: CHAVE ACESSO | K: 0 | L: 0
      const rows = invoice.itens.map(item => [
        invoice.dataEmissao,
        invoice.nomeEmitente,
        item.codigo,
        item.descricao,
        formatPtBrNumber(item.quantidade),
        item.unidade,
        formatPtBrNumber(item.valorUnitario),
        formatPtBrNumber(item.valorTotal),
        invoice.numeroNota,
        cleanChaveAcesso(invoice.chaveAcesso || ''),
        '0', // Coluna K (conforme imagem da planilha)
        '0'  // Coluna L (conforme imagem da planilha)
      ]);

      const range = `${tabName}!A:L`;

      // API Call to Google Sheets API Values Append
      const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED`;

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          range: range,
          majorDimension: 'ROWS',
          values: rows
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error?.message || `Erro na API Google Sheets (${response.status})`);
      }

      setSyncStatus('success');
      // Reset success status after a while
      setTimeout(() => setSyncStatus('idle'), 5000);

    } catch (err: any) {
      console.error('Google Sheets Sync failed:', err);
      let errorMsg = err.message || 'Erro ao sincronizar dados com o Google Sheets. Verifique se você tem permissão de edição nesta planilha.';
      if (errorMsg.toLowerCase().includes('parse range') || errorMsg.toLowerCase().includes('intervalo')) {
        errorMsg = `Erro de Intervalo: Não foi possível encontrar a aba "${tabName}". Certifique-se de que o nome da aba está escrito EXATAMENTE igual na sua planilha do Google (por exemplo, "PRODUTOS_OCR" ou "CADASTRO_PRODUTOS").`;
      }
      setErrorMessage(errorMsg);
      setSyncStatus('error');
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-5 shadow-sm" id="google-sheets-sync-panel">
      <div className="flex items-center justify-between mb-4 select-none">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <FileSpreadsheet className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="font-display font-semibold text-zinc-900 text-sm">Sincronizar com Google Sheets</h3>
            <p className="text-[11px] text-zinc-400">Envie dados diretamente sem planilhas locais</p>
          </div>
        </div>

        {user && (
          <button
            onClick={handleLogout}
            className="text-[10px] font-semibold text-zinc-400 hover:text-red-500 transition-colors inline-flex items-center gap-1.5 px-2 py-1 hover:bg-red-50 rounded-md cursor-pointer"
            title="Sair da conta Google"
          >
            <LogOut className="w-3 h-3" />
            <span>Sair</span>
          </button>
        )}
      </div>

      {isIframe && !user && (
        <div className="mb-4 p-3.5 bg-amber-50 border border-amber-200/80 rounded-xl text-xs text-amber-900" id="iframe-auth-warning">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-amber-950 block">Modo de Visualização Protegido</span>
              <p className="mt-1 leading-relaxed text-amber-800">
                O Google bloqueia autenticações dentro do painel do AI Studio para garantir sua segurança.
              </p>
              <p className="mt-1.5 text-[11px] font-medium text-amber-700">
                Abra o aplicativo em uma nova aba para sincronizar com sua planilha automaticamente.
              </p>
            </div>
          </div>
          <a
            href="/"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3.5 w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 shadow-sm hover:shadow-md transition-all cursor-pointer text-center select-none"
            id="open-new-tab-sync-button"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Abrir App em Nova Aba</span>
          </a>
        </div>
      )}

      <AnimatePresence mode="wait">
        {!user ? (
          /* Sign-In State */
          <motion.div
            key="login-view"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col items-center justify-center py-4 text-center"
          >
            <p className="text-xs text-zinc-500 mb-4 max-w-xs leading-relaxed">
              Conecte sua conta do Google para importar de forma 100% automatizada e segura os itens das suas notas para a sua planilha.
            </p>

            <button
              onClick={handleLogin}
              disabled={isLoggingIn}
              className="gsi-material-button w-full justify-center max-w-xs"
              id="google-signin-button"
            >
              <div className="gsi-material-button-state"></div>
              <div className="gsi-material-button-content-wrapper">
                <div className="gsi-material-button-icon">
                  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                    <path fill="none" d="M0 0h48v48H0z"></path>
                  </svg>
                </div>
                <span className="gsi-material-button-contents text-zinc-700 font-medium font-sans">
                  {isLoggingIn ? 'Conectando...' : 'Fazer login com o Google'}
                </span>
              </div>
            </button>
          </motion.div>
        ) : (
          /* Logged-In & Ready State */
          <motion.div
            key="sync-view"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4"
          >
            {/* User Info Capsule */}
            <div className="flex items-center gap-2.5 p-2.5 bg-zinc-50 border border-zinc-150 rounded-xl">
              {user.photoURL ? (
                <img referrerPolicy="no-referrer" src={user.photoURL} alt={user.displayName || ''} className="w-8 h-8 rounded-full border border-zinc-200" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                  {user.displayName?.charAt(0) || 'G'}
                </div>
              )}
              <div className="min-w-0">
                <p className="text-xs font-semibold text-zinc-800 leading-none truncate">{user.displayName}</p>
                <p className="text-[10px] text-zinc-500 truncate">{user.email}</p>
              </div>
            </div>

            {/* Config Inputs */}
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">URL da Planilha</label>
                <input
                  type="text"
                  value={spreadsheetUrl}
                  onChange={(e) => setSpreadsheetUrl(e.target.value)}
                  className="w-full text-xs bg-zinc-50 border border-zinc-200 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 rounded-lg p-2 font-mono outline-none transition-all"
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Nome da Aba (Tab)</label>
                <input
                  type="text"
                  value={tabName}
                  onChange={(e) => setTabName(e.target.value)}
                  className="w-full text-xs bg-zinc-50 border border-zinc-200 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 rounded-lg p-2 font-mono outline-none transition-all"
                  placeholder="PRODUTOS"
                />
              </div>
            </div>

            {/* Sync Button */}
            <button
              onClick={handleSync}
              disabled={isSyncing || !invoice}
              className={`w-full py-2 px-4 rounded-xl text-sm font-semibold text-white shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                !invoice
                  ? 'bg-zinc-300 shadow-none cursor-not-allowed'
                  : isSyncing
                  ? 'bg-emerald-500/80 shadow-none'
                  : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/10'
              }`}
              id="google-sheets-sync-action"
            >
              {isSyncing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Enviando dados...</span>
                </>
              ) : (
                <>
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Enviar para Google Sheets</span>
                </>
              )}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Notification */}
      {syncStatus === 'success' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3.5 p-3 bg-emerald-50 border border-emerald-100 rounded-xl flex items-start gap-2 text-xs text-emerald-800"
          id="sync-success-alert"
        >
          <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 shrink-0" />
          <div>
            <span className="font-semibold block">Sincronizado!</span>
            <p className="mt-0.5 text-emerald-700">Os produtos foram importados com sucesso para a aba "{tabName}"!</p>
          </div>
        </motion.div>
      )}

      {/* Error Message Box */}
      {errorMessage && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3.5 p-3 bg-red-50 border border-red-100 rounded-xl flex items-start gap-2 text-xs text-red-800"
          id="sync-error-alert"
        >
          <AlertTriangle className="w-4.5 h-4.5 text-red-500 shrink-0" />
          <div>
            <span className="font-semibold block">Erro na Planilha</span>
            <p className="mt-0.5 text-red-600 leading-relaxed">{errorMessage}</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
