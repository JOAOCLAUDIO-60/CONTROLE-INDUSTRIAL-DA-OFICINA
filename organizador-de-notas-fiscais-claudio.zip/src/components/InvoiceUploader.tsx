import React, { useState, useRef } from 'react';
import { Upload, FileImage, FileCode, CheckCircle, AlertTriangle, RefreshCw, Camera, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface InvoiceUploaderProps {
  onInvoiceExtracted: (data: any, fileName: string) => void;
}

export default function InvoiceUploader({ onInvoiceExtracted }: InvoiceUploaderProps) {
  const [dragActive, setDragActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const steps = [
    "Carregando arquivo digitalizado...",
    "Iniciando OCR inteligente de alta precisão...",
    "Extraindo Chave de Acesso, Nº de Série e Data...",
    "Varrendo a tabela de produtos, quantidades e unidades...",
    "Limpando resíduos de leitura e calculando subtotais..."
  ];

  // Advance loading steps sequentially to provide a polished UX
  const startLoadingAnimation = () => {
    setLoading(true);
    setErrorMsg(null);
    setLoadingStep(0);

    const interval = setInterval(() => {
      setLoadingStep((prev) => {
        if (prev >= steps.length - 1) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 1800);

    return interval;
  };

  const handleFile = async (file: File) => {
    if (!file) return;

    // Validate mime type (images or PDFs)
    const validMimeTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    if (!validMimeTypes.includes(file.type)) {
      setErrorMsg("Formato de arquivo inválido. Por favor, envie uma imagem (JPG, PNG) ou um PDF de nota fiscal.");
      return;
    }

    const intervalId = startLoadingAnimation();

    try {
      // Convert file to base64
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
          const result = reader.result as string;
          // Strip out metadata prefix (e.g., "data:image/png;base64,")
          const base64 = result.split(',')[1];
          resolve(base64);
        };
        reader.onerror = (error) => reject(error);
      });

      // Send to server-side API
      const response = await fetch('/api/extract-invoice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          base64Data,
          mimeType: file.type,
          fileName: file.name
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(typeof errorData.error === 'object' ? JSON.stringify(errorData.error) : (errorData.error || `Erro do servidor (${response.status})`));
      }

      const extractedData = await response.json();
      onInvoiceExtracted(extractedData, file.name);

    } catch (err: any) {
      console.error("Erro ao processar nota fiscal:", err);
      let friendlyMessage = err.message || "Erro desconhecido ao processar o arquivo. Certifique-se de que a imagem está nítida.";
      
      // Try to parse nested JSON if the error is a stringified JSON object
      try {
        if (typeof friendlyMessage === 'string') {
          const trimmed = friendlyMessage.trim();
          if (trimmed.startsWith('{') || trimmed.includes('{"error"')) {
            // Find start of JSON
            const startIndex = trimmed.indexOf('{');
            const jsonStr = trimmed.slice(startIndex);
            const parsedError = JSON.parse(jsonStr);
            if (parsedError.error?.message) {
              friendlyMessage = parsedError.error.message;
            } else if (parsedError.message) {
              friendlyMessage = parsedError.message;
            }
          }
        }
      } catch (e) {
        // Failed to parse, keep original friendlyMessage
      }

      // Check for common Google / Gemini errors to translate to highly supportive, clear language
      const msgLower = friendlyMessage.toLowerCase();
      if (
        msgLower.includes("503") || 
        msgLower.includes("alta demanda") || 
        msgLower.includes("indisponível") || 
        msgLower.includes("overloaded") || 
        msgLower.includes("temporarily unavailable") || 
        msgLower.includes("service unavailable")
      ) {
        friendlyMessage = "Os servidores do Google Gemini estão sob alta demanda temporária neste momento (pico de acessos). Não se preocupe! Por favor, aguarde cerca de 5 a 10 segundos e tente enviar o arquivo novamente.";
      } else if (msgLower.includes("api key") || msgLower.includes("api_key")) {
        friendlyMessage = "A chave de API do Gemini não está configurada corretamente no servidor. Verifique se o segredo GEMINI_API_KEY foi adicionado nas configurações.";
      } else if (msgLower.includes("quota") || msgLower.includes("limit") || msgLower.includes("429")) {
        friendlyMessage = "Limite de requisições excedido temporariamente. Por favor, aguarde de 30 a 60 segundos e tente novamente.";
      }

      setErrorMsg(friendlyMessage);
    } finally {
      clearInterval(intervalId);
      setLoading(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleCameraInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm" id="uploader-container">
      <h3 className="font-display font-semibold text-zinc-900 text-base mb-1.5 flex items-center gap-2">
        <Upload className="w-5 h-5 text-emerald-600" />
        <span>Enviar Nova Nota Fiscal</span>
      </h3>
      <p className="text-xs text-zinc-500 mb-4">
        Tire uma foto direta ou selecione um arquivo de nota fiscal. A inteligência artificial irá extrair e salvar os dados automaticamente.
      </p>

      {/* Uploader Drag area */}
      <div
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={onButtonClick}
        className={`relative border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
          dragActive
            ? 'border-emerald-500 bg-emerald-50/30'
            : 'border-zinc-200 hover:border-zinc-300 hover:bg-zinc-50/50'
        }`}
        id="uploader-drag-zone"
      >
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          accept="image/jpeg,image/png,image/webp,application/pdf"
          onChange={handleFileInputChange}
          onClick={(e) => {
            (e.currentTarget as HTMLInputElement).value = '';
          }}
        />

        <input
          ref={cameraInputRef}
          type="file"
          className="hidden"
          accept="image/*"
          capture="environment"
          onChange={handleCameraInputChange}
          onClick={(e) => {
            (e.currentTarget as HTMLInputElement).value = '';
          }}
        />

        {loading ? (
          <div className="flex flex-col items-center py-4" id="uploader-loading-state">
            <div className="relative w-12 h-12 mb-4">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 1.2, ease: "linear" }}
                className="w-12 h-12 rounded-full border-3 border-zinc-100 border-t-emerald-600"
              />
            </div>
            <p className="text-sm font-medium text-zinc-800 animate-pulse transition-all duration-300">
              {steps[loadingStep]}
            </p>
            <p className="text-[11px] text-zinc-400 mt-1">Análise em tempo real via Gemini AI</p>
          </div>
        ) : (
          <div className="flex flex-col items-center w-full" id="uploader-idle-state">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 border border-emerald-100 shadow-2xs">
              <Camera className="w-6 h-6 stroke-[2]" />
            </div>
            
            <p className="text-sm font-semibold text-zinc-800 mb-1">
              Como deseja enviar a nota?
            </p>
            <p className="text-[11px] text-zinc-400 mb-5 max-w-xs leading-relaxed">
              Celulares e tablets podem tirar fotos diretamente com a câmera traseira do aparelho.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md px-2" onClick={(e) => e.stopPropagation()}>
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-semibold py-3.5 px-4 rounded-xl shadow-md shadow-emerald-600/10 transition-all flex items-center justify-center gap-2 cursor-pointer text-xs"
                id="camera-capture-btn"
              >
                <Camera className="w-4 h-4 stroke-[2.5]" />
                <span>📸 Tirar Foto da Nota</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 bg-zinc-100 hover:bg-zinc-200 active:scale-[0.98] text-zinc-700 font-semibold py-3.5 px-4 border border-zinc-200 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer text-xs"
                id="file-browse-btn"
              >
                <FileText className="w-4 h-4 text-zinc-500" />
                <span>📁 Escolher Arquivo / PDF</span>
              </button>
            </div>

            <p className="text-[10px] text-zinc-400 mt-5">
              Ou arraste o arquivo PDF/Imagem para esta área pontilhada.
            </p>
          </div>
        )}
      </div>

      {/* Error Message Box */}
      {errorMsg && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 p-3.5 bg-red-50 border border-red-100 rounded-xl flex items-start gap-2.5 text-xs text-red-700"
          id="uploader-error-box"
        >
          <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold block">Erro de Leitura</span>
            <p className="mt-0.5 leading-relaxed text-red-600">{errorMsg}</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
