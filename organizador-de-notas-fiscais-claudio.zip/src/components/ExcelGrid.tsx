import React, { useState, useEffect } from 'react';
import { Invoice, InvoiceItem } from '../types';
import { Plus, Trash2, FileSpreadsheet, Download, AlertCircle, Check, HelpCircle, Save } from 'lucide-react';

interface ExcelGridProps {
  invoice: Invoice | null;
  onUpdateInvoice: (updated: Invoice) => void;
}

export default function ExcelGrid({ invoice, onUpdateInvoice }: ExcelGridProps) {
  const [csvDelimiter, setCsvDelimiter] = useState<';' | ','>(';');
  const [showExportToast, setShowExportToast] = useState(false);

  if (!invoice) {
    return (
      <div className="flex flex-col items-center justify-center h-96 border border-dashed border-zinc-300 rounded-2xl bg-zinc-50 p-8 text-center" id="empty-grid-state">
        <div className="w-16 h-16 rounded-full bg-zinc-100 flex items-center justify-center mb-4 text-zinc-400">
          <FileSpreadsheet className="w-8 h-8" />
        </div>
        <h3 className="font-display text-lg font-medium text-zinc-800 mb-1">Nenhuma nota selecionada</h3>
        <p className="text-sm text-zinc-500 max-w-sm">
          Faça o upload de uma nota fiscal ou selecione uma nota existente na barra lateral para ver e editar os itens aqui.
        </p>
      </div>
    );
  }

  // Handle updates to invoice header fields
  const handleHeaderChange = (field: keyof Invoice, value: any) => {
    onUpdateInvoice({
      ...invoice,
      [field]: value
    });
  };

  // Handle cell changes in the item table
  const handleItemCellChange = (itemId: string, field: keyof InvoiceItem, value: any) => {
    const updatedItens = invoice.itens.map(item => {
      if (item.id === itemId) {
        const updatedItem = { ...item, [field]: value };
        // Auto-calculate total price if quantity or unit price changes
        if (field === 'quantidade' || field === 'valorUnitario') {
          const qty = field === 'quantidade' ? Number(value) : Number(item.quantidade);
          const unit = field === 'valorUnitario' ? Number(value) : Number(item.valorUnitario);
          updatedItem.valorTotal = parseFloat((qty * unit).toFixed(2));
        }
        return updatedItem;
      }
      return item;
    });

    // Auto-calculate sum of all items for Valor Total Produtos
    const totalProdSum = updatedItens.reduce((sum, item) => sum + (item.valorTotal || 0), 0);

    onUpdateInvoice({
      ...invoice,
      itens: updatedItens,
      valorTotalProdutos: parseFloat(totalProdSum.toFixed(2)),
      // If total nota is equal or unset, align it with products total
      valorTotalNota: invoice.valorTotalNota === invoice.valorTotalProdutos ? parseFloat(totalProdSum.toFixed(2)) : invoice.valorTotalNota
    });
  };

  // Add a new empty row to the item table
  const handleAddItem = () => {
    const newItem: InvoiceItem = {
      id: `item_${Date.now()}`,
      codigo: '',
      descricao: 'NOVO PRODUTO',
      unidade: 'UN',
      quantidade: 1,
      valorUnitario: 0,
      valorTotal: 0
    };

    onUpdateInvoice({
      ...invoice,
      itens: [...invoice.itens, newItem]
    });
  };

  // Delete an item from the table
  const handleDeleteItem = (itemId: string) => {
    const updatedItens = invoice.itens.filter(item => item.id !== itemId);
    const totalProdSum = updatedItens.reduce((sum, item) => sum + (item.valorTotal || 0), 0);

    onUpdateInvoice({
      ...invoice,
      itens: updatedItens,
      valorTotalProdutos: parseFloat(totalProdSum.toFixed(2)),
      valorTotalNota: invoice.valorTotalNota === invoice.valorTotalProdutos ? parseFloat(totalProdSum.toFixed(2)) : invoice.valorTotalNota
    });
  };

  // Export to CSV
  const handleExportCSV = () => {
    // Generate CSV content
    // Columns: DATA | LOJA | CODIGO | PRODUTOS OCR | QTD | UN | VALOR UNITARIO | VALOR TOTAL
    const headers = ['DATA', 'LOJA', 'CODIGO', 'PRODUTO', 'QTD', 'UN', 'VALOR UNITARIO', 'VALOR TOTAL', 'Nº NOTA', 'CHAVE ACESSO'];
    const delimiter = csvDelimiter;

    const rows = invoice.itens.map(item => {
      // Helper to format numbers with comma if Portuguese format
      const formatNum = (val: number) => {
        if (delimiter === ';') {
          return val.toString().replace('.', ',');
        }
        return val.toString();
      };

      return [
        invoice.dataEmissao,
        invoice.nomeEmitente,
        item.codigo,
        `"${item.descricao.replace(/"/g, '""')}"`,
        formatNum(item.quantidade),
        item.unidade,
        formatNum(item.valorUnitario),
        formatNum(item.valorTotal),
        invoice.numeroNota,
        invoice.chaveAcesso || ''
      ];
    });

    const csvContent = [
      headers.join(delimiter),
      ...rows.map(r => r.join(delimiter))
    ].join('\n');

    // Create file blob and download
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `nota_${invoice.numeroNota || 'export'}_itens.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setShowExportToast(true);
    setTimeout(() => setShowExportToast(false), 3000);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full" id="excel-grid-container">
      {/* Grid Toolbar / Header */}
      <div className="p-4 border-b border-zinc-200 bg-zinc-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 mb-1">
            <Check className="w-3.5 h-3.5" /> Extraído com Inteligência Artificial
          </span>
          <h2 className="font-display text-lg font-semibold text-zinc-900 flex items-center gap-2">
            Planilha Interativa da Nota: <span className="font-mono text-emerald-600">Nº {invoice.numeroNota}</span>
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Delimiter Selection */}
          <div className="flex items-center gap-1.5 bg-white border border-zinc-200 rounded-lg p-1 text-xs">
            <span className="text-zinc-500 px-1.5">Separador:</span>
            <button
              onClick={() => setCsvDelimiter(';')}
              className={`px-2 py-1 rounded font-medium transition-colors ${csvDelimiter === ';' ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'}`}
              title="Formato Excel em Português (ponto e vírgula e decimal com vírgula)"
              id="delimiter-semicolon"
            >
              Excel (;)
            </button>
            <button
              onClick={() => setCsvDelimiter(',')}
              className={`px-2 py-1 rounded font-medium transition-colors ${csvDelimiter === ',' ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'}`}
              title="Formato padrão internacional (vírgula e decimal com ponto)"
              id="delimiter-comma"
            >
              Padrão (,)
            </button>
          </div>

          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors shadow-sm cursor-pointer"
            id="export-csv-button"
          >
            <Download className="w-4 h-4" />
            <span>Exportar para Planilha (.csv)</span>
          </button>
        </div>
      </div>

      {/* Invoice Details Block */}
      <div className="p-4 border-b border-zinc-100 bg-white grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4" id="invoice-details-block">
        <div>
          <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-1">Nome do Emitente (Loja)</label>
          <input
            type="text"
            value={invoice.nomeEmitente}
            onChange={(e) => handleHeaderChange('nomeEmitente', e.target.value)}
            className="w-full text-sm font-medium text-zinc-800 bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
            id="input-nome-emitente"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-1">Nº da Nota / Série</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={invoice.numeroNota}
              placeholder="Número"
              onChange={(e) => handleHeaderChange('numeroNota', e.target.value)}
              className="w-2/3 text-sm font-medium text-zinc-800 bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all font-mono"
              id="input-numero-nota"
            />
            <input
              type="text"
              value={invoice.serie || ''}
              placeholder="Série"
              onChange={(e) => handleHeaderChange('serie', e.target.value)}
              className="w-1/3 text-sm font-medium text-zinc-800 bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all font-mono"
              id="input-serie"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-1">Data de Emissão</label>
          <input
            type="text"
            value={invoice.dataEmissao}
            placeholder="DD/MM/AAAA"
            onChange={(e) => handleHeaderChange('dataEmissao', e.target.value)}
            className="w-full text-sm font-medium text-zinc-800 bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all font-mono"
            id="input-data-emissao"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-1">Peso Bruto (KG)</label>
          <input
            type="number"
            step="any"
            value={invoice.pesoBruto !== undefined ? invoice.pesoBruto : ''}
            placeholder="0,00"
            onChange={(e) => handleHeaderChange('pesoBruto', e.target.value === '' ? undefined : parseFloat(e.target.value))}
            className="w-full text-sm font-medium text-zinc-800 bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all font-mono"
            id="input-peso-bruto"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-1">Chave de Acesso (44 dígitos)</label>
          <input
            type="text"
            value={invoice.chaveAcesso || ''}
            onChange={(e) => handleHeaderChange('chaveAcesso', e.target.value)}
            className="w-full text-sm font-medium text-zinc-800 bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all font-mono text-xs"
            id="input-chave-acesso"
          />
        </div>
      </div>

      {/* Main spreadsheet area */}
      <div className="flex-1 overflow-auto" id="spreadsheet-scroll-area">
        <table className="w-full border-collapse text-left text-sm text-zinc-500">
          <thead className="bg-zinc-50 sticky top-0 border-b border-zinc-200 text-zinc-700 select-none z-10">
            <tr>
              <th scope="col" className="px-4 py-2.5 font-semibold text-xs text-zinc-500 w-12 text-center">#</th>
              <th scope="col" className="px-4 py-2.5 font-semibold text-xs text-zinc-500 w-28">Código</th>
              <th scope="col" className="px-4 py-2.5 font-semibold text-xs text-zinc-500 min-w-[240px]">Descrição do Produto</th>
              <th scope="col" className="px-4 py-2.5 font-semibold text-xs text-zinc-500 w-24">Unidade</th>
              <th scope="col" className="px-4 py-2.5 font-semibold text-xs text-zinc-500 w-28 text-right">Qtd.</th>
              <th scope="col" className="px-4 py-2.5 font-semibold text-xs text-zinc-500 w-32 text-right">V. Unitário (R$)</th>
              <th scope="col" className="px-4 py-2.5 font-semibold text-xs text-zinc-500 w-36 text-right">V. Total (R$)</th>
              <th scope="col" className="px-4 py-2.5 font-semibold text-xs text-zinc-500 w-12 text-center">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-100 bg-white">
            {invoice.itens.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center py-8 text-zinc-400 font-medium">
                  Nenhum item na nota. Clique em "+ Adicionar Item" para criar um produto.
                </td>
              </tr>
            ) : (
              invoice.itens.map((item, index) => (
                <tr key={item.id} className="hover:bg-zinc-50/50 transition-colors group">
                  {/* Row index */}
                  <td className="px-4 py-2 text-center text-xs font-mono font-medium text-zinc-400 bg-zinc-50/30">
                    {index + 1}
                  </td>

                  {/* Product Code */}
                  <td className="px-3 py-1.5 font-mono">
                    <input
                      type="text"
                      value={item.codigo}
                      onChange={(e) => handleItemCellChange(item.id, 'codigo', e.target.value)}
                      className="w-full text-sm font-mono text-zinc-800 bg-transparent hover:bg-zinc-100 focus:bg-white border border-transparent focus:border-zinc-300 rounded px-2 py-1 outline-none transition-all"
                      placeholder="Cod"
                    />
                  </td>

                  {/* Product Description */}
                  <td className="px-3 py-1.5">
                    <input
                      type="text"
                      value={item.descricao}
                      onChange={(e) => handleItemCellChange(item.id, 'descricao', e.target.value.toUpperCase())}
                      className="w-full text-sm font-medium text-zinc-800 bg-transparent hover:bg-zinc-100 focus:bg-white border border-transparent focus:border-zinc-300 rounded px-2 py-1 outline-none transition-all"
                      placeholder="Descrição do produto"
                    />
                  </td>

                  {/* Unit of measure */}
                  <td className="px-3 py-1.5">
                    <input
                      type="text"
                      value={item.unidade}
                      onChange={(e) => handleItemCellChange(item.id, 'unidade', e.target.value.toUpperCase())}
                      className="w-full text-sm font-medium text-center text-zinc-800 bg-transparent hover:bg-zinc-100 focus:bg-white border border-transparent focus:border-zinc-300 rounded px-2 py-1 outline-none transition-all"
                      placeholder="UNID"
                    />
                  </td>

                  {/* Quantity */}
                  <td className="px-3 py-1.5">
                    <input
                      type="number"
                      step="any"
                      value={item.quantidade}
                      onChange={(e) => handleItemCellChange(item.id, 'quantidade', e.target.value === '' ? '' : parseFloat(e.target.value))}
                      className="w-full text-sm font-mono text-right text-zinc-800 bg-transparent hover:bg-zinc-100 focus:bg-white border border-transparent focus:border-zinc-300 rounded px-2 py-1 outline-none transition-all"
                      placeholder="0.00"
                    />
                  </td>

                  {/* Unit Price */}
                  <td className="px-3 py-1.5">
                    <input
                      type="number"
                      step="0.01"
                      value={item.valorUnitario}
                      onChange={(e) => handleItemCellChange(item.id, 'valorUnitario', e.target.value === '' ? '' : parseFloat(e.target.value))}
                      className="w-full text-sm font-mono text-right text-zinc-800 bg-transparent hover:bg-zinc-100 focus:bg-white border border-transparent focus:border-zinc-300 rounded px-2 py-1 outline-none transition-all"
                      placeholder="0.00"
                    />
                  </td>

                  {/* Total Price */}
                  <td className="px-3 py-1.5">
                    <input
                      type="number"
                      step="0.01"
                      value={item.valorTotal}
                      onChange={(e) => handleItemCellChange(item.id, 'valorTotal', e.target.value === '' ? '' : parseFloat(e.target.value))}
                      className="w-full text-sm font-mono text-right font-medium text-zinc-900 bg-transparent hover:bg-zinc-100 focus:bg-white border border-transparent focus:border-zinc-300 rounded px-2 py-1 outline-none transition-all"
                      placeholder="0.00"
                    />
                  </td>

                  {/* Actions (Delete row) */}
                  <td className="px-4 py-2 text-center">
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-zinc-400 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
                      title="Deletar este produto"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Grid Footer with Totals and Add Row */}
      <div className="p-4 border-t border-zinc-200 bg-zinc-50 flex flex-col sm:flex-row items-center justify-between gap-4 select-none" id="excel-grid-footer">
        <button
          onClick={handleAddItem}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 border border-zinc-200 bg-white hover:bg-zinc-100 text-zinc-700 rounded-lg text-sm font-medium transition-all shadow-sm cursor-pointer"
          id="add-item-row-button"
        >
          <Plus className="w-4 h-4 text-zinc-500" />
          <span>Adicionar Produto</span>
        </button>

        <div className="flex items-center gap-6 text-sm font-medium text-zinc-800">
          <div className="flex items-center gap-2">
            <span className="text-zinc-500">Total Produtos:</span>
            <span className="font-mono text-zinc-900 text-base font-semibold">
              R$ {invoice.valorTotalProdutos.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>

          <div className="flex items-center gap-2 border-l border-zinc-200 pl-6">
            <span className="text-zinc-500">Valor Total Nota:</span>
            <div className="flex items-center">
              <span className="text-zinc-400 mr-1.5 text-xs">R$</span>
              <input
                type="number"
                step="0.01"
                value={invoice.valorTotalNota}
                onChange={(e) => handleHeaderChange('valorTotalNota', e.target.value === '' ? '' : parseFloat(e.target.value))}
                className="w-24 text-right font-mono text-emerald-600 bg-white border border-zinc-200 rounded px-2 py-0.5 outline-none font-semibold"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Export success notification toast */}
      {showExportToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-zinc-900 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-zinc-900">
            <Check className="w-3.5 h-3.5 stroke-[3]" />
          </div>
          <span className="text-sm font-medium">Exportado com sucesso para planilha .csv!</span>
        </div>
      )}
    </div>
  );
}
