import React, { useMemo } from 'react';
import { Invoice } from '../types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  Cell
} from 'recharts';
import { TrendingUp, FileText, ShoppingBag, DollarSign, Award, Calendar } from 'lucide-react';

interface ChartsDashboardProps {
  invoices: Invoice[];
}

export default function ChartsDashboard({ invoices }: ChartsDashboardProps) {
  const processedInvoices = useMemo(() => {
    return invoices.filter(inv => inv.status === 'processed');
  }, [invoices]);

  // Aggregate statistics
  const stats = useMemo(() => {
    const totalSpent = processedInvoices.reduce((sum, inv) => sum + (inv.valorTotalNota || 0), 0);
    const totalProductsCount = processedInvoices.reduce((sum, inv) => sum + inv.itens.reduce((s, item) => s + item.quantidade, 0), 0);
    const uniqueProducts = new Set<string>();
    processedInvoices.forEach(inv => inv.itens.forEach(item => uniqueProducts.add(item.descricao.toUpperCase())));

    const avgInvoiceValue = processedInvoices.length > 0 ? totalSpent / processedInvoices.length : 0;

    return {
      totalSpent,
      totalInvoices: processedInvoices.length,
      uniqueProductsCount: uniqueProducts.size,
      totalProductsCount,
      avgInvoiceValue
    };
  }, [processedInvoices]);

  // Expenditure over time data
  const spendingOverTimeData = useMemo(() => {
    const dailyMap = new Map<string, number>();
    processedInvoices.forEach(inv => {
      const date = inv.dataEmissao;
      dailyMap.set(date, (dailyMap.get(date) || 0) + (inv.valorTotalNota || 0));
    });

    return Array.from(dailyMap.entries())
      .map(([date, total]) => {
        // Parse date for sorting DD/MM/YYYY
        const parts = date.split('/');
        const timestamp = parts.length === 3 ? new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0])).getTime() : 0;
        return { date, total: parseFloat(total.toFixed(2)), timestamp };
      })
      .sort((a, b) => a.timestamp - b.timestamp);
  }, [processedInvoices]);

  // Top products data (highest total spent)
  const topProductsData = useMemo(() => {
    const productMap = new Map<string, { totalValue: number; qty: number }>();
    processedInvoices.forEach(inv => {
      inv.itens.forEach(item => {
        const desc = item.descricao.toUpperCase().trim();
        const existing = productMap.get(desc) || { totalValue: 0, qty: 0 };
        productMap.set(desc, {
          totalValue: existing.totalValue + (item.valorTotal || 0),
          qty: existing.qty + (item.quantidade || 0)
        });
      });
    });

    return Array.from(productMap.entries())
      .map(([name, stats]) => ({
        name: name.length > 25 ? name.substring(0, 25) + '...' : name,
        total: parseFloat(stats.totalValue.toFixed(2)),
        quantidade: parseFloat(stats.qty.toFixed(2))
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 7); // top 7 items
  }, [processedInvoices]);

  // Color palette for charts
  const COLORS = ['#059669', '#10b981', '#34d399', '#6ee7b7', '#a7f3d0', '#d1fae5', '#ecfdf5'];

  if (processedInvoices.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-96 border border-zinc-200 rounded-2xl bg-white p-8 text-center" id="empty-dashboard-state">
        <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
          <TrendingUp className="w-8 h-8" />
        </div>
        <h3 className="font-display text-lg font-medium text-zinc-800 mb-1">Relatórios Indisponíveis</h3>
        <p className="text-sm text-zinc-500 max-w-sm mb-4">
          Após processar e salvar suas primeiras notas fiscais, gráficos de gastos e estatísticas detalhadas aparecerão aqui de forma dinâmica.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6" id="dashboard-reports-root">
      {/* Cards de Métricas Rápidas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="stats-grid">
        {/* Total Gasto */}
        <div className="bg-white border border-zinc-200 p-4 rounded-2xl shadow-xs flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <DollarSign className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-xs font-medium text-zinc-400 uppercase tracking-wider mb-0.5">Total Acumulado</p>
            <p className="font-display text-lg font-bold text-zinc-950 font-mono">
              R$ {stats.totalSpent.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        </div>

        {/* Quantidade de Notas */}
        <div className="bg-white border border-zinc-200 p-4 rounded-2xl shadow-xs flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <FileText className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-xs font-medium text-zinc-400 uppercase tracking-wider mb-0.5">Notas Processadas</p>
            <p className="font-display text-xl font-bold text-zinc-950">{stats.totalInvoices}</p>
          </div>
        </div>

        {/* Média por Nota */}
        <div className="bg-white border border-zinc-200 p-4 rounded-2xl shadow-xs flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Award className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-xs font-medium text-zinc-400 uppercase tracking-wider mb-0.5">Valor Médio p/ Nota</p>
            <p className="font-display text-lg font-bold text-zinc-950 font-mono">
              R$ {stats.avgInvoiceValue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        </div>

        {/* Itens Comprados */}
        <div className="bg-white border border-zinc-200 p-4 rounded-2xl shadow-xs flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
            <ShoppingBag className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-xs font-medium text-zinc-400 uppercase tracking-wider mb-0.5">Produtos Distintos</p>
            <p className="font-display text-xl font-bold text-zinc-950">
              {stats.uniqueProductsCount} <span className="text-xs text-zinc-400 font-normal">({stats.totalProductsCount.toFixed(0)} total)</span>
            </p>
          </div>
        </div>
      </div>

      {/* Gráficos em duas colunas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" id="charts-wrapper">
        {/* Histórico de Gastos por Dia */}
        <div className="bg-white border border-zinc-200 p-5 rounded-2xl shadow-sm flex flex-col h-[350px]">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-4.5 h-4.5 text-zinc-400" />
            <h3 className="font-display text-sm font-semibold text-zinc-800">Histórico de Gastos por Data</h3>
          </div>
          {spendingOverTimeData.length > 0 ? (
            <div className="flex-1 w-full min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={spendingOverTimeData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f4f5" />
                  <XAxis dataKey="date" tickLine={false} axisLine={false} style={{ fontSize: '11px', fill: '#71717a' }} />
                  <YAxis tickLine={false} axisLine={false} style={{ fontSize: '11px', fill: '#71717a' }} />
                  <Tooltip
                    formatter={(value: any) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Total Gasto']}
                    labelStyle={{ fontWeight: 'bold', color: '#18181b' }}
                    contentStyle={{ borderRadius: '12px', borderColor: '#e4e4e7', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="total"
                    stroke="#059669"
                    strokeWidth={2.5}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                    dot={{ r: 3, fill: '#059669', strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-zinc-400 text-xs">Dados insuficientes para gerar histórico.</div>
          )}
        </div>

        {/* Maiores Gastos por Produto */}
        <div className="bg-white border border-zinc-200 p-5 rounded-2xl shadow-sm flex flex-col h-[350px]">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4.5 h-4.5 text-zinc-400" />
            <h3 className="font-display text-sm font-semibold text-zinc-800">Maiores Custos por Produto (Top 7)</h3>
          </div>
          {topProductsData.length > 0 ? (
            <div className="flex-1 w-full min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topProductsData} layout="vertical" margin={{ top: 10, right: 10, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} horizontal={false} />
                  <XAxis type="number" tickLine={false} axisLine={false} style={{ fontSize: '11px', fill: '#71717a' }} />
                  <YAxis dataKey="name" type="category" tickLine={false} axisLine={false} style={{ fontSize: '10px', fill: '#27272a', fontWeight: 500 }} width={120} />
                  <Tooltip
                    formatter={(value: any, name: any, props: any) => [
                      `R$ ${value.toLocaleString('pt-BR')}`,
                      `Total (${props.payload.quantidade} un)`
                    ]}
                    contentStyle={{ borderRadius: '12px', borderColor: '#e4e4e7', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="total" radius={[0, 6, 6, 0]} maxBarSize={20}>
                    {topProductsData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-zinc-400 text-xs">Dados insuficientes para gerar o gráfico.</div>
          )}
        </div>
      </div>
    </div>
  );
}
