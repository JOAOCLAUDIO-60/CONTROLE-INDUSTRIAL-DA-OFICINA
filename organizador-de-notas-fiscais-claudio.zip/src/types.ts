export interface InvoiceItem {
  id: string;
  codigo: string;
  descricao: string;
  unidade: string;
  quantidade: number;
  valorUnitario: number;
  valorTotal: number;
}

export interface Invoice {
  id: string;
  fileName: string;
  chaveAcesso?: string;
  numeroNota: string;
  serie?: string;
  dataEmissao: string;
  valorTotalProdutos: number;
  valorTotalNota: number;
  pesoBruto?: number;
  nomeEmitente: string;
  cnpjEmitente?: string;
  itens: InvoiceItem[];
  status: 'processed' | 'pending' | 'error';
  errorMessage?: string;
  extractedAt: string;
}

export interface DashboardStats {
  totalSpent: number;
  totalInvoices: number;
  totalProductsCount: number;
  mostPurchasedProduct: {
    descricao: string;
    quantidade: number;
    valorTotal: number;
  } | null;
}
