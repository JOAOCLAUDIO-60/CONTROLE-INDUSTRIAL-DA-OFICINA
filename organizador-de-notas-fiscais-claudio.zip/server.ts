import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import fs from "fs";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Body parser for JSON with increased limit for scanned images/PDFs
  app.use(express.json({ limit: "50mb" }));

  // API endpoint for invoice data extraction
  app.post("/api/extract-invoice", async (req, res) => {
    try {
      const { base64Data, mimeType } = req.body;
      if (!base64Data || !mimeType) {
        return res.status(400).json({ error: "Dados do arquivo ou tipo de arquivo ausentes." });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "A chave de API do Gemini (GEMINI_API_KEY) não está configurada no servidor. Por favor, adicione-a no painel Secrets." });
      }

      // Initialize the official SDK
      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const filePart = {
        inlineData: {
          mimeType,
          data: base64Data,
        },
      };

      const promptPart = {
        text: `Você é uma inteligência artificial especialista em análise de documentos e contabilidade no Brasil.
Sua missão é extrair dados com precisão cirúrgica a partir deste documento fiscal escaneado (DANFE / Nota Fiscal).

Por favor, faça a análise visual e de OCR do documento e extraia os seguintes campos com precisão:
1. chaveAcesso: Chave de acesso de 44 dígitos (geralmente abaixo do código de barras). Remova espaços.
2. numeroNota: Número da nota fiscal eletrônica (NF-e) (ex: "456.837").
3. serie: Série da nota (ex: "55").
4. dataEmissao: Data de emissão (ex: "03/06/2026"), no formato "DD/MM/AAAA".
5. valorTotalProdutos: Valor total bruto dos produtos (ex: 403.63). Deve ser um número decimal (use ponto como separador).
6. valorTotalNota: Valor total da nota (ex: 403.63). Deve ser um número decimal.
7. pesoBruto: Peso bruto total dos volumes transportados em KG, localizado na seção "TRANSPORTADOR / VOLUMES TRANSPORTADOS" ou "DADOS DO TRANSPORTADOR", no campo com rótulo "PESO BRUTO" (ex: "88,264" ou "88.264" ou "120,50"). Converta para número decimal (use ponto como separador, ex: 88.264). Cuidado: Não retorne 0 se o valor estiver impresso na nota!
8. nomeEmitente: Nome ou Razão Social do emitente (ex: "SUPERMERCADO ZONA SUL SA F07" ou "Supermercado Zona Sul").
9. cnpjEmitente: CNPJ do emitente.
10. itens: Uma lista contendo cada produto ou serviço da tabela "DADOS PRODUTOS SERVIÇOS". Para cada produto, extraia:
   - codigo: O código interno do produto (coluna "CÓDIGO"). ex: "10553".
   - descricao: O nome ou descrição do produto. Limpe e remova termos residuais ou sujeira de OCR como "Vlr.ICMS Desonerado..." (ex: "BERINJELA KG" ao invés de "BERINJELA KG Vlr.ICMS Desonerado: R$ 9,66"). Mantenha em maiúsculas se original.
   - unidade: Unidade de medida (coluna "UNID"). ex: "KG" ou "UN".
   - quantidade: Quantidade comprada (coluna "QTDE"). Converta para número decimal. Cuidado: não confunda a quantidade com códigos de barras, NCM ou CFOP!
   - valorUnitario: Valor unitário do item (coluna "UNITÁRIO"). Converta para número decimal.
   - valorTotal: Valor total líquido do item (coluna "V. TOTAL"). Converta para número decimal.

Regras de Validação para evitar falhas de OCR comuns:
- O código do produto é tipicamente um número menor de 4 a 6 dígitos (como 10553, 10570, 200859). Não use o EAN ou NCM como código.
- A descrição não deve conter resíduos de colunas vizinhas.
- A quantidade deve ser extraída da coluna QTDE (ex: "6,0000" vira 6, "19,0000" vira 19, "2,0000" vira 2). Não use o valor da coluna NCM ou EAN para a quantidade!
- Retorne os dados em formato JSON estrito correspondente ao esquema fornecido.`,
      };

      const modelsToTry = ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"];
      let response = null;
      let lastError = null;

      for (const modelName of modelsToTry) {
        try {
          console.log(`Tentando extração de dados com o modelo: ${modelName}`);
          const runResponse = await ai.models.generateContent({
            model: modelName,
            contents: [filePart, promptPart],
            config: {
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  chaveAcesso: { type: Type.STRING, description: "Chave de acesso de 44 dígitos da nota" },
                  numeroNota: { type: Type.STRING, description: "Número da NF-e" },
                  serie: { type: Type.STRING, description: "Série da nota" },
                  dataEmissao: { type: Type.STRING, description: "Data de emissão no formato DD/MM/AAAA" },
                  valorTotalProdutos: { type: Type.NUMBER, description: "Valor bruto total dos produtos" },
                  valorTotalNota: { type: Type.NUMBER, description: "Valor líquido total da nota" },
                  pesoBruto: { type: Type.NUMBER, description: "Peso bruto total dos volumes transportados em KG, geralmente localizado na seção de Transportador/Volumes ou Dados Adicionais da NF-e. Retorne como número decimal ou 0 se não encontrar." },
                  nomeEmitente: { type: Type.STRING, description: "Nome/Razão Social do emitente" },
                  cnpjEmitente: { type: Type.STRING, description: "CNPJ do emitente" },
                  itens: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        codigo: { type: Type.STRING, description: "Código do produto" },
                        descricao: { type: Type.STRING, description: "Descrição limpa do produto" },
                        unidade: { type: Type.STRING, description: "Unidade de medida (ex: KG, UN)" },
                        quantidade: { type: Type.NUMBER, description: "Quantidade" },
                        valorUnitario: { type: Type.NUMBER, description: "Valor unitário" },
                        valorTotal: { type: Type.NUMBER, description: "Valor total do item" }
                      },
                      required: ["codigo", "descricao", "unidade", "quantidade", "valorUnitario", "valorTotal"]
                    },
                    description: "Lista de itens/produtos constantes na nota"
                  }
                },
                required: ["numeroNota", "dataEmissao", "valorTotalProdutos", "valorTotalNota", "nomeEmitente", "itens"]
              }
            }
          });

          if (runResponse && runResponse.text) {
            console.log(`Sucesso na extração de dados com o modelo: ${modelName}`);
            response = runResponse;
            break;
          }
        } catch (err: any) {
          console.warn(`Falha na extração com o modelo ${modelName}:`, err.message || err);
          lastError = err;
        }
      }

      if (!response || !response.text) {
        throw lastError || new Error("Nenhum dos modelos do Gemini pôde processar o documento fiscal no momento.");
      }

      const textResult = response.text;
      if (!textResult) {
        throw new Error("Resposta de extração vazia do Gemini.");
      }

      const parsed = JSON.parse(textResult.trim());
      res.json(parsed);
    } catch (error: any) {
      console.error("Erro no processamento da nota fiscal:", error);
      res.status(500).json({ error: error.message || "Erro interno na extração dos dados da nota fiscal." });
    }
  });

  const INVOICES_FILE = path.join(process.cwd(), "invoices-db.json");

  // Helper to read invoices
  function readInvoices(): any[] {
    try {
      if (fs.existsSync(INVOICES_FILE)) {
        const data = fs.readFileSync(INVOICES_FILE, "utf-8");
        return JSON.parse(data);
      } else {
        // Seed default invoice if database does not exist
        const defaultInvoice = {
          id: 'zona_sul_456837',
          fileName: 'danfe_zona_sul_456837.png',
          chaveAcesso: '3326.0633.3812.8600.1980.5505.5000.4568.3719.7769.6595',
          numeroNota: '456.837',
          serie: '55',
          dataEmissao: '03/06/2026',
          valorTotalProdutos: 403.63,
          valorTotalNota: 403.63,
          pesoBruto: 88.264,
          nomeEmitente: 'SUPERMERCADO ZONA SUL SA F07',
          cnpjEmitente: '33.381.286/0019-80',
          status: 'processed',
          extractedAt: new Date().toLocaleString('pt-BR'),
          itens: [
            { id: '1', codigo: '10553', descricao: 'BERINJELA KG', unidade: 'KG', quantidade: 6.0, valorUnitario: 6.437, valorTotal: 38.62 },
            { id: '2', codigo: '10570', descricao: 'CENOURA KG', unidade: 'KG', quantidade: 7.0, valorUnitario: 7.191, valorTotal: 50.34 },
            { id: '3', codigo: '10774', descricao: 'MARACUJA KG', unidade: 'KG', quantidade: 3.0, valorUnitario: 7.353, valorTotal: 22.06 },
            { id: '4', codigo: '36501', descricao: 'MANGA PALMER KG', unidade: 'KG', quantidade: 6.0, valorUnitario: 6.425, valorTotal: 38.55 },
            { id: '5', codigo: '37672', descricao: 'PEPINO JAPONES KG', unidade: 'KG', quantidade: 4.0, valorUnitario: 6.370, valorTotal: 25.48 },
            { id: '6', codigo: '200840', descricao: 'AGRIAO UN', unidade: 'UN', quantidade: 19.0, valorUnitario: 0.791, valorTotal: 15.03 },
            { id: '7', codigo: '200859', descricao: 'ALFACE AMERICANA UN', unidade: 'UN', quantidade: 35.0, valorUnitario: 2.095, valorTotal: 73.33 },
            { id: '8', codigo: '200867', descricao: 'ALFACE LISA UN', unidade: 'UN', quantidade: 8.0, valorUnitario: 0.853, valorTotal: 6.82 },
            { id: '9', codigo: '200875', descricao: 'ALFACE CRESPA UN', unidade: 'UN', quantidade: 10.0, valorUnitario: 0.806, valorTotal: 8.06 },
            { id: '10', codigo: '200883', descricao: 'ALFACE CRESPA ROXA UN', unidade: 'UN', quantidade: 10.0, valorUnitario: 1.139, valorTotal: 11.39 },
            { id: '11', codigo: '200891', descricao: 'BERTALHA UN', unidade: 'UN', quantidade: 2.0, valorUnitario: 1.000, valorTotal: 2.00 },
            { id: '12', codigo: '200905', descricao: 'BROCOLIS RAMOSO UN', unidade: 'UN', quantidade: 10.0, valorUnitario: 2.301, valorTotal: 23.01 },
            { id: '13', codigo: '200913', descricao: 'CEBOLINHA UN', unidade: 'UN', quantidade: 2.0, valorUnitario: 0.760, valorTotal: 1.52 },
            { id: '14', codigo: '200921', descricao: 'CHICORIA UN', unidade: 'UN', quantidade: 11.0, valorUnitario: 0.851, valorTotal: 9.36 },
            { id: '15', codigo: '201006', descricao: 'RUCULA UN', unidade: 'UN', quantidade: 6.0, valorUnitario: 1.102, valorTotal: 6.61 },
            { id: '16', codigo: '201049', descricao: 'CHEIRO VERDE UN', unidade: 'UN', quantidade: 17.0, valorUnitario: 0.818, valorTotal: 13.91 }
          ]
        };
        fs.writeFileSync(INVOICES_FILE, JSON.stringify([defaultInvoice], null, 2), "utf-8");
        return [defaultInvoice];
      }
    } catch (error) {
      console.error("Erro ao ler banco de dados de notas:", error);
    }
    return [];
  }

  // Helper to write invoices
  function writeInvoices(invoices: any[]) {
    try {
      fs.writeFileSync(INVOICES_FILE, JSON.stringify(invoices, null, 2), "utf-8");
    } catch (error) {
      console.error("Erro ao salvar no banco de dados de notas:", error);
    }
  }

  // Endpoint to get all invoices
  app.get("/api/invoices", (req, res) => {
    const invoices = readInvoices();
    res.json(invoices);
  });

  // Endpoint to save or replace the entire list
  app.post("/api/invoices", (req, res) => {
    const { invoices } = req.body;
    if (Array.isArray(invoices)) {
      writeInvoices(invoices);
      return res.json({ success: true });
    }
    res.status(400).json({ error: "Formato de dados inválido." });
  });

  // Endpoint to append a single invoice safely (ideal for points of collection)
  app.post("/api/add-invoice", (req, res) => {
    console.log("[API] Recebida nova nota fiscal para inserção central:");
    const { invoice } = req.body;
    if (!invoice) {
      console.error("[API] Erro: corpo da requisição não contém 'invoice'.");
      return res.status(400).json({ error: "Nota fiscal ausente." });
    }
    
    console.log(`[API] Detalhes da Nota: Emitente="${invoice.nomeEmitente}", Nº="${invoice.numeroNota}", ChaveAcesso="${invoice.chaveAcesso}"`);
    const invoices = readInvoices();
    
    // Check if invoice already exists to avoid duplicates
    const exists = invoices.some((inv: any) => 
      inv.id === invoice.id || 
      (inv.chaveAcesso && inv.chaveAcesso === invoice.chaveAcesso && invoice.chaveAcesso !== '')
    );
    
    if (!exists) {
      console.log(`[API] Salvando nova nota fiscal no banco: ${invoice.id}`);
      invoices.unshift(invoice); // Add to the top
      writeInvoices(invoices);
      console.log(`[API] Nota gravada com sucesso. Total no banco: ${invoices.length}`);
    } else {
      console.log(`[API] Alerta: Nota fiscal já cadastrada (ID ou Chave de Acesso duplicada). Ignorando para evitar duplicidade.`);
    }
    res.json({ success: true });
  });

  // Serve static assets or mount Vite dev server
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Servidor rodando na porta ${PORT}`);
  });
}

startServer();
