import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;
  const DB_FILE = path.join(process.cwd(), "oficina_db.json");

  // Allow large JSON payloads because of photos in base64
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // CORS and Cache Control Headers for real-time multi-device sync
  app.use("/api", (req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // Helper to read database
  const readDb = () => {
    if (!fs.existsSync(DB_FILE)) {
      return null;
    }
    try {
      const content = fs.readFileSync(DB_FILE, "utf-8");
      const parsed = JSON.parse(content);
      if (parsed && Array.isArray(parsed.receivers)) {
        parsed.receivers = Array.from(new Set(
          parsed.receivers
            .filter((r: any) => typeof r === 'string' && r.trim().length > 0)
            .map((r: string) => r.trim())
        ));
        if (parsed.receivers.length === 0) {
          parsed.receivers = ['Atendimento Balcão', 'JOÃO CLAUDIO'];
        }
      }
      return parsed;
    } catch (err) {
      console.error("Error reading db file:", err);
      return null;
    }
  };

  // Helper to write database
  const writeDb = (data: any) => {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
      return true;
    } catch (err) {
      console.error("Error writing db file:", err);
      return false;
    }
  };

  // Helper to merge two collections of items by ID safely without data loss or status regression
  const mergeCollections = (serverList: any[] = [], clientList: any[] = [], collectionKey?: string) => {
    const map = new Map<string, any>();
    
    // Fill with server items
    if (Array.isArray(serverList)) {
      serverList.forEach(item => {
        if (item && item.id) {
          map.set(item.id, item);
        }
      });
    }

    // Merge with client items
    if (Array.isArray(clientList)) {
      clientList.forEach(item => {
        if (item && item.id) {
          const existing = map.get(item.id);
          if (!existing) {
            map.set(item.id, { ...item, updatedAt: item.updatedAt || new Date().toISOString() });
          } else {
            // SPECIAL SAFEGUARD FOR SERVICE ORDERS:
            // A completed or delivered OS must NEVER be silently regressed back to PENDING by a stale client!
            if (collectionKey === 'orders') {
              const isExistingCompleted = existing.status === 'COMPLETED' || existing.isDelivered;
              const isIncomingPending = item.status === 'PENDING';
              
              if (isExistingCompleted && isIncomingPending) {
                // Stale client still thinks this OS is PENDING - reject downgrade!
                return;
              }
            }

            const existingTime = existing.updatedAt || existing.createdAt || '';
            const incomingTime = item.updatedAt || item.createdAt || '';
            
            const existingMillis = existingTime ? new Date(existingTime).getTime() : 0;
            const incomingMillis = incomingTime ? new Date(incomingTime).getTime() : 0;

            // If server has strictly newer updatedAt, PRESERVE server data and reject stale client overwrite
            if (existingMillis > 0 && incomingMillis > 0 && incomingMillis < existingMillis) {
              // Existing is newer - do not overwrite
              return;
            }

            // Otherwise, accept the update from the active client
            map.set(item.id, { 
              ...existing, 
              ...item, 
              updatedAt: item.updatedAt || new Date().toISOString() 
            });
          }
        }
      });
    }

    return Array.from(map.values());
  };

  // Helper to merge string arrays (like activities, receivers)
  const mergeStringArrays = (serverArr: string[] = [], clientArr: string[] = []) => {
    const set = new Set<string>();
    if (Array.isArray(serverArr)) serverArr.forEach(s => s && set.add(s.trim()));
    if (Array.isArray(clientArr)) clientArr.forEach(s => s && set.add(s.trim()));
    return Array.from(set);
  };

  // API Route - Get database status and content
  app.get("/api/sync", (req, res) => {
    const db = readDb();
    if (!db) {
      return res.json({ 
        initialized: false, 
        data: null, 
        timestamp: new Date().toISOString(),
        message: "Banco de dados ainda não inicializado." 
      });
    }

    const stats = {
      clients: Array.isArray(db.clients) ? db.clients.length : 0,
      equipments: Array.isArray(db.equipments) ? db.equipments.length : 0,
      orders: Array.isArray(db.orders) ? db.orders.length : 0,
      history: Array.isArray(db.history) ? db.history.length : 0,
      transactions: Array.isArray(db.transactions) ? db.transactions.length : 0,
      inventory: Array.isArray(db.inventory) ? db.inventory.length : 0,
      catalogs: Array.isArray(db.catalogs) ? db.catalogs.length : 0,
    };

    return res.json({ 
      initialized: true, 
      data: db, 
      stats,
      timestamp: new Date().toISOString() 
    });
  });

  // API Route - Push and smart-merge data from any device or account
  app.post("/api/sync", (req, res) => {
    const clientData = req.body || {};
    const mode = clientData.mode || "merge"; // "merge" | "replace"

    const serverDb = readDb() || {
      clients: [],
      equipments: [],
      orders: [],
      history: [],
      transactions: [],
      diagnostics: [],
      services: [],
      technicians: [],
      inventory: [],
      quotes: [],
      postMaintenance: [],
      catalogs: [],
      clientActivities: [],
      receivers: []
    };

    const objectCollectionKeys = [
      "clients",
      "equipments",
      "orders",
      "history",
      "transactions",
      "diagnostics",
      "services",
      "technicians",
      "inventory",
      "quotes",
      "postMaintenance",
      "catalogs"
    ];

    const mergedDb: any = { ...serverDb };

    if (mode === "replace" || mode === "force_replace") {
      // Direct replace for explicit single-item deletions or full restore
      objectCollectionKeys.forEach((key) => {
        if (Array.isArray(clientData[key])) {
          mergedDb[key] = clientData[key];
        }
      });
      if (Array.isArray(clientData.clientActivities)) mergedDb.clientActivities = clientData.clientActivities;
      if (Array.isArray(clientData.receivers)) {
        const cleanReceivers = Array.from(new Set(
          clientData.receivers
            .filter((r: any) => typeof r === 'string' && r.trim().length > 0)
            .map((r: string) => r.trim())
        ));
        mergedDb.receivers = cleanReceivers.length > 0 ? cleanReceivers : ['Atendimento Balcão', 'JOÃO CLAUDIO'];
      }
    } else {
      // Safe merge (protects against data loss when a new device connects with empty or partial list)
      objectCollectionKeys.forEach((key) => {
        const clientList = clientData[key];
        const serverList = serverDb[key] || [];

        if (Array.isArray(clientList) && clientList.length > 0) {
          mergedDb[key] = mergeCollections(serverList, clientList, key);
        } else {
          // If incoming is empty or not provided, PRESERVE server data!
          mergedDb[key] = serverList;
        }
      });

      // String lists
      if (Array.isArray(clientData.clientActivities) && clientData.clientActivities.length > 0) {
        mergedDb.clientActivities = clientData.clientActivities;
      }
      if (Array.isArray(clientData.receivers) && clientData.receivers.length > 0) {
        const cleanReceivers = Array.from(new Set(
          clientData.receivers
            .filter((r: any) => typeof r === 'string' && r.trim().length > 0)
            .map((r: string) => r.trim())
        ));
        mergedDb.receivers = cleanReceivers.length > 0 ? cleanReceivers : ['Atendimento Balcão', 'JOÃO CLAUDIO'];
      }
    }

    mergedDb.lastUpdated = new Date().toISOString();

    // Save back to file
    const success = writeDb(mergedDb);

    if (success) {
      res.json({ 
        success: true, 
        message: "Sincronização em nuvem realizada com sucesso!", 
        data: mergedDb,
        timestamp: mergedDb.lastUpdated
      });
    } else {
      res.status(500).json({ success: false, message: "Erro ao salvar os dados no servidor central." });
    }
  });

  // Dedicated routes for receivers to guarantee immediate persistence and fast lookup
  app.get("/api/receivers", (req, res) => {
    const db = readDb();
    const list = (db && Array.isArray(db.receivers) && db.receivers.length > 0)
      ? db.receivers
      : ['Atendimento Balcão', 'JOÃO CLAUDIO'];
    res.json({ success: true, receivers: list });
  });

  app.post("/api/receivers", (req, res) => {
    const { receivers } = req.body;
    if (!Array.isArray(receivers)) {
      return res.status(400).json({ success: false, message: "Lista de atendentes inválida." });
    }
    const cleanReceivers = Array.from(new Set(
      receivers
        .filter((r: any) => typeof r === 'string' && r.trim().length > 0)
        .map((r: string) => r.trim())
    ));
    const finalList = cleanReceivers.length > 0 ? cleanReceivers : ['Atendimento Balcão', 'JOÃO CLAUDIO'];

    const currentDb = readDb() || {
      clients: [], equipments: [], orders: [], history: [], transactions: [],
      diagnostics: [], services: [], technicians: [], inventory: [], quotes: [],
      postMaintenance: [], catalogs: [], clientActivities: [], receivers: []
    };
    currentDb.receivers = finalList;
    currentDb.lastUpdated = new Date().toISOString();
    writeDb(currentDb);

    console.log(`[Server] Receivers updated: ${finalList.length} registered:`, finalList);
    res.json({ success: true, receivers: finalList });
  });

  // API Route - Direct Backup Download
  app.get("/api/sync/backup", (req, res) => {
    const db = readDb();
    if (!db) {
      return res.status(404).json({ error: "Nenhum banco de dados para exportar." });
    }
    const filename = `oficina_backup_${new Date().toISOString().slice(0, 10)}.json`;
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Content-Type", "application/json");
    res.send(JSON.stringify(db, null, 2));
  });

  // API Route - Direct Backup Restore
  app.post("/api/sync/restore", (req, res) => {
    const backupData = req.body;
    if (!backupData || typeof backupData !== "object") {
      return res.status(400).json({ success: false, message: "Arquivo de backup inválido." });
    }
    const success = writeDb(backupData);
    if (success) {
      res.json({ success: true, message: "Backup restaurado com sucesso!", data: backupData });
    } else {
      res.status(500).json({ success: false, message: "Erro ao gravar restauração no servidor." });
    }
  });

  // API Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // Integrate Vite server middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
