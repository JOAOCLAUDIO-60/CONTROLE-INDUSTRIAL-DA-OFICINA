import React, { useState, useEffect } from 'react';
import { Client, Equipment, ServiceOrder, OSStatus, TechnicalDiagnostic, PlannedService, FinancialTransaction, Technician } from '../types';
import { 
  Plus, Search, Edit2, Trash2, FileText, CheckCircle2, Clock, Play, X, AlertTriangle, 
  User, UserPlus, DollarSign, Calendar, ListFilter, LayoutGrid, CheckSquare, ChevronRight, HelpCircle,
  Camera, Upload, Shield, Send, Mail, MessageSquare, QrCode, Key, Share2, ClipboardList, Briefcase,
  ShieldAlert, ShieldCheck, Copy, FileWarning, Phone, AtSign, Wrench, Save, Check
} from 'lucide-react';

interface ServiceOrderManagerProps {
  orders: ServiceOrder[];
  clients: Client[];
  equipments: Equipment[];
  diagnostics?: TechnicalDiagnostic[];
  services?: PlannedService[];
  technicians?: Technician[];
  onAddOrder: (order: Omit<ServiceOrder, 'id' | 'osNumber' | 'createdAt'>) => void;
  onEditOrder: (order: ServiceOrder) => void;
  onDeleteOrder: (id: string) => void;
  onAutoAddHistoryFromOS: (order: ServiceOrder) => void;
  onAddTransaction?: (transactionData: Omit<FinancialTransaction, 'id' | 'createdAt'>) => void;
  receivers?: string[];
  onSaveReceivers?: (receivers: string[]) => void;
}

const JCFLogoIcon = () => (
  <svg 
    viewBox="0 0 390 340" 
    className="w-9 h-9 text-cyan-400"
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    {/* Gear partial outer ring */}
    <path 
      d="M 113.1 102.6 A 100 100 0 0 1 252.4 241.9" 
      className="stroke-cyan-500/10" 
      strokeWidth="24" 
      strokeLinecap="square"
    />
    <path 
      d="M 113.1 102.6 A 100 100 0 0 1 252.4 241.9" 
      className="stroke-cyan-400" 
      strokeWidth="12" 
      strokeLinecap="square"
    />
    
    {/* Gear teeth */}
    {[-135, -105, -75, -45, -15, 15, 45].map((angle, idx) => (
      <rect 
        key={idx}
        x="184" 
        y="42" 
        width="22" 
        height="18" 
        rx="1"
        transform={`rotate(${angle}, 195, 160)`} 
        fill="currentColor" 
      />
    ))}

    {/* J C & F Letters */}
    <g fill="currentColor" fontFamily="Georgia, Cambria, 'Times New Roman', Times, serif" fontWeight="bold">
      <text x="145" y="170" fontSize="100" textAnchor="middle">J</text>
      <text x="210" y="170" fontSize="100" textAnchor="middle">C</text>
      <text x="175" y="235" fontSize="62" textAnchor="middle">&amp;</text>
      <text x="215" y="240" fontSize="100" textAnchor="middle">F</text>
    </g>

    {/* Subtitle banner */}
    <text 
      x="195" 
      y="295" 
      fill="currentColor" 
      fontFamily="Georgia, Cambria, 'Times New Roman', Times, serif" 
      fontWeight="bold" 
      fontSize="11" 
      letterSpacing="2" 
      textAnchor="middle"
    >
      MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA
    </text>
  </svg>
);

const getWarrantyStatus = (order: ServiceOrder) => {
  if (order.warrantyDays === undefined) return { label: 'Sem garantia', active: false, dateStr: '', daysLeft: 0 };
  const endStr = order.endDate || order.startDate;
  const endDate = new Date(endStr);
  const warrantyEndDate = new Date(endDate.getTime() + order.warrantyDays * 24 * 60 * 60 * 1000);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  warrantyEndDate.setHours(0, 0, 0, 0);
  
  const active = warrantyEndDate >= today;
  const formattedDate = warrantyEndDate.toLocaleDateString('pt-BR');
  
  return {
    label: active ? `Garantia Ativa` : `Garantia Expirada`,
    active,
    dateStr: formattedDate,
    daysLeft: Math.ceil((warrantyEndDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
  };
};

const getStayStatus = (order: ServiceOrder) => {
  if (!order.startDate) return { days: 0, label: 'Sem data de entrada', detail: '', isDelivered: false, color: 'text-slate-500 bg-slate-950/20 border-slate-800' };
  
  // Use startDate (format YYYY-MM-DD or ISO string)
  const start = new Date(order.startDate + 'T00:00:00');
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  let end = today;
  if (order.isDelivered && order.deliveryDate) {
    end = new Date(order.deliveryDate + 'T00:00:00');
  }
  
  const diffTime = end.getTime() - start.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // inclusive stay
  const days = Math.max(1, diffDays);

  if (order.isDelivered) {
    const formattedDelivery = order.deliveryDate 
      ? new Date(order.deliveryDate + 'T00:00:00').toLocaleDateString('pt-BR')
      : 'N/A';
    return {
      days,
      label: `Retirado (${days} ${days === 1 ? 'dia' : 'dias'} de estadia)`,
      detail: `Entregue em ${formattedDelivery}`,
      isDelivered: true,
      color: 'text-emerald-800 bg-emerald-50 border-emerald-300 font-bold'
    };
  } else {
    let color = 'text-blue-800 bg-blue-50 border-blue-200 font-bold';
    if (days > 15) {
      color = 'text-rose-800 bg-rose-50 border-rose-300 font-black animate-pulse';
    } else if (days > 7) {
      color = 'text-amber-900 bg-amber-50 border-amber-300 font-bold';
    }
    return {
      days,
      label: `${days} ${days === 1 ? 'dia' : 'dias'} na empresa`,
      detail: 'Equipamento sob nossa custódia',
      isDelivered: false,
      color
    };
  }
};

export default function ServiceOrderManager({
  orders,
  clients,
  equipments,
  diagnostics = [],
  services = [],
  technicians = [],
  receivers,
  onSaveReceivers,
  onAddOrder,
  onEditOrder,
  onDeleteOrder,
  onAutoAddHistoryFromOS,
  onAddTransaction,
}: ServiceOrderManagerProps) {
  const [viewMode, setViewMode] = useState<'KANBAN' | 'LIST'>('LIST');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<ServiceOrder | null>(null);

  // Deletion confirmation state
  const [deleteOrderConfirmation, setDeleteOrderConfirmation] = useState<{ id: string; osNumber: string } | null>(null);

  // Duplicate OS Protection Warning State
  const [duplicateWarning, setDuplicateWarning] = useState<{ existingOrders: ServiceOrder[]; pendingNewOrder: any } | null>(null);

  // Completion confirmation (warranty selection on quick closure)
  const [completionConfirmation, setCompletionConfirmation] = useState<ServiceOrder | null>(null);

  // Form States
  const [clientId, setClientId] = useState('');
  const [equipmentId, setEquipmentId] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<OSStatus>('PENDING');
  const [priority, setPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('MEDIUM');
  const [technician, setTechnician] = useState('');
  const [receiverName, setReceiverName] = useState('');

  // Gerenciamento de Recebedores / Atendentes com Servidor Central
  const DEFAULT_RECEIVERS = ['Atendimento Balcão', 'JOÃO CLAUDIO'];
  const PURGE_MOCK_RECEIVERS = ['Carlos Silva', 'João Carlos', 'Maria Oliveira', 'Roberto Souza'];

  const cleanReceivers = (list: any[]): string[] => {
    if (!Array.isArray(list)) return DEFAULT_RECEIVERS;
    const cleaned = list
      .filter((r) => typeof r === 'string' && r.trim().length > 0)
      .map((r) => r.trim())
      .filter((r) => !PURGE_MOCK_RECEIVERS.includes(r));
    return cleaned.length > 0 ? Array.from(new Set(cleaned)) : DEFAULT_RECEIVERS;
  };

  const [receiversList, setReceiversList] = useState<string[]>(() => {
    if (receivers && receivers.length > 0) return cleanReceivers(receivers);
    try {
      const saved = localStorage.getItem('oficina_receivers');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return cleanReceivers(parsed);
      }
    } catch (e) {
      console.error('Erro ao ler oficina_receivers:', e);
    }
    return DEFAULT_RECEIVERS;
  });

  const activeReceivers = cleanReceivers(receivers && receivers.length > 0 ? receivers : receiversList);

  useEffect(() => {
    if (receivers && receivers.length > 0) {
      const cleaned = cleanReceivers(receivers);
      setReceiversList(cleaned);
      if (!receiverName || !cleaned.includes(receiverName)) {
        setReceiverName(cleaned[0] || 'Atendimento Balcão');
      }
    }
  }, [receivers]);

  const [showReceiversModal, setShowReceiversModal] = useState(false);
  const [newReceiverInput, setNewReceiverInput] = useState('');

  const handleAddReceiver = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const currentList = activeReceivers;
    if (currentList.some(r => r.toLowerCase() === trimmed.toLowerCase())) return;
    const updated = [...currentList, trimmed];
    setReceiversList(updated);
    localStorage.setItem('oficina_receivers', JSON.stringify(updated));
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    setReceiverName(trimmed);
    setNewReceiverInput('');
  };

  const handleDeleteReceiver = (nameToDelete: string) => {
    const currentList = activeReceivers;
    if (currentList.length <= 1) return;
    const updated = currentList.filter(r => r !== nameToDelete);
    setReceiversList(updated);
    localStorage.setItem('oficina_receivers', JSON.stringify(updated));
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    if (receiverName === nameToDelete) {
      setReceiverName(updated[0] || '');
    }
  };
  const [estimatedCost, setEstimatedCost] = useState<number>(0);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [formError, setFormError] = useState('');
  const [equipmentPhoto, setEquipmentPhoto] = useState<string>('');
  const [warrantyDays, setWarrantyDays] = useState<number>(90);
  const [warrantyNotes, setWarrantyNotes] = useState<string>('');
  const [attendanceType, setAttendanceType] = useState<string>('Oficina Interna / Balcão');

  // Budget, diagnostic, planned services states
  const [budgetStatus, setBudgetStatus] = useState<'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED'>('PENDING_APPROVAL');
  const [diagnostic, setDiagnostic] = useState('');
  const [plannedServices, setPlannedServices] = useState('');

  // Stay tracking and delivery states
  const [isDelivered, setIsDelivered] = useState<boolean>(false);
  const [deliveryDate, setDeliveryDate] = useState<string>('');

  // Sharing state
  const [sharingOrder, setSharingOrder] = useState<ServiceOrder | null>(null);
  const [customShareMessage, setCustomShareMessage] = useState('');
  const [shareRecipientType, setShareRecipientType] = useState<'CLIENT' | 'CUSTOM'>('CLIENT');
  const [shareCustomPhone, setShareCustomPhone] = useState('');
  const [shareCustomEmail, setShareCustomEmail] = useState('');
  const [copyFeedback, setCopyFeedback] = useState(false);
  const [includePix, setIncludePix] = useState(false);
  const [localPixType, setLocalPixType] = useState('CNPJ');
  const [localPixKey, setLocalPixKey] = useState('');
  const [localPixName, setLocalPixName] = useState('');
  const [localPixCity, setLocalPixCity] = useState('São Paulo');
  const [copyPixCodeFeedback, setCopyPixCodeFeedback] = useState(false);

  // Drag & drop state + Lightbox state
  const [isDragging, setIsDragging] = useState(false);
  const [activePhotoUrl, setActivePhotoUrl] = useState<string | null>(null);
  const [viewingReportOrder, setViewingReportOrder] = useState<ServiceOrder | null>(null);

  // Delivery confirmation toast
  const [deliveryToast, setDeliveryToast] = useState<{ message: string; type: 'success' | 'info' } | null>(null);

  const showDeliveryToast = (message: string, type: 'success' | 'info' = 'success') => {
    setDeliveryToast({ message, type });
    setTimeout(() => {
      setDeliveryToast(null);
    }, 6000);
  };

  // Finance integration states
  const [addToFinance, setAddToFinance] = useState(true);
  const [financeStatus, setFinanceStatus] = useState<'PAID' | 'PENDING'>('PAID');
  const [financeCategory, setFinanceCategory] = useState('Mão de Obra');
  const [financeAmount, setFinanceAmount] = useState<number>(0);

  // Sync finance amount with order cost when completionConfirmation is selected
  useEffect(() => {
    if (completionConfirmation) {
      setFinanceAmount(completionConfirmation.estimatedCost || 0);
      setAddToFinance(true);
      setFinanceStatus('PAID');
      setFinanceCategory('Mão de Obra');
    }
  }, [completionConfirmation]);

  // Photo handlers
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        setFormError('A imagem deve ter menos de 3MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setEquipmentPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        setFormError('A imagem deve ter menos de 3MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setEquipmentPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // All equipments in the system are available for selection, sorted alphabetically by name
  const formAvailableEquipments = [...equipments].sort((a, b) =>
    a.name.localeCompare(b.name, 'pt-BR', { sensitivity: 'base' })
  );

  // Set default client and equipment when opening Add Modal
  const openAddModal = () => {
    setEditingOrder(null);
    const initialClient = clients[0]?.id || '';
    setClientId(initialClient);
    
    setEquipmentId(formAvailableEquipments[0]?.id || '');
    
    setTitle('');
    setDescription('');
    setStatus('PENDING');
    setPriority('MEDIUM');
    setTechnician('');
    setReceiverName(activeReceivers[0] || 'Atendimento Balcão');
    setAttendanceType('Oficina Interna / Balcão');
    setEstimatedCost(0);
    setStartDate(new Date().toISOString().split('T')[0]);
    setEndDate('');
    setEquipmentPhoto('');
    setWarrantyDays(90);
    setWarrantyNotes('');
    setBudgetStatus('PENDING_APPROVAL');
    setDiagnostic('');
    setPlannedServices('');
    setIsDelivered(false);
    setDeliveryDate('');
    setFormError('');
    setIsModalOpen(true);
  };

  // Set default equipment if none is selected
  useEffect(() => {
    if (!editingOrder && !equipmentId && formAvailableEquipments.length > 0) {
      setEquipmentId(formAvailableEquipments[0].id);
    }
  }, [formAvailableEquipments, editingOrder, equipmentId]);

  // Sync financial variables inside the form modal when status changes to COMPLETED
  useEffect(() => {
    if (status === 'COMPLETED') {
      setFinanceAmount(Number(estimatedCost) || 0);
      setAddToFinance(true);
      setFinanceStatus('PAID');
      setFinanceCategory('Mão de Obra');
    }
  }, [status, estimatedCost]);

  const openEditModal = (order: ServiceOrder) => {
    setEditingOrder(order);
    setClientId(order.clientId);
    setEquipmentId(order.equipmentId);
    setTitle(order.title);
    setDescription(order.description);
    setStatus(order.status);
    setPriority(order.priority);
    setTechnician(order.technician);
    setReceiverName(order.receiverName || '');
    setAttendanceType(order.attendanceType || 'Oficina Interna / Balcão');
    setEstimatedCost(order.estimatedCost);
    setStartDate(order.startDate);
    setEndDate(order.endDate || '');
    setEquipmentPhoto(order.equipmentPhoto || '');
    setWarrantyDays(order.warrantyDays !== undefined ? order.warrantyDays : 90);
    setWarrantyNotes(order.warrantyNotes || '');
    setBudgetStatus(order.budgetStatus || 'PENDING_APPROVAL');
    setDiagnostic(order.diagnostic || '');
    setPlannedServices(order.plannedServices || '');
    setIsDelivered(!!order.isDelivered);
    setDeliveryDate(order.deliveryDate || '');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId || !equipmentId || !title.trim() || !description.trim() || !technician.trim() || !startDate) {
      setFormError('Todos os campos obrigatórios devem ser preenchidos.');
      return;
    }

    if (editingOrder) {
      const updatedOrder: ServiceOrder = {
        ...editingOrder,
        clientId,
        equipmentId,
        title,
        description,
        status,
        priority,
        technician,
        receiverName: receiverName.trim() || undefined,
        attendanceType: attendanceType.trim() || 'Oficina Interna / Balcão',
        estimatedCost: Number(estimatedCost),
        startDate,
        endDate: status === 'COMPLETED' ? (endDate || new Date().toISOString().split('T')[0]) : (endDate || undefined),
        equipmentPhoto,
        warrantyDays: status === 'COMPLETED' ? Number(warrantyDays) : undefined,
        warrantyNotes: status === 'COMPLETED' ? warrantyNotes.trim() : undefined,
        budgetStatus,
        diagnostic: diagnostic.trim() ? diagnostic.trim() : undefined,
        plannedServices: plannedServices.trim() ? plannedServices.trim() : undefined,
        isDelivered,
        deliveryDate: isDelivered ? (deliveryDate || new Date().toISOString().split('T')[0]) : undefined,
      };

      onEditOrder(updatedOrder);

      // Trigger automatic equipment maintenance history registration when order transitions to COMPLETED
      if (status === 'COMPLETED' && editingOrder.status !== 'COMPLETED') {
        onAutoAddHistoryFromOS(updatedOrder);
        setViewingReportOrder(updatedOrder);

        if (addToFinance && onAddTransaction) {
          onAddTransaction({
            type: 'RECEIVABLE',
            description: `Serviço Prestado - ${updatedOrder.osNumber} (${updatedOrder.title})`,
            amount: Number(financeAmount),
            dueDate: new Date().toISOString().split('T')[0],
            paymentDate: financeStatus === 'PAID' ? new Date().toISOString().split('T')[0] : undefined,
            category: financeCategory,
            status: financeStatus,
            notes: `Transferência automática ao finalizar a ${updatedOrder.osNumber} via formulário.`,
            serviceOrderId: updatedOrder.id,
          });
        }
      }
    } else {
      const newOrderPayload = {
        clientId,
        equipmentId,
        title,
        description,
        status,
        priority,
        technician,
        receiverName: receiverName.trim() || undefined,
        attendanceType: attendanceType.trim() || 'Oficina Interna / Balcão',
        estimatedCost: Number(estimatedCost),
        startDate,
        endDate: status === 'COMPLETED' ? (endDate || new Date().toISOString().split('T')[0]) : undefined,
        equipmentPhoto,
        warrantyDays: status === 'COMPLETED' ? Number(warrantyDays) : undefined,
        warrantyNotes: status === 'COMPLETED' ? warrantyNotes.trim() : undefined,
        budgetStatus,
        diagnostic: diagnostic.trim() ? diagnostic.trim() : undefined,
        plannedServices: plannedServices.trim() ? plannedServices.trim() : undefined,
        isDelivered,
        deliveryDate: isDelivered ? (deliveryDate || new Date().toISOString().split('T')[0]) : undefined,
      };
      
      // DISPOSITIVO ANTIDUPLICIDADE CHECK
      const existingDuplicates = orders.filter(o => 
        o.clientId === clientId && 
        o.equipmentId === equipmentId && 
        o.status !== 'CANCELLED' &&
        !o.isDelivered
      );

      if (existingDuplicates.length > 0) {
        setDuplicateWarning({
          existingOrders: existingDuplicates,
          pendingNewOrder: newOrderPayload
        });
        return;
      }

      onAddOrder(newOrderPayload);
    }
    setIsModalOpen(false);
  };

  const handleConfirmDuplicateInManager = () => {
    if (!duplicateWarning) return;
    const finalOrder = {
      ...duplicateWarning.pendingNewOrder,
      title: `${duplicateWarning.pendingNewOrder.title} (2º Equipamento)`,
      description: `${duplicateWarning.pendingNewOrder.description}\n\n[DISPOSITIVO ANTIDUPLICIDADE: OS Autorizada pelo Usuário - Cliente trouxe 2º equipamento idêntico]`,
      isDuplicateAuthorized: true,
      duplicateNote: 'Autorizado pelo usuário: 2º equipamento idêntico do cliente'
    };
    onAddOrder(finalOrder);
    setDuplicateWarning(null);
    setIsModalOpen(false);
  };

  const handleUpdateStatus = (order: ServiceOrder, nextStatus: OSStatus) => {
    if (nextStatus === 'COMPLETED') {
      setWarrantyDays(90);
      setWarrantyNotes('');
      setCompletionConfirmation(order);
      return;
    }
    const updatedOrder: ServiceOrder = {
      ...order,
      status: nextStatus,
    };
    onEditOrder(updatedOrder);
  };

  const handleConfirmCompletion = () => {
    if (!completionConfirmation) return;
    const finalizedOrder: ServiceOrder = {
      ...completionConfirmation,
      status: 'COMPLETED',
      isDelivered: true,
      endDate: new Date().toISOString().split('T')[0],
      deliveryDate: new Date().toISOString().split('T')[0],
      warrantyDays: Number(warrantyDays),
      warrantyNotes: warrantyNotes.trim() ? warrantyNotes.trim() : undefined,
      updatedAt: new Date().toISOString(),
    };
    onEditOrder(finalizedOrder);
    onAutoAddHistoryFromOS(finalizedOrder);

    // Finance integration
    if (addToFinance && onAddTransaction) {
      onAddTransaction({
        type: 'RECEIVABLE',
        description: `Serviço Prestado - ${finalizedOrder.osNumber} (${finalizedOrder.title})`,
        amount: Number(financeAmount),
        dueDate: new Date().toISOString().split('T')[0],
        paymentDate: financeStatus === 'PAID' ? new Date().toISOString().split('T')[0] : undefined,
        category: financeCategory,
        status: financeStatus,
        notes: `Transferência automática ao finalizar a ${finalizedOrder.osNumber} via Kanban.`,
        serviceOrderId: finalizedOrder.id,
      });
    }

    setCompletionConfirmation(null);
    setViewingReportOrder(finalizedOrder);
  };

  const generateMockPixCode = (key: string, name: string, city: string, amount: number) => {
    const cleanKey = key.replace(/[^a-zA-Z0-9@.-]/g, '');
    const cleanName = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().slice(0, 25);
    const cleanCity = city.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().slice(0, 15);
    const formattedAmount = amount.toFixed(2);
    return `00020101021226580014br.gov.bcb.pix01${cleanKey.length.toString().padStart(2, '0')}${cleanKey}52040000530398654${formattedAmount.length.toString().padStart(2, '0')}${formattedAmount}5802BR59${cleanName.length.toString().padStart(2, '0')}${cleanName}60${cleanCity.length.toString().padStart(2, '0')}${cleanCity}62070503***6304D1B2`;
  };

  const handleTogglePixInOSShare = (checked: boolean, customKey?: string, customType?: string, customName?: string, customCity?: string, orderObj?: ServiceOrder) => {
    const activeOrder = orderObj || sharingOrder;
    if (!activeOrder) return;
    setIncludePix(checked);
    
    const client = clients.find((c) => c.id === activeOrder.clientId);
    const equipment = equipments.find((e) => e.id === activeOrder.equipmentId);

    const clientName = client ? client.name : 'Cliente';
    const equipName = equipment ? `${equipment.name} (${equipment.model})` : 'Equipamento';
    const diagnosticText = activeOrder.diagnostic || 'Serviço realizado';
    const plannedText = activeOrder.plannedServices || 'Manutenção executada';
    const costText = activeOrder.estimatedCost ? `R$ ${activeOrder.estimatedCost.toFixed(2)}` : 'R$ 0,00';

    const k = customKey !== undefined ? customKey : localPixKey;
    const t = customType !== undefined ? customType : localPixType;
    const n = customName !== undefined ? customName : localPixName;

    let pixInfo = '';
    if (checked && k) {
      pixInfo = `\n\n🔑 *DADOS PARA PAGAMENTO VIA PIX:* \nBeneficiário: ${n || 'Oficina'}\nChave PIX (${t}): ${k}`;
    }

    let message = '';
    if (activeOrder.status === 'COMPLETED') {
      message = `Olá, *${clientName}*! 🛠️\n\n` +
        `Gostaríamos de informar que a manutenção do seu equipamento *${equipName}* foi concluída com sucesso! 🎉\n\n` +
        `📝 *SERVIÇO EXECUTADO:*\n${plannedText}\n\n` +
        `📅 *ORDEM DE SERVIÇO:* ${activeOrder.osNumber}\n` +
        `💵 *VALOR TOTAL:* ${costText}` +
        `${pixInfo}\n\n` +
        `O equipamento já está pronto para retirada. Agradecemos a preferência!`;
    } else {
      message = `Olá, *${clientName}*! 🛠️\n\n` +
        `Aqui está o diagnóstico técnico e orçamento para a Ordem de Serviço *${activeOrder.osNumber}* do seu equipamento *${equipName}*.\n\n` +
        `📝 *SITUAÇÃO VERIFICADA (DIAGNÓSTICO):*\n${diagnosticText}\n\n` +
        `⚙️ *O QUE SERÁ EFETUADO (SERVIÇO & PEÇAS):*\n${plannedText}\n\n` +
        `💵 *VALOR DO ORÇAMENTO:* ${costText}` +
        `${pixInfo}\n\n` +
        `⚠️ *CONDIÇÕES GERAIS DE SERVIÇO*\n\n` +
        `1. O orçamento será executado somente após a autorização do cliente.\n` +
        `2. Os equipamentos serão entregues mediante a quitação integral dos serviços, peças e demais despesas relacionadas.\n` +
        `3. A garantia cobre exclusivamente os serviços executados e as peças fornecidas pela JC&F Manutenção, não abrangendo mau uso, quedas, sobrecargas, instalações inadequadas ou intervenções de terceiros.\n` +
        `4. Após a comunicação da conclusão do serviço, o cliente deverá retirar o equipamento em até 90 (noventa) dias.\n` +
        `5. Equipamentos não retirados dentro do prazo de 90 (noventa) dias estarão sujeitos à cobrança de taxa de armazenagem no valor de R$ 0,50 (cinquenta centavos) por dia, por equipamento.\n` +
        `6. Os valores de armazenagem deverão ser pagos juntamente com os demais débitos existentes antes da retirada do equipamento.\n` +
        `7. Ao autorizar o serviço, o cliente declara estar ciente e de acordo com as condições acima.\n\n` +
        `Aguardamos sua aprovação para iniciarmos os serviços de manutenção do equipamento. Obrigado!`;
    }
    setCustomShareMessage(message);
  };

  const handleOpenShareModal = (order: ServiceOrder) => {
    // Load PIX key if available
    const savedPix = localStorage.getItem('oficina_company_pix');
    let pixTypeVal = 'CNPJ';
    let pixKeyVal = '';
    let pixNameVal = '';
    let pixCityVal = 'São Paulo';
    
    if (savedPix) {
      try {
        const parsed = JSON.parse(savedPix);
        pixTypeVal = parsed.type || 'CNPJ';
        pixKeyVal = parsed.key || '';
        pixNameVal = parsed.name || '';
        pixCityVal = parsed.city || 'São Paulo';
      } catch (e) {}
    }

    setLocalPixType(pixTypeVal);
    setLocalPixKey(pixKeyVal);
    setLocalPixName(pixNameVal);
    setLocalPixCity(pixCityVal);

    // Default includePix to true if order status is COMPLETED and we have a key
    const shouldIncludePix = order.status === 'COMPLETED' && !!pixKeyVal;
    setIncludePix(shouldIncludePix);
    setShareRecipientType('CLIENT');
    setShareCustomPhone('');
    setShareCustomEmail('');

    setSharingOrder(order);
    
    // Initial message construction
    const client = clients.find((c) => c.id === order.clientId);
    const equipment = equipments.find((e) => e.id === order.equipmentId);

    const clientName = client ? client.name : 'Cliente';
    const equipName = equipment ? `${equipment.name} (${equipment.model})` : 'Equipamento';
    const diagnosticText = order.diagnostic || 'Serviço realizado';
    const plannedText = order.plannedServices || 'Manutenção executada';
    const costText = order.estimatedCost ? `R$ ${order.estimatedCost.toFixed(2)}` : 'R$ 0,00';

    let pixInfo = '';
    if (shouldIncludePix && pixKeyVal) {
      pixInfo = `\n\n🔑 *DADOS PARA PAGAMENTO VIA PIX:* \nBeneficiário: ${pixNameVal || 'Oficina'}\nChave PIX (${pixTypeVal}): ${pixKeyVal}`;
    }

    let message = '';
    if (order.status === 'COMPLETED') {
      message = `Olá, *${clientName}*! 🛠️\n\n` +
        `Gostaríamos de informar que a manutenção do seu equipamento *${equipName}* foi concluída com sucesso! 🎉\n\n` +
        `📝 *SERVIÇO EXECUTADO:*\n${plannedText}\n\n` +
        `📅 *ORDEM DE SERVIÇO:* ${order.osNumber}\n` +
        `💵 *VALOR TOTAL:* ${costText}` +
        `${pixInfo}\n\n` +
        `O equipamento já está pronto para retirada. Agradecemos a preferência!`;
    } else {
      message = `Olá, *${clientName}*! 🛠️\n\n` +
        `Aqui está o diagnóstico técnico e orçamento para a Ordem de Serviço *${order.osNumber}* do seu equipamento *${equipName}*.\n\n` +
        `📝 *SITUAÇÃO VERIFICADA (DIAGNÓSTICO):*\n${diagnosticText}\n\n` +
        `⚙️ *O QUE SERÁ EFETUADO (SERVIÇO & PEÇAS):*\n${plannedText}\n\n` +
        `💵 *VALOR DO ORÇAMENTO:* ${costText}\n\n` +
        `⚠️ *CONDIÇÕES GERAIS DE SERVIÇO*\n\n` +
        `1. O orçamento será executado somente após a autorização do cliente.\n` +
        `2. Os equipamentos serão entregues mediante a quitação integral dos serviços, peças e demais despesas relacionadas.\n` +
        `3. A garantia cobre exclusivamente os serviços executados e as peças fornecidas pela JC&F Manutenção, não abrangendo mau uso, quedas, sobrecargas, instalações inadequadas ou intervenções de terceiros.\n` +
        `4. Após a comunicação da conclusão do serviço, o cliente deverá retirar o equipamento em até 90 (noventa) dias.\n` +
        `5. Equipamentos não retirados dentro do prazo de 90 (noventa) dias estarão sujeitos à cobrança de taxa de armazenagem no valor de R$ 0,50 (cinquenta centavos) por dia, por equipamento.\n` +
        `6. Os valores de armazenagem deverão ser pagos juntamente com os demais débitos existentes antes da retirada do equipamento.\n` +
        `7. Ao autorizar o serviço, o cliente declara estar ciente e de acordo com as condições acima.\n\n` +
        `Aguardamos sua aprovação para iniciarmos os serviços de manutenção do equipamento. Obrigado!`;
    }
    setCustomShareMessage(message);
  };

  const handleDelete = (id: string, osNumber: string) => {
    setDeleteOrderConfirmation({ id, osNumber });
  };

  // Filter & Sort Logic
  const filteredOrders = orders.filter((order) => {
    const client = clients.find((c) => c.id === order.clientId);
    const equipment = equipments.find((e) => e.id === order.equipmentId);
    
    const clientName = client ? client.name.toLowerCase() : '';
    const equipName = equipment ? equipment.name.toLowerCase() : '';
    const matchesSearch = 
      (order.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (order.osNumber || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (order.technician || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      clientName.includes(searchQuery.toLowerCase()) ||
      equipName.includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || order.status === statusFilter;
    const matchesPriority = priorityFilter === 'ALL' || order.priority === priorityFilter;

    return matchesSearch && matchesStatus && matchesPriority;
  }).sort((a, b) => {
    const dateA = a.startDate || a.createdAt || '';
    const dateB = b.startDate || b.createdAt || '';
    if (dateB !== dateA) {
      return dateB.localeCompare(dateA);
    }
    return b.osNumber.localeCompare(a.osNumber);
  });

  // Kanban Columns configuration
  const columns: { title: string; status: OSStatus; color: string; hoverBg: string; text: string; icon: any }[] = [
    { title: 'Aguardando', status: 'PENDING', color: 'border-slate-200 bg-slate-50/70', hoverBg: 'hover:bg-slate-50', text: 'text-slate-500', icon: Clock },
    { title: 'Em Execução', status: 'IN_PROGRESS', color: 'border-blue-150 bg-blue-50/30', hoverBg: 'hover:bg-blue-50/50', text: 'text-blue-600', icon: Play },
    { title: 'Concluída', status: 'COMPLETED', color: 'border-emerald-150 bg-emerald-50/30', hoverBg: 'hover:bg-emerald-50/50', text: 'text-emerald-600', icon: CheckCircle2 },
    { title: 'Cancelada', status: 'CANCELLED', color: 'border-red-150 bg-red-50/30', hoverBg: 'hover:bg-red-50/50', text: 'text-red-500', icon: X },
  ];

  const getPriorityBadge = (p: 'LOW' | 'MEDIUM' | 'HIGH') => {
    switch (p) {
      case 'HIGH':
        return <span className="px-2 py-0.5 rounded-full bg-red-50 border border-red-100 text-[10px] font-bold text-red-600">ALTA</span>;
      case 'MEDIUM':
        return <span className="px-2 py-0.5 rounded-full bg-amber-50 border border-amber-100 text-[10px] font-bold text-amber-600">MÉDIA</span>;
      case 'LOW':
        return <span className="px-2 py-0.5 rounded-full bg-slate-100 border border-slate-200 text-[10px] font-bold text-slate-600">BAIXA</span>;
    }
  };

  const formatMoney = (v: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);
  };

  return (
    <div className="space-y-6" id="service-order-manager-container">
      
      {/* Delivery Confirmation Toast Notification */}
      {deliveryToast && (
        <div 
          className={`fixed top-5 left-1/2 -translate-x-1/2 z-[100] max-w-lg w-[92vw] sm:w-auto p-4 rounded-2xl border-2 shadow-2xl flex items-center gap-3 transition-all animate-in fade-in slide-in-from-top-4 duration-200 ${
            deliveryToast.type === 'success' 
              ? 'bg-[#064e3b] text-emerald-50 border-emerald-400 shadow-emerald-950/40' 
              : 'bg-[#1e3a8a] text-blue-50 border-blue-400 shadow-blue-950/40'
          }`} 
          id="service-order-delivery-toast"
          role="alert"
        >
          <div className="w-8 h-8 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5 text-emerald-200" />
          </div>
          <div className="flex-1 pr-2">
            <div className="text-xs font-black tracking-tight leading-snug">{deliveryToast.message}</div>
          </div>
          <button 
            type="button" 
            onClick={() => setDeliveryToast(null)} 
            className="p-1 hover:bg-white/20 rounded-lg text-white/80 hover:text-white cursor-pointer transition-colors"
            title="Fechar aviso"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
      
      {/* Royal Blue Cheerful Header Banner like Pos-Manutencao */}
      <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm">
        <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-blue-900">
          <div className="flex items-center gap-3">
            <span className="p-2 bg-white/10 rounded-lg border border-white/20 text-cyan-300 shadow-sm">
              <ClipboardList className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-sm sm:text-base font-black text-white tracking-wide uppercase">
                Controle de Ordens de Serviço (OS)
              </h1>
              <p className="text-xs text-cyan-100">
                Acompanhamento em tempo real, triagem, execução técnica, orçamentos e prazos de entrega
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="border border-white/20 rounded-lg p-0.5 flex bg-white/10">
              <button
                id="btn-view-kanban"
                onClick={() => setViewMode('KANBAN')}
                className={`p-1.5 rounded-md text-white/80 hover:text-white transition-all cursor-pointer ${viewMode === 'KANBAN' ? 'bg-white text-[#1b365d] shadow-xs font-bold' : ''}`}
                title="Visualizar Kanban"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                id="btn-view-list"
                onClick={() => setViewMode('LIST')}
                className={`p-1.5 rounded-md text-white/80 hover:text-white transition-all cursor-pointer ${viewMode === 'LIST' ? 'bg-white text-[#1b365d] shadow-xs font-bold' : ''}`}
                title="Visualizar Lista"
              >
                <ListFilter className="w-4 h-4" />
              </button>
            </div>

            <button
              id="btn-add-os"
              onClick={openAddModal}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider rounded-lg transition-all shadow-md flex items-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={clients.length === 0 || equipments.length === 0}
              title={clients.length === 0 || equipments.length === 0 ? "Você precisa de clientes e equipamentos cadastrados." : ""}
            >
              <Plus className="w-4 h-4 text-slate-950 stroke-[3]" />
              <span>ABRIR NOVA OS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Cheerful KPI Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="os-metrics-summary-grid">
        <div className="bg-white p-3.5 rounded-xl border-2 border-[#b0bec5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 bg-blue-50 rounded-xl border border-blue-200 text-[#003b7a] shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-slate-500 font-bold uppercase block tracking-wider truncate">Total de Ordens</span>
            <span className="text-xl font-black text-slate-800 font-mono">{orders.length}</span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border-2 border-[#b0bec5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-amber-700 shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-amber-700 font-bold uppercase block tracking-wider truncate">Aguardando Triagem</span>
            <span className="text-xl font-black text-amber-800 font-mono">
              {orders.filter(o => o.status === 'PENDING').length}
            </span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border-2 border-[#b0bec5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 rounded-xl border border-indigo-200 text-indigo-700 shrink-0">
            <Wrench className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-indigo-700 font-bold uppercase block tracking-wider truncate">Em Execução</span>
            <span className="text-xl font-black text-indigo-800 font-mono">
              {orders.filter(o => o.status === 'IN_PROGRESS').length}
            </span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border-2 border-[#b0bec5] shadow-xs flex items-center gap-3">
          <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-700 shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-emerald-700 font-bold uppercase block tracking-wider truncate">Concluídas</span>
            <span className="text-xl font-black text-emerald-800 font-mono">
              {orders.filter(o => o.status === 'COMPLETED').length}
            </span>
          </div>
        </div>
      </div>

      {/* Search and Filters Strip */}
      <div className="bg-white rounded-xl border-2 border-[#b0bec5] shadow-xs p-4 flex flex-col gap-3">
        {/* Dynamic Filters Layout */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="relative md:col-span-2">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input
              id="filter-search-os"
              type="text"
              placeholder="Buscar OS por número, serviço, técnico, cliente ou equipamento..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-[#0052cc] transition-all font-sans font-medium"
            />
          </div>

          <div>
            <select
              id="filter-status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 font-bold focus:outline-hidden focus:border-blue-600 shadow-xs"
            >
              <option value="ALL">Todos os Status</option>
              <option value="PENDING">Aguardando (Pendente)</option>
              <option value="IN_PROGRESS">Em Execução (Andamento)</option>
              <option value="COMPLETED">Concluída</option>
              <option value="CANCELLED">Cancelada</option>
            </select>
          </div>

          <div>
            <select
              id="filter-priority"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 font-bold focus:outline-hidden focus:border-blue-600 shadow-xs"
            >
              <option value="ALL">Todas as Prioridades</option>
              <option value="HIGH">Prioridade Alta</option>
              <option value="MEDIUM">Prioridade Média</option>
              <option value="LOW">Prioridade Baixa</option>
            </select>
          </div>
        </div>
      </div>

      {/* Kanban Layout */}
      {viewMode === 'KANBAN' ? (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4" id="kanban-board-grid">
          {columns.map((col) => {
            const columnOrders = filteredOrders.filter((o) => o.status === col.status);
            const ColumnIcon = col.icon;
            
            // Custom styles for each kanban column to fit cheerful Pos-Manutencao theme
            let colColorStyle = 'border-[#b0bec5] bg-slate-50/60';
            if (col.status === 'PENDING') colColorStyle = 'border-amber-300 bg-amber-50/50';
            if (col.status === 'IN_PROGRESS') colColorStyle = 'border-blue-300 bg-blue-50/50';
            if (col.status === 'COMPLETED') colColorStyle = 'border-emerald-300 bg-emerald-50/50';
            if (col.status === 'CANCELLED') colColorStyle = 'border-rose-300 bg-rose-50/40';

            return (
              <div
                id={`kanban-column-${col.status}`}
                key={col.status}
                className={`border-2 rounded-2xl p-4 flex flex-col min-h-[500px] shadow-xs ${colColorStyle}`}
              >
                {/* Column Header */}
                <div className="flex items-center justify-between mb-4 pb-2.5 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <ColumnIcon className={`w-4 h-4 ${col.status === 'PENDING' ? 'text-amber-700' : col.status === 'IN_PROGRESS' ? 'text-blue-700' : col.status === 'COMPLETED' ? 'text-emerald-700' : 'text-rose-700'}`} />
                    <h3 className="font-black text-slate-800 text-[11px] uppercase tracking-wider">{col.title}</h3>
                  </div>
                  <span className="bg-white border border-slate-300 text-slate-800 font-black px-2.5 py-0.5 rounded-lg text-xs font-mono shadow-xs">
                    {columnOrders.length}
                  </span>
                </div>

                {/* Card Container */}
                <div className="space-y-3 flex-1 overflow-y-auto">
                  {columnOrders.length === 0 ? (
                    <div className="h-24 flex items-center justify-center text-slate-400 text-[10px] uppercase tracking-widest font-black border-2 border-dashed border-slate-200 rounded-xl bg-white/50">
                      Nenhuma OS
                    </div>
                  ) : (
                    columnOrders.map((order) => {
                      const client = clients.find((c) => c.id === order.clientId);
                      const equipment = equipments.find((e) => e.id === order.equipmentId);
                      
                      // Priority Badge inside Kanban card
                      let priorityPill = (
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 border border-slate-300 text-[9px] font-black text-slate-700 tracking-wider">BAIXA</span>
                      );
                      if (order.priority === 'HIGH') {
                        priorityPill = (
                          <span className="px-2 py-0.5 rounded-md bg-rose-100 border border-rose-300 text-[9px] font-black text-rose-800 tracking-wider">ALTA</span>
                        );
                      } else if (order.priority === 'MEDIUM') {
                        priorityPill = (
                          <span className="px-2 py-0.5 rounded-md bg-amber-100 border border-amber-300 text-[9px] font-black text-amber-900 tracking-wider">MÉDIA</span>
                        );
                      }

                      return (
                        <div
                          id={`os-card-${order.id}`}
                          key={order.id}
                          className="bg-white border-2 border-[#b0bec5] rounded-xl p-4 shadow-xs hover:border-[#1b365d] hover:shadow-md transition-all duration-300 group flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-start justify-between gap-1 mb-2.5">
                              <span className="text-[10px] font-mono font-black text-[#1b365d] bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-lg">
                                {order.osNumber}
                              </span>
                              {priorityPill}
                            </div>

                            <h4 className="font-black text-slate-900 text-xs line-clamp-2 leading-normal group-hover:text-[#0052cc] transition-colors">
                              {order.title}
                            </h4>

                            {order.equipmentPhoto && (
                              <div 
                                className="relative mt-2.5 rounded-lg overflow-hidden border border-slate-200 bg-slate-50 cursor-pointer group/img" 
                                onClick={() => setActivePhotoUrl(order.equipmentPhoto!)}
                              >
                                <img 
                                  src={order.equipmentPhoto} 
                                  alt="Entrada do equipamento" 
                                  className="w-full h-28 object-cover transition-transform duration-300 group-hover/img:scale-105"
                                  referrerPolicy="no-referrer"
                                />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 flex items-center justify-center transition-opacity">
                                  <span className="text-[9px] font-black text-white uppercase tracking-wider bg-[#1b365d]/90 border border-white/20 px-2 py-1 rounded-md flex items-center gap-1 shadow-sm">
                                    <Camera className="w-3 h-3 text-cyan-300" />
                                    Ver Foto
                                  </span>
                                </div>
                              </div>
                            )}

                            <div className="space-y-1.5 mt-3 pt-3 border-t border-slate-200 text-[10px]">
                              <p>
                                <span className="font-bold text-slate-500 block uppercase tracking-wider text-[8px]">Cliente</span>
                                <span className="text-slate-800 font-bold">{client ? client.name : 'Desconhecido'}</span>
                              </p>
                              <p className="mt-1">
                                <span className="font-bold text-slate-500 block uppercase tracking-wider text-[8px]">Equipamento</span>
                                <span className="text-slate-800 font-bold">{equipment ? `${equipment.name} (${equipment.model})` : 'Desconhecido'}</span>
                              </p>

                              {/* Stay duration section (Controle de permanência) */}
                              <div className="mt-2.5 pt-2 border-t border-slate-200">
                                <div className="flex items-center justify-between">
                                  <span className="font-bold text-slate-500 uppercase tracking-wider text-[8px]">Permanência</span>
                                  <span className={`px-2 py-0.5 rounded-md border text-[8px] font-black uppercase tracking-wider ${getStayStatus(order).color}`}>
                                    {getStayStatus(order).days} {getStayStatus(order).days === 1 ? 'Dia' : 'Dias'}
                                  </span>
                                </div>
                                <p className="text-[9px] text-slate-600 mt-1 flex items-center gap-1 font-medium">
                                  <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                                  <span>{getStayStatus(order).detail}</span>
                                </p>
                              </div>

                              {/* Orçamento & Verificação Real info on card */}
                              <div className="mt-2.5 pt-2 border-t border-slate-200 space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="font-bold text-slate-500 uppercase tracking-wider text-[8px]">Orçamento</span>
                                  {order.budgetStatus === 'APPROVED' ? (
                                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-300 text-[8px] font-black text-emerald-800 uppercase tracking-wider">Aprovado</span>
                                  ) : order.budgetStatus === 'REJECTED' ? (
                                    <span className="px-2 py-0.5 rounded-md bg-rose-50 border border-rose-300 text-[8px] font-black text-rose-800 uppercase tracking-wider">Rejeitado</span>
                                  ) : (
                                    <span className="px-2 py-0.5 rounded-md bg-amber-50 border border-amber-300 text-[8px] font-black text-amber-900 uppercase tracking-wider">Aguardando</span>
                                  )}
                                </div>
                                {order.diagnostic && (
                                  <p className="text-[9px] text-slate-700 line-clamp-1 italic mt-1 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                    Obs: {order.diagnostic}
                                  </p>
                                )}
                              </div>
                              
                              {order.status === 'COMPLETED' && (
                                <div className="mt-2.5 p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-[10px]">
                                  <div className="flex items-center gap-1.5 text-emerald-800 font-black uppercase tracking-wider text-[9px]">
                                    <Shield className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>Garantia de {order.warrantyDays || 0} Dias</span>
                                  </div>
                                  {order.warrantyDays ? (
                                    <div className="mt-1 text-slate-700 text-[9px]">
                                      Válida até: <strong className="text-slate-900">{getWarrantyStatus(order).dateStr}</strong> 
                                      {getWarrantyStatus(order).active ? (
                                        <span className="text-emerald-700 font-bold"> ({getWarrantyStatus(order).daysLeft} dias restantes)</span>
                                      ) : (
                                        <span className="text-rose-700 font-bold"> (Expirada)</span>
                                      )}
                                    </div>
                                  ) : null}
                                  {order.warrantyNotes && (
                                    <p className="mt-1.5 text-slate-600 italic text-[9px] border-t border-emerald-200 pt-1">
                                      "{order.warrantyNotes}"
                                    </p>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="mt-4 pt-2.5 border-t border-slate-200 flex items-center justify-between">
                            <span className="text-[10px] font-bold text-slate-700 flex items-center gap-1.5">
                              <User className="w-3 h-3 text-[#0052cc]" />
                              {order.technician}
                            </span>
                            <span className="text-xs font-black text-emerald-700 font-mono">
                              {formatMoney(order.estimatedCost)}
                            </span>
                          </div>

                          {/* Quick State Actions & Controls */}
                          <div className="mt-3.5 pt-2.5 border-t border-slate-200 space-y-2">
                            {/* Workflow Transitions if applicable */}
                            {(order.status === 'PENDING' || order.status === 'IN_PROGRESS') && (
                              <div className="flex items-center gap-1">
                                {order.status === 'PENDING' && (
                                  <button
                                    id={`btn-start-os-${order.id}`}
                                    onClick={() => handleUpdateStatus(order, 'IN_PROGRESS')}
                                    className="flex-1 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[9px] font-black uppercase rounded-lg cursor-pointer transition-colors shadow-xs text-center"
                                  >
                                    Iniciar Execução
                                  </button>
                                )}
                                {order.status === 'IN_PROGRESS' && (
                                  <button
                                    id={`btn-complete-os-${order.id}`}
                                    onClick={() => handleUpdateStatus(order, 'COMPLETED')}
                                    className="flex-1 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[9px] font-black uppercase rounded-lg cursor-pointer transition-colors shadow-xs text-center"
                                  >
                                    Concluir Serviço
                                  </button>
                                )}
                                <button
                                  id={`btn-cancel-os-state-${order.id}`}
                                  onClick={() => handleUpdateStatus(order, 'CANCELLED')}
                                  className="px-2 py-1 bg-rose-100 hover:bg-rose-200 text-rose-800 text-[9px] font-black uppercase rounded-lg cursor-pointer transition-colors border border-rose-300 text-center"
                                  title="Cancelar Ordem"
                                >
                                  Cancelar
                                </button>
                              </div>
                            )}

                            {/* 4 Core Primary Action Buttons: Editar, Excluir, Enviar, Registrar Entrega */}
                            <div className="grid grid-cols-2 gap-1.5 pt-1">
                              <button
                                id={`btn-edit-os-${order.id}`}
                                onClick={() => openEditModal(order)}
                                className="px-2 py-1.5 bg-blue-50 hover:bg-blue-100 text-[#003b7a] border border-blue-200 rounded-lg text-[10px] font-black flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-xs"
                                title="Editar Ordem de Serviço"
                              >
                                <Edit2 className="w-3.5 h-3.5 text-[#003b7a]" />
                                <span>Editar</span>
                              </button>

                              <button
                                id={`btn-delete-os-${order.id}`}
                                onClick={() => handleDelete(order.id, order.osNumber)}
                                className="px-2 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-[10px] font-black flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-xs"
                                title="Excluir Ordem de Serviço"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                <span>Excluir</span>
                              </button>

                              <button
                                id={`btn-share-os-${order.id}`}
                                onClick={() => handleOpenShareModal(order)}
                                className="px-2 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-[10px] font-black flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-xs"
                                title="Enviar Orçamento por WhatsApp / E-mail"
                              >
                                <Send className="w-3.5 h-3.5 text-emerald-700" />
                                <span>Enviar</span>
                              </button>

                              {!order.isDelivered ? (
                                <button
                                  id={`btn-deliver-os-${order.id}`}
                                  onClick={() => {
                                    onEditOrder({
                                      ...order,
                                      isDelivered: true,
                                      deliveryDate: new Date().toISOString().split('T')[0]
                                    });
                                    showDeliveryToast(`✅ Entrega da OS ${order.osNumber} registrada com sucesso!`);
                                  }}
                                  className="px-2 py-1.5 bg-amber-500 hover:bg-amber-400 border border-amber-600 rounded-lg text-slate-950 text-[10px] font-black uppercase cursor-pointer transition-colors shadow-xs flex items-center justify-center gap-1 truncate"
                                  title="Registrar Entrega do Equipamento"
                                >
                                  <Clock className="w-3.5 h-3.5 text-slate-950 shrink-0" />
                                  <span className="truncate">Registrar Entrega</span>
                                </button>
                              ) : (
                                <button
                                  id={`btn-undeliver-os-${order.id}`}
                                  onClick={() => {
                                    onEditOrder({
                                      ...order,
                                      isDelivered: false,
                                      deliveryDate: undefined
                                    });
                                    showDeliveryToast(`Status de entrega da OS ${order.osNumber} desfeito.`, 'info');
                                  }}
                                  className="px-2 py-1.5 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 rounded-lg text-emerald-900 text-[10px] font-black uppercase cursor-pointer transition-colors shadow-xs flex items-center justify-center gap-1 truncate"
                                  title="Equipamento Entregue (clique para retomar)"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                                  <span className="truncate">Entregue</span>
                                </button>
                              )}
                            </div>

                            {/* Extra: PDF Report if Completed */}
                            {order.status === 'COMPLETED' && (
                              <button
                                id={`btn-report-os-${order.id}`}
                                onClick={() => setViewingReportOrder(order)}
                                className="w-full py-1 bg-cyan-50 hover:bg-cyan-100 text-cyan-800 border border-cyan-200 rounded-lg text-[10px] font-black flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-xs mt-1"
                                title="Visualizar Relatório de Encerramento (PDF)"
                              >
                                <ClipboardList className="w-3.5 h-3.5 text-cyan-700" />
                                <span>Relatório Técnico de Encerramento (PDF)</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List View Mode */
        <div className="bg-white rounded-2xl border-2 border-[#b0bec5] shadow-sm overflow-hidden" id="list-orders-table-wrapper">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[1240px]" id="orders-list-table">
              <thead>
                <tr className="bg-[#1b365d] text-white text-[11px] font-black uppercase tracking-wider">
                  <th className="py-3 px-3 font-mono">OS</th>
                  <th className="py-3 px-3">Serviço / Título</th>
                  <th className="py-3 px-2.5">Cliente</th>
                  <th className="py-3 px-2.5">Equipamento</th>
                  <th className="py-3 px-2 text-center">Permanência</th>
                  <th className="py-3 px-2 text-center">Prioridade</th>
                  <th className="py-3 px-2 text-center">Status</th>
                  <th className="py-3 px-2.5">Técnico</th>
                  <th className="py-3 px-2.5 text-right">Custo</th>
                  <th className="py-3 px-4 text-center sticky right-0 bg-[#1b365d] z-20 shadow-[-6px_0_10px_-2px_rgba(0,0,0,0.25)] min-w-[370px] w-[370px]">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-12 text-center text-slate-500 font-bold">
                      Nenhuma Ordem de Serviço encontrada para os filtros aplicados.
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => {
                    const client = clients.find((c) => c.id === order.clientId);
                    const equipment = equipments.find((e) => e.id === order.equipmentId);
                    
                    return (
                      <tr id={`table-row-os-${order.id}`} key={order.id} className="hover:bg-blue-50/70 transition-colors group">
                        <td className="py-2.5 px-3 font-mono font-black text-[#0052cc] whitespace-nowrap">{order.osNumber}</td>
                        <td className="py-2.5 px-3 font-black text-slate-900 max-w-[200px] xl:max-w-[240px]">
                          <div className="flex items-center gap-2">
                            {order.equipmentPhoto && (
                              <div 
                                className="relative w-8 h-8 rounded-lg overflow-hidden border border-slate-300 bg-slate-100 shrink-0 cursor-pointer group/table-img shadow-xs" 
                                onClick={() => setActivePhotoUrl(order.equipmentPhoto!)}
                                title="Clique para ampliar"
                              >
                                <img 
                                  src={order.equipmentPhoto} 
                                  alt="Miniatura" 
                                  className="w-full h-full object-cover transition-transform group-hover/table-img:scale-110"
                                  referrerPolicy="no-referrer"
                                />
                              </div>
                            )}
                            <div className="min-w-0">
                              <span title={order.title} className="truncate block font-bold text-slate-900 text-xs">{order.title}</span>
                              {order.budgetStatus && (
                                <div className="mt-0.5 flex items-center gap-1.5">
                                  {order.budgetStatus === 'APPROVED' ? (
                                    <span className="px-1.5 py-0.2 bg-emerald-100 border border-emerald-300 rounded text-[9px] font-black text-emerald-800 uppercase tracking-wider">Aprovado</span>
                                  ) : order.budgetStatus === 'REJECTED' ? (
                                    <span className="px-1.5 py-0.2 bg-rose-100 border border-rose-300 rounded text-[9px] font-black text-rose-800 uppercase tracking-wider">Rejeitado</span>
                                  ) : (
                                    <span className="px-1.5 py-0.2 bg-amber-100 border border-amber-300 rounded text-[9px] font-black text-amber-900 uppercase tracking-wider">Pendente</span>
                                  )}
                                </div>
                              )}
                              {order.status === 'COMPLETED' && order.warrantyDays !== undefined && (
                                <div className="flex items-center gap-1 mt-0.5 text-[9px] text-emerald-700 font-bold">
                                  <Shield className="w-3 h-3 text-emerald-600 shrink-0" />
                                  <span>{order.warrantyDays}d</span>
                                  {getWarrantyStatus(order).active ? (
                                    <span className="px-1 py-0.2 bg-emerald-100 border border-emerald-300 rounded text-[8px] font-black text-emerald-800">Ativa</span>
                                  ) : (
                                    <span className="px-1 py-0.2 bg-rose-100 border border-rose-300 rounded text-[8px] font-black text-rose-800">Expirada</span>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="py-2.5 px-2.5 text-slate-800 font-bold truncate max-w-[120px] xl:max-w-[150px]" title={client ? client.name : 'Desconhecido'}>
                          {client ? client.name : 'Desconhecido'}
                        </td>
                        <td className="py-2.5 px-2.5 text-slate-700 font-medium truncate max-w-[120px] xl:max-w-[150px]" title={equipment ? `${equipment.name} (${equipment.model})` : 'Desconhecido'}>
                          {equipment ? `${equipment.name} (${equipment.model})` : 'Desconhecido'}
                        </td>
                        <td className="py-2.5 px-2 text-center whitespace-nowrap">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-lg border text-[10px] font-black ${getStayStatus(order).color}`}>
                            {getStayStatus(order).days} {getStayStatus(order).days === 1 ? 'Dia' : 'Dias'}
                          </span>
                        </td>
                        <td className="py-2.5 px-2 text-center whitespace-nowrap">
                          {order.priority === 'HIGH' && <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-rose-100 border border-rose-300 text-rose-800 text-[10px] font-black">ALTA</span>}
                          {order.priority === 'MEDIUM' && <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-amber-100 border border-amber-300 text-amber-900 text-[10px] font-black">MÉDIA</span>}
                          {order.priority === 'LOW' && <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-slate-100 border border-slate-300 text-slate-700 text-[10px] font-black">BAIXA</span>}
                        </td>
                        <td className="py-2.5 px-2 text-center whitespace-nowrap">
                          {order.status === 'PENDING' && <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-amber-100 border border-amber-300 text-amber-900 font-black text-[10px]">Aguardando</span>}
                          {order.status === 'IN_PROGRESS' && <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-blue-100 border border-blue-300 text-[#003b7a] font-black text-[10px]">Executando</span>}
                          {order.status === 'COMPLETED' && <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-emerald-100 border border-emerald-300 text-emerald-800 font-black text-[10px]">Concluída</span>}
                          {order.status === 'CANCELLED' && <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-rose-100 border border-rose-300 text-rose-800 font-black text-[10px]">Cancelada</span>}
                        </td>
                        <td className="py-2.5 px-2.5 text-slate-800 font-bold truncate max-w-[110px] whitespace-nowrap">{order.technician}</td>
                        <td className="py-2.5 px-2.5 font-mono font-black text-emerald-800 text-right whitespace-nowrap">{formatMoney(order.estimatedCost)}</td>
                        <td className="py-2.5 px-3 text-right whitespace-nowrap sticky right-0 z-10 bg-white group-hover:bg-[#eef4fc] transition-colors shadow-[-6px_0_10px_-2px_rgba(0,0,0,0.08)] border-l border-slate-200 min-w-[370px] w-[370px]">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* EDITAR */}
                            <button
                              id={`table-btn-edit-${order.id}`}
                              onClick={() => openEditModal(order)}
                              className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-[#003b7a] border border-blue-200 rounded-lg text-[10px] font-black flex items-center gap-1 cursor-pointer transition-colors shadow-xs shrink-0"
                              title="Editar OS"
                            >
                              <Edit2 className="w-3.5 h-3.5 text-[#003b7a]" />
                              <span>Editar</span>
                            </button>

                            {/* EXCLUIR */}
                            <button
                              id={`table-btn-delete-${order.id}`}
                              onClick={() => handleDelete(order.id, order.osNumber)}
                              className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-[10px] font-black flex items-center gap-1 cursor-pointer transition-colors shrink-0 shadow-xs"
                              title="Excluir Ordem de Serviço"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                              <span>Excluir</span>
                            </button>

                            {/* ENVIAR (WhatsApp / E-mail) */}
                            <button
                              id={`table-btn-share-${order.id}`}
                              onClick={() => handleOpenShareModal(order)}
                              className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-[10px] font-black flex items-center gap-1 cursor-pointer transition-colors shrink-0 shadow-xs"
                              title="Enviar Orçamento por WhatsApp / E-mail"
                            >
                              <Send className="w-3.5 h-3.5 text-emerald-700" />
                              <span>Enviar</span>
                            </button>

                            {/* REGISTRAR ENTREGA */}
                            {!order.isDelivered ? (
                              <button
                                id={`table-btn-deliver-${order.id}`}
                                onClick={() => {
                                  onEditOrder({
                                    ...order,
                                    isDelivered: true,
                                    deliveryDate: new Date().toISOString().split('T')[0]
                                  });
                                  showDeliveryToast(`✅ Entrega da OS ${order.osNumber} registrada com sucesso! Equipamento marcado como entregue.`);
                                }}
                                className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 border border-amber-600 rounded-lg text-slate-950 font-black text-[10px] uppercase cursor-pointer shadow-xs shrink-0 flex items-center gap-1 transition-colors"
                                title="Registrar Entrega do Equipamento ao Cliente"
                              >
                                <Clock className="w-3.5 h-3.5 text-slate-950" />
                                <span>Registrar Entrega</span>
                              </button>
                            ) : (
                              <button
                                id={`table-btn-undeliver-${order.id}`}
                                onClick={() => {
                                  onEditOrder({
                                    ...order,
                                    isDelivered: false,
                                    deliveryDate: undefined
                                  });
                                  showDeliveryToast(`Status de entrega da OS ${order.osNumber} desfeito. Equipamento voltou para pendente de entrega.`, 'info');
                                }}
                                className="px-2.5 py-1.5 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 rounded-lg text-emerald-900 font-black text-[10px] uppercase cursor-pointer shadow-xs shrink-0 flex items-center gap-1 transition-colors"
                                title="Equipamento já entregue (clique para desfazer/retomar)"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                                <span>Entregue</span>
                              </button>
                            )}

                            {/* RELATÓRIO PDF (Quando concluída) */}
                            {order.status === 'COMPLETED' && (
                              <button
                                id={`table-btn-report-${order.id}`}
                                onClick={() => setViewingReportOrder(order)}
                                className="p-1.5 hover:bg-cyan-50 rounded-lg text-cyan-700 border border-cyan-200 cursor-pointer shadow-xs shrink-0"
                                title="Visualizar Relatório de Encerramento (PDF)"
                              >
                                <ClipboardList className="w-3.5 h-3.5 text-cyan-600" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* OS Add/Edit Modal Dialog */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6" id="os-form-modal">
          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs" onClick={() => setIsModalOpen(false)}></div>
          <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-3xl overflow-hidden border-2 border-slate-300 animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
            {/* Modal Header */}
            <div className="bg-[#1b365d] text-white px-6 py-4 flex items-center justify-between border-b-2 border-blue-950 shrink-0">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <Wrench className="w-5 h-5 text-blue-300" />
                  <h3 className="font-black text-white text-base uppercase tracking-wider">
                    {editingOrder ? `Editar Ordem de Serviço ${editingOrder.osNumber}` : 'Abrir Nova Ordem de Serviço'}
                  </h3>
                </div>
                <p className="text-[11px] text-blue-200 font-medium">
                  {editingOrder ? 'Edite os dados cadastrais, técnicos e operacionais da OS com total visibilidade' : 'Cadastre uma nova OS para acompanhamento no ciclo de manutenção'}
                </p>
              </div>
              <button
                id="btn-close-os-modal"
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                title="Fechar"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto bg-slate-50/70 text-slate-900">
              {formError && (
                <div className="p-3.5 bg-rose-50 text-rose-800 rounded-2xl text-xs font-black border-2 border-rose-300 flex items-center gap-2 shadow-xs" id="os-form-error">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Section 1: Cliente e Equipamento */}
              <div className="bg-white p-5 rounded-2xl border-2 border-slate-200 shadow-xs space-y-4">
                <div className="border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-[#1b365d] flex items-center gap-1.5">
                    <User className="w-4 h-4 text-[#0052cc]" />
                    Dados do Solicitante e Equipamento
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Client Selection */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Cliente Solicitante *
                    </label>
                    <select
                      id="form-os-client"
                      value={clientId}
                      onChange={(e) => setClientId(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs cursor-pointer"
                      required
                    >
                      <option value="" className="bg-white text-slate-900">Selecione o Cliente...</option>
                      {clients.map((c) => (
                        <option key={c.id} value={c.id} className="bg-white text-slate-900 font-bold">
                          {c.name} {c.phone ? `(${c.phone})` : ''}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Equipment Selection */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Equipamento Afetado *
                    </label>
                    <select
                      id="form-os-equipment"
                      value={equipmentId}
                      onChange={(e) => setEquipmentId(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs cursor-pointer"
                      required
                    >
                      <option value="" className="bg-white text-slate-900">Selecione o Equipamento...</option>
                      {formAvailableEquipments.map((e) => (
                        <option key={e.id} value={e.id} className="bg-white text-slate-900 font-bold">
                          {e.name} - Modelo: {e.model || 'S/M'}
                        </option>
                      ))}
                    </select>
                    {formAvailableEquipments.length === 0 && (
                      <p className="text-[10px] text-amber-700 font-black uppercase tracking-wider mt-1.5">
                        Nenhum equipamento cadastrado. Cadastre um equipamento na aba Equipamentos primeiro!
                      </p>
                    )}
                  </div>
                </div>

                {/* Característica do Atendimento */}
                <div className="space-y-2 p-3.5 bg-blue-50/60 rounded-xl border-2 border-blue-200">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-black uppercase tracking-wider text-[#1b365d]">
                      Característica do Atendimento *
                    </label>
                    <span className="text-[10px] font-black text-[#0052cc] uppercase">
                      Classificação Operacional
                    </span>
                  </div>

                  <select
                    id="form-os-attendance-type"
                    value={attendanceType}
                    onChange={(e) => setAttendanceType(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-black focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs cursor-pointer"
                    required
                  >
                    <option value="Oficina Interna / Balcão">Oficina Interna / Balcão (Equipamento deixado na empresa)</option>
                    <option value="Externo / Em Campo (Visita Técnica)">Externo / Em Campo (Visita Técnica na planta do cliente)</option>
                    <option value="Garantia / Retorno">Garantia / Retorno (Reparo em garantia anterior)</option>
                    <option value="Emergencial / Plantão 24h">Emergencial / Plantão 24h (Parada de produção)</option>
                    <option value="Manutenção Preventiva / Contrato">Manutenção Preventiva / Contrato Mensal</option>
                    <option value="Orçamento / Avaliação Técnica">Orçamento / Avaliação Técnica Prévia</option>
                    <option value="Reforma Completa / Retrofit">Reforma Completa / Retrofit</option>
                  </select>

                  {/* Quick Preset Buttons */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    <span className="text-[9px] font-black text-slate-600 uppercase">Atalhos rápidos:</span>
                    {[
                      'Oficina Interna / Balcão',
                      'Externo / Em Campo (Visita Técnica)',
                      'Garantia / Retorno',
                      'Emergencial / Plantão 24h',
                      'Manutenção Preventiva / Contrato',
                      'Orçamento / Avaliação Técnica'
                    ].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setAttendanceType(preset)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-black border transition-all cursor-pointer ${
                          attendanceType === preset
                            ? 'bg-[#1b365d] text-white border-[#1b365d] shadow-xs'
                            : 'bg-white hover:bg-blue-100/60 text-slate-800 border-slate-300'
                        }`}
                      >
                        {preset.split(' (')[0]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Title & Technical Defect */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                    Título do Serviço / Sintoma de Defeito *
                  </label>
                  <input
                    id="form-os-title"
                    type="text"
                    placeholder="Ex: Vibração no barramento mecânico / Troca de vedações"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold placeholder-slate-400 focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs"
                    required
                  />
                </div>

                {/* Description */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                    Descrição do Diagnóstico / Problema Reclamado *
                  </label>
                  <textarea
                    id="form-os-description"
                    rows={3}
                    placeholder="Descreva detalhadamente o problema observado e as instruções de reparo..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold placeholder-slate-400 focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 resize-none font-sans leading-relaxed shadow-2xs"
                    required
                  ></textarea>

                  {diagnostics && diagnostics.length > 0 && (
                    <div className="mt-2 p-3 bg-slate-100 rounded-xl border border-slate-300">
                      <span className="block text-[10px] font-black text-slate-700 uppercase tracking-wider mb-1.5">
                        Usar Modelo de Diagnóstico Cadastrado:
                      </span>
                      <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto">
                        {diagnostics.map((diag) => (
                          <button
                            key={diag.id}
                            type="button"
                            onClick={() => {
                              if (!description || description.trim() === '' || description === 'N/A') {
                                setDescription(diag.description);
                              } else {
                                setDescription(prev => `${prev}\n\n${diag.description}`);
                              }
                              if (!title || title.trim() === '') {
                                setTitle(diag.title);
                              }
                            }}
                            className="px-2.5 py-1.5 bg-white hover:bg-blue-50 hover:text-[#0052cc] border border-slate-300 hover:border-blue-400 text-[10px] text-slate-800 rounded-lg font-bold transition-all text-left flex items-center gap-1.5 cursor-pointer shadow-2xs"
                            title={diag.description}
                          >
                            <ClipboardList className="w-3.5 h-3.5 text-[#0052cc] shrink-0" />
                            <span className="truncate">{diag.title}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Section 2: Foto do Equipamento */}
              <div className="bg-white p-5 rounded-2xl border-2 border-slate-200 shadow-xs space-y-3">
                <div className="border-b border-slate-200 pb-2 flex items-center justify-between">
                  <label className="text-xs font-black uppercase tracking-wider text-[#1b365d] flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-[#0052cc]" />
                    Foto do Equipamento na Entrada <span className="text-[10px] text-slate-500 normal-case font-normal">(Opcional)</span>
                  </label>
                  {equipmentPhoto && (
                    <button
                      type="button"
                      id="btn-remove-photo"
                      onClick={() => setEquipmentPhoto('')}
                      className="text-[10px] font-black text-rose-700 hover:text-rose-900 uppercase flex items-center gap-1 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                      Remover Foto
                    </button>
                  )}
                </div>
                
                {equipmentPhoto ? (
                  <div className="relative rounded-2xl overflow-hidden border-2 border-slate-200 bg-slate-50 p-3 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img 
                        src={equipmentPhoto} 
                        alt="Preview do Equipamento" 
                        className="w-20 h-20 object-cover rounded-xl border-2 border-slate-300 shadow-xs"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <span className="text-xs font-black text-emerald-800 uppercase tracking-wider block">Foto anexada com sucesso</span>
                        <span className="text-[10px] text-slate-600 block mt-0.5">Visível na ficha de entrada e relatório em PDF</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-2xl p-5 text-center transition-all duration-150 cursor-pointer ${
                      isDragging 
                        ? 'border-[#0052cc] bg-blue-50/50' 
                        : 'border-slate-300 bg-slate-50/60 hover:border-blue-400 hover:bg-blue-50/30'
                    }`}
                    onClick={() => document.getElementById('photo-file-input')?.click()}
                  >
                    <input
                      id="photo-file-input"
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                    <Camera className="w-7 h-7 text-slate-400 mx-auto mb-1.5" />
                    <span className="block text-xs font-black text-slate-800">Clique para Enviar ou Arraste uma Foto Aqui</span>
                    <span className="block text-[10px] text-slate-500 mt-0.5">Formatos recomendados: JPG, PNG (máx. 5MB)</span>
                  </div>
                )}
              </div>

              {/* Section 3: Diagnóstico Técnico & Orçamento */}
              <div className="space-y-4 p-5 bg-white border-2 border-slate-200 rounded-2xl shadow-xs">
                <div className="border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-[#1b365d] flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-[#0052cc]" />
                    Verificação Técnica & Orçamento Proposto
                  </h4>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Situação Verificada (Diagnóstico Técnico)
                    </label>
                    <span className="text-[10px] text-[#0052cc] font-black uppercase tracking-wider">Modelos Rápidos:</span>
                  </div>
                  {diagnostics && diagnostics.length > 0 && (
                    <div className="flex items-center gap-1.5 flex-wrap pb-1 max-h-24 overflow-y-auto" id="diagnostic-selectors">
                      {diagnostics.map(d => (
                        <button
                          key={d.id}
                          type="button"
                          onClick={() => {
                            setDiagnostic(prev => prev ? `${prev}\n${d.description}` : d.description);
                            if (!title) {
                              setTitle(d.title);
                            }
                          }}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-blue-50 text-[10px] text-slate-800 font-bold border border-slate-300 hover:border-blue-400 rounded-lg cursor-pointer transition-colors shadow-2xs"
                          title={`${d.title}: ${d.description}`}
                        >
                          <span className="font-mono text-[#0052cc] font-black">{d.code}:</span> {d.title}
                        </button>
                      ))}
                    </div>
                  )}
                  <textarea
                    id="form-os-diagnostic"
                    rows={2}
                    placeholder="Descreva a real situação encontrada no equipamento após a inspeção técnica..."
                    value={diagnostic}
                    onChange={(e) => setDiagnostic(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold placeholder-slate-400 focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 resize-none font-sans leading-relaxed shadow-2xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      O que será Efetuado (Serviço & Peças)
                    </label>
                    <span className="text-[10px] text-emerald-700 font-black uppercase tracking-wider">Catálogo de Serviços:</span>
                  </div>
                  {services && services.length > 0 && (
                    <div className="flex items-center gap-1.5 flex-wrap pb-1 max-h-24 overflow-y-auto" id="service-selectors">
                      {services.map(s => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => {
                            setPlannedServices(prev => prev ? `${prev}\n- [${s.code}] ${s.name}: ${s.description}` : `- [${s.code}] ${s.name}: ${s.description}`);
                            setEstimatedCost(prev => (prev || 0) + s.estimatedCost);
                          }}
                          className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-[10px] text-emerald-950 font-bold border border-emerald-300 rounded-lg cursor-pointer transition-colors shadow-2xs"
                          title={`${s.name} (R$ ${s.estimatedCost})`}
                        >
                          <span className="font-mono text-emerald-700 font-black">{s.code}</span> (R$ {s.estimatedCost})
                        </button>
                      ))}
                    </div>
                  )}
                  <textarea
                    id="form-os-planned-services"
                    rows={2}
                    placeholder="Descreva as ações corretivas e preventivas e possíveis peças a serem trocadas..."
                    value={plannedServices}
                    onChange={(e) => setPlannedServices(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold placeholder-slate-400 focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 resize-none font-sans leading-relaxed shadow-2xs"
                  />
                </div>

                <div className="space-y-1.5 pt-1">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                    Aprovação do Orçamento pelo Cliente
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { val: 'PENDING_APPROVAL', label: 'Aguardando Aprovação', color: 'border-amber-400 text-amber-950 bg-amber-50' },
                      { val: 'APPROVED', label: 'Aprovado pelo Cliente', color: 'border-emerald-500 text-emerald-950 bg-emerald-50' },
                      { val: 'REJECTED', label: 'Rejeitado / Declinado', color: 'border-rose-400 text-rose-950 bg-rose-50' },
                    ].map((opt) => (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => {
                          setBudgetStatus(opt.val as any);
                          if (opt.val === 'APPROVED' && status === 'PENDING') {
                            setStatus('IN_PROGRESS');
                          }
                        }}
                        className={`py-2 px-1 rounded-xl text-[10px] font-black border-2 transition-all cursor-pointer text-center ${
                          budgetStatus === opt.val
                            ? `${opt.color} shadow-xs ring-2 ring-blue-500/20`
                            : 'bg-white border-slate-300 text-slate-600 hover:border-slate-400'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Section 4: Parâmetros Operacionais */}
              <div className="bg-white p-5 rounded-2xl border-2 border-slate-200 shadow-xs space-y-4">
                <div className="border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-[#1b365d] flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#0052cc]" />
                    Parâmetros Operacionais e Responsáveis
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Status da OS *
                    </label>
                    <select
                      id="form-os-status"
                      value={status}
                      onChange={(e) => setStatus(e.target.value as OSStatus)}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-black focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs cursor-pointer"
                    >
                      <option value="PENDING" className="bg-white text-slate-900 font-bold">Aguardando (Pendente)</option>
                      <option value="IN_PROGRESS" className="bg-white text-slate-900 font-bold">Em Execução</option>
                      <option value="COMPLETED" className="bg-white text-slate-900 font-bold">Concluída</option>
                      <option value="CANCELLED" className="bg-white text-slate-900 font-bold">Cancelada</option>
                    </select>
                  </div>
                  
                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Prioridade da OS *
                    </label>
                    <select
                      id="form-os-priority"
                      value={priority}
                      onChange={(e) => setPriority(e.target.value as 'LOW' | 'MEDIUM' | 'HIGH')}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-black focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs cursor-pointer"
                    >
                      <option value="LOW" className="bg-white text-slate-900 font-bold">Baixa</option>
                      <option value="MEDIUM" className="bg-white text-slate-900 font-bold">Média</option>
                      <option value="HIGH" className="bg-white text-slate-900 font-bold">Alta / Urgente</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Técnico Responsável *
                    </label>
                    <select
                      id="form-os-technician"
                      value={technician}
                      onChange={(e) => setTechnician(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs cursor-pointer"
                      required
                    >
                      <option value="" disabled>Selecione um técnico...</option>
                      {technicians.filter(t => t.status === 'ACTIVE').map(t => (
                        <option key={t.id} value={t.name} className="bg-white text-slate-900 font-bold">{t.name} - {t.specialty}</option>
                      ))}
                      {technician && !technicians.some(t => t.name === technician && t.status === 'ACTIVE') && (
                        <option value={technician} className="bg-white text-slate-900 font-bold">{technician} (Atual)</option>
                      )}
                      {technicians.length === 0 && (
                        <>
                          <option value="João CLAUDIO" className="bg-white text-slate-900 font-bold">João CLAUDIO</option>
                          <option value="Felipe" className="bg-white text-slate-900 font-bold">Felipe</option>
                          <option value="Suporte Técnico" className="bg-white text-slate-900 font-bold">Suporte Técnico</option>
                        </>
                      )}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                        Atendente / Recebedor
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowReceiversModal(true)}
                        className="text-[10px] text-[#0052cc] hover:underline font-black cursor-pointer"
                      >
                        Gerenciar Recebedores
                      </button>
                    </div>
                    <div className="flex gap-2">
                      <select
                        id="form-os-receiver"
                        value={receiverName}
                        onChange={(e) => {
                          if (e.target.value === 'ADD_NEW') {
                            setShowReceiversModal(true);
                          } else {
                            setReceiverName(e.target.value);
                          }
                        }}
                        className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs cursor-pointer"
                      >
                        <option value="">Selecione um recebedor...</option>
                        {activeReceivers.map((r) => (
                          <option key={r} value={r} className="bg-white text-slate-900 font-bold">
                            {r}
                          </option>
                        ))}
                        <option value="ADD_NEW" className="bg-blue-50 text-[#0052cc] font-black">
                          + Cadastrar Novo Recebedor...
                        </option>
                      </select>
                      <button
                        type="button"
                        onClick={() => setShowReceiversModal(true)}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl border-2 border-slate-300 text-xs font-black shrink-0 cursor-pointer"
                        title="Cadastrar ou Excluir Recebedores"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Custo Estimado (R$)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-black text-xs">R$</span>
                      <input
                        id="form-os-cost"
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="0,00"
                        value={estimatedCost}
                        onChange={(e) => setEstimatedCost(Number(e.target.value))}
                        className="w-full pl-10 pr-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-black font-mono focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Data de Entrada *
                    </label>
                    <input
                      id="form-os-startdate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 shadow-2xs"
                      required
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Data de Encerramento
                    </label>
                    <input
                      id="form-os-enddate"
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold focus:border-[#0052cc] focus:ring-2 focus:ring-blue-100 disabled:bg-slate-100 disabled:text-slate-400 shadow-2xs"
                      disabled={status !== 'COMPLETED'}
                    />
                  </div>
                </div>
              </div>

              {/* Section 5: Garantia & Financeiro (quando Concluída) */}
              {status === 'COMPLETED' && (
                <div className="space-y-4 p-5 bg-emerald-50/70 border-2 border-emerald-300 rounded-2xl shadow-xs">
                  <div className="border-b border-emerald-200 pb-2">
                    <h4 className="text-xs font-black uppercase tracking-wider text-emerald-950 flex items-center gap-1.5">
                      <Shield className="w-4 h-4 text-emerald-700" />
                      Garantia do Serviço Efetuado & Integração Financeira
                    </h4>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black uppercase tracking-wider text-emerald-950">
                      Período de Garantia
                    </label>
                    <div className="grid grid-cols-5 gap-2">
                      {[
                        { label: 'Sem Garantia', val: 0 },
                        { label: '30 Dias', val: 30 },
                        { label: '90 Dias', val: 90 },
                        { label: '180 Dias', val: 180 },
                        { label: '1 Ano', val: 365 },
                      ].map((preset) => (
                        <button
                          key={preset.val}
                          type="button"
                          onClick={() => setWarrantyDays(preset.val)}
                          className={`py-2 rounded-xl text-[10px] font-black border-2 transition-all cursor-pointer ${
                            warrantyDays === preset.val
                              ? 'bg-emerald-700 border-emerald-700 text-white shadow-xs'
                              : 'bg-white border-emerald-200 text-emerald-900 hover:border-emerald-400'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                    <div className="space-y-1 col-span-1">
                      <label className="block text-[10px] font-black text-emerald-950 uppercase tracking-wider">Dias Numéricos</label>
                      <input
                        type="number"
                        min="0"
                        value={warrantyDays}
                        onChange={(e) => setWarrantyDays(Math.max(0, Number(e.target.value)))}
                        className="w-full px-3.5 py-2 bg-white border-2 border-emerald-300 rounded-xl text-xs text-slate-950 font-bold font-mono"
                      />
                    </div>
                    <div className="sm:col-span-2 text-xs text-emerald-950 font-bold bg-white p-3 rounded-xl border border-emerald-200">
                      Garantia válida até: <strong className="text-emerald-700 font-mono text-sm ml-1">{
                        new Date(new Date(endDate || new Date().toISOString().split('T')[0]).getTime() + warrantyDays * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR')
                      }</strong>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-black text-emerald-950 uppercase tracking-wider">Observações / Cobertura da Garantia</label>
                    <input
                      type="text"
                      placeholder="Ex: Garantia cobre montagem, vedações novas e estanqueidade contra vazamento..."
                      value={warrantyNotes}
                      onChange={(e) => setWarrantyNotes(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-emerald-300 rounded-xl text-xs text-slate-950 font-bold placeholder-slate-400"
                    />
                  </div>

                  {/* Finance Integration Section */}
                  <div className="space-y-3 p-4 bg-white border-2 border-emerald-200 rounded-xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-emerald-900 font-black text-xs uppercase tracking-wider">
                        <DollarSign className="w-4 h-4 text-emerald-600" />
                        <span>Lançar Receita Automaticamente no Financeiro</span>
                      </div>
                      <input
                        id="form-chk-add-to-finance"
                        type="checkbox"
                        checked={addToFinance}
                        onChange={(e) => setAddToFinance(e.target.checked)}
                        className="w-5 h-5 rounded border-2 border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                    </div>

                    {addToFinance && (
                      <div className="space-y-3 pt-3 border-t border-slate-200 animate-in fade-in duration-150">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="block text-[10px] font-black text-slate-700 uppercase tracking-wider">Categoria</label>
                            <select
                              id="form-sel-finance-category"
                              value={financeCategory}
                              onChange={(e) => setFinanceCategory(e.target.value)}
                              className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold"
                            >
                              <option value="Mão de Obra">Mão de Obra</option>
                              <option value="Peças">Peças</option>
                              <option value="Contrato Mensal">Contrato Mensal</option>
                              <option value="Inspeção / Certificação">Inspeção / Certificação</option>
                              <option value="Outros">Outros</option>
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="block text-[10px] font-black text-slate-700 uppercase tracking-wider">Situação</label>
                            <select
                              id="form-sel-finance-status"
                              value={financeStatus}
                              onChange={(e) => setFinanceStatus(e.target.value as any)}
                              className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold"
                            >
                              <option value="PAID">Pago (Recebido)</option>
                              <option value="PENDING">Pendente (A Receber)</option>
                            </select>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[10px] font-black text-slate-700 uppercase tracking-wider">Valor do Lançamento (R$)</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">R$</span>
                            <input
                              id="form-num-finance-amount"
                              type="number"
                              step="0.01"
                              min="0"
                              value={financeAmount}
                              onChange={(e) => setFinanceAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                              className="w-full pl-9 pr-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-black font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Section 6: Controle de Permanência & Entrega */}
              <div className="space-y-4 p-5 bg-white border-2 border-slate-200 rounded-2xl shadow-xs">
                <div className="border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-[#1b365d] flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-[#0052cc]" />
                    Controle de Permanência & Entrega do Equipamento
                  </h4>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div className="space-y-0.5">
                    <span className="block text-xs font-black uppercase tracking-wider text-slate-900">Equipamento já foi Entregue ao Cliente?</span>
                    <span className="block text-[11px] text-slate-600 font-medium">Marque para registrar a baixa de saída e permanência total</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsDelivered(!isDelivered);
                      if (!isDelivered && !deliveryDate) {
                        setDeliveryDate(new Date().toISOString().split('T')[0]);
                      }
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider border-2 transition-all cursor-pointer ${
                      isDelivered
                        ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                        : 'bg-white border-slate-300 text-slate-700 hover:border-slate-400'
                    }`}
                  >
                    {isDelivered ? 'Sim (Equipamento Entregue)' : 'Não (Ainda na Empresa)'}
                  </button>
                </div>

                {isDelivered && (
                  <div className="space-y-1.5 animate-in fade-in duration-150">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-900">
                      Data da Entrega / Retirada *
                    </label>
                    <input
                      type="date"
                      value={deliveryDate}
                      onChange={(e) => setDeliveryDate(e.target.value)}
                      max={new Date().toISOString().split('T')[0]}
                      className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-950 font-bold focus:border-[#0052cc]"
                      required={isDelivered}
                    />
                  </div>
                )}

                {startDate && (
                  <div className="p-3 bg-blue-50/70 border-2 border-blue-200 rounded-xl flex items-center justify-between text-xs">
                    <span className="text-[#1b365d] uppercase tracking-wider font-black">Resumo de Estadia:</span>
                    <span className="font-black text-[#0052cc]">
                      {(() => {
                        const start = new Date(startDate + 'T00:00:00');
                        const end = isDelivered && deliveryDate ? new Date(deliveryDate + 'T00:00:00') : new Date();
                        end.setHours(0, 0, 0, 0);
                        const diffTime = end.getTime() - start.getTime();
                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
                        const days = Math.max(1, diffDays);
                        return isDelivered 
                          ? `Total de ${days} ${days === 1 ? 'dia' : 'dias'} de permanência até a entrega final.`
                          : `Atualmente com ${days} ${days === 1 ? 'dia' : 'dias'} de permanência na oficina.`;
                      })()}
                    </span>
                  </div>
                )}
              </div>

              {status === 'COMPLETED' && (
                <div className="p-4 bg-emerald-50 rounded-2xl border-2 border-emerald-300 text-xs text-emerald-950 font-bold flex items-start gap-2 shadow-xs">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <p>Ao salvar como Concluída, esta Ordem de Serviço será registrada automaticamente na ficha de histórico de manutenção do equipamento.</p>
                </div>
              )}

              {/* Modal Footer */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t-2 border-slate-200">
                <button
                  id="btn-cancel-os-form"
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 text-xs font-black uppercase tracking-wider text-slate-700 hover:text-slate-950 hover:bg-slate-200/80 bg-white border-2 border-slate-300 rounded-xl transition-colors cursor-pointer shadow-xs"
                >
                  Cancelar
                </button>
                <button
                  id="btn-submit-os-form"
                  type="submit"
                  className="px-6 py-2.5 text-xs font-black uppercase tracking-wider text-white bg-[#1b365d] hover:bg-[#0052cc] rounded-xl transition-all shadow-md hover:shadow-lg cursor-pointer flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingOrder ? 'SALVAR ALTERAÇÕES' : 'ABRIR ORDEM'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete OS Confirmation Modal */}
      {deleteOrderConfirmation && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-150" id="delete-os-modal">
          <div className="absolute inset-0 bg-[#000000]/75 backdrop-blur-xs" onClick={() => setDeleteOrderConfirmation(null)}></div>
          <div className="relative bg-[#11131c] rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-red-500/20 p-6 space-y-4">
            <div className="flex items-center gap-3 text-red-400">
              <div className="p-2 bg-red-950/30 rounded-xl border border-red-500/15">
                <Trash2 className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-slate-100 text-sm uppercase tracking-wider">Confirmar Exclusão</h3>
            </div>
            
            <p className="text-xs text-slate-300 leading-relaxed">
              Tem certeza de que deseja excluir a Ordem de Serviço <strong className="text-white">{deleteOrderConfirmation.osNumber}</strong>?
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                id="btn-cancel-delete-os"
                onClick={() => setDeleteOrderConfirmation(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                id="btn-confirm-delete-os"
                onClick={() => {
                  onDeleteOrder(deleteOrderConfirmation.id);
                  setDeleteOrderConfirmation(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors shadow-lg shadow-red-900/20 cursor-pointer"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Complete OS & Setup Warranty Modal */}
      {completionConfirmation && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-150" id="complete-os-modal">
          <div className="absolute inset-0 bg-[#000000]/75 backdrop-blur-xs" onClick={() => setCompletionConfirmation(null)}></div>
          <div className="relative bg-[#11131c] rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-slate-800/80 p-6 space-y-4">
            <div className="flex items-center gap-3 text-emerald-400">
              <div className="p-2 bg-emerald-950/30 rounded-xl border border-emerald-500/15">
                <Shield className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-slate-100 text-sm uppercase tracking-wider">Finalizar OS {completionConfirmation.osNumber}</h3>
            </div>
            
            <p className="text-xs text-slate-300 leading-relaxed">
              Você está prestes a concluir a ordem <strong className="text-white">"{completionConfirmation.title}"</strong>. 
              Ao finalizar, defina o tempo de garantia do serviço abaixo:
            </p>

            <div className="space-y-3 p-3 bg-[#0c0d10] border border-emerald-950/40 rounded-xl">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tempo de Garantia</label>
                <div className="grid grid-cols-5 gap-1">
                  {[
                    { label: 'Sem Gar.', val: 0 },
                    { label: '30 Dias', val: 30 },
                    { label: '90 Dias', val: 90 },
                    { label: '180 Dias', val: 180 },
                    { label: '1 Ano', val: 365 },
                  ].map((preset) => (
                    <button
                      key={preset.val}
                      type="button"
                      onClick={() => setWarrantyDays(preset.val)}
                      className={`py-1 rounded-lg text-[9px] font-bold border transition-all cursor-pointer ${
                        warrantyDays === preset.val
                          ? 'bg-emerald-950/40 border-emerald-500 text-emerald-400'
                          : 'bg-[#11131c] border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 items-end">
                <div className="space-y-1 col-span-1">
                  <label className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Dias</label>
                  <input
                    type="number"
                    min="0"
                    value={warrantyDays}
                    onChange={(e) => setWarrantyDays(Math.max(0, Number(e.target.value)))}
                    className="w-full px-2 py-1 bg-[#11131c] border border-slate-800 rounded-lg text-xs text-white font-mono focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
                <div className="col-span-2 text-[9px] text-slate-400 pb-1.5">
                  Válida até: <strong className="text-emerald-400 font-mono">{
                    new Date(new Date().getTime() + warrantyDays * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR')
                  }</strong>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider">Observações da Garantia</label>
                <input
                  type="text"
                  placeholder="Opcional. Ex: Cobertura total de peças..."
                  value={warrantyNotes}
                  onChange={(e) => setWarrantyNotes(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#11131c] border border-slate-800 rounded-lg text-xs text-white placeholder-slate-700 focus:outline-hidden focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Finance Integration Section */}
            <div className="space-y-3 p-3 bg-[#0c0d10] border border-cyan-950/40 rounded-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-cyan-400">
                  <DollarSign className="w-4 h-4" />
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-200">Lançar no Financeiro</span>
                </div>
                <input
                  id="chk-add-to-finance"
                  type="checkbox"
                  checked={addToFinance}
                  onChange={(e) => setAddToFinance(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-800 bg-[#11131c] text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 cursor-pointer"
                />
              </div>

              {addToFinance && (
                <div className="space-y-2.5 pt-1.5 border-t border-slate-900/60 animate-in fade-in duration-150">
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="space-y-1">
                      <label className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Categoria</label>
                      <select
                        id="sel-finance-category"
                        value={financeCategory}
                        onChange={(e) => setFinanceCategory(e.target.value)}
                        className="w-full px-2 py-1 bg-[#11131c] border border-slate-800 rounded-lg text-[10px] text-white focus:outline-hidden focus:border-cyan-500"
                      >
                        <option value="Mão de Obra">Mão de Obra</option>
                        <option value="Peças">Peças</option>
                        <option value="Contrato Mensal">Contrato Mensal</option>
                        <option value="Inspeção / Certificação">Inspeção / Certificação</option>
                        <option value="Outros">Outros</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Situação</label>
                      <select
                        id="sel-finance-status"
                        value={financeStatus}
                        onChange={(e) => setFinanceStatus(e.target.value as any)}
                        className="w-full px-2 py-1 bg-[#11131c] border border-slate-800 rounded-lg text-[10px] text-white focus:outline-hidden focus:border-cyan-500"
                      >
                        <option value="PAID">Pago (Recebido)</option>
                        <option value="PENDING">Pendente (A Receber)</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Valor do Lançamento</label>
                    <div className="relative">
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-500">R$</span>
                      <input
                        id="num-finance-amount"
                        type="number"
                        step="0.01"
                        min="0"
                        value={financeAmount}
                        onChange={(e) => setFinanceAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                        className="w-full pl-6 pr-2 py-1 bg-[#11131c] border border-slate-800 rounded-lg text-[10px] text-white font-mono focus:outline-hidden focus:border-cyan-500"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-3 bg-slate-900/40 rounded-xl text-[10px] text-slate-400 flex items-start gap-1.5 border border-slate-850">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <p>Ao concluir, este serviço será adicionado automaticamente ao histórico do equipamento.</p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                id="btn-cancel-complete-os-modal"
                onClick={() => setCompletionConfirmation(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                id="btn-confirm-complete-os"
                onClick={handleConfirmCompletion}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-emerald-950/20 cursor-pointer"
              >
                Confirmar e Concluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Enviar Orçamento e Aprovação Modal */}
      {sharingOrder && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-150" id="share-budget-modal">
          <div className="absolute inset-0 bg-[#000000]/75 backdrop-blur-xs" onClick={() => setSharingOrder(null)}></div>
          <div className="relative bg-[#11131c] rounded-2xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-800/80 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
              <div className="flex items-center gap-3 text-emerald-400">
                <div className="p-2 bg-emerald-950/30 rounded-xl border border-emerald-500/15">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-100 text-sm uppercase tracking-wider">
                    {sharingOrder.status === 'COMPLETED' ? 'Enviar Cobrança' : 'Enviar Orçamento'}
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono block">OS {sharingOrder.osNumber}</span>
                </div>
              </div>
              <button 
                onClick={() => setSharingOrder(null)}
                className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Checkbox to include PIX info */}
            <div className="p-3 bg-slate-950/20 border border-slate-800 rounded-xl flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-slate-200 block">Incluir Dados de Pagamento via PIX</span>
                  <span className="text-[10px] text-slate-400 block">Adiciona os dados da conta PIX da sua empresa para pagamento imediato</span>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={includePix} 
                  onChange={(e) => {
                    handleTogglePixInOSShare(e.target.checked);
                  }}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-800 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500 peer-checked:after:bg-white peer-checked:after:border-transparent"></div>
              </label>
            </div>

            {/* PIX inline settings if checked */}
            {includePix && (
              <div className="p-3.5 bg-[#0c0d10] border border-slate-850 rounded-xl space-y-3">
                <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Configuração de Pagamento PIX</span>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[8px] font-bold uppercase tracking-wider text-slate-400">Tipo de Chave</label>
                    <select
                      value={localPixType}
                      onChange={(e) => {
                        setLocalPixType(e.target.value);
                        const updated = { type: e.target.value, key: localPixKey, name: localPixName, city: localPixCity };
                        localStorage.setItem('oficina_company_pix', JSON.stringify(updated));
                        handleTogglePixInOSShare(true, localPixKey, e.target.value, localPixName, localPixCity);
                      }}
                      className="w-full px-2 py-1.5 bg-[#11131c] border border-slate-800 rounded-lg text-[10px] text-slate-300 focus:outline-hidden focus:border-emerald-500"
                    >
                      <option value="CNPJ">CNPJ</option>
                      <option value="CPF">CPF</option>
                      <option value="CELULAR">Celular</option>
                      <option value="EMAIL">E-mail</option>
                      <option value="CHAVE_ALEATORIA">Chave Aleatória</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[8px] font-bold uppercase tracking-wider text-slate-400">Chave PIX</label>
                    <input
                      type="text"
                      placeholder="Chave PIX"
                      value={localPixKey}
                      onChange={(e) => {
                        setLocalPixKey(e.target.value);
                        const updated = { type: localPixType, key: e.target.value, name: localPixName, city: localPixCity };
                        localStorage.setItem('oficina_company_pix', JSON.stringify(updated));
                        handleTogglePixInOSShare(true, e.target.value, localPixType, localPixName, localPixCity);
                      }}
                      className="w-full px-2 py-1.5 bg-[#11131c] border border-slate-800 rounded-lg text-[10px] text-white font-mono focus:outline-hidden focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[8px] font-bold uppercase tracking-wider text-slate-400">Recebedor / Beneficiário</label>
                    <input
                      type="text"
                      placeholder="Nome do Beneficiário"
                      value={localPixName}
                      onChange={(e) => {
                        setLocalPixName(e.target.value);
                        const updated = { type: localPixType, key: localPixKey, name: e.target.value, city: localPixCity };
                        localStorage.setItem('oficina_company_pix', JSON.stringify(updated));
                        handleTogglePixInOSShare(true, localPixKey, localPixType, e.target.value, localPixCity);
                      }}
                      className="w-full px-2 py-1.5 bg-[#11131c] border border-slate-800 rounded-lg text-[10px] text-white focus:outline-hidden focus:border-emerald-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[8px] font-bold uppercase tracking-wider text-slate-400">Cidade</label>
                    <input
                      type="text"
                      placeholder="Cidade"
                      value={localPixCity}
                      onChange={(e) => {
                        setLocalPixCity(e.target.value);
                        const updated = { type: localPixType, key: localPixKey, name: localPixName, city: e.target.value };
                        localStorage.setItem('oficina_company_pix', JSON.stringify(updated));
                        handleTogglePixInOSShare(true, localPixKey, localPixType, localPixName, e.target.value);
                      }}
                      className="w-full px-2 py-1.5 bg-[#11131c] border border-slate-800 rounded-lg text-[10px] text-white focus:outline-hidden focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Destination Contact Selection */}
            <div className="space-y-2 bg-[#0c0d10] p-3.5 rounded-xl border border-slate-800">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Destinatário do Envio
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* Client Registered Option */}
                {(() => {
                  const client = clients.find(c => c.id === sharingOrder.clientId);
                  return (
                    <div
                      onClick={() => setShareRecipientType('CLIENT')}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start gap-2.5 ${
                        shareRecipientType === 'CLIENT'
                          ? 'bg-[#181e30] border-cyan-500/60 ring-1 ring-cyan-500/30'
                          : 'bg-[#11131c] border-slate-800/80 hover:border-slate-700'
                      }`}
                    >
                      <input
                        type="radio"
                        name="somRecipientType"
                        checked={shareRecipientType === 'CLIENT'}
                        onChange={() => setShareRecipientType('CLIENT')}
                        className="mt-0.5 w-3.5 h-3.5 text-cyan-500 bg-white border-slate-400 cursor-pointer accent-cyan-500"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-xs flex items-center gap-1">
                            <User className="w-3 h-3 text-cyan-400" />
                            Contato do Cliente
                          </span>
                          <span className="text-[8px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                            Padrão
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-200 font-semibold truncate">
                          {client?.name || 'Cliente'}
                        </p>
                        <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Phone className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                          <span className="truncate">{client?.phone || 'Sem telefone cadastrado'}</span>
                        </p>
                      </div>
                    </div>
                  );
                })()}

                {/* Custom Contact Option */}
                <div
                  onClick={() => setShareRecipientType('CUSTOM')}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start gap-2.5 ${
                    shareRecipientType === 'CUSTOM'
                      ? 'bg-[#181e30] border-cyan-500/60 ring-1 ring-cyan-500/30'
                      : 'bg-[#11131c] border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="somRecipientType"
                    checked={shareRecipientType === 'CUSTOM'}
                    onChange={() => setShareRecipientType('CUSTOM')}
                    className="mt-0.5 w-3.5 h-3.5 text-cyan-500 bg-white border-slate-400 cursor-pointer accent-cyan-500"
                  />
                  <div className="flex-1 min-w-0">
                    <span className="font-bold text-white text-xs flex items-center gap-1">
                      <Phone className="w-3 h-3 text-emerald-400" />
                      Outro Número / E-mail
                    </span>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Enviar para outro telefone ou endereço personalizado
                    </p>
                  </div>
                </div>
              </div>

              {/* Input for custom phone/email if CUSTOM is selected */}
              {shareRecipientType === 'CUSTOM' && (
                <div className="pt-2 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-3" onClick={(e) => e.stopPropagation()}>
                  <div>
                    <label className="block text-[9px] font-bold text-slate-300 uppercase tracking-wider mb-1">
                      WhatsApp de Destino (com DDD)
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: (21) 98765-4321 ou 21987654321"
                      value={shareCustomPhone}
                      onChange={(e) => setShareCustomPhone(e.target.value)}
                      autoFocus
                      className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-black font-bold text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-bold text-slate-300 uppercase tracking-wider mb-1">
                      E-mail de Destino (Opcional)
                    </label>
                    <input
                      type="email"
                      placeholder="Ex: financeiro@cliente.com.br"
                      value={shareCustomEmail}
                      onChange={(e) => setShareCustomEmail(e.target.value)}
                      className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-black font-bold text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Side-by-side Text & QR Code block */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2 space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Mensagem para Envio</span>
                  <span className="text-[9px] text-slate-500 normal-case font-normal">(Você pode editar antes de enviar)</span>
                </label>
                <textarea
                  rows={8}
                  value={customShareMessage}
                  onChange={(e) => setCustomShareMessage(e.target.value)}
                  className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-slate-200 font-mono focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/30 leading-relaxed"
                ></textarea>
              </div>

              {includePix ? (
                <div className="flex flex-col items-center justify-center p-3 bg-[#0c0d10] border border-slate-800 rounded-xl space-y-2">
                  <span className="text-[9px] font-extrabold uppercase tracking-widest text-slate-400 text-center">QR Code PIX</span>
                  
                  <div className="relative p-2 bg-white rounded-lg flex flex-col items-center justify-center w-24 h-24 shadow-md">
                    <QrCode className="w-20 h-20 text-slate-900" />
                    <span className="absolute bottom-0.5 text-[6px] text-slate-900 font-extrabold tracking-widest">PIX SEGURO</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const mockCode = generateMockPixCode(localPixKey || 'pix@empresa.com', localPixName || 'Oficina Ltda', localPixCity || 'Sao Paulo', sharingOrder.estimatedCost);
                      navigator.clipboard.writeText(mockCode);
                      setCopyPixCodeFeedback(true);
                      setTimeout(() => setCopyPixCodeFeedback(false), 2000);
                    }}
                    className={`w-full py-1 px-1.5 rounded-lg text-[9px] font-bold uppercase transition-all flex items-center justify-center gap-1 cursor-pointer border ${
                      copyPixCodeFeedback
                        ? 'bg-emerald-950/40 border-emerald-500 text-emerald-400'
                        : 'bg-[#11131c] border-slate-800 text-slate-300 hover:bg-slate-900'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{copyPixCodeFeedback ? 'PIX Copiado!' : 'Copiar Copia/Cola'}</span>
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center p-4 bg-[#0c0d10]/40 border border-slate-800 border-dashed rounded-xl text-center text-[10px] text-slate-500">
                  <Key className="w-6 h-6 text-slate-600 mb-2" />
                  <span>Ative "Incluir Dados PIX" para gerar QR Code de pagamento e anexar chave PIX no texto.</span>
                </div>
              )}
            </div>

            {/* Sharing buttons */}
            <div className="grid grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => {
                  const client = clients.find(c => c.id === sharingOrder.clientId);
                  const rawPhone = shareRecipientType === 'CLIENT' ? (client?.phone || '') : shareCustomPhone;
                  const digits = rawPhone.replace(/\D/g, '');
                  const phoneWithDDI = (digits.length === 10 || digits.length === 11) ? `55${digits}` : digits;
                  const url = phoneWithDDI 
                    ? `https://api.whatsapp.com/send?phone=${phoneWithDDI}&text=${encodeURIComponent(customShareMessage)}`
                    : `https://api.whatsapp.com/send?text=${encodeURIComponent(customShareMessage)}`;
                  window.open(url, '_blank');
                }}
                className="py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/25 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>
              
              <button
                type="button"
                onClick={() => {
                  const client = clients.find(c => c.id === sharingOrder.clientId);
                  const targetEmail = shareRecipientType === 'CLIENT' ? (client?.email || '') : shareCustomEmail;
                  const subject = sharingOrder.status === 'COMPLETED' 
                    ? `Cobrança de Manutenção Concluída - OS ${sharingOrder.osNumber} - ${client?.name || ''}`
                    : `Orçamento para OS ${sharingOrder.osNumber} - ${client?.name || ''}`;
                  const url = `mailto:${encodeURIComponent(targetEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(customShareMessage)}`;
                  window.open(url, '_blank');
                }}
                className="py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-blue-950/25 cursor-pointer"
              >
                <Mail className="w-4 h-4" />
                <span>E-mail</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(customShareMessage);
                  setCopyFeedback(true);
                  setTimeout(() => setCopyFeedback(false), 2000);
                }}
                className={`py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer border ${
                  copyFeedback 
                    ? 'bg-emerald-950/40 border-emerald-500 text-emerald-400' 
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850 hover:text-white'
                }`}
              >
                <CheckCircle2 className={`w-4 h-4 ${copyFeedback ? 'text-emerald-400 animate-bounce' : 'text-slate-400'}`} />
                <span>{copyFeedback ? 'Copiado!' : 'Copiar'}</span>
              </button>
            </div>

            {/* Quick approval buttons (only for non-completed OS) */}
            {sharingOrder.status !== 'COMPLETED' && (
              <div className="p-4 bg-[#0c0d10] border border-slate-800/80 rounded-xl space-y-3">
                <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-cyan-400" />
                  Ações Rápidas de Aprovação
                </span>
                <p className="text-[10px] text-slate-400 leading-normal">
                  Após falar com o cliente, você pode marcar a resposta dele e alterar o status da Ordem de Serviço imediatamente:
                </p>
                
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      const approvedOrder: ServiceOrder = {
                        ...sharingOrder,
                        budgetStatus: 'APPROVED',
                        status: sharingOrder.status === 'PENDING' ? 'IN_PROGRESS' : sharingOrder.status
                      };
                      onEditOrder(approvedOrder);
                      setSharingOrder(null);
                    }}
                    className="py-2 bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-400 border border-emerald-500/30 hover:border-emerald-500/60 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Aprovar & Iniciar
                  </button>
                  
                  <button
                    type="button"
                    onClick={() => {
                      const rejectedOrder: ServiceOrder = {
                        ...sharingOrder,
                        budgetStatus: 'REJECTED'
                      };
                      onEditOrder(rejectedOrder);
                      setSharingOrder(null);
                    }}
                    className="py-2 bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-500/30 hover:border-red-500/60 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1"
                  >
                    <X className="w-3.5 h-3.5" />
                    Rejeitar Orçamento
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Lightbox / Image Viewer modal */}
      {activePhotoUrl && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 animate-in fade-in duration-150" id="photo-lightbox-modal">
          <div className="absolute inset-0 bg-[#000000]/90 backdrop-blur-xs" onClick={() => setActivePhotoUrl(null)}></div>
          <div className="relative max-w-3xl w-full max-h-[85vh] flex flex-col items-center justify-center space-y-4">
            <button
              id="btn-close-lightbox"
              onClick={() => setActivePhotoUrl(null)}
              className="absolute -top-12 right-0 p-2 text-slate-400 hover:text-white bg-slate-900/60 border border-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="bg-[#11131c] p-2 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden max-h-[80vh] flex items-center justify-center">
              <img 
                src={activePhotoUrl} 
                alt="Foto de Entrada Ampliada" 
                className="max-w-full max-h-[75vh] object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      )}

      {/* Relatório do Cliente (PDF) Modal */}
      {viewingReportOrder && (() => {
        const client = clients.find(c => c.id === viewingReportOrder.clientId);
        const equipment = equipments.find(e => e.id === viewingReportOrder.equipmentId);
        const warranty = getWarrantyStatus(viewingReportOrder);
        const stay = getStayStatus(viewingReportOrder);

        const clientName = client ? client.name : 'Cliente';
        const clientPhone = client?.phone || '';
        const cleanPhone = clientPhone.replace(/\D/g, '');
        const equipName = equipment ? `${equipment.name} (${equipment.model})` : 'Equipamento';
        const costText = `R$ ${(viewingReportOrder.estimatedCost || 0).toFixed(2)}`;
        const warrantyDaysText = viewingReportOrder.warrantyDays ? `${viewingReportOrder.warrantyDays} dias` : 'Sem garantia';
        const formattedEndDate = viewingReportOrder.endDate 
          ? new Date(viewingReportOrder.endDate + 'T00:00:00').toLocaleDateString('pt-BR')
          : new Date().toLocaleDateString('pt-BR');
        const formattedStartDate = viewingReportOrder.startDate
          ? new Date(viewingReportOrder.startDate + 'T00:00:00').toLocaleDateString('pt-BR')
          : 'N/A';

        // Share Message
        const shareMsg = `Olá, *${clientName}*! 🛠️\n\n` +
          `Aqui está o *Relatório Técnico de Execução de Serviço* do seu equipamento *${equipName}*.\n\n` +
          `🏢 *EMPRESA:* JC&F - MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA\n` +
          `📝 *OS:* ${viewingReportOrder.osNumber}\n` +
          `🔧 *SERVIÇO EFETUADO:*\n${viewingReportOrder.plannedServices || 'Manutenção executada.'}\n\n` +
          `📅 *DATA CONCLUSÃO:* ${formattedEndDate}\n` +
          `🛡️ *GARANTIA:* ${warrantyDaysText} (Válida até ${warranty.dateStr || 'N/A'})\n` +
          `💵 *VALOR TOTAL:* ${costText}\n\n` +
          `Agradecemos a confiança! Enviamos este relatório técnico para registro.`;

        const mailSubject = `Relatório Técnico de Serviço - OS ${viewingReportOrder.osNumber} - JC&F`;

        return (
          <div className="fixed inset-0 z-[110] flex flex-col items-center justify-start overflow-y-auto p-4 sm:p-6 md:p-10 animate-in fade-in duration-150" id="client-report-modal">
            <div className="absolute inset-0 bg-[#000000]/80 backdrop-blur-xs print:hidden" onClick={() => setViewingReportOrder(null)}></div>
            
            <style>{`
              @media print {
                body * {
                  visibility: hidden !important;
                }
                #printable-client-report, #printable-client-report * {
                  visibility: visible !important;
                }
                #printable-client-report {
                  position: absolute !important;
                  left: 0 !important;
                  top: 0 !important;
                  width: 100% !important;
                  background: white !important;
                  color: black !important;
                  padding: 1.5cm !important;
                  box-shadow: none !important;
                  border: none !important;
                }
              }
            `}</style>

            {/* Modal Controls (hidden on print) */}
            <div className="relative bg-[#11131c] rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden border border-slate-800/80 p-5 mb-4 flex flex-col sm:flex-row items-center justify-between gap-4 z-10 print:hidden">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-cyan-950/40 rounded-xl border border-cyan-500/20 text-cyan-400">
                  <ClipboardList className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="font-extrabold text-slate-100 text-sm uppercase tracking-wider">
                    Relatório do Cliente (PDF)
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono block">OS {viewingReportOrder.osNumber} • Concluída</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => {
                    const url = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(shareMsg)}`;
                    window.open(url, '_blank');
                  }}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                  title="Enviar via WhatsApp"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const url = `mailto:?subject=${encodeURIComponent(mailSubject)}&body=${encodeURIComponent(shareMsg)}`;
                    window.open(url, '_blank');
                  }}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                  title="Enviar por E-mail"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>E-mail</span>
                </button>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-cyan-950/20"
                  title="Imprimir / Salvar PDF"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Imprimir PDF</span>
                </button>

                <button
                  type="button"
                  onClick={() => setViewingReportOrder(null)}
                  className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer border border-slate-800"
                  title="Fechar"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Report Document Sheet */}
            <div 
              id="printable-client-report"
              className="relative bg-white text-slate-800 w-full max-w-3xl rounded-2xl shadow-2xl p-4 sm:p-8 md:p-10 border border-slate-200 text-left font-sans z-10 overflow-hidden leading-relaxed"
            >
              {/* Header Branding */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 border-b border-slate-200 pb-6 mb-6">
                <div className="flex items-start sm:items-center gap-3 sm:gap-4 text-slate-800 w-full md:w-auto">
                  <div className="p-1 bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-center shrink-0">
                    <JCFLogoIcon />
                  </div>
                  <div>
                    <h1 className="font-extrabold text-xs sm:text-base tracking-wider text-slate-900 uppercase">
                      JC&F - MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA
                    </h1>
                    <p className="text-[9px] sm:text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">
                      Sistemas de Alta Performance em Hidráulica e Pneumática
                    </p>
                    <p className="text-[9px] sm:text-[10px] text-slate-400 font-medium mt-1">
                      Manutenção Preventiva, Corretiva, Vedação, Válvulas e Cilindros Industriais
                    </p>
                  </div>
                </div>
                
                <div className="text-left md:text-right border-t md:border-t-0 border-slate-100 pt-4 md:pt-0 w-full md:w-auto text-slate-850">
                  <span className="inline-block px-3 py-1 bg-cyan-50 border border-cyan-150 text-cyan-700 font-black text-xs uppercase tracking-widest rounded-lg">
                    OS {viewingReportOrder.osNumber}
                  </span>
                  <div className="text-[10px] text-slate-500 mt-2 font-medium">
                    <p>Emissão: {formattedStartDate}</p>
                    <p>Encerramento: {formattedEndDate}</p>
                    <p className="text-slate-700 font-bold mt-0.5">Status: CONCLUÍDA</p>
                  </div>
                </div>
              </div>

              {/* Title Section */}
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-4 mb-6 text-center">
                <h2 className="text-sm font-black uppercase tracking-wider text-slate-800">
                  Relatório Técnico de Execução de Serviço
                </h2>
                <p className="text-[10px] text-slate-500 mt-1">
                  Este documento comprova a realização das manutenções e testes de qualidade no equipamento abaixo.
                </p>
              </div>

              {/* Two-Column Details (Client & Equipment) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                {/* Client Box */}
                <div className="bg-[#fcfcfd] border border-slate-150 rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-1.5 text-slate-900 font-bold uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
                    <User className="w-3.5 h-3.5 text-cyan-600" />
                    <span>Identificação do Cliente</span>
                  </div>
                  <div className="text-[11px] space-y-1 text-slate-600">
                    <p><strong className="text-slate-800">Nome:</strong> {client?.name || 'Não cadastrado'}</p>
                    <p><strong className="text-slate-800">CPF / CNPJ:</strong> {client?.document || 'Não cadastrado'}</p>
                    <p><strong className="text-slate-800">Telefone:</strong> {client?.phone || 'Não cadastrado'}</p>
                    <p><strong className="text-slate-800">Endereço:</strong> {client?.address || 'Não cadastrado'}</p>
                  </div>
                </div>

                {/* Equipment Box */}
                <div className="bg-[#fcfcfd] border border-slate-150 rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-1.5 text-slate-900 font-bold uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-cyan-600" />
                    <span>Dados do Equipamento</span>
                  </div>
                  <div className="text-[11px] space-y-1 text-slate-600">
                    <p><strong className="text-slate-800">Equipamento:</strong> {equipment?.name || 'Não informado'}</p>
                    <p><strong className="text-slate-800">Marca / Modelo:</strong> {equipment?.model || 'Não informado'}</p>
                    <p><strong className="text-slate-800">Tipo:</strong> {equipment?.type || 'N/A'}</p>
                    <p><strong className="text-slate-800">Técnico Responsável:</strong> {viewingReportOrder.technician}</p>
                    <p><strong className="text-slate-800">Recebedor do Equipamento:</strong> {viewingReportOrder.receiverName || viewingReportOrder.technician}</p>
                  </div>
                </div>
              </div>

              {/* Diagnostic Box */}
              <div className="space-y-2 mb-6 border border-slate-200/50 rounded-xl p-4 bg-[#fcfcfd]">
                <div className="flex items-center gap-1.5 text-slate-900 font-bold uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
                  <ClipboardList className="w-3.5 h-3.5 text-cyan-600" />
                  <span>Situação Verificada (Diagnóstico Técnico)</span>
                </div>
                <div className="text-[11px] text-slate-600 whitespace-pre-line leading-relaxed min-h-[40px]">
                  {viewingReportOrder.diagnostic || 'Nenhum diagnóstico técnico registrado.'}
                </div>
              </div>

              {/* Planned Services (Performed Services) */}
              <div className="space-y-2 mb-6 border border-slate-200/50 rounded-xl p-4 bg-[#fcfcfd]">
                <div className="flex items-center gap-1.5 text-slate-900 font-bold uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-600" />
                  <span>Ações Efetuadas (Serviços Realizados e Peças Aplicadas)</span>
                </div>
                <div className="text-[11px] text-slate-600 whitespace-pre-line leading-relaxed min-h-[40px]">
                  {viewingReportOrder.plannedServices || 'Manutenção geral executada sem detalhamento de etapas.'}
                </div>
              </div>

              {/* Optional Equipment Photo */}
              {viewingReportOrder.equipmentPhoto && (
                <div className="mb-6 space-y-2">
                  <div className="flex items-center gap-1.5 text-slate-900 font-bold uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
                    <Camera className="w-3.5 h-3.5 text-cyan-600" />
                    <span>Registro Fotográfico de Entrada / Recebimento</span>
                  </div>
                  <div className="flex justify-center bg-slate-50 border border-slate-150 rounded-xl p-3">
                    <img 
                      src={viewingReportOrder.equipmentPhoto} 
                      alt="Registro fotográfico" 
                      className="max-h-48 object-contain rounded-lg border border-slate-200 shadow-xs" 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>
              )}

              {/* Value and Warranty Summary */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
                {/* Warranty Info */}
                <div className="bg-[#fcfcfd] border border-slate-150 rounded-xl p-4 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 text-slate-900 font-bold uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1.5">
                      <Shield className="w-3.5 h-3.5 text-cyan-600" />
                      <span>Termos de Garantia</span>
                    </div>
                    <div className="text-[11px] text-slate-600 space-y-1">
                      <p><strong className="text-slate-800">Período:</strong> {warrantyDaysText}</p>
                      {viewingReportOrder.warrantyDays ? (
                        <p><strong className="text-slate-800">Validade:</strong> Válida até {warranty.dateStr}</p>
                      ) : null}
                      {viewingReportOrder.warrantyNotes ? (
                        <p className="mt-1 text-[10px] text-slate-500 italic">" {viewingReportOrder.warrantyNotes} "</p>
                      ) : (
                        <p className="mt-1 text-[10px] text-slate-500 italic">Garantia sobre os serviços executados e peças trocadas.</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Total Value */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 flex flex-col justify-between items-center text-center">
                  <div className="w-full">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-500">Valor Total do Serviço</span>
                    <div className="text-2xl font-black text-cyan-700 font-mono mt-1">
                      {costText}
                    </div>
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono mt-2 leading-tight">
                    Preço calculado com base em peças fornecidas e horas de bancada técnica especializadas.
                  </div>
                </div>
              </div>

              {/* Signature Lines */}
              <div className="grid grid-cols-2 gap-10 mt-16 text-center text-[10px] text-slate-600">
                <div className="space-y-1.5">
                  <p className="border-t border-slate-300 pt-2 w-4/5 mx-auto text-slate-800 font-semibold">
                    {viewingReportOrder.technician}
                  </p>
                  <p className="font-extrabold text-slate-900 uppercase">Técnico Responsável</p>
                  <p className="text-[9px] text-slate-400">JC&F Manutenção</p>
                </div>
                
                <div className="space-y-1.5">
                  <p className="border-t border-slate-300 pt-2 w-4/5 mx-auto text-slate-800 font-semibold">
                    {client?.name || 'Representante do Cliente'}
                  </p>
                  <p className="font-extrabold text-slate-900 uppercase">Assinatura do Cliente</p>
                  <p className="text-[9px] text-slate-400">Data: ____/____/______</p>
                </div>
              </div>

              {/* Document footer note */}
              <div className="border-t border-slate-100 mt-12 pt-4 text-center text-[9px] text-slate-400 font-mono">
                JC&F - MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA • Painel Conectado Real-Time • Relatório de Conformidade
              </div>
            </div>
          </div>
        );
      })()}

      {/* ========================================================================= */}
      {/* MODAL: DUPLICATE OS AUTHORIZATION IN SERVICE ORDER MANAGER */}
      {/* ========================================================================= */}
      {duplicateWarning && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border-2 border-amber-500 max-w-lg w-full overflow-hidden animate-in fade-in zoom-in duration-200">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-red-800 to-amber-800 text-white p-4 flex items-center justify-between border-b-2 border-red-950">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-950/80 rounded-lg text-amber-300 border border-red-500/50">
                  <ShieldAlert className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-black text-sm uppercase tracking-wider text-white">
                    DISPOSITIVO ANTIDUPLICIDADE DE OS
                  </h3>
                  <p className="text-[11px] text-amber-200">
                    Alerta de proteção contra Ordens de Serviço repetidas
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDuplicateWarning(null)}
                className="text-amber-200 hover:text-white hover:bg-red-900/50 p-1.5 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 bg-slate-50 text-xs">
              
              <div className="bg-amber-50 border-l-4 border-amber-500 p-3 rounded-r-lg text-amber-950 space-y-1">
                <div className="font-extrabold flex items-center gap-1.5 text-amber-900">
                  <FileWarning className="w-4 h-4 text-amber-700" />
                  <span>OS EM ABERTO EXISTENTE ENCONTRADA</span>
                </div>
                <p className="text-slate-700 leading-relaxed">
                  Já existe <strong>{duplicateWarning.existingOrders.length} OS cadastrada em aberto</strong> para este cliente e equipamento.
                </p>
              </div>

              {/* Table of existing OS */}
              <div className="space-y-1">
                <label className="text-[10px] font-extrabold uppercase text-slate-700 tracking-wider">
                  OS EXISTENTE(S):
                </label>
                <div className="border border-slate-300 rounded-lg overflow-hidden bg-white max-h-36 overflow-y-auto">
                  <table className="w-full text-left text-[11px]">
                    <thead>
                      <tr className="bg-[#1b365d] text-white font-extrabold uppercase">
                        <th className="py-1 px-2">OS</th>
                        <th className="py-1 px-2">DATA</th>
                        <th className="py-1 px-2">STATUS</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-mono">
                      {duplicateWarning.existingOrders.map((o) => (
                        <tr key={o.id} className="hover:bg-amber-50">
                          <td className="py-1.5 px-2 font-black text-blue-900">{o.osNumber}</td>
                          <td className="py-1.5 px-2 text-slate-700">{o.startDate}</td>
                          <td className="py-1.5 px-2">
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 text-amber-800 uppercase">
                              {o.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Guidance note for twin machines */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-blue-950 space-y-1">
                <span className="font-bold block text-blue-900">2º EQUIPAMENTO IGUAL DO CLIENTE?</span>
                <p className="text-slate-700 text-[11px] leading-relaxed">
                  Se o cliente trouxe dois equipamentos idênticos (ex: 2 bombas iguais no mesmo lote), clique em <strong>AUTORIZAR CRIAÇÃO DE OS DUPLICADA</strong> para prosseguir.
                </p>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="bg-slate-100 p-4 border-t border-slate-300 flex flex-col sm:flex-row items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setDuplicateWarning(null)}
                className="w-full sm:w-auto px-4 py-2 bg-slate-300 hover:bg-slate-400 text-slate-800 font-extrabold text-xs uppercase rounded border border-slate-400 cursor-pointer"
              >
                CANCELAR (NÃO DUPLICAR)
              </button>

              <button
                type="button"
                onClick={handleConfirmDuplicateInManager}
                className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs uppercase rounded-lg border border-emerald-400 shadow cursor-pointer flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-200" />
                <span>AUTORIZAR CRIAÇÃO DE OS DUPLICADA</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: EXCLUSÃO DE OS CONFIRMAÇÃO */}
      {/* ========================================================================= */}
      {deleteOrderConfirmation && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4" id="modal-confirm-delete-os">
          <div className="bg-[#11131c] rounded-2xl shadow-2xl border-2 border-red-600 max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            {/* Header */}
            <div className="bg-gradient-to-r from-red-900 to-rose-950 text-white p-4 flex items-center justify-between border-b border-red-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-950/80 rounded-lg text-red-300 border border-red-500/50">
                  <Trash2 className="w-5 h-5 animate-bounce" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm uppercase tracking-wider text-white">
                    CONFIRMAR EXCLUSÃO DE OS
                  </h3>
                  <p className="text-[10px] text-red-200">
                    Ação irreversível de remoção do registro
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeleteOrderConfirmation(null)}
                className="text-red-200 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 text-slate-200">
              <div className="bg-red-950/40 border border-red-500/30 rounded-xl p-3 text-xs space-y-2">
                <p className="font-extrabold text-red-300 text-sm flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span>Excluir Ordem de Serviço {deleteOrderConfirmation.osNumber}?</span>
                </p>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  Esta ação excluirá permanentemente a Ordem de Serviço <strong className="text-white font-mono">{deleteOrderConfirmation.osNumber}</strong> do sistema e da sincronização de dados.
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="bg-[#0c0d10] p-4 border-t border-slate-800/80 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteOrderConfirmation(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase rounded-xl border border-slate-700 cursor-pointer transition-colors"
              >
                CANCELAR
              </button>
              <button
                type="button"
                id="btn-confirm-delete-os-action"
                onClick={() => {
                  onDeleteOrder(deleteOrderConfirmation.id);
                  setDeleteOrderConfirmation(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs uppercase rounded-xl border border-red-500 shadow-md cursor-pointer flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>EXCLUIR DEFINITIVAMENTE</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* MODAL: GERENCIAR RECEBEDORES / ATENDENTES */}
      {showReceiversModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border-2 border-slate-300 rounded-2xl max-w-md w-full p-6 shadow-2xl text-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                  <UserPlus className="w-5 h-5" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900">Gerenciar Recebedores / Atendentes</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowReceiversModal(false)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 font-medium">
              Cadastre os nomes dos atendentes que realizam a recepção de equipamentos na entrada ou remova cadastros desatualizados.
            </p>

            {/* FORMULARIO: NOVO RECEBEDOR */}
            <div className="space-y-2">
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wide">Novo Atendente / Recebedor</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Digite o nome do atendente..."
                  value={newReceiverInput}
                  onChange={(e) => setNewReceiverInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddReceiver(newReceiverInput);
                    }
                  }}
                  className="flex-1 px-3 py-2.5 bg-slate-50 border-2 border-slate-300 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 uppercase focus:outline-hidden focus:border-blue-600 focus:bg-white font-bold transition-all"
                />
                <button
                  type="button"
                  onClick={() => handleAddReceiver(newReceiverInput)}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar</span>
                </button>
              </div>
            </div>

            {/* LISTA DE RECEBEDORES */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wide">
                Atendentes Cadastrados ({activeReceivers.length})
              </label>
              <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                {activeReceivers.map((rec) => (
                  <div
                    key={rec}
                    className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 hover:border-blue-300 hover:bg-blue-50/50 transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                      <span className="uppercase text-slate-900">{rec}</span>
                      {rec === receiverName && (
                        <span className="text-[9px] bg-blue-100 text-blue-800 border border-blue-300 px-1.5 py-0.5 rounded uppercase font-extrabold">
                          Selecionado
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteReceiver(rec)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                      title={`Excluir ${rec}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setShowReceiversModal(false)}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-lg cursor-pointer shadow-xs transition-colors"
              >
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
