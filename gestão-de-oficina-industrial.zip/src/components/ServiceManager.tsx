import React, { useState } from 'react';
import { PlannedService } from '../types';
import { 
  Briefcase, Plus, Search, Edit2, Trash2, X, Check, FileText, Info, DollarSign,
  Share2, Printer, Copy, CheckCircle2, AlertTriangle, Layers, Tag
} from 'lucide-react';
import { generatePriceTablePDF } from '../utils/pdfGenerator';

interface ServiceManagerProps {
  services: PlannedService[];
  onAddService: (data: Omit<PlannedService, 'id' | 'createdAt'>) => void;
  onEditService: (service: PlannedService) => void;
  onDeleteService: (id: string) => void;
}

export default function ServiceManager({
  services,
  onAddService,
  onEditService,
  onDeleteService
}: ServiceManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<PlannedService | null>(null);

  // Form State
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Hidráulica');
  const [unit, setUnit] = useState('Serviço');
  const [estimatedCost, setEstimatedCost] = useState<number>(0);
  const [formError, setFormError] = useState('');
  const [deleteConfirmation, setDeleteConfirmation] = useState<PlannedService | null>(null);

  // Feedback Toast
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showFeedback = (message: string, type: 'success' | 'error' = 'success') => {
    setFeedback({ message, type });
    setTimeout(() => setFeedback(null), 3500);
  };

  const handleOpenAddModal = () => {
    setEditingService(null);
    const nextNum = services.length > 0 
      ? Math.max(...services.map(s => {
          const num = parseInt(s.code.replace(/\D/g, ''));
          return isNaN(num) ? 0 : num;
        })) + 1
      : 1;
    setCode(`SERV-H${String(nextNum).padStart(2, '0')}`);
    setName('');
    setDescription('');
    setCategory('Hidráulica');
    setUnit('Serviço');
    setEstimatedCost(0);
    setFormError('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (s: PlannedService) => {
    setEditingService(s);
    setCode(s.code);
    setName(s.name);
    setDescription(s.description);
    setCategory(s.category || 'Hidráulica');
    setUnit(s.unit || 'Serviço');
    setEstimatedCost(s.estimatedCost);
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim() || !description.trim()) {
      setFormError('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    const isDuplicateCode = services.some(s => 
      s.code.trim().toUpperCase() === code.trim().toUpperCase() && 
      (!editingService || s.id !== editingService.id)
    );

    if (isDuplicateCode) {
      setFormError('Este código de serviço já está em uso na tabela.');
      return;
    }

    if (editingService) {
      onEditService({
        ...editingService,
        code: code.trim().toUpperCase(),
        name: name.trim(),
        description: description.trim(),
        category,
        unit,
        estimatedCost: estimatedCost || 0
      });
      showFeedback(`Serviço "${code.trim().toUpperCase()}" atualizado com sucesso na tabela!`, 'success');
    } else {
      onAddService({
        code: code.trim().toUpperCase(),
        name: name.trim(),
        description: description.trim(),
        category,
        unit,
        estimatedCost: estimatedCost || 0
      });
      showFeedback(`Novo serviço "${code.trim().toUpperCase()}" cadastrado na tabela com sucesso!`, 'success');
    }

    setIsModalOpen(false);
  };

  // Categories list
  const CATEGORIES = ['Hidráulica', 'Pneumática', 'Mecânica', 'Usinagem', 'Eletrônica', 'Geral'];

  const filtered = services.filter(s => {
    const matchesQuery = s.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.category && s.category.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = selectedCategoryFilter === 'ALL' || (s.category || 'Geral') === selectedCategoryFilter;

    return matchesQuery && matchesCategory;
  });

  const formatBRL = (amount: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount);
  };

  // Share Price Table via WhatsApp text
  const handleExportWhatsAppTable = () => {
    if (filtered.length === 0) {
      showFeedback('Nenhum serviço disponível para exportar na tabela.', 'error');
      return;
    }

    let message = `📋 *TABELA OFICIAL DE PREÇOS DE MANUTENÇÃO - JC&F* 📋\n\n`;
    message += `Prezado(a) Cliente, apresentamos nossa tabela de serviços de manutenção predefinidos:\n\n`;

    filtered.forEach((s, idx) => {
      message += `🔹 *[${s.code}] ${s.name}*\n`;
      if (s.category) message += `   🏷️ _Categoria: ${s.category}_\n`;
      message += `   📝 Escopo: ${s.description}\n`;
      message += `   💰 *Valor de Tabela:* ${formatBRL(s.estimatedCost)}\n\n`;
    });

    message += `⚠️ *Nota:* Os valores de tabela podem ser ajustados conforme complexidade específica, peças adicionais necessárias e laudo do diagnóstico técnico.\n\n`;
    message += `*JC&F Manutenção Hidráulica e Pneumática*`;

    navigator.clipboard.writeText(message);
    const encoded = encodeURIComponent(message);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
    showFeedback('Tabela de preços formatada e copiada! Abrindo WhatsApp...', 'success');
  };

  const handleDownloadPDFTable = () => {
    if (filtered.length === 0) {
      showFeedback('Nenhum serviço disponível para gerar PDF da tabela.', 'error');
      return;
    }

    try {
      generatePriceTablePDF(filtered);
      showFeedback('PDF da Tabela de Preços gerado com sucesso!', 'success');
    } catch (err) {
      console.error(err);
      showFeedback('Erro ao gerar o PDF da Tabela de Preços.', 'error');
    }
  };

  return (
    <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="service-manager-root">
      
      {/* Toast Feedback Notification */}
      {feedback && (
        <div className={`p-4 mx-4 mt-4 rounded-xl border flex items-center justify-between gap-3 animate-in slide-in-from-top-2 duration-200 shadow-md ${
          feedback.type === 'success' 
            ? 'bg-emerald-50 border-emerald-300 text-emerald-900' 
            : 'bg-rose-50 border-rose-300 text-rose-900'
        }`} id="service-feedback-toast">
          <div className="flex items-center gap-2.5 text-xs font-bold">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
          <button 
            onClick={() => setFeedback(null)} 
            className="p-1 hover:bg-black/5 rounded-lg text-slate-500 hover:text-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-blue-900">
        <div className="space-y-0.5">
          <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-cyan-300" />
            Tabela de Preços & Serviços de Manutenção
          </h2>
          <p className="text-xs text-cyan-100">
            Cadastre, edite e gerencie os preços e escopos predefinidos. Anexe e envie a tabela oficial diretamente aos clientes.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleExportWhatsAppTable}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            title="Copiar e enviar tabela completa de preços via WhatsApp"
          >
            <Share2 className="w-4 h-4 text-emerald-200" />
            <span>Enviar via WhatsApp</span>
          </button>

          <button
            onClick={handleDownloadPDFTable}
            className="px-3.5 py-2 bg-[#12233c] hover:bg-[#0d1b30] text-cyan-100 border border-blue-700 rounded-lg text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            title="Baixar Tabela de Preços em PDF A4 Oficial"
          >
            <Printer className="w-4 h-4 text-cyan-300" />
            <span>Tabela em PDF</span>
          </button>

          <button
            id="btn-add-service"
            onClick={handleOpenAddModal}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>+ CADASTRAR NOVO SERVIÇO</span>
          </button>
        </div>
      </div>

      {/* Search and List */}
      <div className="p-4 sm:p-6 bg-[#e9edf2] space-y-4">
        
        {/* Search Bar & Category Filters */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full md:max-w-md">
            <div className="relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Pesquisar por código, nome, categoria ou escopo..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 transition-all shadow-inner"
              />
            </div>
          </div>

          {/* Category Filter Pills & Add Button */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setSelectedCategoryFilter('ALL')}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all shrink-0 cursor-pointer ${
                selectedCategoryFilter === 'ALL'
                  ? 'bg-[#1b365d] text-white shadow-sm'
                  : 'bg-white text-slate-700 hover:text-slate-900 border border-slate-300'
              }`}
            >
              Todas ({services.length})
            </button>
            {CATEGORIES.map(cat => {
              const count = services.filter(s => (s.category || 'Geral') === cat).length;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategoryFilter(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all shrink-0 cursor-pointer ${
                    selectedCategoryFilter === cat
                      ? 'bg-[#1b365d] text-white shadow-sm'
                      : 'bg-white text-slate-700 hover:text-slate-900 border border-slate-300'
                  }`}
                >
                  {cat} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {/* List of Services */}
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-500 border border-dashed border-slate-300 rounded-xl bg-white flex flex-col items-center justify-center space-y-3">
            <Info className="w-8 h-8 text-slate-400" />
            <p className="text-xs font-bold text-slate-700">Nenhum serviço encontrado na tabela</p>
            <p className="text-[11px] text-slate-500 max-w-sm">
              Tente ajustar seus termos de pesquisa ou cadastre um novo item na Tabela de Preços.
            </p>
            <button
              onClick={handleOpenAddModal}
              className="mt-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg shadow-md flex items-center gap-2 cursor-pointer transition-all"
            >
              <Plus className="w-4 h-4 text-slate-950" />
              <span>CADASTRAR NOVO SERVIÇO AGORA</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((s) => (
              <div 
                key={s.id} 
                className="bg-white border border-slate-300 hover:border-blue-600 rounded-xl p-4 flex flex-col justify-between transition-all group shadow-sm hover:shadow-md"
                id={`service-card-${s.id}`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] font-black text-[#1b365d] bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-md uppercase tracking-wider">
                        {s.code}
                      </span>
                      {s.category && (
                        <span className="text-[9px] font-black text-slate-700 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-md">
                          {s.category}
                        </span>
                      )}
                    </div>
                    <span className="text-sm font-black text-emerald-700 font-mono">
                      {formatBRL(s.estimatedCost)}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-sm tracking-tight group-hover:text-blue-800 transition-colors">
                      {s.name}
                    </h3>
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed line-clamp-4">
                      {s.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 mt-5 pt-3.5 border-t border-slate-200">
                  <span className="text-[10px] text-slate-500 font-bold font-mono">
                    Unidade: {s.unit || 'Serviço'}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleOpenEditModal(s)}
                      className="p-1.5 hover:bg-blue-50 text-slate-500 hover:text-blue-700 rounded-lg border border-transparent hover:border-blue-200 transition-all cursor-pointer"
                      title="Editar Serviço na Tabela"
                      id={`btn-edit-service-${s.id}`}
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirmation(s)}
                      className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg border border-transparent hover:border-red-200 transition-all cursor-pointer"
                      title="Excluir Serviço da Tabela"
                      id={`btn-delete-service-${s.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Create/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="service-modal">
          <div className="absolute inset-0 bg-[#000000]/60 backdrop-blur-xs" onClick={() => setIsModalOpen(false)}></div>
          
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-300">
            
            {/* Modal Header */}
            <div className="px-5 py-3.5 bg-[#1b365d] text-white border-b border-blue-900 flex items-center justify-between">
              <div className="flex items-center gap-2 text-white">
                <Briefcase className="w-5 h-5 text-cyan-300" />
                <div>
                  <h3 className="font-black text-white text-sm uppercase tracking-wider">
                    {editingService ? 'Editar Item de Tabela' : 'Cadastrar Item na Tabela de Preços'}
                  </h3>
                  <span className="text-[10px] text-cyan-100 block">Configure o modelo de ação corretiva / preço oficial</span>
                </div>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-cyan-200 hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 bg-slate-50">
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Código *</label>
                  <input
                    type="text"
                    placeholder="Ex: SERV-H01"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 font-mono shadow-inner"
                    required
                  />
                </div>

                <div className="sm:col-span-2 space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Nome do Serviço / Manutenção *</label>
                  <input
                    type="text"
                    placeholder="Ex: Brunimento de Camisa e Troca de Selos"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Categoria</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  >
                    {CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Unidade</label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  >
                    <option value="Serviço">Serviço</option>
                    <option value="UN">UN</option>
                    <option value="Hora">Hora</option>
                    <option value="Verba">Verba</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Preço de Tabela (R$) *</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono text-xs font-bold text-slate-500">R$</span>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="Ex: 1500.00"
                      value={estimatedCost || ''}
                      onChange={(e) => setEstimatedCost(parseFloat(e.target.value) || 0)}
                      className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 font-mono shadow-inner"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Descrição das Ações / Escopo de Trabalho *</label>
                <textarea
                  rows={4}
                  placeholder="Descreva as etapas técnicas do serviço e componentes de substituição comuns..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 resize-none leading-relaxed shadow-inner"
                  required
                />
              </div>

              {formError && (
                <p className="text-xs text-red-700 font-bold bg-red-50 border border-red-200 p-2.5 rounded-lg">
                  {formError}
                </p>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 border-t border-slate-200 pt-4 mt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-xs font-black uppercase tracking-wider text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingService ? 'SALVAR ALTERAÇÕES' : 'CADASTRAR NA TABELA'}</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-150" id="delete-service-modal">
          <div className="absolute inset-0 bg-[#000000]/60 backdrop-blur-xs" onClick={() => setDeleteConfirmation(null)}></div>
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-300">
            <div className="px-5 py-3.5 bg-red-700 text-white flex items-center gap-3">
              <Trash2 className="w-5 h-5 text-red-100" />
              <h3 className="font-black text-white text-sm uppercase tracking-wider">Confirmar Exclusão</h3>
            </div>
            
            <div className="p-6 bg-slate-50 space-y-4">
              <p className="text-xs text-slate-700 leading-relaxed">
                Tem certeza de que deseja excluir o serviço <strong className="text-slate-950">"{deleteConfirmation.code} - {deleteConfirmation.name}"</strong>?
              </p>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  id="btn-cancel-delete-service"
                  onClick={() => setDeleteConfirmation(null)}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  id="btn-confirm-delete-service"
                  onClick={() => {
                    onDeleteService(deleteConfirmation.id);
                    setDeleteConfirmation(null);
                  }}
                  className="px-5 py-2 text-xs font-black uppercase tracking-wider text-white bg-red-600 hover:bg-red-700 rounded-xl transition-colors shadow-md cursor-pointer"
                >
                  Excluir
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
