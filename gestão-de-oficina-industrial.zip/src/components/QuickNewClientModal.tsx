import React, { useState, useEffect, useRef } from 'react';
import { Client } from '../types';
import { formatPhoneNumber } from '../utils/phoneFormatter';
import { 
  UserPlus, X, Building2, Phone, Mail, MapPin, 
  FileText, Check, AlertCircle, Sparkles, Keyboard 
} from 'lucide-react';

interface QuickNewClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveClient: (clientData: Omit<Client, 'id' | 'createdAt'>) => Client;
  onClientCreated?: (newClient: Client) => void;
  initialName?: string;
}

const DEFAULT_ACTIVITIES = [
  'PARTICULAR',
  'COMÉRCIO / VAREJO',
  'INDÚSTRIA METALÚRGICA',
  'MINERAÇÃO & CONSTRUÇÃO',
  'TRANSPORTE & LOGÍSTICA',
  'AGROPECUÁRIA & AGRONEGÓCIO',
  'ALIMENTOS & BEBIDAS',
  'PAPEL & PAPELÃO',
  'SERVIÇOS GERAIS',
  'PLÁSTICOS & POLÍMEROS',
  'SISTEMAS HIDRÁULICOS & MANUTENÇÃO',
  'OUTROS'
];

export default function QuickNewClientModal({
  isOpen,
  onClose,
  onSaveClient,
  onClientCreated,
  initialName = ''
}: QuickNewClientModalProps) {
  const [name, setName] = useState(initialName);
  const [document, setDocument] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [activity, setActivity] = useState('PARTICULAR');
  const [customActivity, setCustomActivity] = useState('');
  const [isCustomActivity, setIsCustomActivity] = useState(false);
  const [error, setError] = useState('');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const nameInputRef = useRef<HTMLInputElement>(null);

  // Sync initialName & reset on open
  useEffect(() => {
    if (isOpen) {
      setName(initialName || '');
      setDocument('');
      setPhone('');
      setEmail('');
      setAddress('');
      setActivity('PARTICULAR');
      setCustomActivity('');
      setIsCustomActivity(false);
      setError('');
      setSuccessNotice(null);

      // Focus name input
      setTimeout(() => {
        nameInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, initialName]);

  // Esc key closes modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanName = name.trim();
    const cleanPhone = phone.trim();

    if (!cleanName) {
      setError('Por favor, informe o Nome ou Razão Social do cliente.');
      nameInputRef.current?.focus();
      return;
    }

    if (!cleanPhone) {
      setError('Por favor, informe o Telefone ou WhatsApp para contato.');
      return;
    }

    const finalActivity = isCustomActivity 
      ? (customActivity.trim().toUpperCase() || 'OUTROS')
      : activity;

    try {
      const created = onSaveClient({
        name: cleanName,
        document: document.trim(),
        phone: cleanPhone,
        email: email.trim(),
        address: address.trim(),
        activity: finalActivity
      });

      // Save custom activity to saved list if new
      if (isCustomActivity && customActivity.trim()) {
        try {
          const saved = JSON.parse(localStorage.getItem('oficina_client_activities') || '[]');
          if (!saved.includes(finalActivity)) {
            localStorage.setItem('oficina_client_activities', JSON.stringify([...saved, finalActivity]));
          }
        } catch {
          // ignore
        }
      }

      setSuccessNotice(`Cliente "${created.name}" cadastrado com sucesso!`);
      
      setTimeout(() => {
        if (onClientCreated) {
          onClientCreated(created);
        }
        onClose();
      }, 600);
    } catch (err: any) {
      setError(err?.message || 'Ocorreu um erro ao salvar o cliente. Tente novamente.');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[70] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      id="quick-new-client-backdrop"
    >
      <div 
        className="bg-white border-2 border-slate-400 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col my-6 animate-in fade-in zoom-in-95 duration-150"
        id="quick-new-client-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-quick-client-title"
      >
        {/* Header */}
        <div className="bg-[#1b365d] text-white px-5 py-3.5 flex items-center justify-between border-b border-blue-900">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="modal-quick-client-title" className="text-sm sm:text-base font-black uppercase tracking-wider text-white">
                  Cadastro de Novo Cliente
                </h3>
                <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-800 text-cyan-200 border border-blue-700 text-[10px] font-mono font-black">
                  <Keyboard className="w-3 h-3" />
                  <span>F2</span>
                </span>
              </div>
              <p className="text-[11px] text-cyan-200 mt-0.5">
                Preencha os dados para registrar o cliente no sistema
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-close-quick-client-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg text-cyan-200 hover:text-white hover:bg-blue-800 transition-colors cursor-pointer"
            title="Fechar (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 bg-slate-50 text-xs">
          {error && (
            <div className="p-3 bg-red-50 border border-red-300 rounded-xl flex items-center gap-2.5 text-red-700 font-bold">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center gap-2.5 text-emerald-800 font-bold animate-pulse">
              <Check className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successNotice}</span>
            </div>
          )}

          {/* Nome / Razão Social */}
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1">
              Nome ou Razão Social <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                ref={nameInputRef}
                id="input-quick-client-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Petrobras / Indústria Hidráulica Ltda / João da Silva"
                className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 shadow-inner transition-all"
              />
            </div>
          </div>

          {/* Documento (CPF / CNPJ) & Telefone / WhatsApp */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                <FileText className="w-3 h-3 text-slate-500" />
                <span>CNPJ ou CPF</span>
              </label>
              <input
                id="input-quick-client-document"
                type="text"
                value={document}
                onChange={(e) => setDocument(e.target.value)}
                placeholder="00.000.000/0001-00"
                className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 shadow-inner transition-all"
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                <Phone className="w-3 h-3 text-emerald-600" />
                <span>Telefone / WhatsApp <span className="text-red-500">*</span></span>
              </label>
              <input
                id="input-quick-client-phone"
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(formatPhoneNumber(e.target.value))}
                placeholder="(21) 98369-9728"
                className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 shadow-inner transition-all"
              />
            </div>
          </div>

          {/* E-mail */}
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
              <Mail className="w-3 h-3 text-blue-600" />
              <span>E-mail Corporativo / Faturamento</span>
            </label>
            <input
              id="input-quick-client-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="compras@cliente.com.br"
              className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 shadow-inner transition-all"
            />
          </div>

          {/* Endereço */}
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
              <MapPin className="w-3 h-3 text-amber-600" />
              <span>Endereço Completo</span>
            </label>
            <input
              id="input-quick-client-address"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Rua, Número, Bairro, Cidade - UF"
              className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 shadow-inner transition-all"
            />
          </div>

          {/* Ramo de Atividade */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1">
                <Building2 className="w-3 h-3 text-indigo-600" />
                <span>Ramo / Atividade</span>
              </label>
              <button
                type="button"
                onClick={() => setIsCustomActivity(!isCustomActivity)}
                className="text-[10px] text-blue-700 hover:text-blue-900 font-bold underline cursor-pointer"
              >
                {isCustomActivity ? 'Selecionar da Lista' : '+ Outra Atividade'}
              </button>
            </div>

            {isCustomActivity ? (
              <input
                id="input-quick-client-custom-activity"
                type="text"
                value={customActivity}
                onChange={(e) => setCustomActivity(e.target.value)}
                placeholder="Digite a atividade (ex: USINAGEM DE PRECISÃO)"
                className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3 py-2 text-xs uppercase font-bold text-slate-900 shadow-inner transition-all"
              />
            ) : (
              <select
                id="select-quick-client-activity"
                value={activity}
                onChange={(e) => setActivity(e.target.value)}
                className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 shadow-inner cursor-pointer"
              >
                {DEFAULT_ACTIVITIES.map((act) => (
                  <option key={act} value={act}>
                    {act}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Hint */}
          <div className="p-2.5 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between text-[10px] text-blue-900 font-medium">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>O novo cliente ficará disponível imediatamente em todos os módulos.</span>
            </span>
            <span className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-blue-200 text-blue-800 hidden sm:inline">
              Enter = Salvar
            </span>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
            <button
              type="button"
              id="btn-cancel-quick-client"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs uppercase cursor-pointer transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              id="btn-save-quick-client"
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition-all cursor-pointer flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4 text-slate-950" />
              <span>Cadastrar Cliente</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
