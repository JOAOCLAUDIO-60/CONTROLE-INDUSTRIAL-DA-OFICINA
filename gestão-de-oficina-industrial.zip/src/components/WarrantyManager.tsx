import React, { useState, useMemo } from 'react';
import { Client, Equipment, ServiceOrder } from '../types';
import { 
  Shield, ShieldCheck, ShieldAlert, Search, Calendar, User, Cpu, FileText, 
  Clock, ArrowRight, CheckCircle2, AlertTriangle, AlertCircle, Wrench, Plus, Check, Info, FileSpreadsheet, RotateCcw
} from 'lucide-react';

interface WarrantyManagerProps {
  orders: ServiceOrder[];
  clients: Client[];
  equipments: Equipment[];
  onAddOrder: (orderData: Omit<ServiceOrder, 'id' | 'osNumber' | 'createdAt'>) => void;
  setActiveTab: (tab: 'DASHBOARD' | 'MOBILE_OS' | 'OS' | 'EQUIPMENTS' | 'CLIENTS' | 'TECHNICIANS' | 'INVENTORY' | 'TECHNICAL_REPORT' | 'REPORTS' | 'FINANCE' | 'DIAGNOSTICS' | 'SERVICES' | 'GOOGLE_SHEETS') => void;
}

// Common industrial keywords for matching
const INDUSTRIAL_KEYWORDS = [
  'vazamento', 'retentor', 'haste', 'cilindro', 'bomba', 'óleo', 'vedação', 'selo', 
  'pressão', 'válvula', 'mangueira', 'piston', 'filtro', 'êmbolo', 'motor', 'conexão',
  'ruído', 'aquecimento', 'gasto', 'trava', 'mola', 'corpo', 'placa', 'gargalo'
];

export default function WarrantyManager({
  orders,
  clients,
  equipments,
  onAddOrder,
  setActiveTab
}: WarrantyManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'EXPIRED'>('ALL');
  const [selectedOrderId, setSelectedOrderId] = useState<string>('');
  const [complaintText, setComplaintText] = useState('');
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [createdOSNumber, setCreatedOSNumber] = useState('');

  // 1. Get completed orders that have warrantyDays set (or default to 90 days if completed but undefined)
  const completedOrders = useMemo(() => {
    return orders
      .filter(order => order.status === 'COMPLETED')
      .map(order => {
        // Fallback to 90 days of warranty if not explicitly defined
        const days = order.warrantyDays !== undefined ? order.warrantyDays : 90;
        
        // Calculate expiration date
        // If order has an original non-extendable expiration date (from a parent warranty return OS), use that!
        let expDate: Date;
        if (order.originalWarrantyExpirationDate) {
          expDate = new Date(order.originalWarrantyExpirationDate + 'T12:00:00');
        } else {
          // Use endDate if available, otherwise fallback to startDate or createdAt
          const refDateStr = order.endDate || order.startDate || order.createdAt;
          const refDate = new Date(refDateStr);
          expDate = new Date(refDate);
          expDate.setDate(expDate.getDate() + days);
        }
        
        const today = new Date();
        const diffTime = expDate.getTime() - today.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const isValid = diffDays >= 0;

        return {
          ...order,
          calculatedWarrantyDays: days,
          expirationDate: expDate.toISOString().split('T')[0],
          daysLeft: diffDays,
          isWarrantyActive: isValid,
          client: clients.find(c => c.id === order.clientId),
          equipment: equipments.find(e => e.id === order.equipmentId)
        };
      });
  }, [orders, clients, equipments]);

  // 2. Filter completed orders by search and status tab
  const filteredOrders = useMemo(() => {
    return completedOrders.filter(order => {
      const clientName = order.client?.name.toLowerCase() || '';
      const equipName = order.equipment?.name.toLowerCase() || '';
      const equipModel = order.equipment?.model.toLowerCase() || '';
      const osNo = order.osNumber.toLowerCase();
      const title = order.title.toLowerCase();
      const q = searchQuery.toLowerCase();

      const matchesSearch = clientName.includes(q) || 
                            equipName.includes(q) || 
                            equipModel.includes(q) || 
                            osNo.includes(q) || 
                            title.includes(q);

      if (statusFilter === 'ACTIVE') {
        return matchesSearch && order.isWarrantyActive;
      }
      if (statusFilter === 'EXPIRED') {
        return matchesSearch && !order.isWarrantyActive;
      }
      return matchesSearch;
    });
  }, [completedOrders, searchQuery, statusFilter]);

  // 3. Find currently selected order details
  const activeOrder = useMemo(() => {
    return completedOrders.find(o => o.id === selectedOrderId) || null;
  }, [completedOrders, selectedOrderId]);

  // 4. Reset selected order when filter changes and selected is no longer in list
  React.useEffect(() => {
    if (selectedOrderId && !filteredOrders.some(o => o.id === selectedOrderId)) {
      setSelectedOrderId('');
    }
  }, [filteredOrders, selectedOrderId]);

  // 5. Intelligent similarity auditing algorithm
  const auditAnalysis = useMemo(() => {
    if (!activeOrder || !complaintText.trim()) {
      return { score: 0, matchedKeywords: [] as string[], textMatches: [] as string[], level: 'NONE' as 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' };
    }

    const complaintLower = complaintText.toLowerCase();
    
    // Combine all text from the previous maintenance
    const prevText = [
      activeOrder.title,
      activeOrder.description,
      activeOrder.diagnostic || '',
      activeOrder.plannedServices || '',
      activeOrder.actualServicesPerformed || '',
      activeOrder.materialsUsed || ''
    ].join(' ').toLowerCase();

    const matchedKeywords: string[] = [];
    const textMatches: string[] = [];

    // Check pre-defined industrial keywords
    INDUSTRIAL_KEYWORDS.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\w*\\b`, 'gi');
      const inComplaint = regex.test(complaintLower);
      const inPrev = regex.test(prevText);
      
      if (inComplaint && inPrev) {
        matchedKeywords.push(keyword);
      }
    });

    // Also look for simple multi-character substring intersections of length >= 4
    const words = complaintLower
      .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "")
      .split(/\s+/)
      .filter(w => w.length >= 4);

    words.forEach(word => {
      if (prevText.includes(word) && !matchedKeywords.includes(word)) {
        textMatches.push(word);
      }
    });

    const totalMatchesCount = matchedKeywords.length + textMatches.length;
    let score = 0;
    let level: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' = 'NONE';

    if (totalMatchesCount > 0) {
      score = Math.min(100, Math.round((totalMatchesCount / Math.max(5, words.length)) * 100));
      if (score === 0) score = 15; // minimum if there is any match
    }

    if (score >= 60) {
      level = 'HIGH';
    } else if (score >= 25) {
      level = 'MEDIUM';
    } else if (score > 0) {
      level = 'LOW';
    }

    return {
      score,
      matchedKeywords: [...matchedKeywords, ...textMatches],
      level
    };
  }, [activeOrder, complaintText]);

  // 6. Handle creation of warranty Service Order
  const handleCreateWarrantyOS = () => {
    if (!activeOrder) return;

    // Generate unique warranty OS parameters
    const warrantyTitle = `Reclamação de Garantia: ${activeOrder.title}`;
    const warrantyDesc = `Reclamação do Cliente:\n"${complaintText}"\n\n---\nRef. OS Anterior: ${activeOrder.osNumber} (Concluída em ${activeOrder.endDate ? new Date(activeOrder.endDate).toLocaleDateString('pt-BR') : 'Sem data'})\nServiço executado anteriormente: ${activeOrder.actualServicesPerformed || 'Não detalhado'}\n\n*Termo de Garantia: O prazo original de garantia (${activeOrder.calculatedWarrantyDays} dias) permanece inalterado e NÃO é prorrogado por esta nova intervenção.`;

    onAddOrder({
      clientId: activeOrder.clientId,
      equipmentId: activeOrder.equipmentId,
      title: warrantyTitle,
      description: warrantyDesc,
      status: 'PENDING',
      priority: 'HIGH', // Warranty returns are always critical/high priority
      technician: activeOrder.technician,
      estimatedCost: 0, // Warranty works usually have 0 estimated cost to the client
      startDate: new Date().toISOString().split('T')[0],
      orderType: 'WARRANTY',
      parentOSId: activeOrder.id,
      parentOSNumber: activeOrder.osNumber,
      originalWarrantyStartDate: activeOrder.endDate || activeOrder.deliveryDate || activeOrder.startDate || activeOrder.createdAt,
      originalWarrantyExpirationDate: activeOrder.expirationDate,
      warrantyDays: activeOrder.calculatedWarrantyDays,
      budgetStatus: 'APPROVED' // Pre-approved warranty
    });

    const mockOSNumber = `OS-GAR-${Math.floor(1000 + Math.random() * 9000)}`;
    setCreatedOSNumber(mockOSNumber);
    setShowSuccessToast(true);
    setComplaintText('');
    
    setTimeout(() => {
      setShowSuccessToast(false);
      setActiveTab('OS'); // Switch back to Kanban board to see the new OS
    }, 4500);
  };

  return (
    <div className="space-y-6" id="warranty-manager-container">
      
      {/* Toast Alert on OS creation */}
      {showSuccessToast && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md bg-white border-2 border-emerald-500 rounded-2xl p-4 shadow-2xl animate-bounce flex gap-3.5 items-start">
          <div className="p-2 bg-emerald-100 rounded-xl border border-emerald-300 text-emerald-700 shrink-0">
            <Check className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-black text-xs uppercase tracking-wider text-slate-900">OS de Garantia Gerada com Sucesso!</h4>
            <p className="text-slate-600 text-[11px] mt-1 font-medium">
              Uma nova Ordem de Serviço do tipo <strong className="text-amber-700 font-black">GARANTIA</strong> foi criada e adicionada à sua fila de atendimentos com prioridade <strong className="text-red-600 font-black">ALTA</strong>.
            </p>
            <span className="text-[10px] font-mono font-black text-emerald-700 block mt-2">Redirecionando para as Ordens...</span>
          </div>
        </div>
      )}

      {/* Header section with brand accent - matching InventoryManager */}
      <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4 shadow-md" id="warranty-header-panel">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-amber-500 to-yellow-600 rounded-2xl border border-amber-500/20 text-slate-950 shadow-sm">
            <ShieldCheck className="w-6 h-6 font-bold" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-[#1b365d] text-cyan-200 border border-blue-900 text-[9px] font-mono px-2 py-0.5 rounded-md font-black uppercase tracking-widest">
                AUDIT ENGINE 4.0
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            </div>
            <h1 className="text-base sm:text-lg font-black text-slate-900 uppercase tracking-wider mt-0.5">
              Painel de Auditoria & Controle de Garantias
            </h1>
            <p className="text-[11px] text-slate-600 font-medium">
              Monitore prazos de garantias vigentes, simulação cruzada de defeitos e reabertura de OS
            </p>
          </div>
        </div>

        {/* Header summary count pills */}
        <div className="flex gap-2 bg-slate-100 p-1.5 border border-slate-300 rounded-xl shrink-0">
          <div className="text-center px-3 border-r border-slate-300">
            <span className="text-[9px] uppercase font-black text-slate-500 block font-mono">Em Garantia</span>
            <span className="font-mono text-base font-black text-emerald-700">
              {completedOrders.filter(o => o.isWarrantyActive).length}
            </span>
          </div>
          <div className="text-center px-3">
            <span className="text-[9px] uppercase font-black text-slate-500 block font-mono">Expiradas</span>
            <span className="font-mono text-base font-black text-slate-600">
              {completedOrders.filter(o => !o.isWarrantyActive).length}
            </span>
          </div>
        </div>
      </div>

      {/* Overview Stats Cards - matching InventoryManager */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">OS Concluídas</p>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1 font-mono">{completedOrders.length}</h3>
            </div>
            <div className="p-2 rounded-xl border border-blue-300 bg-blue-50 text-blue-600">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-2 font-medium">Ordens no histórico técnico</p>
        </div>

        <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Garantias Vigentes</p>
              <h3 className="text-xl sm:text-2xl font-extrabold text-emerald-700 mt-1 font-mono">
                {completedOrders.filter(o => o.isWarrantyActive).length}
              </h3>
            </div>
            <div className="p-2 rounded-xl border border-emerald-300 bg-emerald-50 text-emerald-600">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-2 font-medium">Cobertura técnica ativa</p>
        </div>

        <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Garantias Expiradas</p>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-700 mt-1 font-mono">
                {completedOrders.filter(o => !o.isWarrantyActive).length}
              </h3>
            </div>
            <div className="p-2 rounded-xl border border-slate-300 bg-slate-100 text-slate-600">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-2 font-medium">Prazo regular esgotado</p>
        </div>

        <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Motor de Auditoria</p>
              <h3 className="text-xl sm:text-2xl font-extrabold text-amber-700 mt-1 font-mono">Ativo 4.0</h3>
            </div>
            <div className="p-2 rounded-xl border border-amber-300 bg-amber-50 text-amber-600">
              <Shield className="w-5 h-5" />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-2 font-medium">Cruzamento de peças & termos</p>
        </div>
      </div>

      {/* Official Warranty Non-Extension Policy Banner */}
      <div className="bg-blue-50/80 rounded-2xl border border-blue-200 p-4 flex items-start gap-3.5 shadow-xs">
        <div className="p-2.5 bg-[#1b365d] rounded-xl border border-blue-900 text-cyan-300 shrink-0 mt-0.5 shadow-xs">
          <ShieldCheck className="w-5 h-5" />
        </div>
        <div className="space-y-1 text-slate-800">
          <div className="flex items-center gap-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-[#1b365d]">Diretriz Regulatória de Garantia do Sistema</h4>
            <span className="bg-[#1b365d] text-cyan-200 text-[9px] font-mono font-black px-2 py-0.5 rounded-md border border-blue-800">
              NÃO PRORROGÁVEL
            </span>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-700 font-medium">
            "Ao término da execução do serviço, será concedida garantia para a manutenção realizada no equipamento. Caso o equipamento retorne para nova intervenção dentro do período de garantia, o prazo originalmente concedido permanecerá inalterado, não sendo prorrogado, renovado ou reiniciado em razão da execução de serviços corretivos cobertos pela garantia."
          </p>
        </div>
      </div>

      {/* Search and Filters Segment */}
      <div className="bg-white rounded-2xl border border-slate-300 p-3.5 flex flex-col md:flex-row gap-4 items-center justify-between shadow-sm" id="warranty-filters-panel">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por OS, cliente ou equipamento..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-10 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 font-medium focus:outline-hidden focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-500/20 shadow-inner"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 text-xs font-bold cursor-pointer"
            >
              Limpar
            </button>
          )}
        </div>

        {/* Tab filters */}
        <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-300 w-full md:w-auto">
          {[
            { id: 'ALL', label: 'Todas as Ordens Concluídas', count: completedOrders.length },
            { id: 'ACTIVE', label: 'Vigentes (Ativas)', count: completedOrders.filter(o => o.isWarrantyActive).length },
            { id: 'EXPIRED', label: 'Expiradas', count: completedOrders.filter(o => !o.isWarrantyActive).length }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id as any)}
              className={`flex-1 md:flex-none px-3.5 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all cursor-pointer ${
                statusFilter === tab.id 
                  ? 'bg-amber-500 text-slate-950 font-black shadow-xs' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
              }`}
            >
              {tab.label} ({tab.count})
            </button>
          ))}
        </div>
      </div>

      {/* Main Studio Split Grid - framed like InventoryManager */}
      <div className="bg-[#e9edf2] border-2 border-[#b0bec5] rounded-2xl p-3 md:p-4 shadow-sm space-y-4" id="warranty-split-grid">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          
          {/* Left Side: Order List with Warranty Status Indicators */}
          <div className="lg:col-span-5 flex flex-col space-y-3" id="warranty-list-column">
            
            {/* Blue Industrial Header Title */}
            <div className="flex items-center justify-between bg-[#1b365d] text-white px-3.5 py-2.5 rounded-xl border border-blue-900 shadow-xs">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-cyan-300" />
                <span className="text-xs font-black uppercase tracking-wider">Histórico de Conclusões</span>
              </div>
              <span className="text-[10px] font-mono font-black text-cyan-200 bg-blue-950/70 px-2 py-0.5 rounded border border-blue-800">
                {filteredOrders.length} {filteredOrders.length === 1 ? 'ordem' : 'ordens'}
              </span>
            </div>

            {filteredOrders.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-300 p-8 text-center text-slate-500 shadow-xs">
                <ShieldAlert className="w-8 h-8 text-slate-400 mx-auto mb-3" />
                <p className="text-xs font-black text-slate-700">Nenhuma OS concluída encontrada</p>
                <p className="text-[11px] text-slate-500 mt-1">Conclua Ordens de Serviço no ciclo ou no gerenciador de OS para que apareçam no controle de garantias.</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[640px] overflow-y-auto pr-1">
                {filteredOrders.map(order => {
                  const isSelected = order.id === selectedOrderId;
                  return (
                    <button
                      key={order.id}
                      id={`warranty-order-item-${order.id}`}
                      onClick={() => {
                        setSelectedOrderId(order.id);
                        setComplaintText(''); // Clear complaint draft when switching
                      }}
                      className={`w-full text-left p-3.5 rounded-xl border transition-all duration-200 flex flex-col gap-2 relative group cursor-pointer shadow-xs ${
                        isSelected 
                          ? 'bg-blue-50 border-2 border-blue-600 shadow-sm ring-1 ring-blue-500/20' 
                          : 'bg-white border-slate-300 hover:bg-slate-50 hover:border-slate-400'
                      }`}
                    >
                      {/* Selected Indicator Glow Stripe */}
                      {isSelected && (
                        <span className="absolute left-0 top-2 bottom-2 w-1.5 bg-[#0052cc] rounded-r-lg"></span>
                      )}

                      <div className="flex justify-between items-start pl-1">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded-md border ${
                            isSelected 
                              ? 'bg-[#1b365d] text-cyan-200 border-blue-900' 
                              : 'bg-amber-100 text-amber-900 border-amber-300'
                          }`}>
                            {order.osNumber}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono font-bold">
                            {order.endDate ? new Date(order.endDate).toLocaleDateString('pt-BR') : 'Sem data'}
                          </span>
                        </div>

                        {/* Expiration badge */}
                        {order.isWarrantyActive ? (
                          <span className="text-[9px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-md flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                            Vigente ({order.daysLeft}d)
                          </span>
                        ) : (
                          <span className="text-[9px] font-black uppercase tracking-wider text-slate-600 bg-slate-100 border border-slate-300 px-2 py-0.5 rounded-md">
                            Expirada
                          </span>
                        )}
                      </div>

                      <div className="pl-1">
                        <h4 className="font-black text-slate-900 text-xs group-hover:text-blue-700 transition-colors line-clamp-1 leading-snug uppercase">
                          {order.equipment?.name || 'Equipamento'} ({order.equipment?.model || 'S/M'})
                        </h4>
                        <p className="text-[11px] text-slate-600 mt-0.5 truncate font-medium">
                          Cliente: <strong className="text-slate-800">{order.client?.name || 'Indefinido'}</strong>
                        </p>
                        <p className="text-[10px] text-slate-500 mt-1 line-clamp-1 italic">
                          Executado: {order.actualServicesPerformed || order.title}
                        </p>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-slate-200 text-[10px] text-slate-500 font-mono pl-1">
                        <span>Garantia de {order.calculatedWarrantyDays} dias</span>
                        <span className={`flex items-center gap-1 font-bold ${isSelected ? 'text-blue-700 font-black' : 'group-hover:text-blue-600'}`}>
                          Auditar <ArrowRight className="w-3 h-3" />
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Side: Audit Simulator & Warranty Linking */}
          <div className="lg:col-span-7 flex flex-col space-y-3" id="warranty-audit-column">
            
            {/* Blue Industrial Header Title */}
            <div className="flex items-center justify-between bg-[#1b365d] text-white px-3.5 py-2.5 rounded-xl border border-blue-900 shadow-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-300" />
                <span className="text-xs font-black uppercase tracking-wider">Painel de Auditoria & Reclamações</span>
              </div>
              {activeOrder && (
                <span className="text-[10px] font-mono font-black text-cyan-200 bg-blue-950/70 px-2 py-0.5 rounded border border-blue-800">
                  OS: {activeOrder.osNumber}
                </span>
              )}
            </div>

            {!activeOrder ? (
              <div className="bg-white rounded-2xl border border-slate-300 p-10 text-center shadow-sm flex flex-col justify-center items-center min-h-[450px]">
                <div className="p-4 bg-slate-100 border border-slate-300 rounded-2xl text-slate-400 mb-4 shadow-2xs">
                  <Shield className="w-12 h-12 text-slate-500" />
                </div>
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Nenhuma Ordem de Serviço Selecionada</h3>
                <p className="text-xs text-slate-600 mt-2 max-w-md mx-auto leading-relaxed">
                  Selecione uma ordem de serviço concluída na lista à esquerda para carregar o histórico de execução, verificar prazos e iniciar o <strong className="text-blue-700 font-bold">Auditor de Reclamações de Clientes</strong>.
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg w-full mt-8 pt-6 border-t border-slate-200">
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-left">
                    <span className="text-[10px] font-black text-emerald-800 uppercase tracking-wider block mb-1">Como Funciona o Controle</span>
                    <p className="text-[11px] text-slate-600 leading-normal">Se o cliente retornar com um equipamento reclamando de falhas, você digita o problema relatado e a IA local faz o cruzamento com peças e serviços do atendimento anterior.</p>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-left">
                    <span className="text-[10px] font-black text-amber-800 uppercase tracking-wider block mb-1">Evite Cobranças Duplas</span>
                    <p className="text-[11px] text-slate-600 leading-normal">Diferencie facilmente se o defeito atual é um retorno legítimo do serviço anterior ou um novo problema em uma peça que não foi trocada.</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4" id="warranty-audit-workspace">
                
                {/* Workspace Card Header */}
                <div className="bg-white rounded-2xl border border-slate-300 p-4 md:p-5 shadow-sm space-y-4">
                  
                  {/* Visual Status Strip at the top */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-200 pb-4">
                    <div className="space-y-1">
                      <span className="text-[9px] font-mono font-black text-slate-500 uppercase tracking-widest">DADOS DA ORDEM ORIGINAL</span>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-black text-slate-900 uppercase tracking-wider">{activeOrder.osNumber}</h3>
                        <span className="text-xs text-slate-400 font-bold">•</span>
                        <h4 className="text-xs text-slate-700 font-black uppercase">{activeOrder.equipment?.name} ({activeOrder.equipment?.model})</h4>
                      </div>
                    </div>

                    {/* Dynamic Validity Pill */}
                    <div className={`px-3.5 py-1.5 rounded-xl border flex items-center gap-2.5 shadow-2xs ${
                      activeOrder.isWarrantyActive 
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800' 
                        : 'bg-red-50 border-red-300 text-red-700'
                    }`}>
                      {activeOrder.isWarrantyActive ? (
                        <>
                          <ShieldCheck className="w-5 h-5 shrink-0 text-emerald-600" />
                          <div className="text-left leading-none">
                            <span className="text-[9px] font-black uppercase block tracking-wider">Garantia Vigente</span>
                            <span className="text-[10px] font-mono font-black mt-0.5 block">{activeOrder.daysLeft} dias restantes</span>
                          </div>
                        </>
                      ) : (
                        <>
                          <ShieldAlert className="w-5 h-5 shrink-0 text-red-600" />
                          <div className="text-left leading-none">
                            <span className="text-[9px] font-black uppercase block tracking-wider">Prazo Expirado</span>
                            <span className="text-[10px] font-mono font-black mt-0.5 block">Venceu há {Math.abs(activeOrder.daysLeft)} dias</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Audit Grid Details */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3" id="warranty-audit-metrics">
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <span className="text-[9px] uppercase tracking-wider font-black text-slate-500 font-mono block">Duração Registrada</span>
                      <span className="text-sm font-black text-slate-900 block mt-1 font-mono">{activeOrder.calculatedWarrantyDays} Dias</span>
                      <span className="text-[10px] text-slate-500 font-medium block mt-0.5">Prazo padrão de fábrica</span>
                    </div>
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <span className="text-[9px] uppercase tracking-wider font-black text-slate-500 font-mono block">Data de Conclusão</span>
                      <span className="text-sm font-mono font-black text-slate-900 block mt-1">
                        {activeOrder.endDate ? new Date(activeOrder.endDate + 'T12:00:00').toLocaleDateString('pt-BR') : 'Sem data registrada'}
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium block mt-0.5">Início da contagem da garantia</span>
                    </div>
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <span className="text-[9px] uppercase tracking-wider font-black text-slate-500 font-mono block">Data de Vencimento</span>
                      <span className="text-sm font-mono font-black text-slate-900 block mt-1">
                        {new Date(activeOrder.expirationDate + 'T12:00:00').toLocaleDateString('pt-BR')}
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium block mt-0.5">Data final de validade</span>
                    </div>
                  </div>

                  {/* Equipment & Client Profile Cards side-by-side */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-start gap-3">
                      <div className="p-2 bg-white border border-slate-300 rounded-lg text-blue-600 shrink-0 shadow-2xs">
                        <Cpu className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-[9px] uppercase font-bold text-slate-500 font-mono block">Equipamento Atendido</span>
                        <span className="text-xs font-black text-slate-900 block mt-0.5 truncate uppercase">{activeOrder.equipment?.name}</span>
                        <span className="text-[10px] text-slate-600 font-mono block truncate">Modelo: {activeOrder.equipment?.model} | Tipo: {activeOrder.equipment?.type}</span>
                      </div>
                    </div>

                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-start gap-3">
                      <div className="p-2 bg-white border border-slate-300 rounded-lg text-emerald-600 shrink-0 shadow-2xs">
                        <User className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-[9px] uppercase font-bold text-slate-500 font-mono block">Proprietário / Cliente</span>
                        <span className="text-xs font-black text-slate-900 block mt-0.5 truncate">{activeOrder.client?.name}</span>
                        <span className="text-[10px] text-slate-600 block truncate">CNPJ/CPF: {activeOrder.client?.document || 'S/D'} | Tel: {activeOrder.client?.phone || 'S/T'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Technical History summary of the executed job */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                      <Wrench className="w-4 h-4 text-amber-600" />
                      <span className="text-[11px] font-black text-slate-800 uppercase tracking-wider">Histórico de Peças e Serviços Efetuados</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                      <div className="space-y-1">
                        <span className="text-[9px] font-bold text-slate-600 uppercase font-mono block">Diagnóstico Original</span>
                        <p className="text-slate-800 bg-white p-2.5 rounded-lg border border-slate-200 text-xs leading-normal whitespace-pre-wrap shadow-inner">
                          {activeOrder.diagnostic || 'Nenhum diagnóstico registrado.'}
                        </p>
                      </div>

                      <div className="space-y-1">
                        <span className="text-[9px] font-bold text-slate-600 uppercase font-mono block">Serviço Executado</span>
                        <p className="text-slate-800 bg-white p-2.5 rounded-lg border border-slate-200 text-xs leading-normal whitespace-pre-wrap shadow-inner">
                          {activeOrder.actualServicesPerformed || 'Nenhum detalhe de serviço inserido.'}
                        </p>
                      </div>

                      <div className="space-y-1 md:col-span-2">
                        <span className="text-[9px] font-bold text-slate-600 uppercase font-mono block">Materiais e Peças Utilizadas</span>
                        <p className="text-slate-800 bg-white p-2.5 rounded-lg border border-slate-200 text-xs leading-normal whitespace-pre-wrap font-mono shadow-inner">
                          {activeOrder.materialsUsed || 'Nenhuma peça de estoque registrada neste serviço.'}
                        </p>
                      </div>
                    </div>
                  </div>

                </div>

                {/* COMPLAINT AUDIT SIMULATOR */}
                <div className="bg-white rounded-2xl border border-slate-300 p-4 md:p-5 shadow-sm space-y-4">
                  <div className="flex items-center gap-2.5 border-b border-slate-200 pb-3">
                    <ShieldCheck className="w-5 h-5 text-amber-600" />
                    <div className="space-y-0.5">
                      <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">Auditor de Reclamações Inteligente</h3>
                      <p className="text-[11px] text-slate-600">Insira a reclamação atual do cliente para fazer o cruzamento de peças e serviços da OS anterior.</p>
                    </div>
                  </div>

                  {/* Form Input */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-black text-slate-800 uppercase tracking-wider font-mono block">O que o cliente está reclamando agora? *</span>
                    <textarea
                      rows={3}
                      placeholder="Exemplo: Máquina retornou com vazamento na haste do cilindro hidráulico principal que foi consertado há 3 semanas, ou óleo superaquecendo..."
                      value={complaintText}
                      onChange={(e) => setComplaintText(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 font-medium focus:outline-hidden focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-500/20 shadow-inner"
                    />
                  </div>

                  {/* LIVE AUDIT ANALYSIS RESULT */}
                  {complaintText.trim() && (
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-300 space-y-3 animate-fadeIn">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-200 pb-3">
                        <span className="text-[10px] font-mono font-black text-slate-700 uppercase tracking-widest">RELATÓRIO DE AUDITORIA CRUZADA</span>
                        
                        {/* Correlation Index Display */}
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-slate-600 uppercase">Grau de Relação:</span>
                          <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md border ${
                            auditAnalysis.level === 'HIGH' 
                              ? 'bg-red-100 text-red-700 border-red-300 animate-pulse' 
                              : auditAnalysis.level === 'MEDIUM'
                              ? 'bg-amber-100 text-amber-800 border-amber-300'
                              : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          }`}>
                            {auditAnalysis.level === 'HIGH' ? 'ALTA CORRELAÇÃO' : auditAnalysis.level === 'MEDIUM' ? 'MÉDIA CORRELAÇÃO' : 'BAIXA CORRELAÇÃO'} ({auditAnalysis.score}%)
                          </span>
                        </div>
                      </div>

                      {/* Matched Keywords badges */}
                      <div className="space-y-1.5">
                        <span className="text-[10px] font-bold text-slate-600 uppercase font-mono block">Termos e Peças Coincidentes Identificados:</span>
                        {auditAnalysis.matchedKeywords.length === 0 ? (
                          <p className="text-[11px] text-slate-500 italic">Nenhum termo de peça ou falha anterior coincide diretamente com o texto da reclamação.</p>
                        ) : (
                          <div className="flex flex-wrap gap-1.5">
                            {auditAnalysis.matchedKeywords.map((word, idx) => (
                              <span key={idx} className="bg-white text-amber-900 border border-amber-300 px-2 py-0.5 rounded-md font-mono text-[10px] font-black uppercase shadow-2xs">
                                {word}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Recommendations and advice based on correlation score */}
                      <div className={`p-3.5 rounded-xl border flex gap-3 text-xs leading-normal shadow-2xs ${
                        auditAnalysis.level === 'HIGH'
                          ? 'bg-red-50 border-red-200 text-red-900'
                          : auditAnalysis.level === 'MEDIUM'
                          ? 'bg-amber-50 border-amber-200 text-amber-900'
                          : 'bg-white border-slate-200 text-slate-700'
                      }`}>
                        <div className="shrink-0 mt-0.5">
                          {auditAnalysis.level === 'HIGH' ? (
                            <AlertTriangle className="w-5 h-5 text-red-600" />
                          ) : auditAnalysis.level === 'MEDIUM' ? (
                            <AlertCircle className="w-5 h-5 text-amber-600" />
                          ) : (
                            <Info className="w-5 h-5 text-blue-600" />
                          )}
                        </div>
                        <div className="space-y-1">
                          <strong className="font-black uppercase text-[10px] tracking-wide block">
                            {auditAnalysis.level === 'HIGH' 
                              ? 'Alerta Crítico: Possível Retorno de Garantia' 
                              : auditAnalysis.level === 'MEDIUM'
                              ? 'Atenção Requerida: Componentes Próximos Coincidentes'
                              : 'Novo Defeito Provável'}
                          </strong>
                          <p className="text-[11px] leading-relaxed">
                            {auditAnalysis.level === 'HIGH' && (
                              `Os componentes descritos na nova reclamação coincidem fortemente com as peças trocadas (${auditAnalysis.matchedKeywords.join(', ')}) ou com o diagnóstico anterior. É altamente provável que seja um retorno de garantia. Recomenda-se realizar desmontagem técnica sem custo ao cliente para certificar a fixação.`
                            )}
                            {auditAnalysis.level === 'MEDIUM' && (
                              `Foram detectados termos compartilhados. Isso indica que a nova falha ocorreu no mesmo subsistema (ex: circuito de pressão/haste) do reparo anterior. Verifique se a nova falha é consequência indireta do trabalho executado ou fadiga de outra vedação.`
                            )}
                            {auditAnalysis.level === 'LOW' && (
                              `Os termos indicam um problema em um circuito ou peça diferente daquela que foi trabalhada na última OS. É provável que se trate de um novo defeito isolado, o que justificaria uma nova Ordem de Serviço faturada, em vez de cobertura de garantia.`
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ACTION BUTTONS PANEL */}
                  <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-slate-200">
                    
                    {/* Create Warranty OS */}
                    <button
                      type="button"
                      disabled={!complaintText.trim()}
                      onClick={handleCreateWarrantyOS}
                      className={`flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all ${
                        complaintText.trim()
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black shadow-sm'
                          : 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                      }`}
                    >
                      <Plus className="w-4 h-4 stroke-[3px]" />
                      <span>Abrir Nova OS de Garantia (Sem Custos)</span>
                    </button>

                    {/* Reject / Register as Paid New Repair */}
                    <button
                      type="button"
                      onClick={() => {
                        onAddOrder({
                          clientId: activeOrder.clientId,
                          equipmentId: activeOrder.equipmentId,
                          title: `Conserto de ${activeOrder.equipment?.name || 'Equipamento'}`,
                          description: `Novo Defeito Relatado:\n"${complaintText || 'Descrever defeito...'}"\n\n---\nHistórico: Equipamento passou por manutenção prévia na OS ${activeOrder.osNumber} mas foi diagnosticado como novo problema isolado de garantia.`,
                          status: 'PENDING',
                          priority: 'MEDIUM',
                          technician: activeOrder.technician,
                          estimatedCost: activeOrder.estimatedCost || 150,
                          startDate: new Date().toISOString().split('T')[0],
                          orderType: 'SERVICE',
                          budgetStatus: 'PENDING_APPROVAL'
                        });
                        
                        setComplaintText('');
                        setActiveTab('OS');
                      }}
                      className="py-3 px-5 bg-[#1b365d] hover:bg-blue-900 text-white font-black text-xs rounded-xl border border-blue-900 transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs uppercase tracking-wider"
                    >
                      <span>Abrir como Nova OS Padrão (Faturada)</span>
                    </button>
                  </div>

                </div>

              </div>
            )}
          </div>

        </div>
      </div>

    </div>
  );
}
