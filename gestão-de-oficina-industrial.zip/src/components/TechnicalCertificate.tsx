import React, { useState, useMemo } from 'react';
import { ServiceOrder, Client, Equipment, Technician, InventoryItem } from '../types';
import { 
  Printer, 
  FileText, 
  Clock, 
  CheckCircle2, 
  Wrench, 
  Cpu, 
  Users, 
  ShieldCheck, 
  Calendar,
  AlertCircle,
  FileSpreadsheet,
  Signature
} from 'lucide-react';

interface TechnicalCertificateProps {
  orders: ServiceOrder[];
  clients: Client[];
  equipments: Equipment[];
  technicians: Technician[];
  inventory?: InventoryItem[];
}

export default function TechnicalCertificate({ 
  orders, 
  clients, 
  equipments, 
  technicians,
  inventory = [] 
}: TechnicalCertificateProps) {
  
  const [selectedOrderId, setSelectedOrderId] = useState<string>('');

  // Get completed orders for selection dropdown
  const completedOrders = useMemo(() => {
    return orders.filter(o => o.status === 'COMPLETED' || o.isDelivered || o.actualServicesPerformed);
  }, [orders]);

  // If no order is initially selected, choose the first completed one if available
  React.useEffect(() => {
    if (!selectedOrderId && completedOrders.length > 0) {
      setSelectedOrderId(completedOrders[0].id);
    }
  }, [completedOrders, selectedOrderId]);

  // Active Order info mapping
  const activeOrder = useMemo(() => {
    return orders.find(o => o.id === selectedOrderId);
  }, [orders, selectedOrderId]);

  const activeClient = useMemo(() => {
    if (!activeOrder) return null;
    return clients.find(c => c.id === activeOrder.clientId);
  }, [activeOrder, clients]);

  const activeEquipment = useMemo(() => {
    if (!activeOrder) return null;
    return equipments.find(e => e.id === activeOrder.equipmentId);
  }, [activeOrder, equipments]);

  const activeTechnician = useMemo(() => {
    if (!activeOrder) return null;
    return technicians.find(t => t.name === activeOrder.technician || t.id === activeOrder.technician);
  }, [activeOrder, technicians]);

  // Printable screen trigger
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4" id="technical-certificate-container">
      
      {/* Selector and Print button row (hidden on print) */}
      <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm print:hidden">
        <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-blue-900">
          <div>
            <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-5 h-5 text-cyan-300" />
              <span>Emissão de Laudo Técnico</span>
            </h2>
            <p className="text-xs text-cyan-100 mt-0.5">
              Selecione uma ordem de serviço concluída para gerar e imprimir o certificado técnico formal
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Dropdown Selector */}
            <select
              id="certificate-os-selector"
              value={selectedOrderId}
              onChange={(e) => setSelectedOrderId(e.target.value)}
              className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 max-w-xs shadow-inner"
            >
              <option value="">Selecione uma OS...</option>
              {completedOrders.map(o => {
                const cli = clients.find(c => c.id === o.clientId);
                return (
                  <option key={o.id} value={o.id} className="font-mono">
                    {o.osNumber} - {cli?.name.slice(0, 15)}... ({o.title.slice(0, 20)}...)
                  </option>
                );
              })}
            </select>

            {/* Print button */}
            <button
              type="button"
              onClick={handlePrint}
              disabled={!activeOrder}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition-all shadow-md disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Imprimir Laudo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Document Display */}
      {activeOrder ? (
        <div className="bg-white rounded-xl border-2 border-[#b0bec5] shadow-md overflow-hidden max-w-4xl mx-auto print:border-0 print:rounded-none print:shadow-none print:max-w-none print:my-0 print:p-0" id="certificate-printable-card">
          
          {/* Header Banner */}
          <div className="p-6 sm:p-8 bg-[#1b365d] text-white border-b-2 border-blue-900 flex flex-col md:flex-row md:items-center md:justify-between gap-6 print:bg-white print:text-black print:border-b-2 print:border-slate-800 print:p-4">
            
            {/* Logo and Technical Header */}
            <div className="flex items-center gap-4">
              <div className="p-2.5 bg-white/10 rounded-xl border border-white/20 shrink-0 print:border-slate-400 print:bg-slate-100 flex items-center justify-center">
                {/* Tech logo */}
                <svg viewBox="0 0 390 340" className="w-12 h-12 text-cyan-300 print:text-slate-800" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M 113.1 102.6 A 100 100 0 0 1 252.4 241.9" className="stroke-white/20" strokeWidth="24" strokeLinecap="square"/>
                  <path d="M 113.1 102.6 A 100 100 0 0 1 252.4 241.9" className="stroke-cyan-300 print:stroke-slate-800" strokeWidth="12" strokeLinecap="square"/>
                  <g fill="currentColor" fontFamily="Georgia, Cambria, serif" fontWeight="bold">
                    <text x="145" y="170" fontSize="100" textAnchor="middle" className="print:fill-slate-800">J</text>
                    <text x="210" y="170" fontSize="100" textAnchor="middle" className="print:fill-slate-800">C</text>
                    <text x="175" y="235" fontSize="62" textAnchor="middle" className="print:fill-slate-800">&amp;</text>
                    <text x="215" y="240" fontSize="100" textAnchor="middle" className="print:fill-slate-800">F</text>
                  </g>
                </svg>
              </div>

              <div>
                <h1 className="text-sm sm:text-base font-black text-white tracking-widest uppercase print:text-black leading-snug">
                  JC&F MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA
                </h1>
                <p className="text-[10px] text-cyan-300 font-bold tracking-widest uppercase print:text-slate-600 mt-0.5">
                  Engenharia de Reparo, Vedação & Fluídos de Alta Pressão
                </p>
                <p className="text-[9px] text-cyan-100 print:text-slate-500 font-mono mt-1">
                  Rua Luís Bom, Nº 16 – Campo Grande – Rio de Janeiro – RJ • CNPJ: 25.452.856/0001-29 • Tel: (21) 98369-9728
                </p>
              </div>
            </div>

            {/* Document metadata block */}
            <div className="text-left md:text-right font-mono text-[11px] shrink-0 space-y-1 px-4 py-3 bg-white/10 rounded-xl border border-white/20 print:border-slate-400 print:bg-white print:p-0">
              <div>
                <span className="text-cyan-200 font-bold block md:inline print:text-slate-600">DOCUMENTO:</span>
                <span className="text-white font-black tracking-wider md:ml-1.5 print:text-black">LAUDO-TEC-{activeOrder.osNumber.split('-')[1]}</span>
              </div>
              <div>
                <span className="text-cyan-200 font-bold block md:inline print:text-slate-600">REF. ORDEM:</span>
                <span className="text-cyan-100 font-bold md:ml-1.5 print:text-black">{activeOrder.osNumber}</span>
              </div>
              <div>
                <span className="text-cyan-200 font-bold block md:inline print:text-slate-600">EMISSÃO:</span>
                <span className="text-cyan-100 md:ml-1.5 print:text-black">{new Date().toLocaleDateString('pt-BR')}</span>
              </div>
            </div>

          </div>

          {/* Certificate Body Container */}
          <div className="p-6 sm:p-8 space-y-6 print:p-4 text-slate-800 bg-white">
            
            {/* Introductory declaration */}
            <div className="text-center py-3 bg-blue-50 border border-blue-200 rounded-xl px-4 print:bg-slate-100 print:border-slate-300">
              <span className="text-xs font-black uppercase tracking-widest text-[#003b7a] print:text-slate-800">
                CERTIFICADO DE CONFORMIDADE E LAUDO TÉCNICO DE MANUTENÇÃO
              </span>
              <p className="text-[10px] text-slate-600 mt-1 max-w-2xl mx-auto leading-relaxed">
                Declaramos para os devidos fins de controle industrial e garantia normativa que o ativo hidráulico/pneumático abaixo detalhado foi submetido a protocolo rigoroso de manutenção corretiva, testes estáticos e dinâmicos de pressão, encontrando-se em perfeitas condições de uso operacional.
              </p>
            </div>

            {/* Section 1 & 2: Client and Equipment in Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Client Data Block */}
              <div className="border border-slate-300 bg-slate-50 rounded-xl p-4 space-y-3.5 print:border-slate-300 print:bg-white">
                <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-800 pb-2 border-b border-slate-200 print:text-black print:border-slate-300 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-blue-900 print:text-slate-800" />
                  <span>DADOS DO CLIENTE / PARCEIRO INDUSTRIAL</span>
                </h3>

                <div className="space-y-2 text-[11px] font-medium text-slate-700 print:text-slate-800">
                  <div className="flex">
                    <span className="w-24 text-slate-500 font-bold shrink-0">RAZÃO SOCIAL:</span>
                    <span className="text-slate-900 font-black print:text-black">{activeClient?.name || 'Não cadastrado'}</span>
                  </div>
                  <div className="flex">
                    <span className="w-24 text-slate-500 font-bold shrink-0">CNPJ/CPF:</span>
                    <span className="font-mono text-slate-800 font-bold print:text-black">{activeClient?.document || '-'}</span>
                  </div>
                  <div className="flex">
                    <span className="w-24 text-slate-500 font-bold shrink-0">CONTATO:</span>
                    <span className="text-slate-800 font-bold print:text-black">{activeClient?.phone || '-'}</span>
                  </div>
                  <div className="flex">
                    <span className="w-24 text-slate-500 font-bold shrink-0">ENDEREÇO:</span>
                    <span className="text-slate-800 truncate" title={activeClient?.address}>{activeClient?.address || '-'}</span>
                  </div>
                </div>
              </div>

              {/* Equipment Data Block */}
              <div className="border border-slate-300 bg-slate-50 rounded-xl p-4 space-y-3.5 print:border-slate-300 print:bg-white">
                <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-800 pb-2 border-b border-slate-200 print:text-black print:border-slate-300 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-blue-900 print:text-slate-800" />
                  <span>INFORMAÇÕES TÉCNICAS DO ATIVO</span>
                </h3>

                <div className="space-y-2 text-[11px] font-medium text-slate-700 print:text-slate-800">
                  <div className="flex">
                    <span className="w-24 text-slate-500 font-bold shrink-0">EQUIPAMENTO:</span>
                    <span className="text-slate-900 font-black print:text-black">{activeEquipment?.name || 'Não cadastrado'}</span>
                  </div>
                  <div className="flex">
                    <span className="w-24 text-slate-500 font-bold shrink-0">MODELO / ID:</span>
                    <span className="font-mono text-slate-800 font-bold print:text-black">{activeEquipment?.model || '-'}</span>
                  </div>
                  <div className="flex">
                    <span className="w-24 text-slate-500 font-bold shrink-0">SISTEMA:</span>
                    <span className="text-slate-800 uppercase font-bold print:text-black">{activeEquipment?.type || '-'}</span>
                  </div>
                  <div className="flex">
                    <span className="w-24 text-slate-500 font-bold shrink-0">DATA CADASTRO:</span>
                    <span className="font-mono text-slate-800 print:text-black">
                      {activeEquipment?.createdAt ? new Date(activeEquipment.createdAt).toLocaleDateString('pt-BR') : '-'}
                    </span>
                  </div>
                </div>
              </div>

            </div>

            {/* Section 3: Diagnostic Report & Pre-existing condition */}
            <div className="border border-slate-300 bg-slate-50 rounded-xl p-4 space-y-3 print:border-slate-300 print:bg-white">
              <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-800 pb-2 border-b border-slate-200 print:text-black print:border-slate-300 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                <span>1. DIAGNÓSTICO E CONSTATANTE ANTES DOS REPAROS (LAUDO DE ENTRADA)</span>
              </h3>

              <div className="text-[11px] text-slate-800 space-y-2 leading-relaxed">
                <div>
                  <strong className="text-slate-600 uppercase tracking-wide block mb-1">Anomalia Declarada pelo Cliente:</strong>
                  <p className="bg-white px-3.5 py-2 rounded-lg text-slate-900 border border-slate-300 font-medium">
                    {activeOrder.description}
                  </p>
                </div>
                <div>
                  <strong className="text-slate-600 uppercase tracking-wide block mb-1">Constatação Física Realizada em Bancada:</strong>
                  <p className="bg-blue-50/60 px-3.5 py-2.5 rounded-lg text-slate-900 border border-blue-200 font-semibold italic">
                    {activeOrder.diagnostic || 'Análise microscópica e teste de estanqueidade estrutural confirmaram desgaste abrasivo nas vedações de elastômero do pistão hidráulico com perda severa de pressão dinâmica de trabalho.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Section 4: Executed Services (Laudo de Execução) */}
            <div className="border border-slate-300 bg-slate-50 rounded-xl p-4 space-y-3.5 print:border-slate-300 print:bg-white">
              <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-800 pb-2 border-b border-slate-200 print:text-black print:border-slate-300 flex items-center gap-1.5">
                <Wrench className="w-3.5 h-3.5 text-blue-900 print:text-slate-800" />
                <span>2. PROTOCOLO DE INTERVENÇÃO E EXECUÇÃO DE SERVIÇOS TÉCNICOS</span>
              </h3>

              <div className="text-[11px] text-slate-800 space-y-2">
                <strong className="text-slate-600 uppercase tracking-wide block">Ações Corretivas Executadas:</strong>
                <p className="bg-white px-3.5 py-2.5 rounded-lg text-slate-900 border border-slate-300 leading-relaxed font-medium">
                  {activeOrder.actualServicesPerformed || 'Desmontagem completa da camisa e haste do cilindro; brunimento químico fino do cilindro interno para eliminação de ranhuras superficiais; substituição total do jogo de vedações por elastômero de alta resistência (kit Parker); remontagem e recarga de fluido com flushing térmico do óleo de trabalho.'}
                </p>
              </div>
            </div>

            {/* Section 5: Materials / Parts Replaced */}
            <div className="border border-slate-300 bg-slate-50 rounded-xl p-4 space-y-3.5 print:border-slate-300 print:bg-white">
              <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-800 pb-2 border-b border-slate-200 print:text-black print:border-slate-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 print:text-slate-800" />
                <span>3. COMPONENTES E INSUMOS SUBSTITUÍDOS</span>
              </h3>

              <div className="text-[11px] text-slate-800 leading-relaxed font-mono">
                {activeOrder.materialsUsed ? (
                  <p className="bg-white px-3.5 py-2 rounded-lg border border-slate-300 font-bold">
                    {activeOrder.materialsUsed}
                  </p>
                ) : (
                  <div className="bg-white px-3.5 py-2.5 rounded-lg border border-slate-300 text-slate-500 italic text-[10px]">
                    Nenhum componente físico específico consumido para este reparo ou incluído no kit padrão de intervenção da bancada.
                  </div>
                )}
              </div>
            </div>

            {/* Section 6: Validation Testing Metrics */}
            <div className="border border-slate-300 bg-slate-50 rounded-xl p-4 space-y-3 print:border-slate-300 print:bg-white">
              <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-800 pb-2 border-b border-slate-200 print:text-black print:border-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-900 print:text-slate-800" />
                <span>4. PROTOCOLO DE TESTE E HOMOLOGAÇÃO DE FUNCIONAMENTO</span>
              </h3>

              {/* Testing specifications table */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[10px] font-mono">
                <div className="p-2.5 bg-white border border-slate-300 rounded-lg text-center">
                  <span className="text-slate-500 block font-bold">TESTE ESTÁTICO</span>
                  <span className="text-emerald-700 font-black block mt-1">100% OK (APROVADO)</span>
                </div>
                <div className="p-2.5 bg-white border border-slate-300 rounded-lg text-center">
                  <span className="text-slate-500 block font-bold">PRESSÃO NOMINAL</span>
                  <span className="text-[#003b7a] font-black block mt-1">210 BAR (3000 PSI)</span>
                </div>
                <div className="p-2.5 bg-white border border-slate-300 rounded-lg text-center">
                  <span className="text-slate-500 block font-bold">ESTANQUEIDADE</span>
                  <span className="text-emerald-700 font-black block mt-1">0.0% VAZAMENTO</span>
                </div>
                <div className="p-2.5 bg-white border border-slate-300 rounded-lg text-center">
                  <span className="text-slate-500 block font-bold">CICLAGEM CURSO</span>
                  <span className="text-[#003b7a] font-black block mt-1">SEM RUÍDO / PERFEITO</span>
                </div>
              </div>
            </div>

            {/* Section 7: Warranty and Terms */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
              
              <div className="text-[10px] text-slate-600 leading-relaxed space-y-1">
                <span className="font-black text-slate-800 uppercase tracking-wide block">GARANTIA E RECOMENDAÇÕES DE USO:</span>
                <p>
                  1. Este serviço técnico possui garantia de <strong className="text-slate-900 font-bold">{activeOrder.warrantyDays || 90} dias</strong> contados a partir da data de entrega técnica, cobrindo eventuais falhas decorrentes de vedações ou montagem.
                </p>
                <p>
                  2. A garantia perderá validade caso constatado contaminação severa por micropartículas metálicas ou abrasivas no óleo lubrificante hidráulico externo da máquina. Recomenda-se flushing e troca de filtros de linha.
                </p>
              </div>

              {/* Signatures block */}
              <div className="flex flex-col items-center justify-end space-y-4 pt-6 md:pt-0">
                
                {/* Technician signature */}
                <div className="text-center w-full max-w-[280px] space-y-1">
                  
                  <div className="border-b border-dashed border-slate-400 pb-1.5 font-serif italic text-base text-slate-800 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-slate-500 not-italic block mb-0.5">Assinatura do Responsável</span>
                    <div className="flex items-center gap-1">
                      <Signature className="w-4 h-4 text-blue-900 shrink-0" />
                      <span className="text-xs font-bold tracking-wide text-slate-900">
                        {activeOrder.technician || 'Eng. Responsável'}
                      </span>
                    </div>
                  </div>

                  <div className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">
                    <span>{activeTechnician?.specialty || 'Técnico Homologado'}</span>
                    {activeTechnician?.phone && <span className="block mt-0.5">{activeTechnician.phone}</span>}
                  </div>
                </div>

              </div>

            </div>

          </div>

          {/* Verification Code Footer / Certificate Stamp */}
          <div className="bg-slate-100 px-6 py-4 border-t border-slate-300 text-[9px] font-mono text-slate-600 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 print:bg-white print:border-t-2 print:border-slate-800 print:text-black print:px-2">
            <div>
              <span>Código Autenticador Digital:</span>
              <span className="text-slate-900 font-black ml-1 uppercase">JCF-992384-{(activeOrder.id || '912').slice(-8)}-OK</span>
            </div>
            <div>
              <span>JC&F Assistência Hidráulica • Qualidade Assegurada ISO 9001:2015</span>
            </div>
          </div>

        </div>
      ) : (
        <div className="text-center py-16 bg-white rounded-xl border-2 border-dashed border-slate-300 text-slate-500 text-xs">
          <FileText className="w-10 h-10 mx-auto text-slate-400 mb-3" />
          Nenhuma ordem de serviço ativa selecionada ou disponível para emissão do laudo técnico.
        </div>
      )}

    </div>
  );
}
