import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Equipment, 
  InventoryItem, 
  ServiceOrder, 
  EquipmentCatalog, 
  ExplodedPartItem 
} from '../types';
import ExplodedSchematicRenderer from './ExplodedSchematicRenderer';
import { 
  Search, 
  Plus, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Printer, 
  CheckCircle, 
  AlertTriangle, 
  Package, 
  Edit2, 
  Trash2, 
  Link2, 
  Unlink, 
  Layers, 
  Wrench, 
  Upload, 
  FileText, 
  X, 
  Check, 
  Info, 
  Eye, 
  ShoppingCart, 
  ChevronRight, 
  Settings, 
  Crosshair, 
  Download,
  Maximize2,
  Clock,
  Save,
  FileEdit,
  Filter,
  Sparkles
} from 'lucide-react';

interface EquipmentCatalogManagerProps {
  catalogs: EquipmentCatalog[];
  equipments: Equipment[];
  inventory: InventoryItem[];
  orders: ServiceOrder[];
  onSaveCatalog: (catalog: EquipmentCatalog) => void;
  onDeleteCatalog: (catalogId: string) => void;
  onAddInventoryItem: (item: Omit<InventoryItem, 'id' | 'createdAt'>) => void;
  onUpdateServiceOrderMaterials?: (orderId: string, item: { itemId: string; name: string; code: string; quantity: number; salePrice: number }) => void;
  onNavigateToOS?: (orderId: string) => void;
  initialSelectedEquipmentId?: string | null;
}

const DRAFT_CATALOG_STORAGE_KEY = 'oficina_catalog_draft_v1';

interface CatalogDraftState {
  title: string;
  equipmentModel: string;
  equipmentId: string;
  category: string;
  subassembly: string;
  diagramType: 'SVG_SCHEMATIC' | 'IMAGE';
  schematicId: 'KARCHER_CABECOTE' | 'KARCHER_PISTOES' | 'BOMBA_TRIPLEX' | 'CILINDRO_HIDRAULICO' | 'CUSTOM';
  diagramImageUrl: string;
  description: string;
  savedAt: string;
}

export default function EquipmentCatalogManager({
  catalogs,
  equipments,
  inventory,
  orders,
  onSaveCatalog,
  onDeleteCatalog,
  onAddInventoryItem,
  onUpdateServiceOrderMaterials,
  onNavigateToOS,
  initialSelectedEquipmentId
}: EquipmentCatalogManagerProps) {
  // Draft persistence state from localStorage
  const [savedDraft, setSavedDraft] = useState<CatalogDraftState | null>(() => {
    try {
      const stored = localStorage.getItem(DRAFT_CATALOG_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {
      // ignore
    }
    return null;
  });
  const [draftAutoSavedText, setDraftAutoSavedText] = useState<string>('');

  // Catalog & Equipment selection filters
  const [selectedEquipmentFilter, setSelectedEquipmentFilter] = useState<string>(initialSelectedEquipmentId || '');
  const [catalogSearchFilter, setCatalogSearchFilter] = useState<string>('');
  const [catalogStatusFilter, setCatalogStatusFilter] = useState<'ALL' | 'PUBLISHED' | 'DRAFT'>('ALL');

  // Deletion Confirmation Modal
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [catalogToDelete, setCatalogToDelete] = useState<EquipmentCatalog | null>(null);

  // Filtered Catalogs List based on Equipment selection, Search and Status
  const displayedCatalogs = useMemo(() => {
    return catalogs.filter(cat => {
      // Equipment Filter
      if (selectedEquipmentFilter) {
        const matchesEquipId = cat.equipmentId === selectedEquipmentFilter;
        const targetEquip = equipments.find(e => e.id === selectedEquipmentFilter);
        const matchesModel = targetEquip && targetEquip.model && cat.equipmentModel.toLowerCase().includes(targetEquip.model.toLowerCase());
        if (!matchesEquipId && !matchesModel) return false;
      }
      // Status Filter
      if (catalogStatusFilter === 'PUBLISHED' && cat.isDraft) return false;
      if (catalogStatusFilter === 'DRAFT' && !cat.isDraft) return false;
      // Search Filter
      if (catalogSearchFilter.trim()) {
        const q = catalogSearchFilter.toLowerCase();
        const matchesTitle = cat.title.toLowerCase().includes(q);
        const matchesModel = cat.equipmentModel.toLowerCase().includes(q);
        const matchesSub = cat.subassembly.toLowerCase().includes(q);
        const matchesCat = cat.category.toLowerCase().includes(q);
        if (!matchesTitle && !matchesModel && !matchesSub && !matchesCat) return false;
      }
      return true;
    });
  }, [catalogs, selectedEquipmentFilter, catalogStatusFilter, catalogSearchFilter, equipments]);

  // Find initial catalog or fallback to first
  const initialCatId = useMemo(() => {
    if (initialSelectedEquipmentId) {
      const match = catalogs.find(c => c.equipmentId === initialSelectedEquipmentId);
      if (match) return match.id;
    }
    return catalogs[0]?.id || '';
  }, [catalogs, initialSelectedEquipmentId]);

  const [selectedCatalogId, setSelectedCatalogId] = useState<string>(initialCatId);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPartId, setSelectedPartId] = useState<string | null>(null);
  const [hoveredPartId, setHoveredPartId] = useState<string | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Auto-sync selected catalog when filter results change
  React.useEffect(() => {
    if (displayedCatalogs.length > 0) {
      const exists = displayedCatalogs.some(c => c.id === selectedCatalogId);
      if (!exists) {
        setSelectedCatalogId(displayedCatalogs[0].id);
        setSelectedPartId(null);
        setIsPlacingPinMode(false);
      }
    }
  }, [displayedCatalogs, selectedCatalogId]);

  // Pin placement mode states
  const [isPlacingPinMode, setIsPlacingPinMode] = useState(false);
  const [pinToPlace, setPinToPlace] = useState<ExplodedPartItem | null>(null);

  // Modals
  const [isCatalogModalOpen, setIsCatalogModalOpen] = useState(false);
  const [editingCatalog, setEditingCatalog] = useState<EquipmentCatalog | null>(null);
  const [isLinkStockModalOpen, setIsLinkStockModalOpen] = useState(false);
  const [partToLink, setPartToLink] = useState<ExplodedPartItem | null>(null);
  const [isEditPartModalOpen, setIsEditPartModalOpen] = useState(false);
  const [editingPart, setEditingPart] = useState<ExplodedPartItem | null>(null);
  const [isAddToOSModalOpen, setIsAddToOSModalOpen] = useState(false);
  const [partToAddToOS, setPartToAddToOS] = useState<ExplodedPartItem | null>(null);
  const [selectedOSId, setSelectedOSId] = useState<string>('');
  const [osReqQuantity, setOsReqQuantity] = useState<number>(1);
  const [feedbackToast, setFeedbackToast] = useState<{ type: 'SUCCESS' | 'ERROR'; message: string } | null>(null);

  // Stock search inside Link Modal
  const [stockSearchQuery, setStockSearchQuery] = useState('');
  const [showCreateStockInline, setShowCreateStockInline] = useState(false);
  const [newStockCode, setNewStockCode] = useState('');
  const [newStockName, setNewStockName] = useState('');
  const [newStockCategory, setNewStockCategory] = useState('Vedações');
  const [newStockQuantity, setNewStockQuantity] = useState(10);
  const [newStockPurchasePrice, setNewStockPurchasePrice] = useState(15);
  const [newStockSalePrice, setNewStockSalePrice] = useState(35);
  const [newStockUnit, setNewStockUnit] = useState('un');
  const [newStockLocation, setNewStockLocation] = useState('Gaveteiro Kärcher');

  // Catalog Form states
  const [catTitle, setCatTitle] = useState('');
  const [catModel, setCatModel] = useState('');
  const [catEquipmentId, setCatEquipmentId] = useState('');
  const [catCategory, setCatCategory] = useState('Lavadoras de Alta Pressão');
  const [catSubassembly, setCatSubassembly] = useState('Cabeçote de Válvulas');
  const [catDiagramType, setCatDiagramType] = useState<'SVG_SCHEMATIC' | 'IMAGE'>('SVG_SCHEMATIC');
  const [catSchematicId, setCatSchematicId] = useState<'KARCHER_CABECOTE' | 'KARCHER_PISTOES' | 'BOMBA_TRIPLEX' | 'CILINDRO_HIDRAULICO' | 'CUSTOM'>('KARCHER_CABECOTE');
  const [catImageUrl, setCatImageUrl] = useState('');
  const [catDescription, setCatDescription] = useState('');
  const [catIsDraft, setCatIsDraft] = useState<boolean>(false);
  const [isDraftRestoredNotice, setIsDraftRestoredNotice] = useState<boolean>(false);

  // Auto-save form draft to localStorage whenever user modifies fields in "Novo Catálogo"
  useEffect(() => {
    if (!isCatalogModalOpen || editingCatalog) return;
    
    // Only auto-save if user entered any field
    const hasContent = Boolean(
      catTitle.trim() || 
      catModel.trim() || 
      catDescription.trim() || 
      catEquipmentId || 
      catImageUrl ||
      (catSubassembly && catSubassembly !== 'Cabeçote de Válvulas')
    );
    if (!hasContent) return;

    const timer = setTimeout(() => {
      const draftData: CatalogDraftState = {
        title: catTitle,
        equipmentModel: catModel,
        equipmentId: catEquipmentId,
        category: catCategory,
        subassembly: catSubassembly,
        diagramType: catDiagramType,
        schematicId: catSchematicId,
        diagramImageUrl: catImageUrl,
        description: catDescription,
        savedAt: new Date().toISOString()
      };
      try {
        localStorage.setItem(DRAFT_CATALOG_STORAGE_KEY, JSON.stringify(draftData));
        setSavedDraft(draftData);
        const timeStr = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        setDraftAutoSavedText(`Rascunho salvo automaticamente às ${timeStr}`);
      } catch (err) {
        console.error('Erro ao salvar rascunho:', err);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [
    isCatalogModalOpen,
    editingCatalog,
    catTitle,
    catModel,
    catEquipmentId,
    catCategory,
    catSubassembly,
    catDiagramType,
    catSchematicId,
    catImageUrl,
    catDescription
  ]);

  // Part Form states
  const [partPos, setPartPos] = useState('');
  const [partBuyCode, setPartBuyCode] = useState('');
  const [partFactoryDesc, setPartFactoryDesc] = useState('');
  const [partWarehouseCode, setPartWarehouseCode] = useState('');
  const [partQtyRec, setPartQtyRec] = useState<number>(1);
  const [partNotes, setPartNotes] = useState('');

  const tableContainerRef = useRef<HTMLDivElement>(null);

  // Active Catalog
  const activeCatalog = useMemo(() => {
    if (selectedCatalogId) {
      const match = catalogs.find(c => c.id === selectedCatalogId);
      if (match) return match;
    }
    if (displayedCatalogs.length > 0) return displayedCatalogs[0];
    return catalogs[0] || null;
  }, [catalogs, selectedCatalogId, displayedCatalogs]);

  // Filtered Parts
  const filteredParts = useMemo(() => {
    if (!activeCatalog) return [];
    if (!searchQuery.trim()) return activeCatalog.parts;
    const q = searchQuery.toLowerCase();
    return activeCatalog.parts.filter(p => 
      p.position.toLowerCase().includes(q) ||
      p.factoryDescription.toLowerCase().includes(q) ||
      (p.buyCode && p.buyCode.toLowerCase().includes(q)) ||
      (p.warehouseCode && p.warehouseCode.toLowerCase().includes(q)) ||
      (p.notes && p.notes.toLowerCase().includes(q))
    );
  }, [activeCatalog, searchQuery]);

  // Selected Part Object
  const selectedPart = useMemo(() => {
    if (!activeCatalog || !selectedPartId) return null;
    return activeCatalog.parts.find(p => p.id === selectedPartId) || null;
  }, [activeCatalog, selectedPartId]);

  // Map of Inventory Items for fast lookup
  const inventoryMap = useMemo(() => {
    const map = new Map<string, InventoryItem>();
    inventory.forEach(item => {
      map.set(item.id, item);
      if (item.code) {
        map.set(item.code.toLowerCase(), item);
      }
    });
    return map;
  }, [inventory]);

  // Quick stats
  const stats = useMemo(() => {
    if (!activeCatalog) return { total: 0, linked: 0, unlinked: 0, lowStock: 0 };
    let linked = 0;
    let lowStock = 0;
    activeCatalog.parts.forEach(p => {
      if (p.inventoryItemId && inventoryMap.has(p.inventoryItemId)) {
        linked++;
        const inv = inventoryMap.get(p.inventoryItemId);
        if (inv && inv.quantity <= inv.minimumStock) lowStock++;
      } else if (p.warehouseCode && inventoryMap.has(p.warehouseCode.toLowerCase())) {
        linked++;
      }
    });
    return {
      total: activeCatalog.parts.length,
      linked,
      unlinked: activeCatalog.parts.length - linked,
      lowStock
    };
  }, [activeCatalog, inventoryMap]);

  // Toast feedback helper
  const showToast = (type: 'SUCCESS' | 'ERROR', message: string) => {
    setFeedbackToast({ type, message });
    setTimeout(() => setFeedbackToast(null), 3500);
  };

  // Handle pin placement coordinate selection from diagram click
  const handlePlacePinCoords = (x: number, y: number) => {
    if (!activeCatalog || !pinToPlace) return;
    const updatedParts = activeCatalog.parts.map(p => {
      if (p.id === pinToPlace.id) {
        return { ...p, hotspot: { x, y } };
      }
      return p;
    });
    const updatedCatalog: EquipmentCatalog = {
      ...activeCatalog,
      parts: updatedParts,
      updatedAt: new Date().toISOString()
    };
    onSaveCatalog(updatedCatalog);
    setIsPlacingPinMode(false);
    setPinToPlace(null);
    showToast('SUCCESS', `Pino da Pos. ${pinToPlace.position} reposicionado com sucesso!`);
  };

  // Open Link Stock Modal
  const handleOpenLinkStock = (part: ExplodedPartItem) => {
    setPartToLink(part);
    setStockSearchQuery(part.warehouseCode || part.factoryDescription);
    setShowCreateStockInline(false);
    // Pre-fill creation form in case user wants to create
    setNewStockCode(part.warehouseCode && part.warehouseCode !== 'XX' ? part.warehouseCode : part.buyCode || `COD-${part.position}`);
    setNewStockName(part.factoryDescription);
    setIsLinkStockModalOpen(true);
  };

  // Perform linking of inventory item to exploded part
  const handleConfirmLinkStock = (invItem: InventoryItem) => {
    if (!activeCatalog || !partToLink) return;
    const updatedParts = activeCatalog.parts.map(p => {
      if (p.id === partToLink.id) {
        return {
          ...p,
          inventoryItemId: invItem.id,
          warehouseCode: invItem.code,
        };
      }
      return p;
    });
    const updatedCatalog: EquipmentCatalog = {
      ...activeCatalog,
      parts: updatedParts,
      updatedAt: new Date().toISOString()
    };
    onSaveCatalog(updatedCatalog);
    setIsLinkStockModalOpen(false);
    setPartToLink(null);
    showToast('SUCCESS', `Peça da Pos. ${partToLink.position} vinculada ao estoque (${invItem.code})!`);
  };

  // Unlink item from stock
  const handleUnlinkStock = (part: ExplodedPartItem) => {
    if (!activeCatalog) return;
    const updatedParts = activeCatalog.parts.map(p => {
      if (p.id === part.id) {
        const { inventoryItemId, ...rest } = p;
        return { ...rest, warehouseCode: 'XX' };
      }
      return p;
    });
    const updatedCatalog: EquipmentCatalog = {
      ...activeCatalog,
      parts: updatedParts,
      updatedAt: new Date().toISOString()
    };
    onSaveCatalog(updatedCatalog);
    showToast('SUCCESS', `Peça desvinculada do estoque.`);
  };

  // Quick create item in inventory and immediately link it
  const handleCreateAndLinkStock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partToLink || !activeCatalog) return;
    if (!newStockName.trim() || !newStockCode.trim()) {
      showToast('ERROR', 'Informe o código e descrição da peça.');
      return;
    }

    const newItemData: Omit<InventoryItem, 'id' | 'createdAt'> = {
      code: newStockCode.trim().toUpperCase(),
      name: newStockName.trim(),
      category: newStockCategory,
      quantity: Number(newStockQuantity),
      minimumStock: 3,
      purchasePrice: Number(newStockPurchasePrice),
      salePrice: Number(newStockSalePrice),
      unit: newStockUnit,
      location: newStockLocation,
      supplier: 'Kärcher / Original',
      possibleApplications: activeCatalog.equipmentModel,
      description: `Item cadastrado via Catálogo de Vista Explodida (${activeCatalog.title} - Pos. ${partToLink.position})`
    };

    onAddInventoryItem(newItemData);

    // Also update catalog with this warehouse code
    const updatedParts = activeCatalog.parts.map(p => {
      if (p.id === partToLink.id) {
        return {
          ...p,
          warehouseCode: newStockCode.trim().toUpperCase(),
        };
      }
      return p;
    });

    const updatedCatalog: EquipmentCatalog = {
      ...activeCatalog,
      parts: updatedParts,
      updatedAt: new Date().toISOString()
    };
    onSaveCatalog(updatedCatalog);
    setIsLinkStockModalOpen(false);
    setPartToLink(null);
    setShowCreateStockInline(false);
    showToast('SUCCESS', `Item "${newStockName}" cadastrado no estoque e vinculado com sucesso!`);
  };

  // Open Requisition to OS Modal
  const handleOpenAddToOS = (part: ExplodedPartItem) => {
    setPartToAddToOS(part);
    setOsReqQuantity(part.quantityRecommended || 1);
    const activeOrders = orders.filter(o => o.status === 'PENDING' || o.status === 'IN_PROGRESS');
    if (activeOrders.length > 0) {
      setSelectedOSId(activeOrders[0].id);
    }
    setIsAddToOSModalOpen(true);
  };

  // Confirm Requisition to OS
  const handleConfirmAddToOS = () => {
    if (!partToAddToOS || !selectedOSId) return;
    const targetOrder = orders.find(o => o.id === selectedOSId);
    if (!targetOrder) {
      showToast('ERROR', 'Selecione uma Ordem de Serviço válida.');
      return;
    }

    // Determine inventory item or generate material entry
    const linkedInv = partToAddToOS.inventoryItemId 
      ? inventoryMap.get(partToAddToOS.inventoryItemId)
      : (partToAddToOS.warehouseCode ? inventoryMap.get(partToAddToOS.warehouseCode.toLowerCase()) : null);

    const price = linkedInv ? linkedInv.salePrice : 45.00;
    const materialEntry = {
      itemId: linkedInv ? linkedInv.id : `cat-${partToAddToOS.id}`,
      name: `${partToAddToOS.factoryDescription} (Pos. ${partToAddToOS.position})`,
      code: partToAddToOS.warehouseCode || partToAddToOS.buyCode || `POS-${partToAddToOS.position}`,
      quantity: Number(osReqQuantity),
      salePrice: price
    };

    if (onUpdateServiceOrderMaterials) {
      onUpdateServiceOrderMaterials(selectedOSId, materialEntry);
    }

    setIsAddToOSModalOpen(false);
    setPartToAddToOS(null);
    showToast('SUCCESS', `Peça requisitada com sucesso para a ${targetOrder.osNumber}!`);
  };

  // Open Edit Part Modal
  const handleOpenEditPart = (part: ExplodedPartItem) => {
    setEditingPart(part);
    setPartPos(part.position);
    setPartBuyCode(part.buyCode || '');
    setPartFactoryDesc(part.factoryDescription);
    setPartWarehouseCode(part.warehouseCode || '');
    setPartQtyRec(part.quantityRecommended || 1);
    setPartNotes(part.notes || '');
    setIsEditPartModalOpen(true);
  };

  // Save Part Row
  const handleSavePartRow = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCatalog) return;
    if (!partPos.trim() || !partFactoryDesc.trim()) {
      showToast('ERROR', 'Posição e Descrição de Fábrica são obrigatórias.');
      return;
    }

    let updatedParts: ExplodedPartItem[];
    if (editingPart) {
      updatedParts = activeCatalog.parts.map(p => {
        if (p.id === editingPart.id) {
          return {
            ...p,
            position: partPos.trim(),
            buyCode: partBuyCode.trim() || undefined,
            factoryDescription: partFactoryDesc.trim(),
            warehouseCode: partWarehouseCode.trim() || undefined,
            quantityRecommended: Number(partQtyRec) || 1,
            notes: partNotes.trim() || undefined
          };
        }
        return p;
      });
    } else {
      const newPart: ExplodedPartItem = {
        id: `pt-${Date.now()}`,
        position: partPos.trim(),
        buyCode: partBuyCode.trim() || undefined,
        factoryDescription: partFactoryDesc.trim(),
        warehouseCode: partWarehouseCode.trim() || undefined,
        quantityRecommended: Number(partQtyRec) || 1,
        notes: partNotes.trim() || undefined,
        hotspot: { x: 50, y: 50 }
      };
      updatedParts = [...activeCatalog.parts, newPart];
    }

    const updatedCatalog: EquipmentCatalog = {
      ...activeCatalog,
      parts: updatedParts,
      updatedAt: new Date().toISOString()
    };

    onSaveCatalog(updatedCatalog);
    setIsEditPartModalOpen(false);
    setEditingPart(null);
    showToast('SUCCESS', 'Tabela de peças atualizada com sucesso!');
  };

  // Delete Part Row
  const handleDeletePartRow = (partId: string) => {
    if (!activeCatalog) return;
    const updatedParts = activeCatalog.parts.filter(p => p.id !== partId);
    const updatedCatalog: EquipmentCatalog = {
      ...activeCatalog,
      parts: updatedParts,
      updatedAt: new Date().toISOString()
    };
    onSaveCatalog(updatedCatalog);
    if (selectedPartId === partId) setSelectedPartId(null);
    showToast('SUCCESS', 'Item removido do catálogo.');
  };

  // Open Create/Edit Catalog Modal
  const handleOpenCatalogModal = (cat?: EquipmentCatalog) => {
    if (cat) {
      setEditingCatalog(cat);
      setCatTitle(cat.title);
      setCatModel(cat.equipmentModel);
      setCatEquipmentId(cat.equipmentId || '');
      setCatCategory(cat.category);
      setCatSubassembly(cat.subassembly);
      setCatDiagramType(cat.diagramType);
      setCatSchematicId(cat.schematicId || 'KARCHER_CABECOTE');
      setCatImageUrl(cat.diagramImageUrl || '');
      setCatDescription(cat.description || '');
      setCatIsDraft(Boolean(cat.isDraft || cat.status === 'DRAFT'));
      setIsDraftRestoredNotice(false);
    } else {
      setEditingCatalog(null);
      // Check if we have an auto-saved draft in localStorage to restore
      let stored: CatalogDraftState | null = null;
      try {
        const raw = localStorage.getItem(DRAFT_CATALOG_STORAGE_KEY);
        if (raw) stored = JSON.parse(raw);
      } catch {
        // ignore
      }

      if (stored && (stored.title || stored.equipmentModel || stored.description || stored.equipmentId)) {
        setCatTitle(stored.title || '');
        setCatModel(stored.equipmentModel || '');
        setCatEquipmentId(stored.equipmentId || '');
        setCatCategory(stored.category || 'Lavadoras de Alta Pressão');
        setCatSubassembly(stored.subassembly || 'Cabeçote de Válvulas');
        setCatDiagramType(stored.diagramType || 'SVG_SCHEMATIC');
        setCatSchematicId(stored.schematicId || 'KARCHER_CABECOTE');
        setCatImageUrl(stored.diagramImageUrl || '');
        setCatDescription(stored.description || '');
        setCatIsDraft(true);
        setIsDraftRestoredNotice(true);
        const timeStr = stored.savedAt 
          ? new Date(stored.savedAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
          : '';
        setDraftAutoSavedText(timeStr ? `Rascunho recuperado (salvo às ${timeStr})` : 'Rascunho recuperado');
      } else {
        setCatTitle('');
        setCatModel('');
        setCatEquipmentId('');
        setCatCategory('Lavadoras de Alta Pressão');
        setCatSubassembly('Cabeçote de Válvulas');
        setCatDiagramType('SVG_SCHEMATIC');
        setCatSchematicId('KARCHER_CABECOTE');
        setCatImageUrl('');
        setCatDescription('');
        setCatIsDraft(false);
        setIsDraftRestoredNotice(false);
        setDraftAutoSavedText('');
      }
    }
    setIsCatalogModalOpen(true);
  };

  // Discard auto-saved draft from localStorage and clear form
  const handleClearDraft = () => {
    localStorage.removeItem(DRAFT_CATALOG_STORAGE_KEY);
    setSavedDraft(null);
    setDraftAutoSavedText('');
    setIsDraftRestoredNotice(false);
    setCatTitle('');
    setCatModel('');
    setCatEquipmentId('');
    setCatCategory('Lavadoras de Alta Pressão');
    setCatSubassembly('Cabeçote de Válvulas');
    setCatDiagramType('SVG_SCHEMATIC');
    setCatSchematicId('KARCHER_CABECOTE');
    setCatImageUrl('');
    setCatDescription('');
    setCatIsDraft(false);
    showToast('SUCCESS', 'Rascunho descartado. Formulário pronto para novo catálogo.');
  };

  // Handle image upload for custom diagram
  const handleDiagramImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setCatImageUrl(reader.result as string);
      setCatDiagramType('IMAGE');
      setCatSchematicId('CUSTOM');
    };
    reader.readAsDataURL(file);
  };

  // Save Catalog (supports both Finalized/Published and Draft)
  const handleSaveCatalog = (e?: React.FormEvent, forceDraft?: boolean) => {
    if (e) e.preventDefault();
    if (!catTitle.trim() || !catModel.trim()) {
      showToast('ERROR', 'Preencha o título do catálogo e o modelo do equipamento.');
      return;
    }

    const isDraftToSave = forceDraft !== undefined ? forceDraft : catIsDraft;
    const statusVal: 'PUBLISHED' | 'DRAFT' = isDraftToSave ? 'DRAFT' : 'PUBLISHED';

    if (editingCatalog) {
      const updated: EquipmentCatalog = {
        ...editingCatalog,
        title: catTitle.trim(),
        equipmentModel: catModel.trim(),
        equipmentId: catEquipmentId || undefined,
        category: catCategory,
        subassembly: catSubassembly.trim(),
        diagramType: catDiagramType,
        schematicId: catSchematicId,
        diagramImageUrl: catImageUrl || undefined,
        description: catDescription.trim() || undefined,
        isDraft: isDraftToSave,
        status: statusVal,
        updatedAt: new Date().toISOString()
      };
      onSaveCatalog(updated);
      showToast('SUCCESS', isDraftToSave ? 'Catálogo atualizado e salvo como Rascunho!' : 'Catálogo técnico publicado com sucesso!');
    } else {
      const newCat: EquipmentCatalog = {
        id: `cat-${Date.now()}`,
        title: catTitle.trim(),
        equipmentModel: catModel.trim(),
        equipmentId: catEquipmentId || undefined,
        category: catCategory,
        subassembly: catSubassembly.trim(),
        diagramType: catDiagramType,
        schematicId: catSchematicId,
        diagramImageUrl: catImageUrl || undefined,
        description: catDescription.trim() || undefined,
        isDraft: isDraftToSave,
        status: statusVal,
        parts: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      onSaveCatalog(newCat);
      setSelectedCatalogId(newCat.id);
      showToast('SUCCESS', isDraftToSave 
        ? 'Novo catálogo salvo como Rascunho! Você pode complementá-lo quando desejar.' 
        : 'Novo catálogo de equipamento criado e publicado!');
    }

    // Clear auto-saved draft from localStorage because it is now committed to the catalog list
    localStorage.removeItem(DRAFT_CATALOG_STORAGE_KEY);
    setSavedDraft(null);
    setDraftAutoSavedText('');
    setIsCatalogModalOpen(false);
  };

  // Delete Catalog Confirmation
  const handleRequestDeleteCatalog = (cat: EquipmentCatalog) => {
    setCatalogToDelete(cat);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDeleteCatalog = () => {
    if (!catalogToDelete) return;
    onDeleteCatalog(catalogToDelete.id);
    showToast('SUCCESS', `Catálogo "${catalogToDelete.title}" excluído com sucesso.`);
    setIsDeleteModalOpen(false);
    setCatalogToDelete(null);
    if (isCatalogModalOpen && editingCatalog?.id === catalogToDelete.id) {
      setIsCatalogModalOpen(false);
    }
  };

  // Filter stock candidates inside the Link Stock modal
  const filteredStockCandidates = useMemo(() => {
    if (!stockSearchQuery.trim()) return inventory.slice(0, 8);
    const q = stockSearchQuery.toLowerCase();
    return inventory.filter(item => 
      item.code.toLowerCase().includes(q) ||
      item.name.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q) ||
      (item.possibleApplications && item.possibleApplications.toLowerCase().includes(q))
    ).slice(0, 15);
  }, [inventory, stockSearchQuery]);

  return (
    <div className="space-y-5" id="equipment-catalog-manager">
      {/* Feedback Toast Notification */}
      {feedbackToast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 border text-sm font-bold animate-bounce ${
          feedbackToast.type === 'SUCCESS' 
            ? 'bg-emerald-900 border-emerald-500 text-emerald-100' 
            : 'bg-rose-900 border-rose-500 text-rose-100'
        }`}>
          {feedbackToast.type === 'SUCCESS' ? <CheckCircle className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-rose-400" />}
          <span>{feedbackToast.message}</span>
        </div>
      )}

      {/* Header Banner - Industrial Blue Theme */}
      <div className="bg-[#112847] border-2 border-blue-900 rounded-2xl p-4 sm:p-5 text-white shadow-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#0052cc] text-cyan-200 border border-cyan-400/40 font-mono">
              MANUAL TÉCNICO &amp; ALMOXARIFADO
            </span>
            <span className="text-xs text-slate-300 font-mono">| Vistas Explodidas Interativas</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Layers className="w-6 h-6 text-cyan-400" />
            <span>Catálogo de Equipamentos &amp; Vista Explodida</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Visualize o esquema interno (válvulas, gaxetas, pistões, o-rings) e vincule diretamente com as peças cadastradas no estoque da oficina.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#1b365d] hover:bg-[#004a99] text-cyan-200 hover:text-white rounded-xl text-xs font-bold border border-blue-700 shadow-sm transition-all cursor-pointer"
            title="Imprimir Folha Técnica com Vista Explodida e Tabela"
          >
            <Printer className="w-4 h-4 text-cyan-300" />
            <span>Imprimir Ficha</span>
          </button>
          <button
            type="button"
            onClick={() => handleOpenCatalogModal()}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black tracking-wider uppercase shadow-lg border border-emerald-400 transition-all cursor-pointer relative"
            id="btn-new-catalog"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Catálogo</span>
            {savedDraft && (
              <span className="px-1.5 py-0.5 rounded-md text-[9px] bg-amber-300 text-amber-950 font-black tracking-normal uppercase ml-1 animate-pulse">
                Rascunho
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Enhanced Catalog Selection & Management Strip */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3.5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          {/* Filter by Equipment */}
          <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="relative min-w-[240px] flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Wrench className="w-3.5 h-3.5 text-blue-600" />
              </div>
              <select
                value={selectedEquipmentFilter}
                onChange={(e) => setSelectedEquipmentFilter(e.target.value)}
                className="w-full pl-9 pr-8 py-2 text-xs font-bold border border-slate-300 rounded-xl bg-slate-50 hover:bg-white focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all text-slate-800"
              >
                <option value="">-- Todos os Equipamentos ({catalogs.length} catálogos) --</option>
                {equipments.map(eq => {
                  const catCount = catalogs.filter(c => c.equipmentId === eq.id || (eq.model && c.equipmentModel.toLowerCase().includes(eq.model.toLowerCase()))).length;
                  return (
                    <option key={eq.id} value={eq.id}>
                      {eq.name} ({eq.model || 'Sem modelo'}) {catCount > 0 ? `• [${catCount} catálogo(s)]` : ''}
                    </option>
                  );
                })}
              </select>
            </div>

            {/* Instant search query */}
            <div className="relative min-w-[200px] flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Search className="w-3.5 h-3.5" />
              </div>
              <input
                type="text"
                value={catalogSearchFilter}
                onChange={(e) => setCatalogSearchFilter(e.target.value)}
                placeholder="Buscar por modelo, subconjunto..."
                className="w-full pl-9 pr-7 py-2 text-xs border border-slate-300 rounded-xl bg-slate-50 hover:bg-white focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all font-semibold"
              />
              {catalogSearchFilter && (
                <button
                  type="button"
                  onClick={() => setCatalogSearchFilter('')}
                  className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Status filter tabs & Action buttons */}
          <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
            <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-bold">
              <button
                type="button"
                onClick={() => setCatalogStatusFilter('ALL')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  catalogStatusFilter === 'ALL'
                    ? 'bg-white text-blue-700 shadow-2xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Todos ({catalogs.length})
              </button>
              <button
                type="button"
                onClick={() => setCatalogStatusFilter('PUBLISHED')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  catalogStatusFilter === 'PUBLISHED'
                    ? 'bg-white text-emerald-700 shadow-2xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Publicados ({catalogs.filter(c => !c.isDraft).length})
              </button>
              <button
                type="button"
                onClick={() => setCatalogStatusFilter('DRAFT')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                  catalogStatusFilter === 'DRAFT'
                    ? 'bg-white text-amber-700 shadow-2xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Clock className="w-3 h-3" />
                <span>Rascunhos ({catalogs.filter(c => c.isDraft).length})</span>
              </button>
            </div>

            {activeCatalog && (
              <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200">
                <button
                  type="button"
                  onClick={() => handleOpenCatalogModal(activeCatalog)}
                  className="px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-blue-700 hover:bg-blue-50 rounded-xl border border-slate-200 flex items-center gap-1.5 transition-all shadow-2xs cursor-pointer"
                  title="Editar dados cadastrais deste catálogo"
                >
                  <Edit2 className="w-3.5 h-3.5 text-blue-600" />
                  <span className="hidden sm:inline">Editar</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleRequestDeleteCatalog(activeCatalog)}
                  className="p-1.5 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-xl border border-slate-200 transition-all shadow-2xs cursor-pointer"
                  title="Excluir este catálogo"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Catalog Selection List / Pills */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pb-1 pt-0.5">
          {displayedCatalogs.length === 0 ? (
            <div className="py-2 text-xs text-slate-500 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>Nenhum catálogo corresponde aos filtros aplicados.</span>
              <button
                type="button"
                onClick={() => {
                  setSelectedEquipmentFilter('');
                  setCatalogSearchFilter('');
                  setCatalogStatusFilter('ALL');
                }}
                className="text-blue-600 font-bold underline hover:text-blue-800 cursor-pointer ml-1"
              >
                Limpar filtros
              </button>
            </div>
          ) : (
            displayedCatalogs.map(cat => {
              const isSelected = cat.id === activeCatalog?.id;
              const isDraft = Boolean(cat.isDraft || cat.status === 'DRAFT');
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => {
                    setSelectedCatalogId(cat.id);
                    setSelectedPartId(null);
                    setIsPlacingPinMode(false);
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-bold tracking-wide whitespace-nowrap transition-all flex items-center gap-2.5 cursor-pointer border shrink-0 ${
                    isSelected
                      ? 'bg-[#0052cc] text-white shadow-md border-cyan-400 ring-2 ring-blue-400/30'
                      : isDraft
                        ? 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  <div className="flex flex-col text-left">
                    <div className="flex items-center gap-1.5">
                      <span className="font-extrabold">{cat.title}</span>
                      {isDraft && (
                        <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-black tracking-wider uppercase flex items-center gap-0.5 ${
                          isSelected ? 'bg-amber-400 text-slate-950' : 'bg-amber-200 text-amber-900'
                        }`}>
                          <Clock className="w-2.5 h-2.5" />
                          Rascunho
                        </span>
                      )}
                    </div>
                    <span className={`text-[10px] font-medium truncate max-w-[200px] ${isSelected ? 'text-cyan-200' : 'text-slate-500'}`}>
                      {cat.equipmentModel} • {cat.subassembly}
                    </span>
                  </div>
                  <span className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold ${
                    isSelected ? 'bg-cyan-300 text-slate-950 font-black' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {cat.parts.length} peças
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>

      {activeCatalog ? (
        <div className="space-y-4">
          {/* Draft Banner if current catalog is saved as draft */}
          {(activeCatalog.isDraft || activeCatalog.status === 'DRAFT') && (
            <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start sm:items-center gap-3">
                <div className="p-2.5 bg-amber-200 text-amber-900 rounded-xl shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-xs uppercase tracking-wider text-amber-900 font-mono">
                      Catálogo em Rascunho (Em Andamento)
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-200 text-amber-950 font-bold">
                      Salvo para complementação futura
                    </span>
                  </div>
                  <p className="text-xs text-amber-800 mt-0.5">
                    As informações deste catálogo estão seguras. Você pode continuar adicionando itens, ajustar dados técnicos e publicá-lo quando desejar.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                <button
                  type="button"
                  onClick={() => handleOpenCatalogModal(activeCatalog)}
                  className="px-3 py-1.5 bg-white hover:bg-amber-100 text-amber-950 font-bold text-xs rounded-xl border border-amber-300 shadow-2xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5 text-amber-700" />
                  <span>Editar / Complementar</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const published: EquipmentCatalog = {
                      ...activeCatalog,
                      isDraft: false,
                      status: 'PUBLISHED',
                      updatedAt: new Date().toISOString()
                    };
                    onSaveCatalog(published);
                    showToast('SUCCESS', 'Catálogo publicado definitivamente com sucesso!');
                  }}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Publicar Agora</span>
                </button>
              </div>
            </div>
          )}

          {/* Active Catalog Description Bar & Summary Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs flex items-center gap-3">
              <div className="p-2.5 bg-blue-50 text-blue-700 rounded-lg shrink-0">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Modelo &amp; Subconjunto</span>
                <p className="text-sm font-black text-slate-800 truncate">{activeCatalog.equipmentModel} - {activeCatalog.subassembly}</p>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs flex items-center gap-3">
              <div className="p-2.5 bg-cyan-50 text-cyan-700 rounded-lg shrink-0">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Total de Componentes</span>
                <p className="text-sm font-black text-slate-800">{stats.total} posições mapeadas</p>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs flex items-center gap-3">
              <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-lg shrink-0">
                <CheckCircle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Vinculados ao Estoque</span>
                <p className="text-sm font-black text-emerald-700">{stats.linked} peças sincronizadas ({Math.round((stats.linked / (stats.total || 1)) * 100)}%)</p>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs flex items-center gap-3">
              <div className="p-2.5 bg-amber-50 text-amber-700 rounded-lg shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Não Vinculados / Atenção</span>
                <p className="text-sm font-black text-amber-700">{stats.unlinked} pendentes de código</p>
              </div>
            </div>
          </div>

          {/* Main 2-Column Split: Diagram on Left | Technical Parts Table on Right (Matching User Photo Layout) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* Left Column: Exploded Diagram Area (5 of 12 cols on desktop) */}
            <div className="lg:col-span-6 space-y-3">
              <div className="bg-white border-2 border-slate-300 rounded-2xl p-4 shadow-sm">
                
                {/* Diagram Top Control Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-slate-800 flex items-center gap-1.5 uppercase font-mono">
                      <Eye className="w-4 h-4 text-blue-600" />
                      Vista Explodida
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      ({activeCatalog.diagramType === 'SVG_SCHEMATIC' ? 'Esquema Vetorial HD' : 'Foto Técnica'})
                    </span>
                  </div>

                  {/* Zoom & Pin Placer Controls */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setZoomLevel(prev => Math.min(prev + 0.15, 2.0))}
                      className="p-1.5 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 cursor-pointer"
                      title="Aumentar Zoom"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setZoomLevel(prev => Math.max(prev - 0.15, 0.7))}
                      className="p-1.5 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 cursor-pointer"
                      title="Diminuir Zoom"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setZoomLevel(1)}
                      className="p-1.5 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 cursor-pointer"
                      title="Resetar Zoom"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>

                    <div className="h-4 w-px bg-slate-300 mx-1"></div>

                    <button
                      type="button"
                      onClick={() => {
                        setIsPlacingPinMode(!isPlacingPinMode);
                        if (!isPlacingPinMode && !pinToPlace && activeCatalog.parts.length > 0) {
                          setPinToPlace(selectedPart || activeCatalog.parts[0]);
                        }
                      }}
                      className={`px-2.5 py-1 text-xs font-bold rounded-lg border flex items-center gap-1 cursor-pointer transition-all ${
                        isPlacingPinMode 
                          ? 'bg-amber-500 text-slate-950 border-amber-600 font-black ring-2 ring-amber-300' 
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
                      }`}
                      title="Ativar modo para clicar no desenho e reposicionar os pinos"
                    >
                      <Crosshair className="w-3.5 h-3.5" />
                      <span>{isPlacingPinMode ? 'Cancelar Reposicionamento' : 'Mover Pinos'}</span>
                    </button>
                  </div>
                </div>

                {/* Exploded Interactive Drawing Component */}
                <ExplodedSchematicRenderer
                  schematicId={activeCatalog.schematicId}
                  imageUrl={activeCatalog.diagramImageUrl}
                  diagramType={activeCatalog.diagramType}
                  parts={activeCatalog.parts}
                  selectedPartId={selectedPartId}
                  hoveredPartId={hoveredPartId}
                  onSelectPart={(part) => {
                    setSelectedPartId(part.id);
                    // Also scroll table to that row
                    const rowElem = document.getElementById(`part-row-${part.id}`);
                    if (rowElem) {
                      rowElem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }
                  }}
                  onHoverPart={(partId) => setHoveredPartId(partId)}
                  isPlacingPinMode={isPlacingPinMode}
                  pinToPlace={pinToPlace}
                  onPlacePinCoords={handlePlacePinCoords}
                  zoomLevel={zoomLevel}
                />

                {/* Legend Help Bar */}
                <div className="mt-3 pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between text-[11px] text-slate-500 gap-2">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1 font-semibold">
                      <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block"></span>
                      Em Estoque
                    </span>
                    <span className="flex items-center gap-1 font-semibold">
                      <span className="w-3 h-3 rounded-full bg-[#1b365d] inline-block"></span>
                      Padrão de Fábrica
                    </span>
                    <span className="flex items-center gap-1 font-semibold">
                      <span className="w-3 h-3 rounded-full bg-[#0052cc] border-2 border-cyan-400 inline-block"></span>
                      Selecionado
                    </span>
                  </div>
                  <span className="italic text-slate-400">Passe o mouse ou clique no pino para destacar</span>
                </div>
              </div>

              {/* Selected Item Quick Inspector Card */}
              {selectedPart && (
                <div className="bg-[#0f172a] text-white border-2 border-blue-600 rounded-xl p-4 shadow-lg animate-in fade-in duration-150">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-full bg-cyan-400 text-slate-950 font-black flex items-center justify-center font-mono text-sm shadow-sm">
                        {selectedPart.position}
                      </span>
                      <div>
                        <h4 className="font-extrabold text-sm text-cyan-200 leading-tight">
                          {selectedPart.factoryDescription}
                        </h4>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Cód. Compra: {selectedPart.buyCode || 'N/D'}
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedPartId(null)}
                      className="text-slate-400 hover:text-white p-1"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Stock Linking Status inside Inspector */}
                  <div className="bg-[#1e293b] rounded-lg p-2.5 my-2 border border-slate-700 text-xs">
                    {selectedPart.inventoryItemId && inventoryMap.has(selectedPart.inventoryItemId) ? (
                      (() => {
                        const inv = inventoryMap.get(selectedPart.inventoryItemId)!;
                        const isLow = inv.quantity <= inv.minimumStock;
                        return (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-emerald-400 font-bold flex items-center gap-1">
                                <CheckCircle className="w-3.5 h-3.5" />
                                Vinculado ao Estoque:
                              </span>
                              <span className="font-mono text-white font-bold">{inv.code}</span>
                            </div>
                            <p className="text-slate-300 truncate font-semibold">{inv.name}</p>
                            <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-700">
                              <span className={`${isLow ? 'text-amber-400 font-black' : 'text-slate-200'}`}>
                                Saldo: <strong>{inv.quantity} {inv.unit}</strong> {isLow && '(Baixo Estoque!)'}
                              </span>
                              <span className="text-cyan-300 font-mono">
                                Venda: R$ {inv.salePrice.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        );
                      })()
                    ) : selectedPart.warehouseCode && selectedPart.warehouseCode !== 'XX' ? (
                      <div className="flex items-center justify-between text-slate-300">
                        <span>Código do Almoxarifado:</span>
                        <span className="font-mono font-bold text-amber-300 bg-slate-800 px-2 py-0.5 rounded">
                          {selectedPart.warehouseCode}
                        </span>
                      </div>
                    ) : (
                      <div className="text-amber-300 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 shrink-0" />
                        <span>Peça ainda não vinculada a um item do estoque da oficina.</span>
                      </div>
                    )}
                  </div>

                  {/* Inspector Action Buttons */}
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => handleOpenLinkStock(selectedPart)}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-[#0052cc] hover:bg-[#004a99] text-white rounded-lg text-xs font-bold transition-all cursor-pointer"
                    >
                      <Link2 className="w-3.5 h-3.5 text-cyan-300" />
                      <span>{selectedPart.inventoryItemId ? 'Alterar Vínculo' : 'Vincular ao Estoque'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleOpenAddToOS(selectedPart)}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>Requisitar para OS</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPinToPlace(selectedPart);
                        setIsPlacingPinMode(true);
                      }}
                      className="px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs border border-slate-700 cursor-pointer"
                      title="Mover pino no desenho"
                    >
                      <Crosshair className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column: Technical Parts Breakdown Table (6 of 12 cols on desktop, styled like User Photo) */}
            <div className="lg:col-span-6 space-y-3">
              <div className="bg-white border-2 border-slate-300 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full">
                
                {/* Table Header Controls */}
                <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                      <FileText className="w-4 h-4 text-cyan-700" />
                      Tabela de Componentes Internos
                    </h3>
                    <p className="text-xs text-slate-500">
                      Relação de peças, códigos de fábrica e códigos no almoxarifado
                    </p>
                  </div>

                  {/* Search and Add Part Row */}
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Buscar peça..."
                        className="pl-8 pr-3 py-1 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 w-36 sm:w-44"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingPart(null);
                        setPartPos(`${activeCatalog.parts.length + 1}`);
                        setPartBuyCode('');
                        setPartFactoryDesc('');
                        setPartWarehouseCode('');
                        setPartQtyRec(1);
                        setPartNotes('');
                        setIsEditPartModalOpen(true);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 bg-blue-700 hover:bg-blue-600 text-white rounded-lg text-xs font-bold cursor-pointer"
                      title="Adicionar nova posição"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Peça</span>
                    </button>
                  </div>
                </div>

                {/* The Technical Table (Styled with teal header matching user's photo) */}
                <div 
                  ref={tableContainerRef}
                  className="overflow-x-auto overflow-y-auto max-h-[580px] scrollbar-thin divide-y divide-slate-200 flex-grow"
                >
                  <table className="w-full text-left border-collapse min-w-[540px]">
                    {/* Teal Header exact color from user photo: #1e6b7b */}
                    <thead className="bg-[#1e6b7b] text-white sticky top-0 z-10 select-none">
                      <tr className="text-[11px] font-mono tracking-wider font-extrabold border-b-2 border-cyan-900">
                        <th className="py-2.5 px-3 text-center w-14 border-r border-teal-800">Pos.</th>
                        <th className="py-2.5 px-3 w-28 border-r border-teal-800">COD. COMPRA</th>
                        <th className="py-2.5 px-3 border-r border-teal-800">DESCRIÇÃO FÁBRICA</th>
                        <th className="py-2.5 px-3 w-32 border-r border-teal-800">COD. ALMOX</th>
                        <th className="py-2.5 px-2.5 text-center w-28">AÇÕES</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-xs">
                      {filteredParts.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-8 text-center text-slate-400">
                            Nenhuma peça encontrada para o filtro informado.
                          </td>
                        </tr>
                      ) : (
                        filteredParts.map((part, index) => {
                          const isSelected = selectedPartId === part.id;
                          const isHovered = hoveredPartId === part.id;
                          
                          // Check if linked to inventory
                          const linkedInv = part.inventoryItemId 
                            ? inventoryMap.get(part.inventoryItemId) 
                            : (part.warehouseCode ? inventoryMap.get(part.warehouseCode.toLowerCase()) : null);

                          const hasStock = !!linkedInv;
                          const isXX = part.warehouseCode === 'XX' || !part.warehouseCode;

                          return (
                            <tr
                              key={part.id}
                              id={`part-row-${part.id}`}
                              onClick={() => setSelectedPartId(part.id)}
                              onMouseEnter={() => setHoveredPartId(part.id)}
                              onMouseLeave={() => setHoveredPartId(null)}
                              className={`transition-colors cursor-pointer group ${
                                isSelected
                                  ? 'bg-blue-100/90 font-semibold border-l-4 border-l-blue-600'
                                  : isHovered
                                  ? 'bg-amber-50/80'
                                  : index % 2 === 0
                                  ? 'bg-white'
                                  : 'bg-slate-50/70'
                              }`}
                            >
                              {/* Pos. Column */}
                              <td className="py-2.5 px-3 text-center font-mono font-black border-r border-slate-200">
                                <span className={`inline-flex items-center justify-center px-1.5 py-0.5 rounded-md min-w-[24px] ${
                                  isSelected 
                                    ? 'bg-[#0052cc] text-white' 
                                    : hasStock 
                                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' 
                                    : 'bg-slate-200 text-slate-800'
                                }`}>
                                  {part.position}
                                </span>
                              </td>

                              {/* COD. COMPRA Column */}
                              <td className="py-2.5 px-3 font-mono text-slate-600 border-r border-slate-200 whitespace-nowrap">
                                {part.buyCode ? (
                                  <span>{part.buyCode}</span>
                                ) : (
                                  <span className="text-slate-300 italic">-</span>
                                )}
                              </td>

                              {/* DESCRIÇÃO FÁBRICA Column */}
                              <td className="py-2.5 px-3 font-bold text-slate-800 border-r border-slate-200">
                                <div className="flex flex-col">
                                  <span>{part.factoryDescription}</span>
                                  {part.notes && (
                                    <span className="text-[10px] text-slate-500 font-normal truncate max-w-xs">
                                      {part.notes}
                                    </span>
                                  )}
                                </div>
                              </td>

                              {/* COD. ALMOX Column */}
                              <td className="py-2.5 px-3 border-r border-slate-200">
                                {hasStock && linkedInv ? (
                                  <div className="flex flex-col">
                                    <div className="flex items-center gap-1 font-mono font-black text-emerald-800">
                                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                                      <span>{linkedInv.code}</span>
                                    </div>
                                    <span className="text-[10px] text-slate-500">
                                      {linkedInv.quantity} {linkedInv.unit} disp.
                                    </span>
                                  </div>
                                ) : isXX ? (
                                  <div className="flex items-center gap-1 text-rose-600 font-bold font-mono">
                                    <span className="px-1.5 py-0.5 bg-rose-50 border border-rose-200 rounded text-[11px]">
                                      XX (Pendente)
                                    </span>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-1 font-mono font-bold text-slate-800">
                                    <span>{part.warehouseCode}</span>
                                  </div>
                                )}
                              </td>

                              {/* AÇÕES Column */}
                              <td className="py-2.5 px-2 text-center" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center justify-center gap-1">
                                  {/* Link to stock button */}
                                  <button
                                    type="button"
                                    onClick={() => handleOpenLinkStock(part)}
                                    title={hasStock ? 'Alterar vínculo de estoque' : 'Vincular a item do estoque'}
                                    className={`p-1.5 rounded-md transition-colors ${
                                      hasStock 
                                        ? 'text-emerald-700 hover:bg-emerald-50' 
                                        : 'text-blue-700 hover:bg-blue-50 bg-blue-50/50'
                                    }`}
                                  >
                                    <Link2 className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Requisition to OS button */}
                                  <button
                                    type="button"
                                    onClick={() => handleOpenAddToOS(part)}
                                    title="Adicionar à Ordem de Serviço"
                                    className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors"
                                  >
                                    <ShoppingCart className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Edit Row */}
                                  <button
                                    type="button"
                                    onClick={() => handleOpenEditPart(part)}
                                    title="Editar informações da linha"
                                    className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-md transition-colors"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Delete Row */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (confirm(`Excluir a Pos. ${part.position} (${part.factoryDescription})?`)) {
                                        handleDeletePartRow(part.id);
                                      }
                                    }}
                                    title="Excluir posição"
                                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Table Footer Summary Bar */}
                <div className="p-3 bg-slate-100 border-t border-slate-200 text-xs text-slate-600 flex flex-wrap items-center justify-between gap-2">
                  <span className="font-mono">
                    Exibindo <strong>{filteredParts.length}</strong> de <strong>{activeCatalog.parts.length}</strong> componentes
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingPart(null);
                        setPartPos(`${activeCatalog.parts.length + 1}`);
                        setPartBuyCode('');
                        setPartFactoryDesc('');
                        setPartWarehouseCode('');
                        setPartQtyRec(1);
                        setPartNotes('');
                        setIsEditPartModalOpen(true);
                      }}
                      className="px-3 py-1 bg-white hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Inserir Linha</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-slate-500 font-bold mb-3">Nenhum catálogo cadastrado no momento.</p>
          <button
            type="button"
            onClick={() => handleOpenCatalogModal()}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg font-bold text-xs"
          >
            Cadastrar Primeiro Catálogo
          </button>
        </div>
      )}

      {/* =========================================================================
          MODAL 1: Vincular Peça ao Estoque da Oficina
          ========================================================================= */}
      {isLinkStockModalOpen && partToLink && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            {/* Modal Header */}
            <div className="p-4 bg-[#112847] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <Link2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-black text-sm">Vincular Peça do Catálogo ao Estoque</h3>
                  <p className="text-xs text-cyan-200 font-mono">
                    Pos. {partToLink.position} - {partToLink.factoryDescription}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsLinkStockModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-5 overflow-y-auto space-y-4 flex-grow">
              
              {/* Part reference info box */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="text-slate-400 block font-mono text-[10px] uppercase">Descrição de Fábrica:</span>
                  <span className="font-extrabold text-slate-800">{partToLink.factoryDescription}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-mono text-[10px] uppercase">Cód. Fábrica / Compra:</span>
                  <span className="font-mono font-bold text-blue-700">{partToLink.buyCode || 'N/D'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-mono text-[10px] uppercase">Cód. Almox Atual:</span>
                  <span className="font-mono font-bold text-amber-700">{partToLink.warehouseCode || 'XX'}</span>
                </div>
              </div>

              {/* Mode switcher: Pick from existing vs Create new item */}
              <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-2">
                <span className="text-xs font-black text-slate-800 uppercase tracking-wider font-mono">
                  {showCreateStockInline ? 'Cadastrar Novo Item no Estoque' : 'Escolher Item Cadastrado no Estoque'}
                </span>
                <button
                  type="button"
                  onClick={() => setShowCreateStockInline(!showCreateStockInline)}
                  className="text-xs font-bold text-blue-700 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  {showCreateStockInline ? (
                    <span>← Voltar para Busca de Estoque</span>
                  ) : (
                    <span>+ Peça não cadastrada? Criar no Estoque</span>
                  )}
                </button>
              </div>

              {!showCreateStockInline ? (
                <div className="space-y-3">
                  {/* Search Bar */}
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={stockSearchQuery}
                      onChange={(e) => setStockSearchQuery(e.target.value)}
                      placeholder="Pesquise por código, nome, gaxeta, o-ring, pistão..."
                      className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                      autoFocus
                    />
                  </div>

                  {/* Stock List candidates */}
                  <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                    {filteredStockCandidates.length === 0 ? (
                      <div className="p-6 text-center text-slate-400 text-xs border border-dashed border-slate-300 rounded-xl">
                        <p>Nenhum item correspondente encontrado no estoque.</p>
                        <button
                          type="button"
                          onClick={() => setShowCreateStockInline(true)}
                          className="mt-2 text-blue-600 font-bold hover:underline"
                        >
                          Clique aqui para cadastrar agora no estoque com 1 clique
                        </button>
                      </div>
                    ) : (
                      filteredStockCandidates.map(invItem => {
                        const isCurrentLinked = partToLink.inventoryItemId === invItem.id || (partToLink.warehouseCode && partToLink.warehouseCode.toUpperCase() === invItem.code.toUpperCase());
                        return (
                          <div
                            key={invItem.id}
                            onClick={() => handleConfirmLinkStock(invItem)}
                            className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                              isCurrentLinked
                                ? 'bg-emerald-50 border-emerald-500 shadow-xs'
                                : 'bg-white hover:bg-blue-50/70 border-slate-200'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`p-2 rounded-lg font-mono text-xs font-black shrink-0 ${
                                isCurrentLinked ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                              }`}>
                                {invItem.code}
                              </div>
                              <div>
                                <h5 className="font-bold text-xs text-slate-900">{invItem.name}</h5>
                                <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono mt-0.5">
                                  <span>{invItem.category}</span>
                                  <span>•</span>
                                  <span>Local: {invItem.location || 'Oficina'}</span>
                                </div>
                              </div>
                            </div>

                            <div className="text-right shrink-0">
                              <span className={`block font-mono font-black text-xs ${
                                invItem.quantity <= invItem.minimumStock ? 'text-amber-600' : 'text-emerald-700'
                              }`}>
                                {invItem.quantity} {invItem.unit}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                R$ {invItem.salePrice.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {partToLink.inventoryItemId && (
                    <div className="pt-2 border-t border-slate-200 flex justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          handleUnlinkStock(partToLink);
                          setIsLinkStockModalOpen(false);
                        }}
                        className="text-xs text-rose-600 hover:text-rose-700 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Unlink className="w-3.5 h-3.5" />
                        <span>Desvincular esta peça do estoque</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                /* Inline Create & Link Form */
                <form onSubmit={handleCreateAndLinkStock} className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">CÓDIGO NO ALMOXARIFADO *</label>
                      <input
                        type="text"
                        value={newStockCode}
                        onChange={(e) => setNewStockCode(e.target.value.toUpperCase())}
                        required
                        className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono font-bold"
                        placeholder="Ex: N70-2151 ou 63653930"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">CATEGORIA *</label>
                      <select
                        value={newStockCategory}
                        onChange={(e) => setNewStockCategory(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                      >
                        <option value="Vedações">Vedações (O-Rings, Anéis)</option>
                        <option value="Gaxetas">Gaxetas &amp; Raspadores</option>
                        <option value="Válvulas">Válvulas &amp; Assentos</option>
                        <option value="Pistões">Pistões &amp; Guias</option>
                        <option value="Molas">Molas Helicoidais</option>
                        <option value="Filtros">Filtros &amp; Elementos</option>
                        <option value="Conectores">Conectores &amp; Engates</option>
                        <option value="Fixadores">Fixadores &amp; Parafusos</option>
                        <option value="Outros">Outros Componentes</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">DESCRIÇÃO DO ITEM *</label>
                    <input
                      type="text"
                      value={newStockName}
                      onChange={(e) => setNewStockName(e.target.value)}
                      required
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-semibold"
                      placeholder="Ex: O'Ring 75,87 x 2,62 NBR 70 ShA"
                    />
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">QTD INICIAL</label>
                      <input
                        type="number"
                        min="0"
                        value={newStockQuantity}
                        onChange={(e) => setNewStockQuantity(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg font-mono font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">UNIDADE</label>
                      <input
                        type="text"
                        value={newStockUnit}
                        onChange={(e) => setNewStockUnit(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                        placeholder="un, jogo, metro"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">PREÇO COMPRA (R$)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={newStockPurchasePrice}
                        onChange={(e) => setNewStockPurchasePrice(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">PREÇO VENDA (R$)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={newStockSalePrice}
                        onChange={(e) => setNewStockSalePrice(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg font-mono font-bold text-emerald-700"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">LOCALIZAÇÃO NO ESTOQUE</label>
                    <input
                      type="text"
                      value={newStockLocation}
                      onChange={(e) => setNewStockLocation(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                      placeholder="Ex: Gaveteiro Kärcher - Gaveta 1"
                    />
                  </div>

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowCreateStockInline(false)}
                      className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-200 rounded-lg"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-md cursor-pointer"
                    >
                      Cadastrar e Vincular Agora
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 2: Requisitar / Adicionar Peça para Ordem de Serviço (OS)
          ========================================================================= */}
      {isAddToOSModalOpen && partToAddToOS && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-emerald-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-600 rounded-lg">
                  <ShoppingCart className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-black text-sm">Requisitar Peça para Ordem de Serviço</h3>
                  <p className="text-xs text-emerald-200 font-mono">
                    Pos. {partToAddToOS.position} - {partToAddToOS.factoryDescription}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddToOSModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  SELECIONE A ORDEM DE SERVIÇO (OS ATIVA) *
                </label>
                <select
                  value={selectedOSId}
                  onChange={(e) => setSelectedOSId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-800"
                >
                  {orders
                    .filter(o => o.status === 'PENDING' || o.status === 'IN_PROGRESS')
                    .map(o => (
                      <option key={o.id} value={o.id}>
                        {o.osNumber} - {o.title} (Status: {o.status === 'PENDING' ? 'Pendente' : 'Em Execução'})
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  QUANTIDADE A REQUISITAR *
                </label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={osReqQuantity}
                  onChange={(e) => setOsReqQuantity(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-mono font-black"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Recomendado para esta montagem: {partToAddToOS.quantityRecommended || 1} un
                </span>
              </div>

              <div className="bg-slate-50 rounded-xl p-3 text-xs border border-slate-200 text-slate-600">
                <p>
                  Esta ação adicionará a peça aos <strong>materiais utilizados</strong> da OS selecionada e computará o valor de custo no orçamento do cliente.
                </p>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddToOSModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmAddToOS}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black tracking-wider uppercase shadow-md cursor-pointer"
                >
                  Confirmar e Adicionar à OS
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 3: Criar ou Editar Catálogo Técnico
          ========================================================================= */}
      {isCatalogModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-[#112847] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <Layers className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-black text-sm">
                    {editingCatalog ? 'Editar Catálogo de Equipamento' : 'Novo Catálogo de Equipamento'}
                  </h3>
                  <p className="text-xs text-cyan-200">Definição de vista explodida e subconjunto mecânico</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCatalogModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={(e) => handleSaveCatalog(e, false)} className="p-5 space-y-4">
              {/* Draft Recovered Notification Banner */}
              {isDraftRestoredNotice && !editingCatalog && (
                <div className="p-3.5 bg-amber-50 border-2 border-amber-300 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-amber-200 text-amber-900 rounded-lg shrink-0">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-extrabold text-xs text-amber-950 block">
                        Rascunho recuperado automaticamente
                      </span>
                      <p className="text-[11px] text-amber-800">
                        Restauramos as informações que você começou a preencher anteriormente para você não perder nada.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleClearDraft}
                    className="px-3 py-1.5 text-xs font-bold text-amber-950 bg-amber-200 hover:bg-amber-300 rounded-lg shrink-0 border border-amber-400 cursor-pointer"
                  >
                    Descartar e Limpar
                  </button>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  TÍTULO DO CATÁLOGO *
                </label>
                <input
                  type="text"
                  value={catTitle}
                  onChange={(e) => setCatTitle(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-blue-500"
                  placeholder="Ex: Lava Jato Kärcher K 3.10 - Cabeçote de Pressão"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    MODELO DO EQUIPAMENTO *
                  </label>
                  <input
                    type="text"
                    value={catModel}
                    onChange={(e) => setCatModel(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-blue-500"
                    placeholder="Ex: Kärcher K 3.10 ou HD 585"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    SUBCONJUNTO / MONTAGEM *
                  </label>
                  <input
                    type="text"
                    value={catSubassembly}
                    onChange={(e) => setCatSubassembly(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-blue-500"
                    placeholder="Ex: Cabeçote, Pistões, Válvula By-Pass"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  VINCULAR A UM EQUIPAMENTO CADASTRADO (OPCIONAL)
                </label>
                <select
                  value={catEquipmentId}
                  onChange={(e) => {
                    setCatEquipmentId(e.target.value);
                    const matched = equipments.find(eq => eq.id === e.target.value);
                    if (matched) {
                      setCatModel(matched.model || matched.name);
                    }
                  }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">-- Selecione ou deixe avulso --</option>
                  {equipments.map(eq => (
                    <option key={eq.id} value={eq.id}>
                      {eq.name} ({eq.model || 'Sem modelo'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  TIPO DE DIAGRAMA VISTA EXPLODIDA
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCatDiagramType('SVG_SCHEMATIC')}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                      catDiagramType === 'SVG_SCHEMATIC'
                        ? 'bg-blue-50 border-blue-600 ring-2 ring-blue-400'
                        : 'bg-white border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="block font-bold text-xs text-slate-900">Esquema Técnico Vetorial</span>
                    <span className="text-[11px] text-slate-500">Desenho técnico nítido em SVG</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCatDiagramType('IMAGE')}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                      catDiagramType === 'IMAGE'
                        ? 'bg-blue-50 border-blue-600 ring-2 ring-blue-400'
                        : 'bg-white border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="block font-bold text-xs text-slate-900">Carregar Imagem / Foto</span>
                    <span className="text-[11px] text-slate-500">PNG, JPG ou escaneamento</span>
                  </button>
                </div>
              </div>

              {catDiagramType === 'SVG_SCHEMATIC' ? (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ESQUEMA TÉCNICO PADRÃO
                  </label>
                  <select
                    value={catSchematicId}
                    onChange={(e) => setCatSchematicId(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-bold text-slate-800"
                  >
                    <option value="KARCHER_CABECOTE">Lava Jato Kärcher - Cabeçote de Pressão (Foto 1)</option>
                    <option value="KARCHER_PISTOES">Lava Jato Kärcher - Guia de Pistões e By-Pass (Foto 2)</option>
                    <option value="BOMBA_TRIPLEX">Bomba Triplex Industrial de Alta Pressão</option>
                    <option value="CILINDRO_HIDRAULICO">Cilindro Hidráulico Industrial Dupla Ação</option>
                  </select>
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-700">
                    ENVIE O ARQUIVO DA VISTA EXPLODIDA (IMAGEM / FOTO)
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleDiagramImageUpload}
                    className="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
                  />
                  {catImageUrl && (
                    <div className="mt-2 h-32 border rounded-xl overflow-hidden bg-slate-100 flex items-center justify-center">
                      <img src={catImageUrl} alt="Preview" className="h-full object-contain" />
                    </div>
                  )}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  OBSERVAÇÕES / INSTRUÇÕES TÉCNICAS
                </label>
                <textarea
                  value={catDescription}
                  onChange={(e) => setCatDescription(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                  placeholder="Informações sobre torque de aperto, lubrificação, especificações técnicas..."
                />
              </div>

              {/* Real-time Draft Auto-save Indicator */}
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-600 animate-pulse shrink-0" />
                  <span className="text-emerald-700 font-bold text-[11px]">
                    {draftAutoSavedText || 'Auto-salvamento em tempo real ativo: suas informações não serão perdidas'}
                  </span>
                </div>
                {editingCatalog && (
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    editingCatalog.isDraft ? 'bg-amber-200 text-amber-900' : 'bg-emerald-200 text-emerald-900'
                  }`}>
                    {editingCatalog.isDraft ? 'Modo Rascunho' : 'Publicado'}
                  </span>
                )}
              </div>

              {/* Action Buttons with Save, Draft, Edit and Delete */}
              <div className="pt-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-t border-slate-200">
                <div>
                  {editingCatalog ? (
                    <button
                      type="button"
                      onClick={() => handleRequestDeleteCatalog(editingCatalog)}
                      className="w-full sm:w-auto px-3.5 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-xl border border-rose-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      title="Excluir este catálogo definitivamente"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Excluir Catálogo</span>
                    </button>
                  ) : (catTitle || catModel || catDescription) ? (
                    <button
                      type="button"
                      onClick={handleClearDraft}
                      className="w-full sm:w-auto px-3.5 py-2 text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      title="Limpar formulário e apagar rascunho temporário"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Limpar Rascunho</span>
                    </button>
                  ) : null}
                </div>

                <div className="flex flex-wrap items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsCatalogModalOpen(false)}
                    className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                  >
                    Cancelar
                  </button>

                  <button
                    type="button"
                    onClick={(e) => handleSaveCatalog(e, true)}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-black tracking-wide flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                    title="Salvar informações como rascunho para complementar futuramente"
                  >
                    <Clock className="w-4 h-4" />
                    <span>Salvar como Rascunho</span>
                  </button>

                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#0052cc] hover:bg-[#004a99] text-white rounded-xl text-xs font-black tracking-wider uppercase shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>{editingCatalog?.isDraft ? 'Publicar Definitivamente' : (editingCatalog ? 'Salvar Alterações' : 'Salvar e Publicar')}</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 4: Editar Linha de Peça (Posição, Códigos e Descrição)
          ========================================================================= */}
      {isEditPartModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-[#112847] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-cyan-600 rounded-lg">
                  <Edit2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-black text-sm">
                    {editingPart ? 'Editar Componente do Catálogo' : 'Adicionar Novo Componente'}
                  </h3>
                  <p className="text-xs text-cyan-200">Dados técnicos da vista explodida</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsEditPartModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePartRow} className="p-5 space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">POSIÇÃO *</label>
                  <input
                    type="text"
                    value={partPos}
                    onChange={(e) => setPartPos(e.target.value)}
                    required
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono font-black text-center"
                    placeholder="1, 2, 5.1"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">COD. COMPRA / REF</label>
                  <input
                    type="text"
                    value={partBuyCode}
                    onChange={(e) => setPartBuyCode(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                    placeholder="Ex: 9.001-105.0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">DESCRIÇÃO FÁBRICA *</label>
                <input
                  type="text"
                  value={partFactoryDesc}
                  onChange={(e) => setPartFactoryDesc(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-bold"
                  placeholder="Ex: CONJ. CABEÇOTE ou GAXETA 20 X 12 X 5"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">COD. ALMOX</label>
                  <input
                    type="text"
                    value={partWarehouseCode}
                    onChange={(e) => setPartWarehouseCode(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono font-bold"
                    placeholder="Ex: N70-2151 ou 1500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">QTD MONTAGEM</label>
                  <input
                    type="number"
                    min="1"
                    value={partQtyRec}
                    onChange={(e) => setPartQtyRec(Number(e.target.value))}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">NOTAS TÉCNICAS</label>
                <textarea
                  value={partNotes}
                  onChange={(e) => setPartNotes(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  placeholder="Medidas, material, localização no cabeçote..."
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsEditPartModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#0052cc] hover:bg-[#004a99] text-white rounded-lg text-xs font-bold shadow-md cursor-pointer"
                >
                  Salvar Peça
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 5: Confirmação de Exclusão Segura de Catálogo
          ========================================================================= */}
      {isDeleteModalOpen && catalogToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-rose-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-rose-800 rounded-lg">
                  <Trash2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-black text-sm">Excluir Catálogo Técnico</h3>
                  <p className="text-xs text-rose-100">Esta ação não pode ser desfeita</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsDeleteModalOpen(false);
                  setCatalogToDelete(null);
                }}
                className="text-rose-200 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-700 leading-relaxed">
                Tem certeza que deseja excluir permanentemente o catálogo{' '}
                <strong className="text-slate-950 font-black">"{catalogToDelete.title}"</strong>?
              </p>

              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-1 text-xs text-rose-800">
                <div className="flex items-center gap-1.5 font-bold">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>Atenção:</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  O diagrama e todas as <strong>{catalogToDelete.parts.length} peças mapeadas</strong> deste catálogo serão removidos da listagem de vistas explodidas.
                </p>
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setIsDeleteModalOpen(false);
                    setCatalogToDelete(null);
                  }}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDeleteCatalog}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black tracking-wider uppercase shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Sim, Excluir Catálogo</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
