import React, { useState } from 'react';
import { TechnicalDiagnostic } from '../types';
import { 
  ClipboardList, Plus, Search, Edit2, Trash2, X, Check, FileText, Info
} from 'lucide-react';

interface DiagnosticManagerProps {
  diagnostics: TechnicalDiagnostic[];
  onAddDiagnostic: (data: Omit<TechnicalDiagnostic, 'id' | 'createdAt'>) => void;
  onEditDiagnostic: (diagnostic: TechnicalDiagnostic) => void;
  onDeleteDiagnostic: (id: string) => void;
}

export default function DiagnosticManager({
  diagnostics,
  onAddDiagnostic,
  onEditDiagnostic,
  onDeleteDiagnostic
}: DiagnosticManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDiagnostic, setEditingDiagnostic] = useState<TechnicalDiagnostic | null>(null);
  const [diagnosticToDelete, setDiagnosticToDelete] = useState<TechnicalDiagnostic | null>(null);
  const [feedback, setFeedback] = useState<{ message: string, type: 'success' | 'info' | 'error' } | null>(null);

  const triggerFeedback = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setFeedback({ message, type });
    setTimeout(() => {
      setFeedback(null);
    }, 4000);
  };

  // Form State
  const [code, setCode] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [formError, setFormError] = useState('');

  const handleOpenAddModal = () => {
    setEditingDiagnostic(null);
    // Generate next code
    const nextNum = diagnostics.length > 0 
      ? Math.max(...diagnostics.map(d => {
          const num = parseInt(d.code.replace(/\D/g, ''));
          return isNaN(num) ? 0 : num;
        })) + 1
      : 1;
    setCode(`DIAG-H${String(nextNum).padStart(2, '0')}`);
    setTitle('');
    setDescription('');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (diag: TechnicalDiagnostic) => {
    setEditingDiagnostic(diag);
    setCode(diag.code);
    setTitle(diag.title);
    setDescription(diag.description);
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !title.trim() || !description.trim()) {
      setFormError('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    // Check duplicate code
    const isDuplicateCode = diagnostics.some(d => 
      d.code.trim().toUpperCase() === code.trim().toUpperCase() && 
      (!editingDiagnostic || d.id !== editingDiagnostic.id)
    );

    if (isDuplicateCode) {
      setFormError('Este código de diagnóstico já está em uso.');
      return;
    }

    if (editingDiagnostic) {
      onEditDiagnostic({
        ...editingDiagnostic,
        code: code.trim().toUpperCase(),
        title: title.trim(),
        description: description.trim()
      });
      triggerFeedback(`Diagnóstico ${code.trim().toUpperCase()} editado com sucesso!`, 'success');
    } else {
      onAddDiagnostic({
        code: code.trim().toUpperCase(),
        title: title.trim(),
        description: description.trim()
      });
      triggerFeedback(`Diagnóstico ${code.trim().toUpperCase()} cadastrado com sucesso!`, 'success');
    }

    setIsModalOpen(false);
  };

  const filtered = diagnostics.filter(d => 
    d.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="diagnostic-manager-root">
      
      {/* Toast Notification */}
      {feedback && (
        <div className={`p-4 mx-4 mt-4 rounded-xl border flex items-center justify-between gap-3 animate-in slide-in-from-top-2 duration-200 shadow-md ${
          feedback.type === 'success' 
            ? 'bg-emerald-50 border-emerald-300 text-emerald-900' 
            : feedback.type === 'info'
            ? 'bg-blue-50 border-blue-300 text-blue-900'
            : 'bg-rose-50 border-rose-300 text-rose-900'
        }`}>
          <div className="text-xs font-bold uppercase tracking-wider">{feedback.message}</div>
          <button 
            onClick={() => setFeedback(null)} 
            className="p-1 hover:bg-black/5 rounded-lg text-slate-500 hover:text-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
      
      {/* Header Banner */}
      <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-blue-900">
        <div className="space-y-0.5">
          <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-cyan-300" />
            Cadastro de Diagnósticos Técnicos
          </h2>
          <p className="text-xs text-cyan-100">
            Gerencie modelos de diagnósticos de problemas para reutilização ágil nas Ordens de Serviço.
          </p>
        </div>
        <button
          id="btn-add-diagnostic"
          onClick={handleOpenAddModal}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>NOVO DIAGNÓSTICO</span>
        </button>
      </div>

      {/* Search and List */}
      <div className="p-4 sm:p-6 bg-[#e9edf2] space-y-4">
        
        {/* Search Bar */}
        <div className="relative max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por código, título ou descrição..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 transition-all shadow-inner"
          />
        </div>

        {/* List of Diagnostics */}
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-500 border border-dashed border-slate-300 rounded-xl bg-white flex flex-col items-center justify-center space-y-3">
            <Info className="w-8 h-8 mx-auto text-slate-400" />
            <p className="text-xs font-bold text-slate-700">Nenhum diagnóstico encontrado</p>
            <p className="text-[11px] text-slate-500">Tente ajustar seus termos de pesquisa ou adicione um novo.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((diag) => (
              <div 
                key={diag.id} 
                className="bg-white border border-slate-300 hover:border-blue-600 rounded-xl p-4 flex flex-col justify-between transition-all group shadow-sm hover:shadow-md"
                id={`diagnostic-card-${diag.id}`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-2.5">
                    <span className="font-mono text-[10px] font-black text-[#1b365d] bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-md uppercase tracking-wider">
                      {diag.code}
                    </span>
                    <span className="text-[9px] font-bold text-slate-500">
                      {new Date(diag.createdAt).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-sm tracking-tight group-hover:text-blue-800 transition-colors">
                      {diag.title}
                    </h3>
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed line-clamp-4">
                      {diag.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-1.5 mt-5 pt-3.5 border-t border-slate-200">
                  <button
                    onClick={() => handleOpenEditModal(diag)}
                    className="p-1.5 hover:bg-blue-50 text-slate-500 hover:text-blue-700 rounded-lg border border-transparent hover:border-blue-200 transition-all cursor-pointer"
                    title="Editar Diagnóstico"
                    id={`btn-edit-diag-${diag.id}`}
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setDiagnosticToDelete(diag)}
                    className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg border border-transparent hover:border-red-200 transition-all cursor-pointer"
                    title="Excluir Diagnóstico"
                    id={`btn-delete-diag-${diag.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Create/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="diagnostic-modal">
          <div className="absolute inset-0 bg-[#000000]/60 backdrop-blur-xs" onClick={() => setIsModalOpen(false)}></div>
          
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-300">
            
            {/* Modal Header */}
            <div className="px-5 py-3.5 bg-[#1b365d] text-white border-b border-blue-900 flex items-center justify-between">
              <div className="flex items-center gap-2 text-white">
                <FileText className="w-5 h-5 text-cyan-300" />
                <div>
                  <h3 className="font-black text-white text-sm uppercase tracking-wider">
                    {editingDiagnostic ? 'Editar Diagnóstico' : 'Cadastrar Diagnóstico'}
                  </h3>
                  <span className="text-[10px] text-cyan-100 block">Configure o modelo para inserção rápida</span>
                </div>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-cyan-200 hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 bg-slate-50">
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Código *</label>
                  <input
                    type="text"
                    placeholder="Ex: DIAG-H01"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 font-mono shadow-inner"
                    required
                  />
                </div>

                <div className="sm:col-span-2 space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Título do Sintoma / Diagnóstico *</label>
                  <input
                    type="text"
                    placeholder="Ex: Vazamento de Óleo Hidráulico"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Descrição Detalhada do Modelo *</label>
                <textarea
                  rows={5}
                  placeholder="Descreva a situação padrão observada que serve como base..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 resize-none leading-relaxed shadow-inner"
                  required
                />
              </div>

              {formError && (
                <p className="text-xs text-red-700 font-bold bg-red-50 border border-red-200 p-2.5 rounded-lg">
                  {formError}
                </p>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 border-t border-slate-200 pt-4 mt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-xs font-black uppercase tracking-wider text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingDiagnostic ? 'SALVAR ALTERAÇÕES' : 'CADASTRAR DIAGNÓSTICO'}</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {diagnosticToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="delete-diagnostic-modal">
          <div className="absolute inset-0 bg-[#000000]/60 backdrop-blur-xs" onClick={() => setDiagnosticToDelete(null)}></div>
          
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-300">
            <div className="px-5 py-3.5 bg-red-700 text-white flex items-center gap-3">
              <Trash2 className="w-5 h-5 text-red-100" />
              <div>
                <h3 className="font-black text-white text-sm uppercase tracking-wider">
                  Confirmar Exclusão
                </h3>
                <span className="text-[10px] text-red-100 block">Esta ação não poderá ser desfeita</span>
              </div>
            </div>

            <div className="p-6 bg-slate-50 space-y-4">
              <p className="text-xs text-slate-700 leading-relaxed">
                Você tem certeza que deseja excluir o diagnóstico técnico <strong className="text-blue-900 font-mono">{diagnosticToDelete.code}</strong> (<em>{diagnosticToDelete.title}</em>)?
              </p>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setDiagnosticToDelete(null)}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const codeToDisplay = diagnosticToDelete.code;
                    onDeleteDiagnostic(diagnosticToDelete.id);
                    triggerFeedback(`Diagnóstico ${codeToDisplay} excluído com sucesso!`, 'info');
                    setDiagnosticToDelete(null);
                  }}
                  className="px-5 py-2 text-xs font-black uppercase tracking-wider text-white bg-red-600 hover:bg-red-700 rounded-xl transition-colors shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Confirmar Exclusão</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
