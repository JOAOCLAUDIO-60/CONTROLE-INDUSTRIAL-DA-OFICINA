import React from 'react';

interface JCFCompanyLogoProps {
  className?: string;
  variant?: 'dark' | 'light' | 'mono-black' | 'color';
  showSubtitle?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'custom';
}

/**
 * Logomarca Oficial JC&F - Manutenção Hidráulica e Pneumática
 * Fielmente reconstruída a partir da identidade visual da empresa (image.png):
 * - Arco de engrenagem industrial sólido preto no quadrante superior-direito com 7 dentes radiais
 * - Monograma serifado com as iniciais "JC" superiores, "&" e "F" inferiores
 * - Subtítulo oficial "MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA"
 */
export default function JCFCompanyLogo({
  className = '',
  variant = 'mono-black',
  showSubtitle = true,
  size = 'md'
}: JCFCompanyLogoProps) {
  // Dimension sizing presets
  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-16 h-16',
    lg: 'w-24 h-24',
    xl: 'w-36 h-36',
    custom: ''
  }[size];

  // Color scheme variants
  let primaryColor = '#000000';
  let arcColor = '#000000';
  let teethColor = '#000000';
  let textColor = '#000000';

  if (variant === 'light' || variant === 'dark') {
    primaryColor = '#ffffff';
    arcColor = '#ffffff';
    teethColor = '#ffffff';
    textColor = '#ffffff';
  } else if (variant === 'color') {
    primaryColor = '#1b365d'; // JC&F Navy Blue
    arcColor = '#0052cc';
    teethColor = '#f59e0b'; // Amber accent
    textColor = '#1b365d';
  }

  return (
    <div className={`inline-flex flex-col items-center justify-center select-none ${className}`}>
      <svg 
        viewBox="0 0 420 350" 
        className={sizeClasses || 'w-full h-auto'}
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <style>
            {`
              @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@700;800;900&family=Playfair+Display:ital,wght@0,700;0,800;0,900;1,700&display=swap');
              .jcf-monogram {
                font-family: 'Playfair Display', 'Times New Roman', Times, Georgia, Cambria, serif;
                font-weight: 800;
              }
              .jcf-sub-text {
                font-family: 'Cinzel', 'Playfair Display', 'Times New Roman', Times, Georgia, sans-serif;
                font-weight: 800;
                letter-spacing: 0.16em;
              }
            `}
          </style>
        </defs>

        {/* Industrial Gear Outer Arc & Teeth */}
        <g id="gear-cog-arc" fill={teethColor} stroke={arcColor}>
          {/* Main Curved Gear Ring Sector (Solid Black) */}
          <path
            d="M 175 60 A 135 135 0 0 1 340 215"
            stroke={arcColor}
            strokeWidth="34"
            strokeLinecap="round"
            fill="none"
          />

          {/* Radial Gear Teeth protruding outward */}
          {/* Tooth 1 (~105°) */}
          <rect x="175" y="24" width="28" height="24" rx="2" transform="rotate(-15, 188, 36)" fill={teethColor} stroke="none" />
          {/* Tooth 2 (~75°) */}
          <rect x="220" y="22" width="28" height="24" rx="2" transform="rotate(15, 233, 34)" fill={teethColor} stroke="none" />
          {/* Tooth 3 (~45°) */}
          <rect x="265" y="44" width="28" height="24" rx="2" transform="rotate(45, 278, 56)" fill={teethColor} stroke="none" />
          {/* Tooth 4 (~15°) */}
          <rect x="300" y="86" width="28" height="24" rx="2" transform="rotate(75, 313, 98)" fill={teethColor} stroke="none" />
          {/* Tooth 5 (~345°) */}
          <rect x="316" y="138" width="28" height="24" rx="2" transform="rotate(105, 329, 150)" fill={teethColor} stroke="none" />
          {/* Tooth 6 (~315°) */}
          <rect x="310" y="190" width="28" height="24" rx="2" transform="rotate(135, 323, 202)" fill={teethColor} stroke="none" />
          {/* Tooth 7 (~290°) */}
          <rect x="282" y="235" width="28" height="24" rx="2" transform="rotate(160, 295, 247)" fill={teethColor} stroke="none" />
        </g>

        {/* Central Monogram: J C & F */}
        <g fill={primaryColor} className="jcf-monogram">
          {/* Letter J */}
          <text 
            x="148" 
            y="178" 
            fontSize="124" 
            textAnchor="middle" 
            className="jcf-monogram"
          >
            J
          </text>

          {/* Letter C */}
          <text 
            x="228" 
            y="175" 
            fontSize="118" 
            textAnchor="middle" 
            className="jcf-monogram"
          >
            C
          </text>

          {/* Ampersand & */}
          <text 
            x="180" 
            y="256" 
            fontSize="78" 
            textAnchor="middle" 
            className="jcf-monogram"
            fontStyle="italic"
          >
            &amp;
          </text>

          {/* Letter F */}
          <text 
            x="248" 
            y="262" 
            fontSize="120" 
            textAnchor="middle" 
            className="jcf-monogram"
          >
            F
          </text>
        </g>

        {/* Subtitle Banner text */}
        {showSubtitle && (
          <text 
            x="210" 
            y="320" 
            fill={textColor} 
            fontSize="13" 
            textAnchor="middle"
            className="jcf-sub-text"
          >
            MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA
          </text>
        )}
      </svg>
    </div>
  );
}
