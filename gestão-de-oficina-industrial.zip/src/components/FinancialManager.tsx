import React, { useState } from 'react';
import { Client, ServiceOrder, FinancialTransaction, FinancialStatus, FinancialType } from '../types';
import { 
  DollarSign, TrendingUp, TrendingDown, Calendar, Plus, Search, Edit2, Trash2, 
  CheckCircle2, Clock, AlertTriangle, X, ArrowUpRight, ArrowDownRight, Filter, FileText, Check,
  Share2, Key, QrCode, MessageSquare, Mail, Copy
} from 'lucide-react';

interface FinancialManagerProps {
  transactions: FinancialTransaction[];
  clients: Client[];
  orders: ServiceOrder[];
  onAddTransaction: (transactionData: Omit<FinancialTransaction, 'id' | 'createdAt'>) => void;
  onEditTransaction: (updatedTransaction: FinancialTransaction) => void;
  onDeleteTransaction: (id: string) => void;
}

export default function FinancialManager({
  transactions,
  clients,
  orders,
  onAddTransaction,
  onEditTransaction,
  onDeleteTransaction
}: FinancialManagerProps) {
  // Navigation inside Finance
  const [financeTab, setFinanceTab] = useState<'OVERVIEW' | 'RECEIVABLE' | 'PAYABLE'>('OVERVIEW');

  // Search and Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<FinancialTransaction | null>(null);

  // Deletion Confirmation & Feedback States
  const [deleteConfirmation, setDeleteConfirmation] = useState<FinancialTransaction | null>(null);
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showFeedback = (message: string, type: 'success' | 'error' = 'success') => {
    setFeedback({ message, type });
    setTimeout(() => setFeedback(null), 3500);
  };

  // Duplicate Warning Confirmation State
  const [duplicateWarning, setDuplicateWarning] = useState<{
    pendingData: Omit<FinancialTransaction, 'id' | 'createdAt'>;
    existingTx: FinancialTransaction;
    isEditing: boolean;
  } | null>(null);

  // Form States
  const [description, setDescription] = useState('');
  const [type, setType] = useState<FinancialType>('RECEIVABLE');
  const [amount, setAmount] = useState<number>(0);
  const [dueDate, setDueDate] = useState('');
  const [paymentDate, setPaymentDate] = useState('');
  const [category, setCategory] = useState('');
  const [status, setStatus] = useState<FinancialStatus>('PENDING');
  const [notes, setNotes] = useState('');
  const [associatedOSId, setAssociatedOSId] = useState('');
  const [formError, setFormError] = useState('');

  // Company PIX Settings State
  const [pixType, setPixType] = useState<string>(() => {
    const saved = localStorage.getItem('oficina_company_pix');
    if (saved) {
      try {
        return JSON.parse(saved).type || 'CNPJ';
      } catch (e) {}
    }
    return 'CNPJ';
  });
  const [pixKey, setPixKey] = useState<string>(() => {
    const saved = localStorage.getItem('oficina_company_pix');
    if (saved) {
      try {
        return JSON.parse(saved).key || '';
      } catch (e) {}
    }
    return '';
  });
  const [pixName, setPixName] = useState<string>(() => {
    const saved = localStorage.getItem('oficina_company_pix');
    if (saved) {
      try {
        return JSON.parse(saved).name || '';
      } catch (e) {}
    }
    return '';
  });
  const [pixCity, setPixCity] = useState<string>(() => {
    const saved = localStorage.getItem('oficina_company_pix');
    if (saved) {
      try {
        return JSON.parse(saved).city || 'São Paulo';
      } catch (e) {}
    }
    return 'São Paulo';
  });
  const [isPixSaved, setIsPixSaved] = useState(false);

  // Share PIX Billing Modal states
  const [sharingTx, setSharingTx] = useState<FinancialTransaction | null>(null);
  const [sharingClient, setSharingClient] = useState<Client | null>(null);
  const [customPixMessage, setCustomPixMessage] = useState('');
  const [copyTxFeedback, setCopyTxFeedback] = useState(false);
  const [copyPixCodeFeedback, setCopyPixCodeFeedback] = useState(false);

  const handleSavePixSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const pixData = { type: pixType, key: pixKey, name: pixName, city: pixCity };
    localStorage.setItem('oficina_company_pix', JSON.stringify(pixData));
    setIsPixSaved(true);
    setTimeout(() => setIsPixSaved(false), 3000);
  };

  const generateMockPixCode = (key: string, name: string, city: string, amount: number) => {
    const cleanKey = key.replace(/[^a-zA-Z0-9@.-]/g, '');
    const cleanName = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().slice(0, 25);
    const cleanCity = city.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().slice(0, 15);
    const formattedAmount = amount.toFixed(2);
    return `00020101021226580014br.gov.bcb.pix01${cleanKey.length.toString().padStart(2, '0')}${cleanKey}52040000530398654${formattedAmount.length.toString().padStart(2, '0')}${formattedAmount}5802BR59${cleanName.length.toString().padStart(2, '0')}${cleanName}60${cleanCity.length.toString().padStart(2, '0')}${cleanCity}62070503***6304D1B2`;
  };

  const regeneratePixMessage = (t: FinancialTransaction, client: Client | null) => {
    const clientName = client ? client.name : 'Cliente';
    const amountText = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(t.amount);
    
    // Load fresh PIX settings from localStorage
    const saved = localStorage.getItem('oficina_company_pix');
    let localType = pixType;
    let localKey = pixKey;
    let localName = pixName;
    let localCity = pixCity;
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        localType = parsed.type || 'CNPJ';
        localKey = parsed.key || '';
        localName = parsed.name || '';
        localCity = parsed.city || 'São Paulo';
      } catch (e) {}
    }

    const pixStr = localKey ? `\n\n🔑 *DADOS PARA PAGAMENTO VIA PIX:* \nBeneficiário: ${localName || 'Oficina'}\nChave PIX (${localType}): ${localKey}` : '\n\n⚠️ *Nota:* Cadastre a chave PIX nas configurações financeiras para incluir os dados de pagamento automaticamente.';
    
    let osRefText = '';
    if (t.serviceOrderId) {
      const order = orders.find(o => o.id === t.serviceOrderId);
      if (order) {
        osRefText = ` referente à Ordem de Serviço *${order.osNumber}* (${order.title})`;
      }
    }

    const msg = `Olá, *${clientName}*! 🛠️\n\n` +
      `Estamos enviando a cobrança para o pagamento da manutenção executada${osRefText}.\n\n` +
      `📝 *SERVIÇO:* ${t.description}\n` +
      `📅 *VENCIMENTO:* ${new Date(t.dueDate + 'T12:00:00').toLocaleDateString('pt-BR')}\n` +
      `💵 *VALOR TOTAL:* ${amountText}` +
      `${pixStr}\n\n` +
      `Qualquer dúvida, estamos à disposição. Obrigado pela preferência!`;

    setCustomPixMessage(msg);
  };

  const handleOpenPixShareModal = (t: FinancialTransaction) => {
    let clientObj: Client | null = null;
    if (t.serviceOrderId) {
      const order = orders.find(o => o.id === t.serviceOrderId);
      if (order) {
        clientObj = clients.find(c => c.id === order.clientId) || null;
      }
    }
    
    // Fallback: If no client found, try to look up name in description or default to first client
    if (!clientObj && clients.length > 0) {
      clientObj = clients[0];
    }
    
    setSharingTx(t);
    setSharingClient(clientObj);
    regeneratePixMessage(t, clientObj);
  };

  // Form Categories
  const categories = {
    RECEIVABLE: ['Mão de Obra', 'Peças', 'Contrato Mensal', 'Inspeção / Certificação', 'Outros'],
    PAYABLE: ['Peças', 'Ferramentas', 'Aluguel', 'Salário', 'Utilidades', 'Impostos', 'Combustível / Logística', 'Outros']
  };

  // Calculations
  const now = new Date();
  now.setHours(0, 0, 0, 0);

  // Helper to verify overdue status and update list status dynamically for display
  const getDisplayStatus = (t: FinancialTransaction): FinancialStatus => {
    if (t.status === 'PENDING') {
      const due = new Date(t.dueDate + 'T00:00:00');
      if (due < now) {
        return 'OVERDUE';
      }
    }
    return t.status;
  };

  // Aggregate values
  const totalPaidReceivable = transactions
    .filter(t => t.type === 'RECEIVABLE' && t.status === 'PAID')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalPendingReceivable = transactions
    .filter(t => t.type === 'RECEIVABLE' && getDisplayStatus(t) === 'PENDING')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalOverdueReceivable = transactions
    .filter(t => t.type === 'RECEIVABLE' && getDisplayStatus(t) === 'OVERDUE')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalPaidPayable = transactions
    .filter(t => t.type === 'PAYABLE' && t.status === 'PAID')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalPendingPayable = transactions
    .filter(t => t.type === 'PAYABLE' && getDisplayStatus(t) === 'PENDING')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalOverduePayable = transactions
    .filter(t => t.type === 'PAYABLE' && getDisplayStatus(t) === 'OVERDUE')
    .reduce((sum, t) => sum + t.amount, 0);

  const currentBalance = totalPaidReceivable - totalPaidPayable;
  const projectableBalance = (totalPaidReceivable + totalPendingReceivable + totalOverdueReceivable) - 
                             (totalPaidPayable + totalPendingPayable + totalOverduePayable);

  // Open modal for add
  const handleOpenAddModal = (initialType?: FinancialType) => {
    setEditingTransaction(null);
    setDescription('');
    setType(initialType || 'RECEIVABLE');
    setAmount(0);
    setDueDate(new Date().toISOString().split('T')[0]);
    setPaymentDate('');
    setCategory(initialType === 'PAYABLE' ? 'Peças' : 'Mão de Obra');
    setStatus('PENDING');
    setNotes('');
    setAssociatedOSId('');
    setFormError('');
    setIsModalOpen(true);
  };

  // Open modal for edit
  const handleOpenEditModal = (t: FinancialTransaction) => {
    setEditingTransaction(t);
    setDescription(t.description);
    setType(t.type);
    setAmount(t.amount);
    setDueDate(t.dueDate);
    setPaymentDate(t.paymentDate || '');
    setCategory(t.category);
    setStatus(t.status);
    setNotes(t.notes || '');
    setAssociatedOSId(t.serviceOrderId || '');
    setFormError('');
    setIsModalOpen(true);
  };

  // Duplicate transaction checker
  const findDuplicateTransaction = (txData: Omit<FinancialTransaction, 'id' | 'createdAt'>, currentId?: string) => {
    return transactions.find(t => {
      if (currentId && t.id === currentId) return false;

      // 1. Same service order ID
      if (txData.serviceOrderId && t.serviceOrderId === txData.serviceOrderId) {
        return true;
      }

      // 2. Same description (case-insensitive) + amount + type + dueDate
      const sameDesc = t.description.trim().toLowerCase() === txData.description.trim().toLowerCase();
      const sameAmount = Math.abs(t.amount - txData.amount) < 0.01;
      const sameType = t.type === txData.type;
      const sameDueDate = t.dueDate === txData.dueDate;

      return sameDesc && sameAmount && sameType && sameDueDate;
    });
  };

  // Commit Save Transaction
  const commitSaveTransaction = (txData: Omit<FinancialTransaction, 'id' | 'createdAt'>) => {
    if (editingTransaction) {
      onEditTransaction({
        ...editingTransaction,
        ...txData
      });
      showFeedback('Lançamento financeiro atualizado com sucesso!', 'success');
    } else {
      onAddTransaction(txData);
      showFeedback('Novo lançamento financeiro cadastrado com sucesso!', 'success');
    }
    setIsModalOpen(false);
    setDuplicateWarning(null);
  };

  // Save Transaction Handler
  const handleSaveTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      setFormError('A descrição é obrigatória.');
      return;
    }
    if (amount <= 0) {
      setFormError('O valor deve ser maior que zero.');
      return;
    }
    if (!dueDate) {
      setFormError('A data de vencimento é obrigatória.');
      return;
    }
    if (status === 'PAID' && !paymentDate) {
      setFormError('A data de pagamento/recebimento é obrigatória quando marcado como Pago.');
      return;
    }

    const txData = {
      description: description.trim(),
      type,
      amount,
      dueDate,
      paymentDate: status === 'PAID' ? paymentDate : undefined,
      category,
      status,
      notes: notes.trim() ? notes.trim() : undefined,
      serviceOrderId: associatedOSId || undefined,
    };

    // Check for duplicate unless confirmed by user
    const existingDuplicate = findDuplicateTransaction(txData, editingTransaction?.id);
    if (existingDuplicate) {
      setDuplicateWarning({
        pendingData: txData,
        existingTx: existingDuplicate,
        isEditing: !!editingTransaction
      });
      return;
    }

    commitSaveTransaction(txData);
  };

  // Confirm Delete Handler
  const handleConfirmDelete = () => {
    if (!deleteConfirmation) return;
    onDeleteTransaction(deleteConfirmation.id);
    showFeedback(`Lançamento "${deleteConfirmation.description}" excluído com sucesso!`, 'success');
    setDeleteConfirmation(null);
  };

  // Quick mark as Paid / Recebido
  const handleQuickMarkPaid = (t: FinancialTransaction) => {
    onEditTransaction({
      ...t,
      status: 'PAID',
      paymentDate: new Date().toISOString().split('T')[0]
    });
  };

  // Sync Unlisted Completed OS
  const completedOSList = orders.filter(o => o.status === 'COMPLETED');
  const unsyncedOS = completedOSList.filter(o => {
    return !transactions.some(t => t.serviceOrderId === o.id);
  });

  const handleSyncOS = (order: ServiceOrder) => {
    const client = clients.find(c => c.id === order.clientId);
    const txData = {
      description: `Faturamento automático: OS-${order.osNumber} (${order.title})`,
      type: 'RECEIVABLE' as FinancialType,
      amount: order.estimatedCost,
      dueDate: order.endDate || new Date().toISOString().split('T')[0],
      category: 'Mão de Obra e Peças',
      status: 'PENDING' as FinancialStatus,
      serviceOrderId: order.id,
      notes: `Faturamento gerado a partir da conclusão da ordem de serviço. Cliente: ${client?.name || 'Desconhecido'}`
    };

    const existing = findDuplicateTransaction(txData);
    if (existing) {
      showFeedback(`A OS-${order.osNumber} já possui lançamento cadastrado no financeiro.`, 'error');
      return;
    }

    onAddTransaction(txData);
    showFeedback(`OS-${order.osNumber} faturada com sucesso no financeiro!`, 'success');
  };

  // Filter Transactions
  const filteredTransactions = transactions.filter(t => {
    // Type Filter (according to tab)
    if (financeTab === 'RECEIVABLE' && t.type !== 'RECEIVABLE') return false;
    if (financeTab === 'PAYABLE' && t.type !== 'PAYABLE') return false;

    // Search query
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      const descMatches = t.description.toLowerCase().includes(query);
      const catMatches = t.category.toLowerCase().includes(query);
      const notesMatches = t.notes?.toLowerCase().includes(query) || false;
      const osMatches = t.serviceOrderId ? t.serviceOrderId.toLowerCase().includes(query) : false;
      if (!descMatches && !catMatches && !notesMatches && !osMatches) return false;
    }

    // Status Filter
    const displayStatus = getDisplayStatus(t);
    if (statusFilter !== 'ALL') {
      if (statusFilter === 'PAID' && t.status !== 'PAID') return false;
      if (statusFilter === 'PENDING' && displayStatus !== 'PENDING') return false;
      if (statusFilter === 'OVERDUE' && displayStatus !== 'OVERDUE') return false;
    }

    // Category Filter
    if (categoryFilter !== 'ALL' && t.category !== categoryFilter) return false;

    return true;
  });

  // Get dynamic categories list for dropdown filters
  const allUsedCategories = Array.from(new Set(transactions.map(t => t.category)));

  // Format currencies
  const formatBRL = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  return (
    <div className="space-y-6" id="financial-manager-root">
      
      {/* Toast Feedback Notification */}
      {feedback && (
        <div className={`p-4 rounded-2xl border flex items-center justify-between gap-3 animate-in slide-in-from-top-2 duration-200 shadow-xl ${
          feedback.type === 'success' 
            ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-200' 
            : 'bg-rose-950/90 border-rose-500/40 text-rose-200'
        }`} id="financial-feedback-toast">
          <div className="flex items-center gap-2.5 text-xs font-bold">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
          <button 
            onClick={() => setFeedback(null)} 
            className="p-1 hover:bg-slate-900/50 rounded-lg text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Tab Select & Title Header Banner */}
      <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm">
        <div className="bg-[#1b365d] text-white px-5 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-blue-900">
          <div className="flex items-center gap-3">
            <span className="p-2.5 bg-white/10 rounded-xl border border-white/20 text-emerald-300 shadow-sm shrink-0">
              <DollarSign className="w-6 h-6" />
            </span>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 font-black text-[10px] tracking-wider uppercase">
                  Módulo Financeiro
                </span>
                <span className="text-cyan-200 text-xs font-bold font-mono">FLUXO DE CAIXA</span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-wide">
                Controle Financeiro & Fluxo de Caixa
              </h2>
              <p className="text-xs text-cyan-100">
                Gestão unificada de contas a pagar, contas a receber e cobranças integradas com PIX
              </p>
            </div>
          </div>

          {/* Interior Navigation Tabs */}
          <div className="flex items-center gap-1.5 bg-white/10 p-1.5 rounded-xl border border-white/20 shrink-0">
            <button
              onClick={() => { setFinanceTab('OVERVIEW'); setStatusFilter('ALL'); setCategoryFilter('ALL'); }}
              className={`px-3.5 py-2 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                financeTab === 'OVERVIEW'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-white hover:bg-white/15'
              }`}
            >
              Visão Geral
            </button>
            <button
              onClick={() => { setFinanceTab('RECEIVABLE'); setStatusFilter('ALL'); setCategoryFilter('ALL'); }}
              className={`px-3.5 py-2 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                financeTab === 'RECEIVABLE'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-white hover:bg-white/15'
              }`}
            >
              Contas a Receber
            </button>
            <button
              onClick={() => { setFinanceTab('PAYABLE'); setStatusFilter('ALL'); setCategoryFilter('ALL'); }}
              className={`px-3.5 py-2 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                financeTab === 'PAYABLE'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-white hover:bg-white/15'
              }`}
            >
              Contas a Pagar
            </button>
          </div>
        </div>
      </div>

      {/* Main Stats Panel Grid */}
      {financeTab === 'OVERVIEW' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5" id="finance-stats-grid">
          {/* Box Recebíveis */}
          <div className="bg-white rounded-xl border-2 border-[#b0bec5] p-5 space-y-4 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-emerald-800 flex items-center justify-between pb-2 border-b-2 border-slate-200">
                <span className="flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                  CONTAS A RECEBER
                </span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-black">ENTRADAS</span>
              </h3>
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 block font-bold uppercase">Total Recebido (Efetivado):</span>
                <span className="font-mono text-2xl font-black text-emerald-700">{formatBRL(totalPaidReceivable)}</span>
              </div>
              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-200">
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[9px] text-slate-500 block font-black uppercase">A Receber:</span>
                  <span className="font-mono text-sm font-bold text-slate-800">{formatBRL(totalPendingReceivable)}</span>
                </div>
                <div className="bg-rose-50 p-2.5 rounded-lg border border-rose-200">
                  <span className="text-[9px] text-rose-700 block font-black uppercase flex items-center gap-0.5">
                    <AlertTriangle className="w-3 h-3 text-rose-600 shrink-0" />
                    Vencidos:
                  </span>
                  <span className="font-mono text-sm font-bold text-rose-700">{formatBRL(totalOverdueReceivable)}</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => handleOpenAddModal('RECEIVABLE')}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer text-center block shadow-xs"
            >
              + Novo Recebimento
            </button>
          </div>

          {/* Box Contas a Pagar */}
          <div className="bg-white rounded-xl border-2 border-[#b0bec5] p-5 space-y-4 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-rose-800 flex items-center justify-between pb-2 border-b-2 border-slate-200">
                <span className="flex items-center gap-1.5">
                  <TrendingDown className="w-4 h-4 text-rose-600" />
                  CONTAS A PAGAR
                </span>
                <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded text-[10px] font-black">SAÍDAS</span>
              </h3>
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 block font-bold uppercase">Total Pago (Efetivado):</span>
                <span className="font-mono text-2xl font-black text-rose-700">{formatBRL(totalPaidPayable)}</span>
              </div>
              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-200">
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[9px] text-slate-500 block font-black uppercase">A Pagar:</span>
                  <span className="font-mono text-sm font-bold text-slate-800">{formatBRL(totalPendingPayable)}</span>
                </div>
                <div className="bg-rose-50 p-2.5 rounded-lg border border-rose-200">
                  <span className="text-[9px] text-rose-700 block font-black uppercase flex items-center gap-0.5">
                    <AlertTriangle className="w-3 h-3 text-rose-600 shrink-0" />
                    Vencidos:
                  </span>
                  <span className="font-mono text-sm font-bold text-rose-700">{formatBRL(totalOverduePayable)}</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => handleOpenAddModal('PAYABLE')}
              className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer text-center block shadow-xs"
            >
              + Nova Despesa
            </button>
          </div>

          {/* Box Fluxo de Caixa / Saldo */}
          <div className="bg-white rounded-xl border-2 border-[#b0bec5] p-5 space-y-4 shadow-sm flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[#1b365d] flex items-center justify-between pb-2 border-b-2 border-slate-200">
                <span className="flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-[#0052cc]" />
                  FLUXO DE CAIXA
                </span>
                <span className="px-2 py-0.5 bg-blue-100 text-[#0052cc] rounded text-[10px] font-black">SALDO</span>
              </h3>
              <div className="space-y-2 mt-3">
                <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-600 font-black uppercase">Saldo em Caixa:</span>
                  <span className={`font-mono text-lg font-black ${currentBalance >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {formatBRL(currentBalance)}
                  </span>
                </div>
                <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-600 font-black uppercase">Projeção de Caixa:</span>
                  <span className={`font-mono text-sm font-black ${projectableBalance >= 0 ? 'text-[#0052cc]' : 'text-rose-700'}`}>
                    {formatBRL(projectableBalance)}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-blue-50/60 border border-blue-200 rounded-xl space-y-1 text-[11px] text-slate-700 leading-normal">
              <span className="font-black text-[#1b365d] block">Indicador de Saúde Financeira:</span>
              <span>
                {currentBalance > 0 
                  ? 'Sua empresa opera com saldo de caixa positivo no período selecionado.'
                  : 'Atenção ao saldo de caixa atual negativo. Considere antecipar cobranças ou renegociar despesas.'
                }
              </span>
            </div>
          </div>

          {/* Seção de Configuração de Cobrança PIX */}
          <div className="md:col-span-3 bg-white rounded-xl border-2 border-[#b0bec5] p-5 space-y-4 shadow-sm" id="pix-settings-card">
            <div className="flex items-center justify-between border-b-2 border-slate-200 pb-3">
              <div className="flex items-center gap-2 text-[#1b365d]">
                <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-700">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider">Chave PIX da Empresa</h3>
                  <span className="text-xs text-slate-500 block">Configure a chave PIX que será enviada aos clientes nas mensagens de cobrança de manutenção</span>
                </div>
              </div>
            </div>

            <form onSubmit={handleSavePixSettings} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Tipo de Chave</label>
                <select
                  value={pixType}
                  onChange={(e) => setPixType(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:outline-hidden focus:border-[#0052cc]"
                >
                  <option value="CNPJ">CNPJ</option>
                  <option value="CPF">CPF</option>
                  <option value="CELULAR">Celular</option>
                  <option value="EMAIL">E-mail</option>
                  <option value="CHAVE_ALEATORIA">Chave Aleatória</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Chave PIX</label>
                <input
                  type="text"
                  placeholder="Ex: 00.000.000/0001-00 ou pix@oficina.com"
                  value={pixKey}
                  onChange={(e) => setPixKey(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-mono font-medium"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Beneficiário (Nome)</label>
                <input
                  type="text"
                  placeholder="Ex: Oficina Tech Ltda"
                  value={pixName}
                  onChange={(e) => setPixName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-medium"
                />
              </div>

              <div className="flex gap-2">
                <div className="space-y-1.5 flex-grow">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Cidade</label>
                  <input
                    type="text"
                    placeholder="Ex: São Paulo"
                    value={pixCity}
                    onChange={(e) => setPixCity(e.target.value)}
                    className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-medium"
                  />
                </div>
                <button
                  type="submit"
                  className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1 shrink-0 h-[38px] ${
                    isPixSaved
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-xs'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>{isPixSaved ? 'Salvo!' : 'Salvar'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Auto Sync Banner for Unsynced Completed OS */}
      {unsyncedOS.length > 0 && (
        <div className="p-4 bg-amber-50 border-2 border-amber-300 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
          <div className="space-y-1">
            <span className="inline-flex items-center gap-1.5 text-xs font-black text-amber-900 uppercase tracking-wider">
              <TrendingUp className="w-4 h-4 text-amber-700 shrink-0" />
              Faturamento Disponível de OS Concluídas
            </span>
            <p className="text-xs text-slate-700">
              Existem <strong>{unsyncedOS.length}</strong> Ordens de Serviço concluídas que ainda não foram faturadas nas suas Contas a Receber.
            </p>
          </div>
          <button
            onClick={() => {
              // Sync all
              unsyncedOS.forEach(o => handleSyncOS(o));
            }}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider transition-colors cursor-pointer self-start sm:self-auto shrink-0 shadow-xs"
          >
            Faturar Todas Agora
          </button>
        </div>
      )}

      {/* List / Management Panel */}
      <div className="bg-white rounded-xl border-2 border-[#b0bec5] overflow-hidden shadow-sm" id="financial-list-container">
        
        {/* Table/List Filter Header Controls */}
        <div className="p-4 border-b-2 border-slate-200 bg-slate-50 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-grow max-w-md">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Pesquisar por descrição, categoria, obs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-medium"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              
              {/* Filter Status */}
              <div className="flex items-center gap-1.5">
                <Filter className="w-4 h-4 text-slate-500" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:outline-hidden focus:border-[#0052cc]"
                >
                  <option value="ALL">Todos os Status</option>
                  <option value="PAID">Liquidados (Pagos)</option>
                  <option value="PENDING">Pendentes</option>
                  <option value="OVERDUE">Vencidos</option>
                </select>
              </div>

              {/* Filter Category */}
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:outline-hidden focus:border-[#0052cc]"
              >
                <option value="ALL">Todas as Categorias</option>
                {allUsedCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>

              {(searchQuery || statusFilter !== 'ALL' || categoryFilter !== 'ALL') && (
                <button
                  type="button"
                  onClick={() => { setSearchQuery(''); setStatusFilter('ALL'); setCategoryFilter('ALL'); }}
                  className="px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl flex items-center gap-1 transition-colors cursor-pointer border border-slate-300"
                  title="Limpar todos os filtros da pesquisa"
                >
                  <X className="w-3.5 h-3.5 text-slate-600" />
                  <span>Limpar Filtros</span>
                </button>
              )}

              <button
                onClick={() => handleOpenAddModal(financeTab === 'PAYABLE' ? 'PAYABLE' : 'RECEIVABLE')}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                Adicionar Registro
              </button>
            </div>
          </div>

          {(searchQuery || statusFilter !== 'ALL' || categoryFilter !== 'ALL') && (
            <div className="flex items-center justify-between text-xs text-slate-600 font-mono pt-1">
              <span>
                Exibindo <strong className="text-[#0052cc]">{filteredTransactions.length}</strong> de <strong className="text-slate-900">{transactions.length}</strong> lançamentos na listagem
              </span>
              {searchQuery && (
                <span className="text-slate-500 italic">
                  Filtro: "{searchQuery}"
                </span>
              )}
            </div>
          )}
        </div>

        {/* Transactions Table */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="bg-[#1b365d] text-white text-[10px] font-black uppercase tracking-wider">
                <th className="py-3 px-4 w-12 text-center">Tipo</th>
                <th className="py-3 px-4">Descrição</th>
                <th className="py-3 px-4">Categoria</th>
                <th className="py-3 px-4">Vencimento</th>
                <th className="py-3 px-4">Pagamento</th>
                <th className="py-3 px-4 text-right">Valor (R$)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500 font-medium">
                    Nenhum registro financeiro localizado para as condições atuais.
                  </td>
                </tr>
              ) : (
                filteredTransactions
                  .slice()
                  .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
                  .map(t => {
                    const displayStatus = getDisplayStatus(t);
                    return (
                      <tr id={`fin-tx-row-${t.id}`} key={t.id} className="hover:bg-blue-50/40 transition-colors">
                        <td className="py-3 px-4 text-center">
                          {t.type === 'RECEIVABLE' ? (
                            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800 border border-emerald-300 inline-block" title="Receita / Contas a Receber">
                              <ArrowUpRight className="w-3.5 h-3.5" />
                            </span>
                          ) : (
                            <span className="p-1.5 rounded-lg bg-rose-100 text-rose-800 border border-rose-300 inline-block" title="Despesa / Contas a Pagar">
                              <ArrowDownRight className="w-3.5 h-3.5" />
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <div className="space-y-0.5">
                            <span className="font-bold text-slate-900 block leading-tight">{t.description}</span>
                            {t.notes && <span className="text-[10px] text-slate-500 line-clamp-1 italic">{t.notes}</span>}
                            {t.serviceOrderId && (
                              <span className="inline-flex items-center gap-1 text-[9px] font-mono font-black text-[#0052cc] bg-blue-50 px-1.5 py-0.5 border border-blue-200 rounded">
                                <FileText className="w-2.5 h-2.5" />
                                OS Ref: {orders.find(o => o.id === t.serviceOrderId)?.osNumber || 'Manual'}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-slate-700 font-medium">{t.category}</td>
                        <td className="py-3 px-4 font-mono font-medium text-slate-800">
                          {new Date(t.dueDate + 'T12:00:00').toLocaleDateString('pt-BR')}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-600">
                          {t.paymentDate 
                            ? new Date(t.paymentDate + 'T12:00:00').toLocaleDateString('pt-BR') 
                            : <span className="text-slate-400">-</span>
                          }
                        </td>
                        <td className={`py-3 px-4 font-mono font-black text-right ${t.type === 'RECEIVABLE' ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {formatBRL(t.amount)}
                        </td>
                        <td className="py-3 px-4">
                          {displayStatus === 'PAID' && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 border border-emerald-300 text-emerald-800 text-[10px] font-black uppercase tracking-wider">
                              <CheckCircle2 className="w-3 h-3 text-emerald-700" /> Pago
                            </span>
                          )}
                          {displayStatus === 'PENDING' && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-100 border border-amber-300 text-amber-900 text-[10px] font-black uppercase tracking-wider">
                              <Clock className="w-3 h-3 text-amber-700" /> Pendente
                            </span>
                          )}
                          {displayStatus === 'OVERDUE' && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-100 border border-rose-300 text-rose-800 text-[10px] font-black uppercase tracking-wider animate-pulse">
                              <AlertTriangle className="w-3 h-3 text-rose-700" /> Vencido
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {t.type === 'RECEIVABLE' && (
                              <button
                                id={`btn-share-pix-${t.id}`}
                                onClick={() => handleOpenPixShareModal(t)}
                                className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg border border-emerald-200 cursor-pointer transition-colors"
                                title="Enviar Cobrança com PIX"
                              >
                                <Share2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                            {t.status === 'PENDING' && (
                              <button
                                id={`btn-quick-pay-${t.id}`}
                                onClick={() => handleQuickMarkPaid(t)}
                                className="p-1.5 bg-blue-50 hover:bg-blue-100 text-[#0052cc] rounded-lg border border-blue-200 cursor-pointer transition-colors"
                                title={t.type === 'RECEIVABLE' ? 'Registrar Recebimento' : 'Registrar Pagamento'}
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              id={`btn-edit-tx-${t.id}`}
                              onClick={() => handleOpenEditModal(t)}
                              className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-slate-900 border border-slate-200 cursor-pointer transition-colors"
                              title="Editar Lançamento"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              id={`btn-delete-tx-${t.id}`}
                              onClick={() => setDeleteConfirmation(t)}
                              className="p-1.5 hover:bg-rose-50 rounded-lg text-rose-600 hover:text-rose-700 border border-rose-200 cursor-pointer transition-colors"
                              title="Excluir Lançamento"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Insert / Edit Transaction Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="transaction-form-modal">
          <div className="absolute inset-0 bg-[#000000]/70 backdrop-blur-xs" onClick={() => setIsModalOpen(false)}></div>
          
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border-2 border-[#b0bec5]">
            
            {/* Modal Header */}
            <div className="bg-[#1b365d] text-white px-5 py-4 flex items-center justify-between border-b border-blue-900">
              <h3 className="font-black text-white text-sm uppercase tracking-wider flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-amber-400" />
                {editingTransaction ? 'Editar Registro Financeiro' : 'Adicionar Novo Registro'}
              </h3>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-white/15 rounded-lg text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {formError && (
                <div className="p-3 bg-rose-50 border-2 border-rose-300 text-rose-800 text-xs rounded-xl flex items-center gap-2 font-bold">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <form onSubmit={handleSaveTransaction} className="space-y-4">
                
                {/* Type Selection */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Tipo de Registro</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => { setType('RECEIVABLE'); setCategory('Mão de Obra'); }}
                      className={`py-2 rounded-xl text-xs font-black uppercase border-2 transition-all cursor-pointer text-center ${
                        type === 'RECEIVABLE'
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                          : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      Contas a Receber
                    </button>
                    <button
                      type="button"
                      onClick={() => { setType('PAYABLE'); setCategory('Peças'); }}
                      className={`py-2 rounded-xl text-xs font-black uppercase border-2 transition-all cursor-pointer text-center ${
                        type === 'PAYABLE'
                          ? 'bg-rose-600 border-rose-600 text-white shadow-xs'
                          : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      Contas a Pagar
                    </button>
                  </div>
                </div>

                {/* Description */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Descrição / Título *</label>
                  <input
                    type="text"
                    placeholder="Ex: Fornecedor de engrenagens, Faturamento OS..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-medium"
                    required
                  />
                </div>

                {/* Amount & Category */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Valor (R$) *</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      placeholder="0.00"
                      value={amount || ''}
                      onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-hidden focus:border-[#0052cc]"
                      required
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Categoria</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:outline-hidden focus:border-[#0052cc]"
                    >
                      {categories[type].map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Due Date & Status */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Vencimento *</label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:outline-hidden focus:border-[#0052cc]"
                      required
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Situação</label>
                    <select
                      value={status}
                      onChange={(e) => {
                        const newStatus = e.target.value as FinancialStatus;
                        setStatus(newStatus);
                        if (newStatus === 'PAID' && !paymentDate) {
                          setPaymentDate(new Date().toISOString().split('T')[0]);
                        }
                      }}
                      className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:outline-hidden focus:border-[#0052cc] cursor-pointer"
                    >
                      <option value="PENDING">Pendente</option>
                      <option value="PAID">Liquidado / Pago</option>
                    </select>
                  </div>
                </div>

                {/* Payment Date (if PAID) */}
                {status === 'PAID' && (
                  <div className="space-y-1.5 animate-in fade-in duration-100">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700">
                      Data do {type === 'RECEIVABLE' ? 'Recebimento' : 'Pagamento'} *
                    </label>
                    <input
                      type="date"
                      value={paymentDate}
                      onChange={(e) => setPaymentDate(e.target.value)}
                      className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:outline-hidden focus:border-[#0052cc]"
                      required={status === 'PAID'}
                    />
                  </div>
                )}

                {/* Optional Service Order reference */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Vincular à Ordem de Serviço (Opcional)</label>
                  <select
                    value={associatedOSId}
                    onChange={(e) => setAssociatedOSId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-medium focus:outline-hidden focus:border-[#0052cc]"
                  >
                    <option value="">Nenhuma ordem de serviço vinculada</option>
                    {orders.map(o => (
                      <option key={o.id} value={o.id}>OS-{o.osNumber}: {o.title} (R$ {o.estimatedCost.toFixed(2)})</option>
                    ))}
                  </select>
                </div>

                {/* Notes */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700">Observações</label>
                  <textarea
                    rows={2}
                    placeholder="Informações adicionais como número de nota fiscal, condições de parcelas..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] resize-none font-medium"
                  />
                </div>

                {/* Actions Footer */}
                <div className="flex items-center justify-end gap-2.5 pt-3 border-t-2 border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 bg-slate-200 hover:bg-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider text-slate-800 transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md cursor-pointer"
                  >
                    {editingTransaction ? 'Salvar Alterações' : 'Adicionar Registro'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Share PIX Billing Modal */}
      {sharingTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="share-pix-billing-modal">
          <div className="absolute inset-0 bg-[#000000]/70 backdrop-blur-xs" onClick={() => setSharingTx(null)}></div>
          
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border-2 border-[#b0bec5]">
            
            {/* Modal Header */}
            <div className="bg-[#1b365d] text-white px-5 py-4 flex items-center justify-between border-b border-blue-900">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Share2 className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="font-black text-white text-sm uppercase tracking-wider">Enviar Cobrança com PIX</h3>
                  <span className="text-[10px] text-blue-200 font-mono block">Valor: {formatBRL(sharingTx.amount)}</span>
                </div>
              </div>
              <button 
                onClick={() => setSharingTx(null)}
                className="p-1 hover:bg-white/15 rounded-lg text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Client Selector (if multiple clients available) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-700 uppercase tracking-wider">Enviar para Cliente</label>
                  <select
                    value={sharingClient?.id || ''}
                    onChange={(e) => {
                      const selected = clients.find(c => c.id === e.target.value) || null;
                      setSharingClient(selected);
                      regeneratePixMessage(sharingTx, selected);
                    }}
                    className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-medium focus:outline-hidden focus:border-[#0052cc]"
                  >
                    <option value="">-- Selecione o Cliente --</option>
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-700 uppercase tracking-wider">Contato do Cliente</label>
                  <div className="px-3 py-2 bg-slate-100 border-2 border-slate-200 rounded-xl text-xs text-slate-700 font-mono font-medium">
                    {sharingClient ? `${sharingClient.phone} | ${sharingClient.document}` : 'Nenhum cliente selecionado'}
                  </div>
                </div>
              </div>

              {/* Quick PIX configuration verification */}
              {!pixKey && (
                <div className="p-3.5 bg-amber-50 border-2 border-amber-300 rounded-xl space-y-2">
                  <div className="flex items-center gap-2 text-amber-800 text-xs font-black uppercase">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>Chave PIX não cadastrada!</span>
                  </div>
                  <p className="text-xs text-amber-900 leading-normal">
                    Cadastre a chave PIX da sua empresa para que os dados de pagamento sejam inseridos automaticamente na mensagem de cobrança.
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Chave PIX da Empresa"
                      value={pixKey}
                      onChange={(e) => {
                        setPixKey(e.target.value);
                        const updated = { type: pixType, key: e.target.value, name: pixName, city: pixCity };
                        localStorage.setItem('oficina_company_pix', JSON.stringify(updated));
                        setTimeout(() => regeneratePixMessage(sharingTx, sharingClient), 10);
                      }}
                      className="px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 font-medium"
                    />
                    <input
                      type="text"
                      placeholder="Nome do Recebedor"
                      value={pixName}
                      onChange={(e) => {
                        setPixName(e.target.value);
                        const updated = { type: pixType, key: pixKey, name: e.target.value, city: pixCity };
                        localStorage.setItem('oficina_company_pix', JSON.stringify(updated));
                        setTimeout(() => regeneratePixMessage(sharingTx, sharingClient), 10);
                      }}
                      className="px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 font-medium"
                    />
                  </div>
                </div>
              )}

              {/* Message Preview and QR Code Side-by-Side */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 space-y-1.5">
                  <label className="block text-xs font-black text-slate-700 uppercase tracking-wider flex items-center justify-between">
                    <span>Mensagem Personalizada</span>
                    <span className="text-[10px] text-slate-500 normal-case font-medium">(Editável)</span>
                  </label>
                  <textarea
                    rows={7}
                    value={customPixMessage}
                    onChange={(e) => setCustomPixMessage(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-mono focus:outline-hidden focus:border-[#0052cc] leading-relaxed"
                  ></textarea>
                </div>

                <div className="flex flex-col items-center justify-center p-3 bg-slate-50 border-2 border-slate-200 rounded-xl space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-700 text-center">QR Code PIX</span>
                  
                  <div className="relative p-2.5 bg-white rounded-xl flex flex-col items-center justify-center w-28 h-28 shadow-sm border border-slate-200">
                    <QrCode className="w-24 h-24 text-slate-900" />
                    <span className="absolute bottom-0.5 text-[7px] text-[#1b365d] font-black tracking-wider">PIX SEGURO</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const mockCode = generateMockPixCode(pixKey || 'pix@empresa.com', pixName || 'Oficina Ltda', pixCity || 'Sao Paulo', sharingTx.amount);
                      navigator.clipboard.writeText(mockCode);
                      setCopyPixCodeFeedback(true);
                      setTimeout(() => setCopyPixCodeFeedback(false), 2000);
                    }}
                    className={`w-full py-1.5 px-2 rounded-xl text-[10px] font-black uppercase transition-all flex items-center justify-center gap-1 cursor-pointer border ${
                      copyPixCodeFeedback
                        ? 'bg-emerald-100 border-emerald-400 text-emerald-800'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100 shadow-xs'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{copyPixCodeFeedback ? 'PIX Copiado!' : 'Copia/Cola'}</span>
                  </button>
                </div>
              </div>

              {/* Action Buttons for Sending */}
              <div className="grid grid-cols-3 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    const phone = sharingClient?.phone ? sharingClient.phone.replace(/\D/g, '') : '';
                    const url = `https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(customPixMessage)}`;
                    window.open(url, '_blank');
                  }}
                  className="py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>WhatsApp</span>
                </button>
                
                <button
                  type="button"
                  onClick={() => {
                    const subject = `Cobrança de Manutenção - ${sharingClient?.name || ''}`;
                    const url = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(customPixMessage)}`;
                    window.open(url, '_blank');
                  }}
                  className="py-2.5 bg-[#0052cc] hover:bg-blue-600 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Mail className="w-4 h-4" />
                  <span>E-mail</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(customPixMessage);
                    setCopyTxFeedback(true);
                    setTimeout(() => setCopyTxFeedback(false), 2000);
                  }}
                  className={`py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer border ${
                    copyTxFeedback 
                      ? 'bg-emerald-100 border-emerald-400 text-emerald-800' 
                      : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <CheckCircle2 className={`w-4 h-4 ${copyTxFeedback ? 'text-emerald-600 animate-bounce' : 'text-slate-500'}`} />
                  <span>{copyTxFeedback ? 'Copiado!' : 'Copiar Texto'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="delete-confirmation-modal">
          <div className="absolute inset-0 bg-[#000000]/70 backdrop-blur-xs" onClick={() => setDeleteConfirmation(null)}></div>
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border-2 border-rose-300">
            <div className="bg-rose-700 text-white px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-xl">
                  <Trash2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-black text-white text-sm uppercase tracking-wider">Excluir Registro</h3>
                  <span className="text-[10px] text-rose-100 block">Confirmação de Exclusão</span>
                </div>
              </div>
              <button 
                onClick={() => setDeleteConfirmation(null)}
                className="p-1 hover:bg-white/15 rounded-lg text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="p-4 bg-slate-50 border-2 border-slate-200 rounded-xl space-y-1.5 text-xs">
                <p className="text-slate-700"><strong>Descrição:</strong> <span className="text-slate-900 font-bold">{deleteConfirmation.description}</span></p>
                <p className="text-slate-700"><strong>Tipo:</strong> <span className={deleteConfirmation.type === 'RECEIVABLE' ? 'text-emerald-700 font-bold' : 'text-rose-700 font-bold'}>{deleteConfirmation.type === 'RECEIVABLE' ? 'Contas a Receber' : 'Contas a Pagar'}</span></p>
                <p className="text-slate-700"><strong>Valor:</strong> <span className="text-slate-900 font-mono font-bold">{formatBRL(deleteConfirmation.amount)}</span></p>
                <p className="text-slate-700"><strong>Vencimento:</strong> <span className="text-slate-900 font-mono">{new Date(deleteConfirmation.dueDate + 'T12:00:00').toLocaleDateString('pt-BR')}</span></p>
                <p className="text-slate-700"><strong>Categoria:</strong> <span className="text-slate-900">{deleteConfirmation.category}</span></p>
              </div>

              <p className="text-xs text-slate-600 font-medium">
                A exclusão removerá este registro permanentemente do fluxo financeiro. Tem certeza de que deseja prosseguir?
              </p>

              <div className="flex items-center justify-end gap-2.5 pt-2 border-t-2 border-slate-200">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmation(null)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  Excluir Definitivamente
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Duplicate Warning Modal */}
      {duplicateWarning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="duplicate-warning-modal">
          <div className="absolute inset-0 bg-[#000000]/70 backdrop-blur-xs" onClick={() => setDuplicateWarning(null)}></div>
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border-2 border-amber-400">
            <div className="bg-amber-500 text-slate-950 px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-950/10 rounded-xl">
                  <AlertTriangle className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <h3 className="font-black text-slate-950 text-sm uppercase tracking-wider">Atenção: Registro Duplicado</h3>
                  <span className="text-[10px] text-slate-800 font-bold block">Item equivalente localizado no controle financeiro</span>
                </div>
              </div>
              <button 
                onClick={() => setDuplicateWarning(null)}
                className="p-1 hover:bg-slate-950/10 rounded-lg text-slate-900 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="p-4 bg-amber-50 border-2 border-amber-200 rounded-xl space-y-1.5 text-xs">
                <span className="text-[10px] font-black text-amber-900 uppercase block">Lançamento Já Cadastrado:</span>
                <p className="text-slate-800"><strong>Descrição:</strong> <span className="text-slate-950 font-bold">{duplicateWarning.existingTx.description}</span></p>
                <p className="text-slate-800"><strong>Tipo:</strong> <span className={duplicateWarning.existingTx.type === 'RECEIVABLE' ? 'text-emerald-700 font-bold' : 'text-rose-700 font-bold'}>{duplicateWarning.existingTx.type === 'RECEIVABLE' ? 'Contas a Receber' : 'Contas a Pagar'}</span></p>
                <p className="text-slate-800"><strong>Valor:</strong> <span className="text-slate-950 font-mono font-bold">{formatBRL(duplicateWarning.existingTx.amount)}</span></p>
                <p className="text-slate-800"><strong>Vencimento:</strong> <span className="text-slate-950 font-mono">{new Date(duplicateWarning.existingTx.dueDate + 'T12:00:00').toLocaleDateString('pt-BR')}</span></p>
                <p className="text-slate-800"><strong>Categoria:</strong> <span className="text-slate-900">{duplicateWarning.existingTx.category}</span></p>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed font-medium">
                O sistema detectou que este registro possui os mesmos dados de um lançamento existente. A criação desordenada de duplicatas é bloqueada para manter a precisão do seu fluxo de caixa.
              </p>
              <p className="text-xs text-amber-900 font-bold">
                Deseja autorizar a inserção deste item duplicado assim mesmo?
              </p>

              <div className="flex flex-wrap items-center justify-end gap-2.5 pt-2 border-t-2 border-slate-200">
                <button
                  type="button"
                  onClick={() => setDuplicateWarning(null)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Cancelar / Corrigir
                </button>
                <button
                  type="button"
                  onClick={() => commitSaveTransaction(duplicateWarning.pendingData)}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Permitir Cadastro Duplicado
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
