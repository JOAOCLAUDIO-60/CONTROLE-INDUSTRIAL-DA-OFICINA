import React, { useState, useEffect } from 'react';
import { MessageSquare, Mail, User, Phone, AtSign, Copy, CheckCircle2, X, ExternalLink, Send, ShieldCheck, FileText } from 'lucide-react';
import { formatPhoneNumber } from '../utils/phoneFormatter';

export interface ShareContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  docType?: 'ORCAMENTO' | 'RECIBO_GARANTIA' | 'FICHA_ENTRADA' | 'GERAL';
  clientName: string;
  clientPhone: string;
  clientEmail?: string;
  defaultChannel?: 'WHATSAPP' | 'EMAIL';
  defaultMessage: string;
  subject?: string;
  onFeedback?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ShareContactModal: React.FC<ShareContactModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  docType = 'GERAL',
  clientName,
  clientPhone,
  clientEmail = '',
  defaultChannel = 'WHATSAPP',
  defaultMessage,
  subject = 'Documento de Manutenção - JC&F',
  onFeedback,
}) => {
  const [channel, setChannel] = useState<'WHATSAPP' | 'EMAIL'>(defaultChannel);
  const [recipientType, setRecipientType] = useState<'CLIENT' | 'CUSTOM'>('CLIENT');
  const [customPhone, setCustomPhone] = useState('');
  const [customEmail, setCustomEmail] = useState('');
  const [message, setMessage] = useState(defaultMessage);
  const [emailSubject, setEmailSubject] = useState(subject);
  const [copied, setCopied] = useState(false);

  // Sync state whenever modal opens or defaults change
  useEffect(() => {
    if (isOpen) {
      setChannel(defaultChannel);
      setRecipientType('CLIENT');
      setCustomPhone('');
      setCustomEmail('');
      setMessage(defaultMessage);
      setEmailSubject(subject);
      setCopied(false);
    }
  }, [isOpen, defaultChannel, defaultMessage, subject]);

  if (!isOpen) return null;

  // Clean phone number helper
  const getSanitizedPhone = (rawPhone: string) => {
    const digits = rawPhone.replace(/\D/g, '');
    if (!digits) return '';
    // If it's standard 10 or 11 digits Brazilian number without country code 55
    if (digits.length === 10 || digits.length === 11) {
      return `55${digits}`;
    }
    return digits;
  };

  const getTargetPhone = () => {
    if (recipientType === 'CLIENT') {
      return getSanitizedPhone(clientPhone);
    }
    return getSanitizedPhone(customPhone);
  };

  const getTargetEmail = () => {
    if (recipientType === 'CLIENT') {
      return (clientEmail || '').trim();
    }
    return customEmail.trim();
  };

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    if (onFeedback) {
      onFeedback('Mensagem copiada para a área de transferência!', 'success');
    }
  };

  const handleSend = () => {
    if (channel === 'WHATSAPP') {
      const targetPhone = getTargetPhone();
      if (!targetPhone && recipientType === 'CUSTOM') {
        if (onFeedback) onFeedback('Por favor, informe o número de WhatsApp para envio.', 'error');
        return;
      }
      if (!targetPhone && recipientType === 'CLIENT' && !clientPhone) {
        if (onFeedback) onFeedback('O cliente não possui telefone cadastrado. Selecione "Outro Número" para informar.', 'error');
        return;
      }

      // WhatsApp URL: If phone is provided, target that number; otherwise open WhatsApp Web prompt
      const url = targetPhone
        ? `https://api.whatsapp.com/send?phone=${targetPhone}&text=${encodeURIComponent(message)}`
        : `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;

      window.open(url, '_blank');
      navigator.clipboard.writeText(message);
      if (onFeedback) {
        onFeedback(`Abrindo WhatsApp para ${recipientType === 'CLIENT' ? clientName : 'o número informado'}...`, 'success');
      }
      onClose();
    } else {
      // EMAIL
      const targetEmail = getTargetEmail();
      if (!targetEmail && recipientType === 'CUSTOM') {
        if (onFeedback) onFeedback('Por favor, informe o endereço de e-mail de destino.', 'error');
        return;
      }

      const mailtoUrl = `mailto:${encodeURIComponent(targetEmail)}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(message)}`;
      window.open(mailtoUrl, '_blank');
      navigator.clipboard.writeText(message);
      if (onFeedback) {
        onFeedback(`Abrindo aplicativo de e-mail para ${targetEmail || 'o destinatário'}...`, 'success');
      }
      onClose();
    }
  };

  // Badge icon by docType
  const getDocTypeIcon = () => {
    switch (docType) {
      case 'ORCAMENTO':
        return <FileText className="w-5 h-5 text-amber-400" />;
      case 'RECIBO_GARANTIA':
        return <ShieldCheck className="w-5 h-5 text-emerald-400" />;
      case 'FICHA_ENTRADA':
        return <FileText className="w-5 h-5 text-cyan-400" />;
      default:
        return <Send className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150" id="share-contact-modal">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-xs" onClick={onClose} />

      {/* Modal Dialog */}
      <div className="relative bg-[#0f111a] rounded-2xl shadow-2xl w-full max-w-xl overflow-hidden border border-slate-800 text-slate-100 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-[#151824]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-700/80 shadow-inner">
              {getDocTypeIcon()}
            </div>
            <div>
              <h3 className="font-black text-white text-sm sm:text-base uppercase tracking-wider">
                {title}
              </h3>
              {subtitle && (
                <p className="text-[11px] text-cyan-400 font-mono font-medium">
                  {subtitle}
                </p>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1 text-xs">

          {/* Step 1: Canal de Envio (WhatsApp vs E-mail) */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              1. Selecione o Canal de Envio
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setChannel('WHATSAPP')}
                className={`py-2.5 px-3 rounded-xl font-bold uppercase tracking-wider flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                  channel === 'WHATSAPP'
                    ? 'bg-emerald-600 border-emerald-400 text-white shadow-lg shadow-emerald-950/40 ring-2 ring-emerald-500/40'
                    : 'bg-[#151824] border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={() => setChannel('EMAIL')}
                className={`py-2.5 px-3 rounded-xl font-bold uppercase tracking-wider flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                  channel === 'EMAIL'
                    ? 'bg-blue-600 border-blue-400 text-white shadow-lg shadow-blue-950/40 ring-2 ring-blue-500/40'
                    : 'bg-[#151824] border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Mail className="w-4 h-4" />
                <span>E-mail</span>
              </button>
            </div>
          </div>

          {/* Step 2: Destinatário (Cliente Cadastrado vs Outro Contato) */}
          <div className="space-y-2">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              2. Escolha o Destinatário
            </label>

            {/* Radio 1: Contato do Cliente */}
            <div
              onClick={() => setRecipientType('CLIENT')}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                recipientType === 'CLIENT'
                  ? 'bg-[#181e30] border-cyan-500/60 shadow-md ring-1 ring-cyan-500/30'
                  : 'bg-[#131520] border-slate-800 hover:border-slate-700'
              }`}
            >
              <input
                type="radio"
                name="recipientType"
                checked={recipientType === 'CLIENT'}
                onChange={() => setRecipientType('CLIENT')}
                className="mt-1 w-4 h-4 text-cyan-500 bg-white border-slate-400 cursor-pointer accent-cyan-500"
              />
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-cyan-400" />
                    Contato Cadastrado do Cliente
                  </span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 font-mono font-bold">
                    Padrão
                  </span>
                </div>
                
                <p className="text-[11px] text-slate-200 font-semibold">
                  {clientName || 'Cliente não identificado'}
                </p>

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] text-slate-400 pt-0.5">
                  <span className="flex items-center gap-1">
                    <Phone className="w-3 h-3 text-emerald-400" />
                    {clientPhone ? formatPhoneNumber(clientPhone) : <em className="text-rose-400">Sem telefone</em>}
                  </span>
                  {clientEmail && (
                    <span className="flex items-center gap-1">
                      <AtSign className="w-3 h-3 text-blue-400" />
                      {clientEmail}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Radio 2: Outro Número / Outro Endereço */}
            <div
              onClick={() => setRecipientType('CUSTOM')}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-3 ${
                recipientType === 'CUSTOM'
                  ? 'bg-[#181e30] border-cyan-500/60 shadow-md ring-1 ring-cyan-500/30'
                  : 'bg-[#131520] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start gap-3">
                <input
                  type="radio"
                  name="recipientType"
                  checked={recipientType === 'CUSTOM'}
                  onChange={() => setRecipientType('CUSTOM')}
                  className="mt-1 w-4 h-4 text-cyan-500 bg-white border-slate-400 cursor-pointer accent-cyan-500"
                />
                <div className="flex-1">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5">
                    {channel === 'WHATSAPP' ? (
                      <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <AtSign className="w-3.5 h-3.5 text-blue-400" />
                    )}
                    {channel === 'WHATSAPP' ? 'Enviar para Outro Número de WhatsApp' : 'Enviar para Outro Endereço de E-mail'}
                  </span>
                  <p className="text-[10px] text-slate-400">
                    {channel === 'WHATSAPP'
                      ? 'Informe um telefone diferente (ex: setor de compras, responsável, filial ou sócio).'
                      : 'Informe um e-mail diferente (ex: financeiro@cliente.com.br, compras, etc.).'}
                  </p>
                </div>
              </div>

              {/* Input for Custom Number or Custom Email when CUSTOM is selected */}
              {recipientType === 'CUSTOM' && (
                <div className="pt-2 border-t border-slate-700/60 space-y-2" onClick={(e) => e.stopPropagation()}>
                  {channel === 'WHATSAPP' ? (
                    <div>
                      <label className="block text-[10px] font-bold text-slate-300 uppercase tracking-wider mb-1">
                        Número de Celular / WhatsApp (com DDD) *
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: (21) 98765-4321 ou 21987654321"
                        value={customPhone}
                        onChange={(e) => setCustomPhone(e.target.value)}
                        autoFocus
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-black font-bold text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden shadow-inner"
                      />
                      <span className="block text-[9px] text-slate-400 mt-1">
                        Dica: O sistema adiciona automaticamente o código do país (+55 Brasil) se necessário.
                      </span>
                    </div>
                  ) : (
                    <div>
                      <label className="block text-[10px] font-bold text-slate-300 uppercase tracking-wider mb-1">
                        Endereço de E-mail de Destino *
                      </label>
                      <input
                        type="email"
                        placeholder="Ex: financeiro@empresa.com.br"
                        value={customEmail}
                        onChange={(e) => setCustomEmail(e.target.value)}
                        autoFocus
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-black font-bold text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden shadow-inner"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Email Subject (if email is selected) */}
          {channel === 'EMAIL' && (
            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Assunto do E-mail
              </label>
              <input
                type="text"
                value={emailSubject}
                onChange={(e) => setEmailSubject(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-black font-bold text-xs focus:outline-hidden shadow-inner"
              />
            </div>
          )}

          {/* Step 3: Mensagem (Prévia e Edição Rápida) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                3. Texto da Mensagem Formatada
              </label>
              <span className="text-[9px] text-slate-500 italic">
                (Você pode personalizar o texto antes do envio)
              </span>
            </div>

            <textarea
              rows={7}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-black font-mono font-medium focus:ring-2 focus:ring-cyan-500 focus:outline-hidden leading-relaxed shadow-inner"
            />
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-[#151824] border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleCopyMessage}
            className={`w-full sm:w-auto px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
              copied
                ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-md'
                : 'bg-slate-900 border-slate-750 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Mensagem Copiada!' : 'Copiar Mensagem'}</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
            >
              Cancelar
            </button>

            <button
              type="button"
              onClick={handleSend}
              className={`w-full sm:w-auto px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                channel === 'WHATSAPP'
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/50'
                  : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-950/50'
              }`}
            >
              {channel === 'WHATSAPP' ? (
                <>
                  <MessageSquare className="w-4 h-4" />
                  <span>Abrir no WhatsApp</span>
                  <ExternalLink className="w-3.5 h-3.5 opacity-70" />
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4" />
                  <span>Enviar por E-mail</span>
                  <ExternalLink className="w-3.5 h-3.5 opacity-70" />
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
