import React, { useState, useEffect } from 'react';
import { 
  initAuth, 
  googleSignIn, 
  logout, 
  createJCFSpreadsheet, 
  listSpreadsheetsInDrive, 
  syncDataToSpreadsheet, 
  fetchDataFromSpreadsheet,
  SyncData 
} from '../lib/googleAuth';
import { User } from 'firebase/auth';
import { 
  FileSpreadsheet, Plus, RefreshCw, LogOut, ExternalLink, CheckCircle, 
  AlertCircle, Table, HelpCircle, Users, Smartphone, FileText, DollarSign, Database, Download
} from 'lucide-react';

interface GoogleSheetsSyncProps {
  clients: any[];
  equipments: any[];
  orders: any[];
  transactions: any[];
  inventory: any[];
  onImportData?: (data: SyncData) => void;
}

export default function GoogleSheetsSync({
  clients,
  equipments,
  orders,
  transactions,
  inventory,
  onImportData
}: GoogleSheetsSyncProps) {
  // Authentication & session state
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Drive/Sheets state
  const [spreadsheets, setSpreadsheets] = useState<{ id: string; name: string }[]>([]);
  const [selectedSpreadsheetId, setSelectedSpreadsheetId] = useState<string>('');
  const [isLoadingSpreadsheets, setIsLoadingSpreadsheets] = useState(false);
  const [isCreatingSpreadsheet, setIsCreatingSpreadsheet] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [lastSynced, setLastSynced] = useState<string | null>(null);

  // Status message
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [showSyncConfirm, setShowSyncConfirm] = useState(false);
  const [showImportConfirm, setShowImportConfirm] = useState(false);

  // Initialize auth state
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, currentToken) => {
        setUser(currentUser);
        setToken(currentToken);
        setNeedsAuth(false);
        setFeedback({ message: `Conectado como ${currentUser.email}`, type: 'success' });
        loadSpreadsheets(currentToken);
      },
      () => {
        setUser(null);
        setToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, []);

  // Fetch spreadsheets
  const loadSpreadsheets = async (authToken: string) => {
    setIsLoadingSpreadsheets(true);
    try {
      const files = await listSpreadsheetsInDrive(authToken);
      setSpreadsheets(files);
      
      // Auto select the first or previously saved spreadsheet from local storage
      const savedSheetId = localStorage.getItem('jcf_sync_spreadsheet_id');
      if (savedSheetId && files.some(f => f.id === savedSheetId)) {
        setSelectedSpreadsheetId(savedSheetId);
      } else if (files.length > 0) {
        setSelectedSpreadsheetId(files[0].id);
        localStorage.setItem('jcf_sync_spreadsheet_id', files[0].id);
      }
    } catch (err: any) {
      console.error(err);
      setFeedback({ message: 'Erro ao carregar arquivos do Drive. Verifique a conexão.', type: 'error' });
    } finally {
      setIsLoadingSpreadsheets(false);
    }
  };

  // Google Sign-In
  const handleLogin = async () => {
    setIsLoggingIn(true);
    setFeedback(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setToken(res.accessToken);
        setNeedsAuth(false);
        setFeedback({ message: 'Autenticado com sucesso no Google!', type: 'success' });
        loadSpreadsheets(res.accessToken);
      }
    } catch (err: any) {
      console.error(err);
      setFeedback({ message: 'Falha na autenticação do Google. Tente novamente.', type: 'error' });
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Log out
  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
      setToken(null);
      setNeedsAuth(true);
      setSpreadsheets([]);
      setSelectedSpreadsheetId('');
      setFeedback({ message: 'Sessão encerrada com sucesso.', type: 'info' });
    } catch (err) {
      console.error(err);
    }
  };

  // Create JCF Database Spreadsheet
  const handleCreateNewSpreadsheet = async () => {
    if (!token) return;
    setIsCreatingSpreadsheet(true);
    setFeedback({ message: 'Criando nova planilha estruturada...', type: 'info' });
    try {
      const newId = await createJCFSpreadsheet(token, `JC&F Manutenção - BD - ${new Date().toLocaleDateString('pt-BR')}`);
      setSelectedSpreadsheetId(newId);
      localStorage.setItem('jcf_sync_spreadsheet_id', newId);
      setFeedback({ message: 'Planilha JC&F criada com sucesso no seu Google Drive!', type: 'success' });
      // Reload spreadsheet list
      await loadSpreadsheets(token);
    } catch (err: any) {
      console.error(err);
      setFeedback({ message: 'Erro ao criar a planilha no seu Google Drive.', type: 'error' });
    } finally {
      setIsCreatingSpreadsheet(false);
    }
  };

  // Trigger sync confirmation modal
  const handleSyncData = () => {
    if (!token || !selectedSpreadsheetId) return;
    setShowSyncConfirm(true);
  };

  // Perform actual sync
  const executeSyncData = async () => {
    setShowSyncConfirm(false);
    if (!token || !selectedSpreadsheetId) return;

    setIsSyncing(true);
    setFeedback({ message: 'Sincronizando dados com o Google Sheets...', type: 'info' });

    try {
      const syncPayload: SyncData = {
        clients,
        equipments,
        orders,
        transactions,
        inventory
      };

      await syncDataToSpreadsheet(token, selectedSpreadsheetId, syncPayload);
      
      const timestamp = new Date().toLocaleTimeString('pt-BR');
      setLastSynced(timestamp);
      setFeedback({ message: `Sincronização concluída com sucesso às ${timestamp}!`, type: 'success' });
    } catch (err: any) {
      console.error(err);
      setFeedback({ message: 'Erro durante a sincronização de abas.', type: 'error' });
    } finally {
      setIsSyncing(false);
    }
  };

  // Trigger import confirmation modal
  const handleImportData = () => {
    if (!token || !selectedSpreadsheetId) return;
    setShowImportConfirm(true);
  };

  // Perform actual import
  const executeImportData = async () => {
    setShowImportConfirm(false);
    if (!token || !selectedSpreadsheetId || !onImportData) return;

    setIsImporting(true);
    setFeedback({ message: 'Buscando e importando dados do Google Sheets...', type: 'info' });

    try {
      const imported = await fetchDataFromSpreadsheet(token, selectedSpreadsheetId);
      onImportData(imported);
      
      const timestamp = new Date().toLocaleTimeString('pt-BR');
      setFeedback({ 
        message: `Importação concluída com sucesso às ${timestamp}! Dados locais sincronizados com o Google Sheets.`, 
        type: 'success' 
      });
    } catch (err: any) {
      console.error(err);
      setFeedback({ message: 'Erro ao importar. Verifique se a planilha selecionada possui as abas necessárias formatadas.', type: 'error' });
    } finally {
      setIsImporting(false);
    }
  };

  // Select Change Handler
  const handleSpreadsheetChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setSelectedSpreadsheetId(val);
    localStorage.setItem('jcf_sync_spreadsheet_id', val);
    setFeedback({ message: 'Planilha de destino alterada.', type: 'info' });
  };

  const selectedSpreadsheetName = spreadsheets.find(s => s.id === selectedSpreadsheetId)?.name || 'Planilha selecionada';

  return (
    <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="sheets-sync-root">
      
      {/* Header Banner */}
      <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-blue-900">
        <div>
          <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-cyan-300" />
            <span>Integração Google Sheets</span>
          </h2>
          <p className="text-xs text-cyan-100 mt-0.5">
            Exporte, sincronize e gerencie o banco de dados da oficina diretamente nas Planilhas Google
          </p>
        </div>
      </div>

      <div className="p-4 sm:p-6 bg-[#e9edf2] space-y-4">
        {feedback && (
          <div className={`p-4 rounded-xl border flex items-start gap-3 transition-all ${
            feedback.type === 'success' 
              ? 'bg-emerald-50 border-emerald-300 text-emerald-800' 
              : feedback.type === 'error' 
              ? 'bg-red-50 border-red-300 text-red-800' 
              : 'bg-blue-50 border-blue-300 text-blue-900'
          }`} id="sync-feedback">
            {feedback.type === 'success' ? (
              <CheckCircle className="w-4 h-4 mt-0.5 shrink-0 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-amber-600" />
            )}
            <div className="text-xs font-bold font-mono tracking-tight">{feedback.message}</div>
          </div>
        )}

        {needsAuth ? (
          /* Sign In Area */
          <div className="bg-white rounded-xl border border-slate-300 p-8 text-center max-w-xl mx-auto space-y-6 shadow-xs" id="sheets-auth-prompt-card">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-full w-16 h-16 flex items-center justify-center mx-auto text-blue-900">
              <FileSpreadsheet className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h3 className="text-base font-black text-slate-900 uppercase tracking-wider">Conectar ao Google Sheets</h3>
              <p className="text-xs text-slate-600 leading-relaxed max-w-md mx-auto">
                Para exportar suas Ordens de Serviço, Clientes, Equipamentos e Fluxo Financeiro, conecte sua conta Google de forma segura.
              </p>
            </div>

            <div className="flex justify-center pt-2">
              {/* Native GSI Button Wrapper */}
              <button 
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="gsi-material-button inline-flex items-center justify-center cursor-pointer transition-all duration-200 hover:scale-[1.02] disabled:opacity-50 disabled:pointer-events-none shadow-sm"
                id="btn-google-sign-in"
                style={{
                  backgroundColor: 'white',
                  border: '1px solid #747775',
                  borderRadius: '12px',
                  boxSizing: 'border-box',
                  color: '#1f1f1f',
                  fontFamily: '"Inter", sans-serif',
                  fontSize: '14px',
                  fontWeight: '600',
                  height: '46px',
                  padding: '0 24px',
                  minWidth: '240px',
                  position: 'relative'
                }}
              >
                <div className="gsi-material-button-content-wrapper flex items-center gap-3">
                  <div className="gsi-material-button-icon flex items-center justify-center">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block', width: '20px', height: '20px' }}>
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                    </svg>
                  </div>
                  <span className="gsi-material-button-contents font-semibold">{isLoggingIn ? 'Conectando...' : 'Entrar com o Google'}</span>
                </div>
              </button>
            </div>

            <p className="text-[10px] text-slate-500 italic max-w-sm mx-auto">
              Este aplicativo solicita permissão com segurança via protocolo Google OAuth 2.0 para salvar arquivos de planilha no seu Google Drive. Suas credenciais não são compartilhadas.
            </p>
          </div>
        ) : (
          /* Connected Dashboard */
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4" id="sheets-sync-dashboard">
            
            {/* Main Sync Controls (Span 2) */}
            <div className="lg:col-span-2 space-y-4">
              
              {/* Sheet Target Panel */}
              <div className="bg-white rounded-xl border border-slate-300 p-5 space-y-4 shadow-xs" id="target-sheets-panel">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2.5">
                  <Database className="w-4.5 h-4.5 text-blue-900" />
                  <h3 className="font-black text-slate-900 text-xs uppercase tracking-wider">Planilha de Destino</h3>
                </div>

                <div className="space-y-3.5">
                  <div className="flex flex-col sm:flex-row sm:items-end gap-3">
                    <div className="flex-1 space-y-1">
                      <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">
                        Selecione uma Planilha do seu Drive
                      </label>
                      <select
                        value={selectedSpreadsheetId}
                        onChange={handleSpreadsheetChange}
                        disabled={isLoadingSpreadsheets || isSyncing}
                        className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                        id="select-spreadsheet"
                      >
                        {spreadsheets.length === 0 ? (
                          <option value="">Nenhuma planilha encontrada</option>
                        ) : (
                          spreadsheets.map((sheet) => (
                            <option key={sheet.id} value={sheet.id}>
                              {sheet.name}
                            </option>
                          ))
                        )}
                      </select>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => token && loadSpreadsheets(token)}
                        disabled={isLoadingSpreadsheets || isSyncing}
                        className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center shrink-0"
                        title="Recarregar arquivos"
                        id="btn-reload-sheets"
                      >
                        <RefreshCw className={`w-4 h-4 ${isLoadingSpreadsheets ? 'animate-spin' : ''}`} />
                      </button>

                      <button
                        type="button"
                        onClick={handleCreateNewSpreadsheet}
                        disabled={isCreatingSpreadsheet || isSyncing}
                        className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0 shadow-sm"
                        id="btn-create-sheet"
                      >
                        <Plus className="w-4 h-4" />
                        <span>{isCreatingSpreadsheet ? 'Criando...' : 'Nova Planilha'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Spreadsheet Info Badge & Open Link */}
                  {selectedSpreadsheetId && (
                    <div className="bg-slate-50 p-3.5 border border-slate-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <span className="block text-[8px] uppercase font-black text-slate-500">Planilha Conectada</span>
                        <span className="block text-xs font-black text-slate-900">{selectedSpreadsheetName}</span>
                        <span className="block text-[9px] font-mono text-slate-500 truncate max-w-[280px] sm:max-w-md">ID: {selectedSpreadsheetId}</span>
                      </div>

                      <a
                        href={`https://docs.google.com/spreadsheets/d/${selectedSpreadsheetId}/edit`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-900 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer transition-colors"
                        id="link-open-spreadsheet"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Abrir Planilha</span>
                      </a>
                    </div>
                  )}
                </div>
              </div>

              {/* Sync Trigger Panel */}
              {selectedSpreadsheetId && (
                <div className="bg-white rounded-xl border border-slate-300 p-6 text-center space-y-5 shadow-xs" id="sync-trigger-panel">
                  <div className="space-y-1.5 max-w-md mx-auto">
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">Sincronização Bidirecional</h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Você pode enviar os dados deste computador para a planilha em nuvem ou puxar as informações que estão na planilha para atualizar este aparelho.
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    {/* Export Button */}
                    <button
                      type="button"
                      onClick={handleSyncData}
                      disabled={isSyncing || isImporting}
                      className="w-full sm:w-auto px-5 py-2.5 bg-[#1b365d] hover:bg-[#132644] disabled:bg-slate-300 text-white rounded-lg text-xs font-black uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
                      id="btn-trigger-sync"
                    >
                      <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                      <span>{isSyncing ? 'Exportando...' : 'Exportar para Planilha'}</span>
                    </button>

                    {/* Import Button */}
                    <button
                      type="button"
                      onClick={handleImportData}
                      disabled={isSyncing || isImporting}
                      className="w-full sm:w-auto px-5 py-2.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-300 text-slate-950 rounded-lg text-xs font-black uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
                      id="btn-trigger-import"
                    >
                      <Download className={`w-4 h-4 ${isImporting ? 'animate-bounce' : ''}`} />
                      <span>{isImporting ? 'Importando...' : 'Importar da Planilha'}</span>
                    </button>
                  </div>

                  {lastSynced && (
                    <span className="block text-[10px] text-emerald-700 font-mono font-bold">
                      ✓ Última atividade realizada às {lastSynced}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Sync Metadata & Summary Sidebar */}
            <div className="space-y-4">
              
              {/* Connected User Identity */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 space-y-3.5 shadow-xs" id="google-profile-card">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2.5">
                  <Users className="w-4 h-4 text-blue-900" />
                  <h4 className="font-black text-slate-900 text-[10px] uppercase tracking-wider">Conta Google Conectada</h4>
                </div>

                {user && (
                  <div className="flex items-center gap-3 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                    {user.photoURL ? (
                      <img src={user.photoURL} alt={user.displayName || 'Google User'} referrerPolicy="no-referrer" className="w-9 h-9 rounded-full border border-slate-300" />
                    ) : (
                      <div className="w-9 h-9 rounded-full bg-blue-900 flex items-center justify-center text-xs font-bold text-white">
                        {user.displayName ? user.displayName.charAt(0) : 'U'}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <span className="block text-xs font-black text-slate-900 truncate">{user.displayName || 'Usuário JC&F'}</span>
                      <span className="block text-[9px] text-slate-500 truncate font-mono">{user.email}</span>
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleLogout}
                  className="w-full py-2 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  id="btn-google-sign-out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Desconectar Conta</span>
                </button>
              </div>

              {/* Sync Payload Info Card */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 space-y-3.5 shadow-xs" id="sheets-payload-summary">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2.5">
                  <Table className="w-4 h-4 text-emerald-700" />
                  <h4 className="font-black text-slate-900 text-[10px] uppercase tracking-wider">Estrutura das Abas</h4>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs bg-slate-50 p-2 border border-slate-200 rounded-lg">
                    <div className="flex items-center gap-2">
                      <FileText className="w-3.5 h-3.5 text-blue-900" />
                      <span className="text-slate-800 font-bold">Ordens de Serviço</span>
                    </div>
                    <span className="text-slate-700 font-mono font-black text-[11px]">{orders.length} itens</span>
                  </div>

                  <div className="flex items-center justify-between text-xs bg-slate-50 p-2 border border-slate-200 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-blue-800" />
                      <span className="text-slate-800 font-bold">Clientes</span>
                    </div>
                    <span className="text-slate-700 font-mono font-black text-[11px]">{clients.length} itens</span>
                  </div>

                  <div className="flex items-center justify-between text-xs bg-slate-50 p-2 border border-slate-200 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-3.5 h-3.5 text-purple-700" />
                      <span className="text-slate-800 font-bold">Equipamentos</span>
                    </div>
                    <span className="text-slate-700 font-mono font-black text-[11px]">{equipments.length} itens</span>
                  </div>

                  <div className="flex items-center justify-between text-xs bg-slate-50 p-2 border border-slate-200 rounded-lg">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-700" />
                      <span className="text-slate-800 font-bold">Financeiro</span>
                    </div>
                    <span className="text-slate-700 font-mono font-black text-[11px]">{transactions.length} itens</span>
                  </div>

                  <div className="flex items-center justify-between text-xs bg-slate-50 p-2 border border-slate-200 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Database className="w-3.5 h-3.5 text-amber-700" />
                      <span className="text-slate-800 font-bold">Estoque / Peças</span>
                    </div>
                    <span className="text-slate-700 font-mono font-black text-[11px]">{inventory.length} itens</span>
                  </div>
                </div>
              </div>

              {/* Instruction Card */}
              <div className="bg-slate-100 p-3.5 rounded-xl border border-slate-300 space-y-1.5">
                <span className="flex items-center gap-1.5 text-slate-800 font-black text-[10px] uppercase tracking-wider">
                  <HelpCircle className="w-3.5 h-3.5 text-blue-900" />
                  Instruções de Uso
                </span>
                <p className="text-[10px] text-slate-600 leading-relaxed">
                  Cada aba na planilha selecionada receberá cabeçalhos formatados e registros detalhados das transações. Útil para extração de relatórios, gráficos pivotados, faturamento avançado e auditorias em equipe.
                </p>
              </div>

            </div>

          </div>
        )}
      </div>

      {/* Custom Sync Confirmation Modal */}
      {showSyncConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#000000]/60 backdrop-blur-xs">
          <div className="bg-white border-2 border-[#b0bec5] rounded-xl max-w-md w-full overflow-hidden shadow-2xl animate-fade-in text-left">
            <div className="bg-[#1b365d] text-white p-4 flex items-center gap-3">
              <div className="p-2 bg-white/10 text-cyan-300 rounded-lg">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Exportar para o Google Sheets?</h3>
            </div>
            <div className="p-5 text-xs text-slate-700 leading-relaxed">
              Você deseja exportar todos os dados do aplicativo para o Google Sheets? Isso atualizará os registros nas abas correspondentes da planilha vinculada.
            </div>
            <div className="flex items-center gap-2.5 justify-end bg-slate-50 border-t border-slate-200 p-4">
              <button
                type="button"
                onClick={() => setShowSyncConfirm(false)}
                className="px-4 py-2 bg-white border border-slate-300 text-slate-700 hover:text-slate-900 rounded-lg cursor-pointer text-xs font-bold uppercase tracking-wider"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={executeSyncData}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg font-black transition-colors cursor-pointer text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md"
              >
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Exportar Agora</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Import Confirmation Modal */}
      {showImportConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#000000]/60 backdrop-blur-xs">
          <div className="bg-white border-2 border-[#b0bec5] rounded-xl max-w-md w-full overflow-hidden shadow-2xl animate-fade-in text-left">
            <div className="bg-[#1b365d] text-white p-4 flex items-center gap-3">
              <div className="p-2 bg-white/10 text-amber-300 rounded-lg">
                <Download className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Importar do Google Sheets?</h3>
            </div>
            <div className="p-5 text-xs text-slate-700 leading-relaxed">
              Isso irá substituir os dados atuais de Clientes, Equipamentos, Ordens, Financeiro e Estoque deste aparelho pelos dados salvos na planilha conectada. Deseja continuar?
            </div>
            <div className="flex items-center gap-2.5 justify-end bg-slate-50 border-t border-slate-200 p-4">
              <button
                type="button"
                onClick={() => setShowImportConfirm(false)}
                className="px-4 py-2 bg-white border border-slate-300 text-slate-700 hover:text-slate-900 rounded-lg cursor-pointer text-xs font-bold uppercase tracking-wider"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={executeImportData}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg font-black transition-colors cursor-pointer text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md"
              >
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Importar Agora</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
