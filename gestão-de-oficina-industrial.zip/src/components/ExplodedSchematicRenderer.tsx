import React from 'react';
import { ExplodedPartItem } from '../types';

interface ExplodedSchematicRendererProps {
  schematicId?: string;
  imageUrl?: string;
  diagramType: 'SVG_SCHEMATIC' | 'IMAGE';
  parts: ExplodedPartItem[];
  selectedPartId: string | null;
  hoveredPartId: string | null;
  onSelectPart: (part: ExplodedPartItem) => void;
  onHoverPart: (partId: string | null) => void;
  isPlacingPinMode?: boolean;
  pinToPlace?: ExplodedPartItem | null;
  onPlacePinCoords?: (xPercent: number, yPercent: number) => void;
  zoomLevel: number;
}

export default function ExplodedSchematicRenderer({
  schematicId,
  imageUrl,
  diagramType,
  parts,
  selectedPartId,
  hoveredPartId,
  onSelectPart,
  onHoverPart,
  isPlacingPinMode,
  pinToPlace,
  onPlacePinCoords,
  zoomLevel
}: ExplodedSchematicRendererProps) {
  
  const handleContainerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPlacingPinMode || !onPlacePinCoords) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    onPlacePinCoords(Math.round(x * 10) / 10, Math.round(y * 10) / 10);
  };

  const renderBadge = (part: ExplodedPartItem, defaultX: number, defaultY: number) => {
    const x = part.hotspot?.x ?? defaultX;
    const y = part.hotspot?.y ?? defaultY;
    const isSelected = selectedPartId === part.id;
    const isHovered = hoveredPartId === part.id;
    const hasStockLink = !!part.inventoryItemId;

    return (
      <button
        key={part.id}
        type="button"
        style={{ left: `${x}%`, top: `${y}%` }}
        onClick={(e) => {
          e.stopPropagation();
          onSelectPart(part);
        }}
        onMouseEnter={() => onHoverPart(part.id)}
        onMouseLeave={() => onHoverPart(null)}
        title={`Pos. ${part.position} - ${part.factoryDescription}`}
        className={`absolute transform -translate-x-1/2 -translate-y-1/2 z-20 cursor-pointer transition-all duration-150 select-none flex items-center justify-center font-bold font-mono ${
          isSelected
            ? 'scale-125 ring-4 ring-cyan-400 shadow-xl bg-[#0052cc] text-white z-30'
            : isHovered
            ? 'scale-115 ring-2 ring-amber-400 bg-amber-500 text-slate-950 z-25'
            : hasStockLink
            ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md border border-emerald-300'
            : 'bg-[#1b365d] hover:bg-cyan-600 text-white shadow-md border border-slate-300'
        } ${
          part.position.length > 2 ? 'px-2 py-0.5 rounded-full text-[10px] min-w-[24px] h-6' : 'w-6 h-6 rounded-full text-[11px]'
        }`}
      >
        {part.position}
        {hasStockLink && !isSelected && (
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-400 border border-white rounded-full"></span>
        )}
      </button>
    );
  };

  return (
    <div 
      className={`relative w-full h-[520px] bg-slate-50 overflow-hidden border border-slate-300 rounded-xl select-none transition-transform flex items-center justify-center ${
        isPlacingPinMode ? 'cursor-crosshair ring-2 ring-amber-500' : 'cursor-default'
      }`}
      onClick={handleContainerClick}
    >
      <div 
        className="w-full h-full relative transition-transform duration-200 origin-center"
        style={{ transform: `scale(${zoomLevel})` }}
      >
        {/* Custom Image or SVG Schematic Background */}
        {diagramType === 'IMAGE' && imageUrl ? (
          <img 
            src={imageUrl} 
            alt="Vista Explodida Técnica"
            className="w-full h-full object-contain pointer-events-none p-4"
          />
        ) : schematicId === 'KARCHER_CABECOTE' ? (
          <KarcherCabecoteSvg parts={parts} selectedPartId={selectedPartId} hoveredPartId={hoveredPartId} />
        ) : schematicId === 'KARCHER_PISTOES' ? (
          <KarcherPistoesSvg parts={parts} selectedPartId={selectedPartId} hoveredPartId={hoveredPartId} />
        ) : schematicId === 'BOMBA_TRIPLEX' ? (
          <BombaTriplexSvg parts={parts} selectedPartId={selectedPartId} hoveredPartId={hoveredPartId} />
        ) : schematicId === 'CILINDRO_HIDRAULICO' ? (
          <CilindroHidraulicoSvg parts={parts} selectedPartId={selectedPartId} hoveredPartId={hoveredPartId} />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-slate-400">
            <p className="text-sm font-semibold">Diagrama técnico interativo</p>
            <p className="text-xs">Selecione uma peça na lista lateral para destacar suas características</p>
          </div>
        )}

        {/* Hotspots / Interactive Pin Badges */}
        {parts.map((part, idx) => {
          // Default fallbacks if hotspot is not placed yet
          const defaultX = 15 + (idx % 6) * 14;
          const defaultY = 20 + Math.floor(idx / 6) * 25;
          return renderBadge(part, defaultX, defaultY);
        })}

        {/* Placing Pin Indicator */}
        {isPlacingPinMode && pinToPlace && (
          <div className="absolute top-3 left-3 bg-amber-500 text-slate-950 font-bold px-3 py-1.5 rounded-lg shadow-lg text-xs flex items-center gap-2 z-30 animate-pulse border border-amber-300">
            <span>Clique no diagrama para posicionar o pino:</span>
            <span className="font-mono bg-slate-900 text-white px-2 py-0.5 rounded text-[11px]">
              Pos. {pinToPlace.position}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

// Technical Exploded Schematic for Kärcher K 3.10 Cabeçote (matching photo 1)
function KarcherCabecoteSvg({ 
  parts, 
  selectedPartId, 
  hoveredPartId 
}: { 
  parts: ExplodedPartItem[]; 
  selectedPartId: string | null; 
  hoveredPartId: string | null; 
}) {
  return (
    <svg 
      viewBox="0 0 900 650" 
      className="w-full h-full p-2 select-none"
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern id="metalHatch" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="8" stroke="#cbd5e1" strokeWidth="1" />
        </pattern>
        <filter id="dropGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="1" dy="2" stdDeviation="3" floodColor="#0284c7" floodOpacity="0.3" />
        </filter>
      </defs>

      {/* Grid background reference lines */}
      <rect x="10" y="10" width="880" height="630" rx="8" fill="#f8fafc" stroke="#e2e8f0" strokeWidth="1.5" />
      
      {/* Title Watermark */}
      <text x="30" y="45" fill="#94a3b8" fontSize="14" fontFamily="monospace" fontWeight="bold">
        VISTA EXPLODIDA TÉCNICA - CABEÇOTE DE PRESSÃO (KÄRCHER K 3.10)
      </text>
      <text x="30" y="65" fill="#cbd5e1" fontSize="11" fontFamily="monospace">
        BOMBA TRIPLEX AXIAL COM VÁLVULAS DE PRESSÃO E SUCÇÃO
      </text>

      {/* Upper Motor/Housing Inset - Pos 4 O-Ring Flange */}
      <g id="housing-inset" transform="translate(260, 40)">
        <ellipse cx="140" cy="90" rx="90" ry="45" fill="#f1f5f9" stroke="#334155" strokeWidth="2.5" strokeDasharray="4 2" />
        <ellipse cx="140" cy="90" rx="75" ry="38" fill="#ffffff" stroke="#475569" strokeWidth="1.5" />
        
        {/* Pos 4 - Large O-Ring 75.87 x 2.62 */}
        <ellipse cx="140" cy="90" rx="80" ry="40" fill="none" stroke="#0f172a" strokeWidth="5" />
        <text x="140" y="94" fill="#0f172a" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
          O&apos;RING 75,87 x 2,62 (Pos. 4)
        </text>

        {/* Flange Cutout detail circle */}
        <circle cx="50" cy="40" r="42" fill="#ffffff" stroke="#0284c7" strokeWidth="2" />
        <rect x="25" y="32" width="50" height="15" fill="url(#metalHatch)" stroke="#334155" strokeWidth="1.5" />
        <line x1="25" y1="47" x2="60" y2="47" stroke="#dc2626" strokeWidth="2" />
        <polygon points="60,47 52,43 52,51" fill="#dc2626" />
        <line x1="95" y1="40" x2="135" y2="70" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="2 2" />
      </g>

      {/* Explosion Leader Guidelines */}
      <g stroke="#94a3b8" strokeWidth="1.2" strokeDasharray="3 3">
        {/* Vertical lines to valve chambers */}
        <line x1="125" y1="230" x2="125" y2="340" />
        <line x1="165" y1="230" x2="165" y2="340" />
        <line x1="205" y1="230" x2="205" y2="340" />
        {/* Horizontal line to suction valves */}
        <line x1="240" y1="360" x2="330" y2="360" />
        {/* Bushing connection to pump body */}
        <line x1="390" y1="410" x2="480" y2="410" />
        {/* Packings lines */}
        <line x1="420" y1="470" x2="520" y2="470" />
        {/* Bolt alignment */}
        <line x1="120" y1="550" x2="220" y2="520" />
      </g>

      {/* POS 1: Conjunto Tampa Lateral Válvula */}
      <g id="pos-1-tampa-lateral" transform="translate(100, 220)">
        <rect x="10" y="5" width="30" height="16" rx="2" fill="#e2e8f0" stroke="#1e293b" strokeWidth="2" />
        <polygon points="15,5 25,0 35,5" fill="#cbd5e1" stroke="#1e293b" strokeWidth="1.5" />
        <line x1="15" y1="12" x2="35" y2="12" stroke="#64748b" strokeWidth="1.5" />
      </g>

      {/* POS 2: Válvula de Pressão */}
      <g id="pos-2-valvula-pressao" transform="translate(100, 265)">
        <rect x="12" y="5" width="26" height="24" rx="3" fill="#f8fafc" stroke="#1e293b" strokeWidth="2" />
        {/* Internal spring & cone */}
        <path d="M 17 12 Q 25 9 33 12 Q 25 18 17 22 Q 25 25 33 26" stroke="#0284c7" strokeWidth="2" fill="none" />
        <circle cx="25" cy="8" r="4" fill="#ef4444" />
      </g>

      {/* POS 3: Conjunto Tampa Central Válvula */}
      <g id="pos-3-tampa-central" transform="translate(170, 235)">
        <polygon points="10,12 25,2 40,12 35,26 15,26" fill="#e2e8f0" stroke="#1e293b" strokeWidth="2" />
        <circle cx="25" cy="14" r="5" fill="#94a3b8" />
        <rect x="22" y="26" width="6" height="16" fill="#cbd5e1" stroke="#1e293b" strokeWidth="1.5" />
      </g>

      {/* POS 9: CONJUNTO CABEÇOTE (Casting Body - Central Element) */}
      <g id="pos-9-cabecote" transform="translate(70, 340)">
        {/* Main Aluminum Block with 3 cylinder heads */}
        <rect x="20" y="20" width="160" height="120" rx="14" fill="#e2e8f0" stroke="#0f172a" strokeWidth="3" />
        {/* 3 Top Valve Ports */}
        <ellipse cx="50" cy="20" rx="18" ry="10" fill="#f1f5f9" stroke="#334155" strokeWidth="2" />
        <ellipse cx="100" cy="20" rx="18" ry="10" fill="#f1f5f9" stroke="#334155" strokeWidth="2" />
        <ellipse cx="150" cy="20" rx="18" ry="10" fill="#f1f5f9" stroke="#334155" strokeWidth="2" />
        {/* Front Cooling / Stiffener Ribs */}
        <rect x="40" y="50" width="20" height="60" rx="3" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        <rect x="90" y="50" width="20" height="60" rx="3" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        <rect x="140" y="50" width="20" height="60" rx="3" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        {/* Lower Bolt Hole */}
        <circle cx="35" cy="120" r="7" fill="#ffffff" stroke="#0f172a" strokeWidth="2" />
        <circle cx="165" cy="120" r="7" fill="#ffffff" stroke="#0f172a" strokeWidth="2" />
      </g>

      {/* POS 10: Parafuso M8 x 50 */}
      <g id="pos-10-parafuso" transform="translate(40, 520)">
        <polygon points="10,25 25,20 25,35 10,40" fill="#94a3b8" stroke="#1e293b" strokeWidth="2" />
        <rect x="25" y="22" width="70" height="12" rx="1" fill="#cbd5e1" stroke="#1e293b" strokeWidth="2" />
        {/* Threads */}
        <line x1="65" y1="22" x2="65" y2="34" stroke="#475569" strokeWidth="1.5" />
        <line x1="72" y1="22" x2="72" y2="34" stroke="#475569" strokeWidth="1.5" />
        <line x1="79" y1="22" x2="79" y2="34" stroke="#475569" strokeWidth="1.5" />
        <line x1="86" y1="22" x2="86" y2="34" stroke="#475569" strokeWidth="1.5" />
      </g>

      {/* POS 6, 6.1, 6.2: Válvula de Sucção e O-rings */}
      <g id="pos-6-sucao" transform="translate(320, 330)">
        <rect x="10" y="10" width="35" height="18" rx="4" fill="#f8fafc" stroke="#1e293b" strokeWidth="2" />
        {/* 6.1: O-Ring Maior */}
        <ellipse cx="20" cy="19" rx="5" ry="11" fill="none" stroke="#0f172a" strokeWidth="3" />
        {/* 6.2: O-Ring Menor */}
        <ellipse cx="32" cy="19" rx="4" ry="9" fill="none" stroke="#0f172a" strokeWidth="3" />
        <path d="M 45 19 L 55 19" stroke="#1e293b" strokeWidth="2" />
      </g>

      {/* Secondary Body / Rear Manifold (Direita) */}
      <g id="bloco-bomba-traseiro" transform="translate(460, 270)">
        {/* Cylindrical Inlets & Outlets */}
        <rect x="10" y="10" width="60" height="24" rx="4" fill="#cbd5e1" stroke="#1e293b" strokeWidth="2" transform="rotate(-20 10 10)" />
        <rect x="200" y="60" width="70" height="26" rx="4" fill="#cbd5e1" stroke="#1e293b" strokeWidth="2" />
        {/* Main Flange Body */}
        <path d="M 50 60 C 50 40, 190 40, 210 60 L 210 160 C 190 180, 50 180, 50 160 Z" fill="#e2e8f0" stroke="#0f172a" strokeWidth="2.5" />
        {/* 3 Plunger Bores */}
        <circle cx="80" cy="110" r="18" fill="#ffffff" stroke="#334155" strokeWidth="2" />
        <circle cx="130" cy="110" r="18" fill="#ffffff" stroke="#334155" strokeWidth="2" />
        <circle cx="180" cy="110" r="18" fill="#ffffff" stroke="#334155" strokeWidth="2" />
        {/* Internal Channel Ribs */}
        <line x1="80" y1="80" x2="180" y2="80" stroke="#64748b" strokeWidth="2" />
      </g>

      {/* POS 5 & 5.1: Bucha de Ligação e O-Ring */}
      <g id="pos-5-bucha" transform="translate(560, 390)">
        <rect x="10" y="5" width="22" height="16" rx="2" fill="#cbd5e1" stroke="#1e293b" strokeWidth="2" />
        {/* Pos 5.1 O-Ring */}
        <ellipse cx="21" cy="13" rx="3" ry="8" fill="none" stroke="#0f172a" strokeWidth="3" />
      </g>

      {/* POS 7: Guia da Gaxeta & POS 8: Gaxeta 20 x 12 x 5 */}
      <g id="pos-7-8-gaxeta" transform="translate(560, 460)">
        {/* Pos 7 Guia da Gaxeta */}
        <path d="M 50 5 L 65 0 L 65 24 L 50 19 Z" fill="#e2e8f0" stroke="#1e293b" strokeWidth="2" />
        <circle cx="58" cy="12" r="5" fill="#94a3b8" />
        {/* Pos 8 Gaxeta 20 x 12 x 5 */}
        <rect x="15" y="2" width="18" height="20" rx="3" fill="#1e293b" stroke="#0f172a" strokeWidth="1.5" />
        <rect x="18" y="5" width="12" height="14" fill="#475569" />
        <ellipse cx="24" cy="12" rx="4" ry="7" fill="#0f172a" />
      </g>
    </svg>
  );
}

// Technical Exploded Schematic for Kärcher K 3.10 Pistões, Guia, By-Pass e Conexões (matching photo 2)
function KarcherPistoesSvg({ 
  parts, 
  selectedPartId, 
  hoveredPartId 
}: { 
  parts: ExplodedPartItem[]; 
  selectedPartId: string | null; 
  hoveredPartId: string | null; 
}) {
  return (
    <svg 
      viewBox="0 0 920 660" 
      className="w-full h-full p-2 select-none"
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Background card */}
      <rect x="10" y="10" width="900" height="640" rx="8" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.5" />
      
      {/* Title Watermark */}
      <text x="30" y="42" fill="#94a3b8" fontSize="14" fontFamily="monospace" fontWeight="bold">
        VISTA EXPLODIDA TÉCNICA - GUIA DE PISTÕES, BY-PASS &amp; ENGATE (KÄRCHER K 3.10)
      </text>
      <text x="30" y="62" fill="#cbd5e1" fontSize="11" fontFamily="monospace">
        CONJUNTO DO PISTÃO AXIAL, VÁLVULA DE RETENÇÃO, ALÍVIO E FILTRO DE SUCÇÃO
      </text>

      {/* Exploded Guideline Axes */}
      <g stroke="#94a3b8" strokeWidth="1.2" strokeDasharray="3 3">
        {/* Top-left to body: Retenção/química */}
        <line x1="80" y1="120" x2="190" y2="180" />
        {/* Piston & Spring axial line */}
        <line x1="560" y1="180" x2="280" y2="280" />
        {/* Vertical By-pass line */}
        <line x1="200" y1="360" x2="200" y2="560" />
        {/* Filter and quick coupler line */}
        <line x1="430" y1="320" x2="680" y2="440" />
      </g>

      {/* POS 1 & POS 2: Guia de Pistões Pré-Montado & Válvula de Retenção Cpl */}
      <g id="pos-1-2-retencao" transform="translate(60, 90)">
        {/* Spring & guide assembly */}
        <polygon points="10,18 22,8 22,28" fill="#cbd5e1" stroke="#1e293b" strokeWidth="2" />
        <path d="M 22 18 Q 30 10 38 18 Q 46 26 54 18 Q 62 10 70 18" stroke="#0284c7" strokeWidth="2.5" fill="none" />
        <rect x="70" y="10" width="22" height="16" rx="3" fill="#e2e8f0" stroke="#1e293b" strokeWidth="2" />
        <ellipse cx="92" cy="18" rx="4" ry="8" fill="#334155" />
      </g>

      {/* POS 3: MOLA DO PISTÃO */}
      <g id="pos-3-mola" transform="translate(420, 160)">
        <path 
          d="M 10 30 Q 25 10 40 30 Q 55 50 70 30 Q 85 10 100 30 Q 115 50 130 30 Q 145 10 160 30" 
          stroke="#475569" 
          strokeWidth="6" 
          strokeLinecap="round"
          fill="none" 
        />
        <text x="85" y="65" fill="#475569" fontSize="10" fontFamily="monospace" fontWeight="bold">MOLA HELICOIDAL</text>
      </g>

      {/* POS 4: PISTÃO COMPLETO (Stainless Steel Plunger) */}
      <g id="pos-4-pistao" transform="translate(600, 90)">
        {/* Back Thrust Plate */}
        <ellipse cx="140" cy="35" rx="14" ry="24" fill="#cbd5e1" stroke="#1e293b" strokeWidth="2.5" />
        <ellipse cx="140" cy="35" rx="6" ry="10" fill="#94a3b8" stroke="#1e293b" strokeWidth="1.5" />
        {/* Plunger Shaft */}
        <rect x="15" y="24" width="115" height="22" rx="11" fill="#f1f5f9" stroke="#0f172a" strokeWidth="3" />
        {/* Polished Chrome Highlight line */}
        <line x1="25" y1="28" x2="120" y2="28" stroke="#ffffff" strokeWidth="2.5" />
        <line x1="25" y1="38" x2="120" y2="38" stroke="#cbd5e1" strokeWidth="2" />
      </g>

      {/* CENTRAL MANIFOLD BODY (Cabeçote Intermediário) */}
      <g id="corpo-central-interm" transform="translate(200, 200)">
        {/* Water Inlet Port */}
        <rect x="0" y="10" width="80" height="30" rx="6" fill="#cbd5e1" stroke="#1e293b" strokeWidth="2.5" transform="rotate(-20 0 10)" />
        {/* Central Hydraulic Housing */}
        <path d="M 50 40 C 50 20, 220 20, 240 40 L 240 180 C 220 200, 50 200, 50 180 Z" fill="#e2e8f0" stroke="#0f172a" strokeWidth="3" />
        {/* Internal Valve Chambers */}
        <circle cx="85" cy="110" r="22" fill="#ffffff" stroke="#334155" strokeWidth="2.5" />
        <circle cx="145" cy="110" r="22" fill="#ffffff" stroke="#334155" strokeWidth="2.5" />
        <circle cx="205" cy="110" r="22" fill="#ffffff" stroke="#334155" strokeWidth="2.5" />
        {/* Outlet Neck */}
        <rect x="235" y="100" width="60" height="34" rx="4" fill="#cbd5e1" stroke="#0f172a" strokeWidth="2.5" />
        <line x1="260" y1="100" x2="260" y2="134" stroke="#475569" strokeWidth="2" />
      </g>

      {/* POS 5: ANEL RASPADOR 12 X 20 X 4/6 */}
      <g id="pos-5-raspador" transform="translate(180, 280)">
        <ellipse cx="25" cy="25" rx="20" ry="14" fill="#0f172a" stroke="#1e293b" strokeWidth="2" />
        <ellipse cx="25" cy="25" rx="12" ry="8" fill="#f8fafc" stroke="#1e293b" strokeWidth="1.5" />
      </g>

      {/* POS 6, 6.1, 6.2: VÁLVULA COMPLETA & O-RINGS */}
      <g id="pos-6-valvula-cpl" transform="translate(180, 390)">
        <rect x="15" y="5" width="22" height="32" rx="4" fill="#f8fafc" stroke="#0f172a" strokeWidth="2" />
        {/* 6.1 O-Ring Maior */}
        <ellipse cx="26" cy="18" rx="14" ry="5" fill="none" stroke="#0f172a" strokeWidth="3.5" />
        {/* 6.2 O-Ring Menor */}
        <ellipse cx="26" cy="28" rx="10" ry="4" fill="none" stroke="#0f172a" strokeWidth="3.5" />
        <circle cx="26" cy="10" r="4" fill="#dc2626" />
      </g>

      {/* POS 7, 8, 9: VÁLVULA BY-PASS & O-RINGS */}
      <g id="pos-7-bypass" transform="translate(160, 480)">
        {/* Pos 8 O-Ring */}
        <ellipse cx="45" cy="10" rx="18" ry="6" fill="none" stroke="#0f172a" strokeWidth="3.5" />
        {/* Pos 9 O-Ring */}
        <ellipse cx="45" cy="22" rx="15" ry="5" fill="none" stroke="#0f172a" strokeWidth="3.5" />
        {/* Valve Cartridge Body */}
        <rect x="25" y="32" width="40" height="50" rx="8" fill="#e2e8f0" stroke="#0f172a" strokeWidth="2.5" />
        <polygon points="35,82 45,95 55,82" fill="#cbd5e1" stroke="#0f172a" strokeWidth="2" />
        <line x1="30" y1="50" x2="60" y2="50" stroke="#64748b" strokeWidth="2" />
      </g>

      {/* POS 10: FILTRO MICRA 90 */}
      <g id="pos-10-filtro" transform="translate(520, 310)">
        {/* Hex brass nut connector */}
        <polygon points="10,20 22,12 34,20 34,36 22,44 10,36" fill="#fef08a" stroke="#ca8a04" strokeWidth="2" />
        {/* Conical mesh filter */}
        <polygon points="34,16 80,24 80,32 34,40" fill="#f8fafc" stroke="#0284c7" strokeWidth="2" strokeDasharray="3 1" />
        <line x1="45" y1="18" x2="45" y2="38" stroke="#94a3b8" strokeWidth="1" />
        <line x1="58" y1="20" x2="58" y2="36" stroke="#94a3b8" strokeWidth="1" />
        <line x1="70" y1="22" x2="70" y2="34" stroke="#94a3b8" strokeWidth="1" />
      </g>

      {/* POS 11: ENGATE RÁPIDO DE 3/4 */}
      <g id="pos-11-engate" transform="translate(640, 360)">
        {/* Outer Quick-coupling collar */}
        <rect x="60" y="20" width="70" height="55" rx="14" fill="#f1f5f9" stroke="#0f172a" strokeWidth="3" />
        {/* Grip indents / Dimples */}
        <circle cx="80" cy="35" r="5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        <circle cx="95" cy="35" r="5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        <circle cx="110" cy="35" r="5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        <circle cx="80" cy="55" r="5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        <circle cx="95" cy="55" r="5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        <circle cx="110" cy="55" r="5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
        {/* Inner threaded brass stem */}
        <rect x="15" y="32" width="45" height="30" rx="3" fill="#fef08a" stroke="#ca8a04" strokeWidth="2.5" />
        <ellipse cx="15" cy="47" rx="6" ry="15" fill="#eab308" />
      </g>
    </svg>
  );
}

// Technical Exploded Schematic for Industrial Triplex Pump (HD 585)
function BombaTriplexSvg({ 
  parts, 
  selectedPartId, 
  hoveredPartId 
}: { 
  parts: ExplodedPartItem[]; 
  selectedPartId: string | null; 
  hoveredPartId: string | null; 
}) {
  return (
    <svg viewBox="0 0 900 600" className="w-full h-full p-2 select-none" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="10" width="880" height="580" rx="8" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.5" />
      <text x="30" y="45" fill="#94a3b8" fontSize="14" fontFamily="monospace" fontWeight="bold">
        CABEÇOTE FORJADO EM LATÃO - BOMBA TRIPLEX INDUSTRIAL (KÄRCHER HD 585)
      </text>
      
      {/* 3 Upper Valves (Pressure) */}
      {[180, 360, 540].map((cx, i) => (
        <g key={`valv-p-${i}`} transform={`translate(${cx}, 100)`}>
          <rect x="-25" y="0" width="50" height="40" rx="4" fill="#fef08a" stroke="#ca8a04" strokeWidth="2" />
          <ellipse cx="0" cy="40" rx="20" ry="6" fill="none" stroke="#0f172a" strokeWidth="3" />
          <line x1="0" y1="40" x2="0" y2="120" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="3 3" />
        </g>
      ))}

      {/* Brass Forged Manifold Block */}
      <g transform="translate(120, 220)">
        <rect x="0" y="0" width="540" height="150" rx="16" fill="#fef9c3" stroke="#ca8a04" strokeWidth="3.5" />
        {[60, 240, 420].map((cx, idx) => (
          <g key={`valve-chamber-${idx}`}>
            <circle cx={cx} cy="45" r="28" fill="#ffffff" stroke="#a16207" strokeWidth="2" />
            <circle cx={cx} cy="105" r="24" fill="#ffffff" stroke="#a16207" strokeWidth="2" />
          </g>
        ))}
        {/* Water Inlet & Outlet Ports */}
        <rect x="-40" y="80" width="40" height="40" rx="6" fill="#fef08a" stroke="#ca8a04" strokeWidth="2.5" />
        <rect x="540" y="30" width="45" height="35" rx="6" fill="#fef08a" stroke="#ca8a04" strokeWidth="2.5" />
      </g>

      {/* 3 Lower Packings & Plungers */}
      {[180, 360, 540].map((cx, i) => (
        <g key={`plunger-${i}`} transform={`translate(${cx}, 390)`}>
          <rect x="-18" y="0" width="36" height="24" rx="3" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
          <rect x="-12" y="30" width="24" height="80" rx="4" fill="#f1f5f9" stroke="#334155" strokeWidth="2" />
          <text x="0" y="130" fill="#64748b" fontSize="10" textAnchor="middle" fontFamily="monospace">PISTÃO {i + 1}</text>
        </g>
      ))}
    </svg>
  );
}

// Technical Exploded Schematic for Industrial Hydraulic Cylinder
function CilindroHidraulicoSvg({ 
  parts, 
  selectedPartId, 
  hoveredPartId 
}: { 
  parts: ExplodedPartItem[]; 
  selectedPartId: string | null; 
  hoveredPartId: string | null; 
}) {
  return (
    <svg viewBox="0 0 900 550" className="w-full h-full p-2 select-none" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="10" width="880" height="530" rx="8" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.5" />
      <text x="30" y="45" fill="#94a3b8" fontSize="14" fontFamily="monospace" fontWeight="bold">
        VISTA EXPLODIDA - CILINDRO HIDRÁULICO INDUSTRIAL DUPLA AÇÃO (100T)
      </text>

      {/* Central Explosion Axis */}
      <line x1="50" y1="270" x2="850" y2="270" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="5 3" />

      {/* POS 1: Haste de Cromo Duro */}
      <g transform="translate(60, 230)">
        <rect x="0" y="10" width="180" height="60" rx="8" fill="#f1f5f9" stroke="#0f172a" strokeWidth="3" />
        <circle cx="20" cy="40" r="12" fill="#cbd5e1" stroke="#0f172a" strokeWidth="2" />
        <line x1="40" y1="20" x2="170" y2="20" stroke="#ffffff" strokeWidth="3" />
      </g>

      {/* POS 2: Anel Raspador & Guia */}
      <g transform="translate(270, 220)">
        <rect x="0" y="5" width="25" height="70" rx="4" fill="#0284c7" stroke="#0369a1" strokeWidth="2" />
        <polygon points="12,5 25,20 12,35" fill="#38bdf8" />
      </g>

      {/* POS 3: Gaxeta Chevron / Selos */}
      <g transform="translate(330, 210)">
        <rect x="0" y="0" width="35" height="90" rx="4" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
        <path d="M 10 20 L 25 35 L 10 50 L 25 65" stroke="#94a3b8" strokeWidth="2" fill="none" />
      </g>

      {/* POS 4: Êmbolo / Pistão */}
      <g transform="translate(420, 190)">
        <rect x="0" y="0" width="70" height="130" rx="8" fill="#cbd5e1" stroke="#0f172a" strokeWidth="3" />
        {/* Wear rings */}
        <rect x="10" y="10" width="12" height="110" fill="#d97706" />
        <rect x="48" y="10" width="12" height="110" fill="#d97706" />
      </g>

      {/* POS 5: Camisa Brunida do Cilindro */}
      <g transform="translate(560, 160)">
        <rect x="0" y="0" width="240" height="190" rx="12" fill="#e2e8f0" stroke="#0f172a" strokeWidth="3" />
        {/* Oil Ports */}
        <rect x="30" y="-20" width="25" height="20" fill="#94a3b8" stroke="#0f172a" strokeWidth="2" />
        <rect x="180" y="-20" width="25" height="20" fill="#94a3b8" stroke="#0f172a" strokeWidth="2" />
      </g>
    </svg>
  );
}
