import React, { useState, useEffect, useRef } from 'react';
import { Client, Equipment } from '../types';
import { 
  Cpu, X, User, Tag, Layers, Wrench, 
  Check, AlertCircle, Sparkles, Keyboard, Plus, Building2
} from 'lucide-react';

interface QuickNewEquipmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: Client[];
  onSaveEquipment: (equipData: Omit<Equipment, 'id' | 'createdAt'>) => Equipment;
  onEquipmentCreated?: (newEquip: Equipment) => void;
  initialClientId?: string;
}

const EQUIPMENT_TYPES = [
  'Cilindro Hidráulico',
  'Cilindro Pneumático',
  'Unidade Hidráulica',
  'Bomba Hidráulica de Pistões',
  'Bomba Hidráulica de Engrenagens',
  'Bomba Hidráulica de Palhetas',
  'Motor Hidráulico Orbital',
  'Válvula Direcional / Proporcional',
  'Bloco Manifold Hidráulico',
  'Prensa Hidráulica',
  'Lavadora de Alta Pressão',
  'Redutor Planetário',
  'Torno / Fresadora / Maquinário',
  'Compressor de Ar',
  'Outros'
];

export default function QuickNewEquipmentModal({
  isOpen,
  onClose,
  clients,
  onSaveEquipment,
  onEquipmentCreated,
  initialClientId = ''
}: QuickNewEquipmentModalProps) {
  const [clientId, setClientId] = useState(initialClientId);
  const [name, setName] = useState('');
  const [model, setModel] = useState('');
  const [type, setType] = useState('Cilindro Hidráulico');
  const [patrimonyNumber, setPatrimonyNumber] = useState('');
  const [error, setError] = useState('');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const nameInputRef = useRef<HTMLInputElement>(null);

  // Sync initialClientId & reset on open
  useEffect(() => {
    if (isOpen) {
      setClientId(initialClientId || (clients.length > 0 ? clients[0].id : ''));
      setName('');
      setModel('');
      setType('Cilindro Hidráulico');
      setPatrimonyNumber('');
      setError('');
      setSuccessNotice(null);

      setTimeout(() => {
        nameInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, initialClientId, clients]);

  // Esc key closes modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanName = name.trim();
    const cleanModel = model.trim();
    const cleanType = type.trim() || 'Equipamento Geral';

    if (!clientId) {
      setError('Por favor, selecione o Cliente proprietário do equipamento.');
      return;
    }

    if (!cleanName) {
      setError('Por favor, informe a Identificação ou Nome do equipamento.');
      nameInputRef.current?.focus();
      return;
    }

    try {
      const created = onSaveEquipment({
        clientId,
        name: cleanName,
        model: cleanModel || 'Modelo Padrão',
        type: cleanType,
        patrimonyNumber: patrimonyNumber.trim() || undefined
      });

      setSuccessNotice(`Equipamento "${created.name}" cadastrado com sucesso!`);

      setTimeout(() => {
        if (onEquipmentCreated) {
          onEquipmentCreated(created);
        }
        onClose();
      }, 600);
    } catch (err: any) {
      setError(err?.message || 'Ocorreu um erro ao cadastrar o equipamento.');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[70] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      id="quick-new-equipment-backdrop"
    >
      <div 
        className="bg-white border-2 border-slate-400 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col my-6 animate-in fade-in zoom-in-95 duration-150"
        id="quick-new-equipment-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-quick-equipment-title"
      >
        {/* Header */}
        <div className="bg-[#1b365d] text-white px-5 py-3.5 flex items-center justify-between border-b border-blue-900">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="modal-quick-equipment-title" className="text-sm sm:text-base font-black uppercase tracking-wider text-white">
                  Cadastro de Novo Equipamento
                </h3>
                <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-800 text-cyan-200 border border-blue-700 text-[10px] font-mono font-black">
                  <Keyboard className="w-3 h-3" />
                  <span>F4</span>
                </span>
              </div>
              <p className="text-[11px] text-cyan-200 mt-0.5">
                Cadastre a máquina ou maquinário vinculado à frota do cliente
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-close-quick-equipment-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg text-cyan-200 hover:text-white hover:bg-blue-800 transition-colors cursor-pointer"
            title="Fechar (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 bg-slate-50 text-xs">
          {error && (
            <div className="p-3 bg-red-50 border border-red-300 rounded-xl flex items-center gap-2.5 text-red-700 font-bold">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center gap-2.5 text-emerald-800 font-bold animate-pulse">
              <Check className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successNotice}</span>
            </div>
          )}

          {/* Cliente Proprietário */}
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
              <User className="w-3 h-3 text-blue-900" />
              <span>Cliente Proprietário / Solicitante <span className="text-red-500">*</span></span>
            </label>
            <select
              id="select-quick-equipment-client"
              required
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 shadow-inner cursor-pointer"
            >
              <option value="">-- Selecione o Cliente --</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.document ? `(${c.document})` : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Nome / Identificação do Equipamento */}
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1">
              Nome ou Descrição do Equipamento <span className="text-red-500">*</span>
            </label>
            <input
              ref={nameInputRef}
              id="input-quick-equipment-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Cilindro Hidráulico Principal de Basculamento 200mm"
              className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 shadow-inner"
            />
          </div>

          {/* Tipo / Categoria & Modelo */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                <Layers className="w-3 h-3 text-indigo-600" />
                <span>Tipo / Família do Equipamento</span>
              </label>
              <select
                id="select-quick-equipment-type"
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 shadow-inner cursor-pointer"
              >
                {EQUIPMENT_TYPES.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                <Wrench className="w-3 h-3 text-slate-600" />
                <span>Modelo / Fabricante</span>
              </label>
              <input
                id="input-quick-equipment-model"
                type="text"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="Ex: Parker HMI 125/90 ou Rexroth"
                className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 shadow-inner"
              />
            </div>
          </div>

          {/* Número de Patrimônio / Tag / Série */}
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
              <Tag className="w-3 h-3 text-amber-600" />
              <span>Número de Série / Tag / Patrimônio</span>
            </label>
            <input
              id="input-quick-equipment-patrimony"
              type="text"
              value={patrimonyNumber}
              onChange={(e) => setPatrimonyNumber(e.target.value)}
              placeholder="Ex: PAT-CIL-024 ou SN-2026-981"
              className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 shadow-inner uppercase"
            />
          </div>

          {/* Hint */}
          <div className="p-2.5 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between text-[10px] text-blue-900 font-medium">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>O equipamento ficará pronto para novas OS, Check-In e Orçamentos.</span>
            </span>
            <span className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-blue-200 text-blue-800 hidden sm:inline">
              Enter = Salvar
            </span>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
            <button
              type="button"
              id="btn-cancel-quick-equipment"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs uppercase cursor-pointer transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              id="btn-save-quick-equipment"
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition-all cursor-pointer flex items-center gap-2"
            >
              <Plus className="w-4 h-4 text-slate-950" />
              <span>Salvar Equipamento</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
