import React, { useState, useMemo } from 'react';
import { Client, Equipment, ServiceOrder, PostMaintenanceFeedback, PostMaintenanceStatus, EquipmentSourceType, Technician } from '../types';
import { formatPhoneNumber } from '../utils/phoneFormatter';
import { 
  Star, MessageSquare, Send, CheckCircle2, AlertTriangle, ShieldAlert, Phone, Calendar, 
  User, Cpu, FileText, Search, Plus, Filter, RefreshCw, BarChart3, ThumbsUp, Wrench, 
  Clock, Trash2, Edit2, ExternalLink, Printer, Award, ArrowUpRight, Sparkles, X, Check, Briefcase
} from 'lucide-react';

interface PostMaintenanceManagerProps {
  feedbacks: PostMaintenanceFeedback[];
  orders: ServiceOrder[];
  clients: Client[];
  equipments: Equipment[];
  technicians?: Technician[];
  onAddFeedback: (feedback: Omit<PostMaintenanceFeedback, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateFeedback: (feedback: PostMaintenanceFeedback) => void;
  onDeleteFeedback: (id: string) => void;
  setActiveTab?: (tab: any) => void;
}

export default function PostMaintenanceManager({
  feedbacks,
  orders,
  clients,
  equipments,
  technicians = [],
  onAddFeedback,
  onUpdateFeedback,
  onDeleteFeedback,
  setActiveTab
}: PostMaintenanceManagerProps) {
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingFeedback, setEditingFeedback] = useState<PostMaintenanceFeedback | null>(null);

  // Form states
  const [selectedOSId, setSelectedOSId] = useState('');
  const [clientId, setClientId] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [equipmentId, setEquipmentId] = useState('');
  const [equipmentName, setEquipmentName] = useState('');
  const [sourceType, setSourceType] = useState<EquipmentSourceType>('REPAIRED');
  const [osNumber, setOsNumber] = useState('');
  const [deliveryDate, setDeliveryDate] = useState(new Date().toISOString().split('T')[0]);
  const [contactDate, setContactDate] = useState(new Date().toISOString().split('T')[0]);
  const [status, setStatus] = useState<PostMaintenanceStatus>('PENDING_CONTACT');
  const [rating, setRating] = useState<number>(5);
  const [performanceStatus, setPerformanceStatus] = useState<'EXCELLENT' | 'OPERATING_NORMAL' | 'MINOR_ADJUSTMENT' | 'NEEDS_INSPECTION' | 'CRITICAL_DEFECT'>('EXCELLENT');
  const [feedbackNotes, setFeedbackNotes] = useState('');
  const [technicianNotes, setTechnicianNotes] = useState('');
  const [npsScore, setNpsScore] = useState<number | undefined>(10);
  const [contactedBy, setContactedBy] = useState('');
  const [nextFollowUpDate, setNextFollowUpDate] = useState('');

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [sourceFilter, setSourceFilter] = useState<string>('ALL');

  // Quick feedback notification toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Completed / Delivered Service Orders for quick import
  const completedOrders = useMemo(() => {
    return orders.filter(o => o.status === 'COMPLETED' || o.isDelivered);
  }, [orders]);

  // Handle OS Auto-fill in form
  const handleSelectOS = (osId: string) => {
    setSelectedOSId(osId);
    const os = orders.find(o => o.id === osId);
    if (os) {
      const cli = clients.find(c => c.id === os.clientId);
      const eq = equipments.find(e => e.id === os.equipmentId);
      
      setClientId(os.clientId);
      setClientName(cli?.name || 'Cliente Indefinido');
      setClientPhone(cli?.phone || '');
      setEquipmentId(os.equipmentId);
      setEquipmentName(eq?.name ? `${eq.name} (${eq.model})` : os.title);
      setOsNumber(os.osNumber);
      setSourceType('REPAIRED');
      if (os.deliveryDate) {
        setDeliveryDate(os.deliveryDate);
      } else if (os.endDate) {
        setDeliveryDate(os.endDate);
      }
    }
  };

  const handleOpenAddModal = () => {
    setEditingFeedback(null);
    setSelectedOSId('');
    setClientId('');
    setClientName('');
    setClientPhone('');
    setEquipmentId('');
    setEquipmentName('');
    setSourceType('REPAIRED');
    setOsNumber('');
    setDeliveryDate(new Date().toISOString().split('T')[0]);
    setContactDate(new Date().toISOString().split('T')[0]);
    setStatus('PENDING_CONTACT');
    setRating(5);
    setPerformanceStatus('EXCELLENT');
    setFeedbackNotes('');
    setTechnicianNotes('');
    setNpsScore(10);
    setContactedBy('');
    setNextFollowUpDate('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (fb: PostMaintenanceFeedback) => {
    setEditingFeedback(fb);
    setSelectedOSId(fb.serviceOrderId || '');
    setClientId(fb.clientId);
    setClientName(fb.clientName);
    setClientPhone(fb.clientPhone);
    setEquipmentId(fb.equipmentId || '');
    setEquipmentName(fb.equipmentName);
    setSourceType(fb.sourceType || 'REPAIRED');
    setOsNumber(fb.osNumber || '');
    setDeliveryDate(fb.deliveryDate || '');
    setContactDate(fb.contactDate || new Date().toISOString().split('T')[0]);
    setStatus(fb.status);
    setRating(fb.rating || 5);
    setPerformanceStatus(fb.performanceStatus || 'EXCELLENT');
    setFeedbackNotes(fb.feedbackNotes || '');
    setTechnicianNotes(fb.technicianNotes || '');
    setNpsScore(fb.npsScore);
    setContactedBy(fb.contactedBy || '');
    setNextFollowUpDate(fb.nextFollowUpDate || '');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!clientName.trim()) {
      alert('Por favor, informe o nome do cliente.');
      return;
    }

    if (!equipmentName.trim()) {
      alert('Por favor, informe o equipamento consertado ou vendido.');
      return;
    }

    if (editingFeedback) {
      const updated: PostMaintenanceFeedback = {
        ...editingFeedback,
        serviceOrderId: selectedOSId || undefined,
        osNumber: osNumber || undefined,
        clientId: clientId || `cli-${Date.now()}`,
        clientName,
        clientPhone,
        equipmentId: equipmentId || undefined,
        equipmentName,
        sourceType,
        deliveryDate,
        contactDate,
        status,
        rating,
        performanceStatus,
        feedbackNotes,
        technicianNotes,
        npsScore,
        contactedBy,
        nextFollowUpDate,
        updatedAt: new Date().toISOString()
      };
      onUpdateFeedback(updated);
      showToast(`Aferição de qualidade de ${clientName} atualizada com sucesso!`);
    } else {
      onAddFeedback({
        serviceOrderId: selectedOSId || undefined,
        osNumber: osNumber || undefined,
        clientId: clientId || `cli-${Date.now()}`,
        clientName,
        clientPhone,
        equipmentId: equipmentId || undefined,
        equipmentName,
        sourceType,
        deliveryDate,
        contactDate,
        status,
        rating,
        performanceStatus,
        feedbackNotes,
        technicianNotes,
        npsScore,
        contactedBy,
        nextFollowUpDate
      });
      showToast(`Aferição pós-manutenção registrada com sucesso!`);
    }

    setIsModalOpen(false);
  };

  // WhatsApp Message Generator
  const generateWhatsAppLink = (fb: PostMaintenanceFeedback) => {
    const rawPhone = fb.clientPhone.replace(/\D/g, '');
    const phone = rawPhone.length <= 11 && !rawPhone.startsWith('55') ? `55${rawPhone}` : rawPhone;
    
    const isSold = fb.sourceType === 'SOLD';
    const sourceText = isSold ? 'adquirido/fornecido' : 'reparado/revisado';

    const text = `Olá *${fb.clientName}*, tudo bem? Aqui é do Controle de Qualidade da *JC&F Manutenção Hidráulica e Pneumática*! 🔧⚙️\n\n` +
      `Gostaríamos de saber como está o desempenho do equipamento *${fb.equipmentName}* (${fb.osNumber ? `OS: ${fb.osNumber}` : 'Equipamento'} entregue em ${new Date((fb.deliveryDate || '') + 'T12:00:00').toLocaleDateString('pt-BR')}) que foi ${sourceText} por nossa equipe.\n\n` +
      `• A pressão e estanqueidade estão operando conforme esperado?\n` +
      `• Notou algum ruído, vazamento ou necessidade de ajuste fino?\n` +
      `• Como avalia o serviço e atendimento da nossa empresa de 1 a 5 estrelas?\n\n` +
      `Sua opinião e aferição são fundamentais para mantermos o nosso padrão de excelência técnica! Muito obrigado pela parceria! 🙌`;

    return `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
  };

  // Filtered Feedbacks
  const filteredFeedbacks = useMemo(() => {
    return feedbacks.filter(fb => {
      const matchesSearch = !searchTerm || 
        fb.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        fb.equipmentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (fb.osNumber && fb.osNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (fb.feedbackNotes && fb.feedbackNotes.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesStatus = statusFilter === 'ALL' || fb.status === statusFilter;
      const matchesSource = sourceFilter === 'ALL' || fb.sourceType === sourceFilter;

      return matchesSearch && matchesStatus && matchesSource;
    });
  }, [feedbacks, searchTerm, statusFilter, sourceFilter]);

  // High Level Quality Analytics Metrics
  const metrics = useMemo(() => {
    const total = feedbacks.length;
    if (total === 0) {
      return { total: 0, avgRating: 0, qualityRate: 0, avgNps: 0, pendingCount: 0, adjustmentCount: 0 };
    }

    const ratedFeedbacks = feedbacks.filter(f => f.rating > 0);
    const avgRating = ratedFeedbacks.length > 0
      ? (ratedFeedbacks.reduce((acc, f) => acc + f.rating, 0) / ratedFeedbacks.length).toFixed(1)
      : '5.0';

    const excellentCount = feedbacks.filter(f => f.performanceStatus === 'EXCELLENT' || f.performanceStatus === 'OPERATING_NORMAL').length;
    const qualityRate = Math.round((excellentCount / total) * 100);

    const npsFeedbacks = feedbacks.filter(f => f.npsScore !== undefined && f.npsScore !== null);
    const avgNps = npsFeedbacks.length > 0
      ? (npsFeedbacks.reduce((acc, f) => acc + (f.npsScore || 0), 0) / npsFeedbacks.length).toFixed(1)
      : '9.8';

    const pendingCount = feedbacks.filter(f => f.status === 'PENDING_CONTACT').length;
    const adjustmentCount = feedbacks.filter(f => f.performanceStatus === 'MINOR_ADJUSTMENT' || f.performanceStatus === 'NEEDS_INSPECTION' || f.performanceStatus === 'CRITICAL_DEFECT').length;

    return {
      total,
      avgRating,
      qualityRate,
      avgNps,
      pendingCount,
      adjustmentCount
    };
  }, [feedbacks]);

  return (
    <div className="space-y-4" id="post-maintenance-manager-container">
      
      {/* Toast notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-600 text-white px-4 py-3 rounded-xl shadow-2xl border border-emerald-400 flex items-center gap-2 text-xs font-extrabold animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-200" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm">
        <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-blue-900">
          <div className="flex items-center gap-3">
            <span className="p-2 bg-white/10 rounded-lg border border-white/20 text-cyan-300 shadow-sm">
              <Award className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-sm sm:text-base font-black text-white tracking-wide uppercase">
                Pós-Manutenção & Aferição de Qualidade
              </h1>
              <p className="text-xs text-cyan-100">
                Acompanhamento de desempenho pós-entrega, satisfação do cliente e controle de qualidade operacional
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => window.print()}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 text-xs font-bold rounded-lg transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Printer className="w-4 h-4 text-cyan-300" />
              <span className="hidden sm:inline">Imprimir Relatório</span>
            </button>

            <button
              type="button"
              onClick={handleOpenAddModal}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider rounded-lg transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Nova Aferição Pós-Manutenção</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quality Analytics Dashboard Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3" id="post-maint-metrics-grid">
        
        {/* Metric 1: Quality Rate */}
        <div className="bg-white p-4 rounded-xl border-2 border-[#b0bec5] shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Índice de Qualidade</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-emerald-700 font-mono">{metrics.qualityRate}%</span>
              <span className="text-[10px] text-emerald-600 font-bold">100% Ok / Normal</span>
            </div>
            <span className="text-[9px] text-slate-500 block">Aferidos em pleno funcionamento</span>
          </div>
          <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-700">
            <ThumbsUp className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 2: Average Rating */}
        <div className="bg-white p-4 rounded-xl border-2 border-[#b0bec5] shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Média de Satisfação</span>
            <div className="flex items-center gap-1.5">
              <span className="text-2xl font-black text-amber-600 font-mono">{metrics.avgRating}</span>
              <div className="flex text-amber-500">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className="w-3.5 h-3.5 fill-amber-500 stroke-amber-500" />
                ))}
              </div>
            </div>
            <span className="text-[9px] text-slate-500 block">Nota média dada pelos clientes</span>
          </div>
          <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-amber-600">
            <Star className="w-6 h-6 fill-amber-500" />
          </div>
        </div>

        {/* Metric 3: NPS Score */}
        <div className="bg-white p-4 rounded-xl border-2 border-[#b0bec5] shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">NPS Médio (Recomendação)</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-[#003b7a] font-mono">{metrics.avgNps}</span>
              <span className="text-[10px] text-blue-700 font-bold">/ 10</span>
            </div>
            <span className="text-[9px] text-slate-500 block">Zona de Excelência Comercial</span>
          </div>
          <div className="p-2.5 bg-blue-50 rounded-xl border border-blue-200 text-[#003b7a]">
            <BarChart3 className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 4: Adjustments & Attention needed */}
        <div className="bg-white p-4 rounded-xl border-2 border-[#b0bec5] shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Requerem Ajuste / Vistoria</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-amber-600 font-mono">{metrics.adjustmentCount}</span>
              <span className="text-[10px] text-slate-600 font-bold">de {metrics.total} máquinas</span>
            </div>
            <span className="text-[9px] text-slate-500 block">Ajustes finos em campo agendados</span>
          </div>
          <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-amber-600">
            <Wrench className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3.5 rounded-xl border-2 border-[#b0bec5] shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar cliente, equipamento ou OS..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 font-medium"
          />
        </div>

        {/* Filter Dropdowns */}
        <div className="flex items-center gap-3 w-full md:w-auto overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          <div className="flex items-center gap-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-black text-slate-600 uppercase tracking-wider">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-white border border-slate-300 text-xs text-slate-800 rounded-lg px-2.5 py-1.5 focus:outline-hidden focus:border-blue-600 font-bold"
            >
              <option value="ALL">Todos os Status</option>
              <option value="PENDING_CONTACT">Aguardando Contato</option>
              <option value="CONTACTED">Pesquisa Enviada</option>
              <option value="EXCELLENT">Desempenho Excelente</option>
              <option value="NEEDS_ADJUSTMENT">Requer Ajuste/Vistoria</option>
              <option value="WARRANTY_CLAIM">Acionou Garantia</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-[10px] font-black text-slate-600 uppercase tracking-wider">Origem:</span>
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="bg-white border border-slate-300 text-xs text-slate-800 rounded-lg px-2.5 py-1.5 focus:outline-hidden focus:border-blue-600 font-bold"
            >
              <option value="ALL">Todas as Origens</option>
              <option value="REPAIRED">Equipamento Consertado (Manutenção)</option>
              <option value="SOLD">Equipamento Vendido (Venda)</option>
            </select>
          </div>
        </div>

      </div>

      {/* Feedbacks Grid List */}
      <div className="space-y-3" id="post-maintenance-feedbacks-list">
        {filteredFeedbacks.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border-2 border-dashed border-slate-300 p-8 space-y-3">
            <Award className="w-10 h-10 text-slate-400 mx-auto" />
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-slate-700">Nenhum registro de pós-manutenção encontrado</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Registre o acompanhamento dos equipamentos entregues para acompanhar a satisfação e qualidade técnica.
              </p>
            </div>
            <button
              type="button"
              onClick={handleOpenAddModal}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Criar Aferição de Qualidade</span>
            </button>
          </div>
        ) : (
          filteredFeedbacks.map((fb) => {
            const isSold = fb.sourceType === 'SOLD';
            
            return (
              <div 
                key={fb.id}
                className="bg-white border-2 border-[#b0bec5] hover:border-[#1b365d] rounded-xl p-4 shadow-xs transition-all space-y-3"
              >
                
                {/* Row Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      {/* Source Type Tag */}
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider ${
                        isSold 
                          ? 'bg-purple-50 text-purple-800 border-purple-300' 
                          : 'bg-blue-50 text-blue-900 border-blue-300'
                      }`}>
                        {isSold ? 'Equipamento Vendido' : 'Equipamento Reparado'}
                      </span>

                      {/* OS Number Badge */}
                      {fb.osNumber && (
                        <span className="font-mono text-xs font-black text-[#003b7a] bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-md">
                          {fb.osNumber}
                        </span>
                      )}

                      {/* Performance Status Badge */}
                      {fb.performanceStatus === 'EXCELLENT' && (
                        <span className="text-[9px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-300 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Desempenho 100% Excelente</span>
                        </span>
                      )}
                      {fb.performanceStatus === 'OPERATING_NORMAL' && (
                        <span className="text-[9px] font-bold text-blue-800 bg-blue-50 border border-blue-300 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Check className="w-3 h-3 text-blue-600" />
                          <span>Operando Normal</span>
                        </span>
                      )}
                      {fb.performanceStatus === 'MINOR_ADJUSTMENT' && (
                        <span className="text-[9px] font-bold text-amber-800 bg-amber-50 border border-amber-300 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3 text-amber-600" />
                          <span>Pequeno Ajuste Fino</span>
                        </span>
                      )}
                      {fb.performanceStatus === 'NEEDS_INSPECTION' && (
                        <span className="text-[9px] font-bold text-orange-800 bg-orange-50 border border-orange-300 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Wrench className="w-3 h-3 text-orange-600" />
                          <span>Requer Vistoria no Local</span>
                        </span>
                      )}
                      {fb.performanceStatus === 'CRITICAL_DEFECT' && (
                        <span className="text-[9px] font-bold text-red-800 bg-red-50 border border-red-300 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <ShieldAlert className="w-3 h-3 text-red-600" />
                          <span>Defeito / Acionou Garantia</span>
                        </span>
                      )}
                    </div>

                    <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-blue-900 shrink-0" />
                      <span>{fb.equipmentName}</span>
                    </h3>
                  </div>

                  {/* Rating Stars & Actions */}
                  <div className="flex items-center gap-3 shrink-0">
                    {fb.rating > 0 && (
                      <div className="flex items-center gap-1 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                        <span className="text-xs font-mono font-bold text-amber-800">{fb.rating}.0</span>
                        <div className="flex text-amber-500">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star 
                              key={star} 
                              className={`w-3.5 h-3.5 ${star <= fb.rating ? 'fill-amber-500 stroke-amber-500' : 'text-slate-300'}`} 
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-1.5">
                      {/* WhatsApp Quick Dispatch */}
                      {fb.clientPhone && (
                        <a
                          href={generateWhatsAppLink(fb)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-700 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                          title="Enviar Mensagem de Aferição via WhatsApp"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-white" />
                          <span className="hidden sm:inline">Perguntar no WhatsApp</span>
                        </a>
                      )}

                      {/* Edit Button */}
                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(fb)}
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 rounded-lg transition-colors cursor-pointer"
                        title="Editar Feedback / Registro"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      {/* Delete Button */}
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Deseja remover este registro de pós-manutenção do cliente ${fb.clientName}?`)) {
                            onDeleteFeedback(fb.id);
                            showToast('Registro excluído com sucesso.');
                          }
                        }}
                        className="p-1.5 bg-slate-100 hover:bg-red-100 border border-slate-300 hover:border-red-300 text-slate-600 hover:text-red-700 rounded-lg transition-colors cursor-pointer"
                        title="Excluir Registro"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Main Content Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-700">
                  
                  {/* Column 1: Client & Delivery Info */}
                  <div className="space-y-1.5 bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[9px] font-black text-slate-500 uppercase tracking-wider block">Dados do Cliente & Entrega</span>
                    <p className="font-black text-slate-900 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-blue-900 shrink-0" />
                      <span>{fb.clientName}</span>
                    </p>
                    {fb.clientPhone && (
                      <p className="text-[11px] text-slate-600 flex items-center gap-1.5 font-mono font-medium">
                        <Phone className="w-3 h-3 text-slate-500" />
                        <span>{fb.clientPhone}</span>
                      </p>
                    )}
                    <p className="text-[10px] text-slate-600 flex items-center gap-1.5">
                      <Calendar className="w-3 h-3 text-slate-500" />
                      <span>Entregue em: <strong className="text-slate-900 font-bold">{new Date((fb.deliveryDate || '') + 'T12:00:00').toLocaleDateString('pt-BR')}</strong></span>
                    </p>
                    {fb.contactedBy && (
                      <p className="text-[10px] text-slate-600">
                        Responsável: <strong className="text-slate-900 font-bold">{fb.contactedBy}</strong>
                      </p>
                    )}
                  </div>

                  {/* Column 2: Client Feedback Comments */}
                  <div className="space-y-1.5 bg-slate-50 p-3 rounded-lg border border-slate-200 md:col-span-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-black text-slate-500 uppercase tracking-wider block">Relato do Cliente (Desempenho da Máquina)</span>
                      {fb.npsScore !== undefined && fb.npsScore !== null && (
                        <span className="text-[10px] font-bold font-mono text-[#003b7a] bg-blue-100/70 border border-blue-300 px-2 py-0.5 rounded">
                          NPS: {fb.npsScore}/10
                        </span>
                      )}
                    </div>
                    
                    {fb.feedbackNotes ? (
                      <p className="text-xs text-slate-800 italic leading-relaxed bg-white p-2.5 rounded-lg border border-slate-200">
                        "{fb.feedbackNotes}"
                      </p>
                    ) : (
                      <p className="text-xs text-slate-500 italic py-2">
                        Aguardando retorno do cliente sobre a pressão/estanqueidade...
                      </p>
                    )}

                    {fb.technicianNotes && (
                      <div className="pt-1 text-[10px] text-slate-600 flex items-start gap-1">
                        <span className="font-bold text-blue-900 shrink-0">Obs. Interna:</span>
                        <span>{fb.technicianNotes}</span>
                      </div>
                    )}
                  </div>

                </div>

                {/* Footer bar for warranty action if needed */}
                {(fb.performanceStatus === 'CRITICAL_DEFECT' || fb.performanceStatus === 'NEEDS_INSPECTION') && setActiveTab && (
                  <div className="bg-red-50 border border-red-200 p-2.5 rounded-lg flex items-center justify-between gap-2">
                    <span className="text-[11px] font-bold text-red-800 flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
                      <span>Máquina sinalizada com ajuste pendente ou acionamento de garantia.</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('WARRANTY_CONTROL')}
                      className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-[10px] font-black uppercase rounded-lg transition-all flex items-center gap-1 shrink-0 cursor-pointer shadow-xs"
                    >
                      <span>Abrir Controle de Garantia</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

              </div>
            );
          })
        )}
      </div>

      {/* Modal Form: Add / Edit Post Maintenance */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="post-maintenance-modal">
          <div className="absolute inset-0 bg-[#000000]/60 backdrop-blur-xs" onClick={() => setIsModalOpen(false)}></div>
          
          <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-2xl border-2 border-[#b0bec5] flex flex-col max-h-[90vh] overflow-hidden">
            
            {/* Modal Header */}
            <div className="bg-[#1b365d] text-white px-6 py-4 flex items-center justify-between border-b border-blue-900 shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-lg border border-white/20">
                  <Award className="w-5 h-5 text-cyan-300" />
                </div>
                <div>
                  <h3 className="font-black text-white text-sm uppercase tracking-wider">
                    {editingFeedback ? 'Editar Aferição Pós-Manutenção' : 'Nova Aferição Pós-Manutenção / Venda'}
                  </h3>
                  <span className="text-[10px] text-cyan-100 block">
                    Pergunte ao cliente sobre o desempenho do equipamento consertado ou vendido
                  </span>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-white/10 rounded text-cyan-200 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
              
              {/* Quick Auto-Fill from Completed OS */}
              {!editingFeedback && completedOrders.length > 0 && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl space-y-1.5">
                  <label className="block text-[10px] font-black text-[#003b7a] uppercase tracking-wider flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-blue-800" />
                    <span>Importar Dados de uma Ordem de Serviço Concluída:</span>
                  </label>
                  <select
                    value={selectedOSId}
                    onChange={(e) => handleSelectOS(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  >
                    <option value="">-- Selecionar da lista de Ordens de Serviço Entregues --</option>
                    {completedOrders.map(o => {
                      const c = clients.find(cli => cli.id === o.clientId);
                      return (
                        <option key={o.id} value={o.id}>
                          [{o.osNumber}] {o.title} — {c?.name}
                        </option>
                      );
                    })}
                  </select>
                </div>
              )}

              {/* Source Type & OS Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Tipo de Fornecimento *</label>
                  <select
                    value={sourceType}
                    onChange={(e) => setSourceType(e.target.value as EquipmentSourceType)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600"
                  >
                    <option value="REPAIRED">Equipamento Consertado (Manutenção)</option>
                    <option value="SOLD">Equipamento Vendido (Venda / Fornecimento)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Número da OS / Pedido</label>
                  <input
                    type="text"
                    placeholder="Ex: OS-1001 ou PED-2026"
                    value={osNumber}
                    onChange={(e) => setOsNumber(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
              </div>

              {/* Client & Equipment Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Nome do Cliente / Empresa *</label>
                  <input
                    type="text"
                    placeholder="Ex: Metalúrgica Alfa S.A."
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-600"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Telefone / WhatsApp para Contato</label>
                  <input
                    type="text"
                    placeholder="Ex: (21) 98369-9728"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(formatPhoneNumber(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-medium text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Equipamento Consertado ou Vendido *</label>
                  <input
                    type="text"
                    placeholder="Ex: Cilindro Hidráulico Parker 200mm"
                    value={equipmentName}
                    onChange={(e) => setEquipmentName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-600"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Data da Entrega *</label>
                  <input
                    type="date"
                    value={deliveryDate}
                    onChange={(e) => setDeliveryDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-hidden focus:border-blue-600"
                    required
                  />
                </div>
              </div>

              {/* Performance Status & Rating */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-300 space-y-3">
                <h4 className="text-[11px] font-black text-slate-800 uppercase tracking-wider">
                  Avaliação do Desempenho e Qualidade
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Condição de Funcionamento *</label>
                    <select
                      value={performanceStatus}
                      onChange={(e) => setPerformanceStatus(e.target.value as any)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600"
                    >
                      <option value="EXCELLENT">🌟 100% Excelente / Estanqueidade Total</option>
                      <option value="OPERATING_NORMAL">✅ Operando Normal Sem Anomalias</option>
                      <option value="MINOR_ADJUSTMENT">⚠️ Requer Pequeno Ajuste Fino</option>
                      <option value="NEEDS_INSPECTION">🔧 Requer Vistoria Técnica no Local</option>
                      <option value="CRITICAL_DEFECT">🚨 Defeito / Acionou Garantia</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Nota de Satisfação (1 a 5 Estrelas)</label>
                    <div className="flex items-center gap-2 pt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="p-1.5 hover:scale-110 transition-transform cursor-pointer"
                        >
                          <Star 
                            className={`w-6 h-6 ${star <= rating ? 'fill-amber-500 stroke-amber-500' : 'text-slate-300 stroke-slate-400'}`} 
                          />
                        </button>
                      ))}
                      <span className="text-xs font-mono font-black text-amber-600 ml-2">{rating}/5</span>
                    </div>
                  </div>
                </div>

                {/* NPS Score */}
                <div className="space-y-1 pt-2 border-t border-slate-200">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">
                    Net Promoter Score - NPS (0 a 10 - Probabilidade de recomendar nossa empresa)
                  </label>
                  <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
                    {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setNpsScore(num)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                          npsScore === num 
                            ? 'bg-[#003b7a] text-white shadow-md font-black scale-105' 
                            : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {num}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Feedback Textarea */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Relato do Cliente (Perguntas sobre Ruídos, Pressão, Estanqueidade)</label>
                <textarea
                  rows={3}
                  placeholder="Ex: O cliente informou que o cilindro montou perfeitamente na prensa e atingiu a pressão máxima sem vazamentos nas gaxetas..."
                  value={feedbackNotes}
                  onChange={(e) => setFeedbackNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-600 resize-none"
                />
              </div>

              {/* Technician Internal Notes & Person */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Responsável pelo Acompanhamento</label>
                  <input
                    type="text"
                    placeholder="Ex: Juliana (Controle de Qualidade)"
                    value={contactedBy}
                    onChange={(e) => setContactedBy(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Status do Contato</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as PostMaintenanceStatus)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600"
                  >
                    <option value="PENDING_CONTACT">Aguardando Envio de Mensagem</option>
                    <option value="CONTACTED">Pesquisa Enviada ao Cliente</option>
                    <option value="EXCELLENT">Aferição Concluída (Satisfação 100%)</option>
                    <option value="NEEDS_ADJUSTMENT">Necessita Visita de Ajuste</option>
                    <option value="WARRANTY_CLAIM">Encaminhado para Garantia</option>
                  </select>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition-all shadow-md cursor-pointer"
                >
                  {editingFeedback ? 'Salvar Alterações' : 'Registrar Aferição'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
