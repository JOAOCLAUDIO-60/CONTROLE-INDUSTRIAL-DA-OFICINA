import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Client, Equipment, ServiceOrder, OSStatus, PlannedService } from '../types';
import { formatPhoneNumber } from '../utils/phoneFormatter';
import { 
  Search, Plus, Check, X, Printer, UserPlus, Cpu, FileText, 
  Sparkles, DollarSign, AlertTriangle, ShieldCheck, RefreshCw, 
  HelpCircle, Eye, CornerDownRight, Handshake, Save, ArrowRight,
  ShieldAlert, Copy, FileWarning, Lock, Camera, Upload, Trash2, Image as ImageIcon, Briefcase, Building2
} from 'lucide-react';

interface EquipmentEntryRegistryProps {
  clients: Client[];
  equipments: Equipment[];
  orders: ServiceOrder[];
  services?: PlannedService[];
  onAddClient: (client: Omit<Client, 'id' | 'createdAt'>) => Client;
  onAddEquipment: (equipment: Omit<Equipment, 'id' | 'createdAt'>) => Equipment;
  onAddOrder: (order: Omit<ServiceOrder, 'id' | 'osNumber' | 'createdAt'>) => ServiceOrder;
  onEditOrder: (order: ServiceOrder) => void;
  onDeleteOrder?: (id: string) => void;
  onEditEquipment?: (equipment: Equipment) => void;
  onOpenPriceTableTab?: () => void;
  onOpenWarrantyTab?: () => void;
  receivers?: string[];
  onSaveReceivers?: (receivers: string[]) => void;
}

export default function EquipmentEntryRegistry({
  clients,
  equipments,
  orders,
  services = [],
  receivers,
  onSaveReceivers,
  onAddClient,
  onAddEquipment,
  onAddOrder,
  onEditOrder,
  onDeleteOrder,
  onEditEquipment,
  onOpenPriceTableTab,
  onOpenWarrantyTab
}: EquipmentEntryRegistryProps) {
  // Search states
  const [clientSearch, setClientSearch] = useState('');
  const [equipSearch, setEquipSearch] = useState('');

  // Currently selected Client & Equipment (empty by default for new launch)
  const [selectedClientId, setSelectedClientId] = useState<string>('');
  const [selectedEquipId, setSelectedEquipId] = useState<string>('');

  // Form Fields State (Client)
  const [clientCode, setClientCode] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientActivity, setClientActivity] = useState('PARTICULAR');
  const [entryDate, setEntryDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [entryOSNumber, setEntryOSNumber] = useState('OS-2026-101');
  const [caracteristica, setCaracteristica] = useState('ORÇAMENTO TÉCNICO NORMAL');
  const [estimatedValue, setEstimatedValue] = useState('');

  const handleCaracteristicaChange = (newCarac: string) => {
    setCaracteristica(newCarac);
    if (newCarac.includes('GARANTIA')) {
      setEstimatedValue('0,00');
    }
  };

  // Gerenciamento de Recebedores / Atendentes com localStorage e Servidor Central
  const DEFAULT_RECEIVERS = ['Atendimento Balcão', 'JOÃO CLAUDIO'];
  const PURGE_MOCK_RECEIVERS = ['Carlos Silva', 'João Carlos', 'Maria Oliveira', 'Roberto Souza'];

  const cleanReceivers = (list: any[]): string[] => {
    if (!Array.isArray(list)) return DEFAULT_RECEIVERS;
    const cleaned = list
      .filter((r) => typeof r === 'string' && r.trim().length > 0)
      .map((r) => r.trim())
      .filter((r) => !PURGE_MOCK_RECEIVERS.includes(r));
    return cleaned.length > 0 ? Array.from(new Set(cleaned)) : DEFAULT_RECEIVERS;
  };

  const [receiversList, setReceiversList] = useState<string[]>(() => {
    if (receivers && receivers.length > 0) return cleanReceivers(receivers);
    try {
      const saved = localStorage.getItem('oficina_receivers');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return cleanReceivers(parsed);
      }
    } catch (e) {
      console.error('Erro ao ler oficina_receivers:', e);
    }
    return DEFAULT_RECEIVERS;
  });

  const activeReceivers = cleanReceivers(receivers && receivers.length > 0 ? receivers : receiversList);
  const [receiverName, setReceiverName] = useState(() => activeReceivers[0] || 'Atendimento Balcão');
  const [showReceiversModal, setShowReceiversModal] = useState(false);
  const [newReceiverInput, setNewReceiverInput] = useState('');

  // Sincronizar quando a lista de atendentes for atualizada via props
  useEffect(() => {
    if (receivers && receivers.length > 0) {
      const cleaned = cleanReceivers(receivers);
      setReceiversList(cleaned);
      if (!receiverName || !cleaned.includes(receiverName)) {
        setReceiverName(cleaned[0] || 'Atendimento Balcão');
      }
    }
  }, [receivers]);

  const handleAddReceiver = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const currentList = activeReceivers;
    if (currentList.some(r => r.toLowerCase() === trimmed.toLowerCase())) {
      showToast('Este atendente/recebedor já está cadastrado.', 'info');
      return;
    }
    const updated = [...currentList, trimmed];
    setReceiversList(updated);
    localStorage.setItem('oficina_receivers', JSON.stringify(updated));
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    setReceiverName(trimmed);
    setNewReceiverInput('');
    showToast(`Atendente "${trimmed}" cadastrado e salvo com sucesso!`, 'success');
  };

  const handleDeleteReceiver = (nameToDelete: string) => {
    const currentList = activeReceivers;
    if (currentList.length <= 1) {
      showToast('É necessário manter pelo menos um atendente cadastrado.', 'error');
      return;
    }
    const updated = currentList.filter(r => r !== nameToDelete);
    setReceiversList(updated);
    localStorage.setItem('oficina_receivers', JSON.stringify(updated));
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    if (receiverName === nameToDelete) {
      setReceiverName(updated[0] || '');
    }
    showToast(`Atendente "${nameToDelete}" removido.`, 'info');
  };

  // Gerenciamento de Ramos / Atividades com localStorage
  const DEFAULT_ACTIVITIES = [
    'PARTICULAR',
    'COMÉRCIO / VAREJO',
    'INDÚSTRIA METALÚRGICA',
    'MINERAÇÃO & CONSTRUÇÃO',
    'TRANSPORTE & LOGÍSTICA',
    'AGROPECUÁRIA & AGRONEGÓCIO',
    'ALIMENTOS & BEBIDAS',
    'PAPEL & PAPELÃO',
    'SERVIÇOS GERAIS',
    'PLÁSTICOS & POLÍMEROS',
    'SISTEMAS HIDRÁULICOS & MANUTENÇÃO',
    'OUTROS'
  ];

  const [activitiesList, setActivitiesList] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('oficina_client_activities');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          if (!parsed.includes('PARTICULAR')) {
            return ['PARTICULAR', ...parsed];
          }
          return parsed;
        }
      }
    } catch (e) {
      console.error('Erro ao ler oficina_client_activities:', e);
    }
    return DEFAULT_ACTIVITIES;
  });

  const [showActivitiesModal, setShowActivitiesModal] = useState(false);
  const [newActivityInput, setNewActivityInput] = useState('');

  const handleAddActivity = (name: string) => {
    const trimmed = name.trim().toUpperCase();
    if (!trimmed) return;
    if (activitiesList.some(a => a.toUpperCase() === trimmed)) {
      showToast('Esta atividade já está cadastrada.', 'info');
      return;
    }
    const updated = [...activitiesList, trimmed];
    setActivitiesList(updated);
    localStorage.setItem('oficina_client_activities', JSON.stringify(updated));
    setClientActivity(trimmed);
    setNewActivityInput('');
    showToast(`Atividade "${trimmed}" cadastrada com sucesso!`, 'success');
  };

  const handleDeleteActivity = (actToDelete: string) => {
    if (activitiesList.length <= 1) {
      showToast('É necessário manter pelo menos uma atividade cadastrada.', 'error');
      return;
    }
    const updated = activitiesList.filter(a => a !== actToDelete);
    setActivitiesList(updated);
    localStorage.setItem('oficina_client_activities', JSON.stringify(updated));
    if (clientActivity === actToDelete) {
      setClientActivity(updated[0] || 'PARTICULAR');
    }
    showToast(`Atividade "${actToDelete}" removida.`, 'info');
  };

  // Form Fields State (Equipment)
  const [equipCode, setEquipCode] = useState('');
  const [equipName, setEquipName] = useState('');
  const [equipModel, setEquipModel] = useState('');
  const [equipBrand, setEquipBrand] = useState('');
  const [equipPatrimony, setEquipPatrimony] = useState('');
  const [defeitoApresentado, setDefeitoApresentado] = useState('');

  // Equipment Photo & Camera States
  const [equipmentPhoto, setEquipmentPhoto] = useState<string>('');
  const [showCameraModal, setShowCameraModal] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);

  // Modals & Popovers
  const [showAddClientModal, setShowAddClientModal] = useState(false);
  const [showAddEquipModal, setShowAddEquipModal] = useState(false);
  const [showNewOrderModal, setShowNewOrderModal] = useState(false);
  const [showPriceTableModal, setShowPriceTableModal] = useState(false);
  const [showOrdersListModal, setShowOrdersListModal] = useState(false);
  const [showDuplicateModal, setShowDuplicateModal] = useState(false);
  const [duplicateOrdersFound, setDuplicateOrdersFound] = useState<ServiceOrder[]>([]);

  // Feedback Notification Toast
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success', duration = 3000) => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), duration);
  };

  // Camera & File Upload Handlers
  const handleStartCamera = async () => {
    try {
      setShowCameraModal(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } }
      });
      setMediaStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      showToast('Não foi possível acessar a câmera. Verifique as permissões.', 'error');
      setShowCameraModal(false);
    }
  };

  const handleStopCamera = () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
      setMediaStream(null);
    }
    setShowCameraModal(false);
  };

  const handleCapturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setEquipmentPhoto(dataUrl);
      showToast('Foto do equipamento capturada com sucesso!', 'success');
    }
    handleStopCamera();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setEquipmentPhoto(event.target.result as string);
        showToast('Imagem do equipamento anexada!', 'success');
      }
    };
    reader.readAsDataURL(file);
  };

  // Active client & equipment lookup
  const activeClient = useMemo(() => {
    if (selectedClientId) {
      return clients.find(c => c.id === selectedClientId) || null;
    }
    if (clientName.trim()) {
      return clients.find(c => c.name.trim().toLowerCase() === clientName.trim().toLowerCase()) || null;
    }
    return null;
  }, [clients, selectedClientId, clientName]);

  const activeEquip = useMemo(() => {
    if (selectedEquipId) {
      return equipments.find(e => e.id === selectedEquipId) || null;
    }
    if (equipName.trim()) {
      return equipments.find(e => e.name.trim().toLowerCase() === equipName.trim().toLowerCase()) || null;
    }
    return null;
  }, [equipments, selectedEquipId, equipName]);

  // Filter clients table
  const filteredClients = useMemo(() => {
    return clients.filter(c => 
      c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
      c.phone.includes(clientSearch) ||
      c.id.includes(clientSearch)
    );
  }, [clients, clientSearch]);

  // Filter equipments table
  const filteredEquipments = useMemo(() => {
    return equipments.filter(e => 
      e.name.toLowerCase().includes(equipSearch.toLowerCase()) ||
      e.model.toLowerCase().includes(equipSearch.toLowerCase()) ||
      (e.type && e.type.toLowerCase().includes(equipSearch.toLowerCase())) ||
      (e.patrimonyNumber && e.patrimonyNumber.toLowerCase().includes(equipSearch.toLowerCase())) ||
      e.id.includes(equipSearch)
    );
  }, [equipments, equipSearch]);

  // Handle Client Row Click (Independent: does NOT alter or wipe equipment)
  const handleSelectClient = (client: Client) => {
    setSelectedClientId(client.id);
    setClientCode(client.id.slice(-3).padStart(3, '0'));
    setClientName(client.name.toUpperCase());
    setClientPhone(formatPhoneNumber(client.phone));
    setClientActivity(client.activity || 'PARTICULAR');
    showToast(`Cliente selecionado: ${client.name}`, 'info');
  };

  // Handle Equipment Row Click (Independent: does NOT alter or wipe client)
  const handleSelectEquipment = (equip: Equipment) => {
    setSelectedEquipId(equip.id);
    setEquipCode(equip.id.slice(-3).padStart(3, '0'));
    setEquipName(equip.name.toUpperCase());
    setEquipModel(equip.model.toUpperCase());
    setEquipBrand((equip.type || 'JC&F').toUpperCase());
    setEquipPatrimony((equip.patrimonyNumber || '').toUpperCase());
    showToast(`Equipamento selecionado: ${equip.name}`, 'info');
  };

  // Clean all form fields for a new entry launch
  const handleResetForm = () => {
    setSelectedClientId('');
    setSelectedEquipId('');
    setClientCode('');
    setClientName('');
    setClientPhone('');
    setClientActivity('PARTICULAR');
    setEquipCode('');
    setEquipName('');
    setEquipModel('');
    setEquipBrand('');
    setEquipPatrimony('');
    setDefeitoApresentado('');
    setEquipmentPhoto('');
    setEstimatedValue('');
    setCaracteristica('ORÇAMENTO TÉCNICO NORMAL');
    setClientSearch('');
    setEquipSearch('');
  };

  // Save defect changes to current order or equipment
  const handleSaveDefect = () => {
    let savedSomething = false;
    // Save to equipment if an equipment is selected or loaded
    if (selectedEquipId && onEditEquipment) {
      const existingEquip = equipments.find(e => e.id === selectedEquipId);
      if (existingEquip) {
        onEditEquipment({
          ...existingEquip,
          name: equipName.trim() || existingEquip.name,
          model: equipModel.trim() || existingEquip.model,
          type: equipBrand.trim() || existingEquip.type,
          patrimonyNumber: equipPatrimony.trim() || undefined,
          updatedAt: new Date().toISOString()
        });
        savedSomething = true;
      }
    }

    // Find active order for this equipment and client
    const activeOrder = orders.find(o => selectedEquipId && o.equipmentId === selectedEquipId && selectedClientId && o.clientId === selectedClientId) || 
                        orders.find(o => selectedEquipId && o.equipmentId === selectedEquipId);
    if (activeOrder) {
      onEditOrder({
        ...activeOrder,
        description: defeitoApresentado,
        patrimonyNumber: equipPatrimony.trim() || activeOrder.patrimonyNumber
      });
      savedSomething = true;
      showToast('Dados do equipamento, patrimônio e defeito da OS atualizados!', 'success');
    } else if (savedSomething) {
      showToast('Dados do equipamento e patrimônio atualizados com sucesso!', 'success');
    } else {
      showToast('Defeito registrado para abertura da OS!', 'success');
    }
  };

  // Print Receipt Ticket
  const handlePrintReceipt = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Comprovante de Entrada - ${entryOSNumber}</title>
          <style>
            body { font-family: 'Courier New', monospace; font-size: 13px; max-width: 420px; margin: 0 auto; padding: 20px; color: #000; }
            .header { text-align: center; border-bottom: 2px dashed #000; pb-10px; margin-bottom: 12px; }
            .header h2 { margin: 0; font-size: 16px; }
            .header p { margin: 3px 0; font-size: 11px; }
            .line { display: flex; justify-content: space-between; margin: 4px 0; }
            .bold { font-weight: bold; }
            .box { border: 1px solid #000; padding: 8px; margin: 10px 0; font-size: 12px; }
            .footer { text-align: center; border-top: 2px dashed #000; margin-top: 20px; pt-10px; font-size: 11px; }
          </style>
        </head>
        <body onload="window.print()">
          <div class="header">
            <h2>SISTEMA DE ASSISTÊNCIA TÉCNICA</h2>
            <p>PREFEITURA DO RIO / ASSISTÊNCIA TÉCNICA</p>
            <p><strong>COMPROVANTE DE ENTRADA DE EQUIPAMENTO</strong></p>
          </div>
          <div class="line"><span class="bold">ORDEM:</span> <span>${entryOSNumber}</span></div>
          <div class="line"><span class="bold">DATA ENTRADA:</span> <span>${entryDate}</span></div>
          <div class="line"><span class="bold">RECEBEDOR / ATENDENTE:</span> <span>${receiverName}</span></div>
          <div class="line"><span class="bold">CARACTERÍSTICA:</span> <span>${caracteristica}</span></div>
          <div class="line"><span class="bold">VALOR ESTIMADO:</span> <span>R$ ${estimatedValue || (caracteristica.includes('GARANTIA') ? '0,00' : '0,00')}</span></div>
          <hr />
          <div class="line"><span class="bold">CLIENTE:</span> <span>${clientName || 'NÃO INFORMADO'}</span></div>
          <div class="line"><span class="bold">TELEFONE:</span> <span>${clientPhone || 'NÃO INFORMADO'}</span></div>
          <div class="line"><span class="bold">ATIVIDADE:</span> <span>${clientActivity}</span></div>
          <hr />
          <div class="line"><span class="bold">CÓD. EQUIP:</span> <span>${equipCode ? `EQ-${equipCode}` : 'NOVO'}</span></div>
          <div class="line"><span class="bold">EQUIPAMENTO:</span> <span>${equipName || 'NÃO INFORMADO'}</span></div>
          <div class="line"><span class="bold">MODELO:</span> <span>${equipModel || 'PADRÃO'}</span></div>
          <div class="line"><span class="bold">FABRICANTE:</span> <span>${equipBrand || 'JC&F'}</span></div>
          ${equipPatrimony ? `<div class="line"><span class="bold">PATRIMÔNIO / FILIAL:</span> <span style="font-weight:bold; background:#fef3c7; padding:1px 4px; border:1px solid #d97706;">${equipPatrimony}</span></div>` : ''}
          <div class="box">
            <strong>DEFEITO DECLARADO:</strong><br />
            "${defeitoApresentado || 'Entrada para vistoria e orçamento técnico.'}"
          </div>
          <div class="footer">
            <p>Documento de controle de entrada e vistoria inicial.</p>
            <p>Assinatura do Técnico / Recebedor</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Check active duplicate orders for selected client & equipment
  const activeEquipDuplicateOrders = useMemo(() => {
    if (!activeClient || !activeEquip) return [];
    return orders.filter(o => 
      o.clientId === activeClient.id && 
      (o.equipmentId === activeEquip.id || 
       equipments.find(e => e.id === o.equipmentId)?.name.toLowerCase() === activeEquip.name.toLowerCase()) &&
      o.status !== 'CANCELLED' &&
      !o.isDelivered
    );
  }, [orders, activeClient, activeEquip, equipments]);

  // Create new OS action with antiduplicity protection and post-creation form reset
  const handleCreateNewOrder = (forceAuthorization = false) => {
    const trimmedClientName = clientName.trim();
    const trimmedEquipName = equipName.trim();

    if (!trimmedClientName && !selectedClientId) {
      showToast('Preencha o Nome do Cliente ou selecione um cliente na lista.', 'error');
      return;
    }

    if (!trimmedEquipName && !selectedEquipId) {
      showToast('Preencha o Nome do Equipamento ou selecione um equipamento na lista.', 'error');
      return;
    }

    // Resolve or automatically create client
    let targetClient: Client | null = activeClient;
    if (!targetClient) {
      if (selectedClientId) {
        targetClient = clients.find(c => c.id === selectedClientId) || null;
      }
      if (!targetClient && trimmedClientName) {
        targetClient = onAddClient({
          name: trimmedClientName,
          phone: clientPhone.trim() || '(21) 00000-0000',
          document: 'N/A',
          address: 'N/A',
          activity: clientActivity || 'PARTICULAR'
        });
      }
    }

    if (!targetClient) {
      showToast('Não foi possível identificar ou cadastrar o cliente.', 'error');
      return;
    }

    // Resolve or automatically create equipment
    let targetEquip: Equipment | null = activeEquip;
    if (!targetEquip) {
      if (selectedEquipId) {
        targetEquip = equipments.find(e => e.id === selectedEquipId) || null;
      }
      if (!targetEquip && trimmedEquipName) {
        targetEquip = onAddEquipment({
          name: trimmedEquipName,
          model: equipModel.trim() || 'PADRÃO',
          type: equipBrand.trim() || 'JC&F',
          patrimonyNumber: equipPatrimony.trim() || undefined,
          clientId: targetClient.id
        });
      }
    } else {
      // If equipment already existed, sync any changes to patrimony or names
      if (onEditEquipment && equipPatrimony.trim() !== (targetEquip.patrimonyNumber || '')) {
        const updatedEquip: Equipment = {
          ...targetEquip,
          name: trimmedEquipName || targetEquip.name,
          model: equipModel.trim() || targetEquip.model,
          type: equipBrand.trim() || targetEquip.type,
          patrimonyNumber: equipPatrimony.trim() || undefined,
          updatedAt: new Date().toISOString()
        };
        onEditEquipment(updatedEquip);
        targetEquip = updatedEquip;
      }
    }

    if (!targetEquip) {
      showToast('Não foi possível identificar ou cadastrar o equipamento.', 'error');
      return;
    }

    // Antiduplicity device check for same client + same equipment simultaneously active
    const existingDuplicates = orders.filter(o => 
      o.clientId === targetClient!.id && 
      (o.equipmentId === targetEquip!.id || 
       equipments.find(e => e.id === o.equipmentId)?.name.toLowerCase() === targetEquip!.name.toLowerCase()) &&
      o.status !== 'CANCELLED' && 
      !o.isDelivered
    );

    if (existingDuplicates.length > 0 && !forceAuthorization) {
      setDuplicateOrdersFound(existingDuplicates);
      setShowDuplicateModal(true);
      return;
    }

    const isSecondMachine = existingDuplicates.length > 0;
    const rawEstimated = (estimatedValue || '').replace(/\./g, '').replace(',', '.');
    const parsedEstimatedCost = parseFloat(rawEstimated);
    const finalEstimatedCost = isNaN(parsedEstimatedCost) 
      ? (caracteristica.includes('GARANTIA') ? 0 : 0) 
      : parsedEstimatedCost;

    const assignedPatrimony = equipPatrimony.trim() || targetEquip.patrimonyNumber || undefined;

    const newOS = onAddOrder({
      clientId: targetClient.id,
      equipmentId: targetEquip.id,
      patrimonyNumber: assignedPatrimony,
      title: `Entrada: ${targetEquip.name}${assignedPatrimony ? ` [${assignedPatrimony}]` : ''}${isSecondMachine ? ' (2º Equipamento)' : ''}`,
      description: forceAuthorization
        ? `${defeitoApresentado}\n\n[DISPOSITIVO ANTIDUPLICIDADE: OS Autorizada pelo Usuário - Cliente trouxe 2º equipamento idêntico${assignedPatrimony ? ` (Patrimônio/Filial: ${assignedPatrimony})` : ''}]`
        : (defeitoApresentado || 'Entrada para vistoria e orçamento técnico.'),
      orderType: caracteristica.includes('GARANTIA') ? 'WARRANTY' : 'SERVICE',
      status: 'PENDING',
      priority: 'MEDIUM',
      technician: receiverName || (activeReceivers[0] || 'JOÃO CLAUDIO'),
      receiverName: receiverName || (activeReceivers[0] || 'Atendimento Balcão'),
      estimatedCost: finalEstimatedCost,
      startDate: entryDate || new Date().toISOString().split('T')[0],
      equipmentPhoto: equipmentPhoto || undefined,
      isDelivered: false,
      isDuplicateAuthorized: forceAuthorization,
      duplicateNote: forceAuthorization ? `Autorizado pelo usuário: 2º equipamento idêntico do cliente${assignedPatrimony ? ` (Patrimônio/Filial: ${assignedPatrimony})` : ''}` : undefined
    });

    // Reset all form inputs to empty for a fresh entry
    handleResetForm();
    setShowDuplicateModal(false);
    showToast(
      '✅ Equipamento recebido, registrado com sucesso no sistema da JC&F e encaminhado para avaliação técnica.',
      'success',
      7000
    );
  };

  return (
    <div className="w-full bg-[#3b5998] p-2 md:p-4 rounded-xl shadow-2xl font-sans text-slate-900 border border-slate-700 max-w-[1400px] mx-auto select-none" id="equipment-entry-registry-frame">
      
      {/* Toast Feedback */}
      {toastMessage && (
        <div className={`fixed top-5 right-5 z-50 px-4 py-2.5 rounded-lg shadow-xl font-bold text-xs flex items-center gap-2 border animate-bounce ${
          toastMessage.type === 'success' ? 'bg-emerald-600 text-white border-emerald-400' :
          toastMessage.type === 'error' ? 'bg-red-600 text-white border-red-400' :
          'bg-blue-600 text-white border-blue-400'
        }`}>
          <Sparkles className="w-4 h-4" />
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* MAIN ROYAL BLUE HEADER BANNER */}
      <div className="bg-[#004a99] text-white p-3 md:p-4 flex flex-col xl:flex-row items-start xl:items-center justify-between gap-3 border-b-2 border-blue-950 shadow-md rounded-t-lg" id="royal-header-banner">
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <span className="bg-cyan-900 text-cyan-200 text-[9px] font-black uppercase px-2 py-0.5 rounded border border-cyan-400/40 tracking-widest font-mono">
              SISTEMA CHECK-IN 4.0
            </span>
            <span className="bg-emerald-900 text-emerald-200 text-[9px] font-black uppercase px-2 py-0.5 rounded border border-emerald-400/40 tracking-widest font-mono">
              PAINEL UNIFICADO DE COMANDOS
            </span>
          </div>
          <h1 className="text-lg md:text-xl font-black tracking-wider uppercase font-sans text-white drop-shadow-sm flex items-center gap-2">
            <span>ENTRADA DE EQUIPAMENTOS PARA MANUTENÇÃO (CHECK-IN)</span>
          </h1>
        </div>

        {/* Header Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto" id="header-actions">
          <button
            type="button"
            id="btn-header-cadastrar-gerar-os"
            onClick={() => handleCreateNewOrder()}
            className="flex-1 xl:flex-initial px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-wider rounded-lg border-2 border-emerald-300 shadow-md cursor-pointer transition-all flex items-center justify-center gap-1.5 animate-pulse hover:animate-none shrink-0"
          >
            <Plus className="w-4 h-4 text-white" />
            <span>CADASTRAR E GERAR OS</span>
          </button>

          <button
            type="button"
            id="btn-header-novo-lancamento"
            onClick={() => {
              handleResetForm();
              showToast('Janelas limpas para um novo lançamento!', 'info');
            }}
            className="flex-1 xl:flex-initial px-3.5 py-2 bg-[#334155] hover:bg-[#1e293b] text-white font-black text-xs uppercase tracking-wider rounded-lg border border-slate-400 shadow cursor-pointer transition-all flex items-center justify-center gap-1.5 shrink-0"
            title="Limpar todas as janelas para um novo lançamento"
          >
            <RefreshCw className="w-4 h-4 text-cyan-200" />
            <span>NOVO LANÇAMENTO</span>
          </button>

          <button
            type="button"
            id="btn-header-novo-cliente"
            onClick={() => setShowAddClientModal(true)}
            className="flex-1 xl:flex-initial px-3.5 py-2 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-black text-xs uppercase tracking-wider rounded-lg border border-blue-300 shadow cursor-pointer transition-all flex items-center justify-center gap-1.5 shrink-0"
            title="Cadastrar Novo Cliente (F2)"
          >
            <UserPlus className="w-4 h-4 text-cyan-200" />
            <span>NOVO CLIENTE</span>
            <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1 py-0.2 rounded border border-amber-500/40">F2</span>
          </button>

          <button
            type="button"
            id="btn-header-novo-equip"
            onClick={() => setShowAddEquipModal(true)}
            className="flex-1 xl:flex-initial px-3.5 py-2 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-black text-xs uppercase tracking-wider rounded-lg border border-blue-300 shadow cursor-pointer transition-all flex items-center justify-center gap-1.5 shrink-0"
            title="Cadastrar Novo Equipamento (F4)"
          >
            <Cpu className="w-4 h-4 text-cyan-200" />
            <span>NOVO EQUIP.</span>
            <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1 py-0.2 rounded border border-amber-500/40">F4</span>
          </button>

          <button
            type="button"
            id="btn-header-ordens-registradas"
            onClick={() => setShowOrdersListModal(true)}
            className="flex-1 xl:flex-initial px-3.5 py-2 bg-[#1e293b] hover:bg-[#334155] text-white font-extrabold text-xs uppercase tracking-wider rounded-lg border border-slate-500 shadow cursor-pointer transition-all flex items-center justify-center gap-1.5 shrink-0"
          >
            <FileText className="w-4 h-4 text-cyan-300" />
            <span>OS REGISTRADAS ({orders.length})</span>
          </button>

          <button
            type="button"
            id="btn-header-imprimir-comprovante"
            onClick={handlePrintReceipt}
            className="flex-1 xl:flex-initial px-3.5 py-2 bg-[#ea580c] hover:bg-[#c2410c] text-white font-extrabold text-xs uppercase tracking-wider rounded-lg border border-amber-300 shadow cursor-pointer transition-all flex items-center justify-center gap-1.5 shrink-0"
          >
            <Printer className="w-4 h-4" />
            <span>IMPRIMIR</span>
          </button>

          <button
            type="button"
            id="btn-header-tab-preco"
            onClick={() => setShowPriceTableModal(true)}
            className="flex-1 xl:flex-initial px-3.5 py-2 bg-[#fef08a] hover:bg-[#fde047] text-amber-950 font-black text-xs uppercase tracking-wider rounded-lg border-2 border-amber-400 shadow cursor-pointer transition-all flex items-center justify-center gap-1.5 shrink-0"
          >
            <DollarSign className="w-4 h-4 text-amber-800" />
            <span>TAB. PREÇO</span>
          </button>

          {onOpenWarrantyTab && (
            <button
              type="button"
              id="btn-header-controle-garantia"
              onClick={onOpenWarrantyTab}
              className="flex-1 xl:flex-initial px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg border-2 border-amber-600 shadow cursor-pointer transition-all flex items-center justify-center gap-1.5 shrink-0"
              title="Acessar Controle & Auditoria de Garantias da Oficina"
            >
              <ShieldCheck className="w-4 h-4 text-slate-950" />
              <span>CONTROLE DE GARANTIA</span>
            </button>
          )}
        </div>
      </div>

      {/* METALLIC / CANVAS CONTAINER - SIDE BY SIDE PANELS ON DESKTOP */}
      <div className="bg-[#d5dbe3] p-2 md:p-3 space-y-3 border-t border-slate-200" id="main-canvas-panel">

        {/* SIDE-BY-SIDE GRID LAYOUT ON DESKTOP SCREENS */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3" id="main-canvas-grid">

          {/* ========================================================================= */}
          {/* PANEL 1: CLIENTES SECTION */}
          {/* ========================================================================= */}
          <div className="bg-[#e4e9f0] border-2 border-[#b0bec5] rounded-lg p-3 shadow-sm relative flex flex-col justify-between" id="section-clientes-panel">
            
            {/* Section Legend Label */}
            <div className="absolute -top-3.5 left-4 bg-[#1b365d] text-white px-2 py-0.5 border border-blue-900 rounded text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 shadow-xs z-10">
              <UserPlus className="w-3.5 h-3.5 text-cyan-300" />
              <span>1. CLIENTE SELECIONADO</span>
            </div>

            <div className="space-y-3 mt-1">
              
              {/* SEARCH & CLIENTS TABLE */}
              <div className="flex flex-col space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-black text-slate-900 uppercase tracking-wider">PESQUISA DE CLIENTE</label>
                  <button
                    type="button"
                    id="btn-cad-clientes-open"
                    onClick={() => setShowAddClientModal(true)}
                    className="px-2.5 py-0.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] font-black uppercase rounded border border-amber-600 shadow-2xs flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Cadastrar Novo Cliente (Tecla F2)"
                  >
                    <UserPlus className="w-3 h-3 text-slate-950" />
                    <span>NOVO CLIENTE</span>
                    <span className="bg-slate-950 text-amber-300 font-mono text-[9px] px-1 rounded">F2</span>
                  </button>
                </div>
                <div className="relative">
                  <input
                    id="input-search-clients"
                    type="text"
                    placeholder="BUSCAR POR NOME, CÓDIGO OU TELEFONE..."
                    value={clientSearch}
                    onChange={(e) => setClientSearch(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded px-2.5 py-1 text-xs text-slate-900 font-medium uppercase tracking-tight focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-500 shadow-inner"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2" />
                </div>

                {/* Clients Data Grid Table - Compact Height for Screen Visibility */}
                <div className="border border-slate-400 rounded bg-white overflow-hidden shadow-inner h-36 overflow-y-auto">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="bg-slate-200 border-b border-slate-300 text-slate-950 font-black uppercase sticky top-0 z-10 shadow-2xs">
                        <th className="py-1 px-1.5 w-14 text-center text-slate-950 font-black">CÓDIGO</th>
                        <th className="py-1 px-2 text-slate-950 font-black">NOME</th>
                        <th className="py-1 px-2 w-28 text-slate-950 font-black">TELEFONE</th>
                        <th className="py-1 px-2 text-slate-950 font-black">ATIVIDADE</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredClients.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="py-4 text-center text-slate-500 text-xs">
                            Nenhum cliente encontrado.
                          </td>
                        </tr>
                      ) : (
                        filteredClients.map((c) => {
                          const isSelected = (selectedClientId === c.id);
                          const code = c.id.slice(-3).padStart(3, '0');
                          return (
                            <tr
                              key={c.id}
                              id={`row-client-${c.id}`}
                              onClick={() => handleSelectClient(c)}
                              className={`cursor-pointer transition-colors font-medium ${
                                isSelected 
                                  ? 'bg-[#0052cc] text-white font-bold' 
                                  : 'hover:bg-blue-50 text-slate-800'
                              }`}
                            >
                              <td className="py-1 px-1.5 text-center font-mono">
                                <span className="flex items-center justify-center gap-1">
                                  {isSelected ? <Check className="w-3 h-3 text-cyan-200 font-black" /> : null}
                                  <span>{code}</span>
                                </span>
                              </td>
                              <td className="py-1 px-2 font-bold uppercase truncate max-w-[120px]">{c.name}</td>
                              <td className="py-1 px-2 font-mono whitespace-nowrap">{c.phone}</td>
                              <td className="py-1 px-2 uppercase truncate max-w-[110px]">{c.activity || (c.document ? `CNPJ ${c.document}` : 'PARTICULAR')}</td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SELECTED CLIENT FORM FIELDS */}
              <div className="grid grid-cols-12 gap-2 pt-1">
                
                {/* CÓDIGO */}
                <div className="col-span-3">
                  <label className="block text-[10px] font-black text-slate-900 uppercase">CÓDIGO</label>
                  <input
                    type="text"
                    readOnly
                    value={clientCode}
                    className="w-full bg-slate-100 border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-mono font-bold"
                  />
                </div>

                {/* NOME */}
                <div className="col-span-9">
                  <label className="block text-[10px] font-black text-slate-900 uppercase">NOME DO CLIENTE</label>
                  <input
                    type="text"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-bold uppercase"
                  />
                </div>

                {/* TELEFONE */}
                <div className="col-span-6">
                  <label className="block text-[10px] font-black text-slate-900 uppercase">TELEFONE</label>
                  <input
                    type="text"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(formatPhoneNumber(e.target.value))}
                    placeholder="(21) 98369-9728"
                    className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-mono font-bold"
                  />
                </div>

                {/* ATIVIDADE */}
                <div className="col-span-6">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[10px] font-black text-slate-900 uppercase">
                      RAMO / ATIVIDADE
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowActivitiesModal(true)}
                      className="text-[10px] font-black text-blue-900 hover:text-blue-700 flex items-center gap-1 underline cursor-pointer"
                      title="Cadastrar ou Excluir Atividades"
                    >
                      <Building2 className="w-3 h-3 text-blue-800" />
                      <span>Gerenciar Atividades</span>
                    </button>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <select
                      value={clientActivity}
                      onChange={(e) => {
                        if (e.target.value === 'ADD_NEW') {
                          setShowActivitiesModal(true);
                        } else {
                          setClientActivity(e.target.value);
                        }
                      }}
                      className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-extrabold uppercase cursor-pointer focus:border-blue-600 focus:outline-hidden"
                    >
                      {activitiesList.map((act) => (
                        <option key={act} value={act}>
                          {act}
                        </option>
                      ))}
                      <option value="ADD_NEW" className="font-extrabold text-blue-800">
                        + Cadastrar Nova Atividade...
                      </option>
                    </select>
                    <button
                      type="button"
                      onClick={() => setShowActivitiesModal(true)}
                      className="px-2 py-1 bg-[#1b365d] hover:bg-blue-900 text-white font-extrabold text-[10px] uppercase rounded border border-blue-900 shadow-2xs flex items-center gap-1 shrink-0 cursor-pointer"
                      title="Cadastrar / Excluir Atividades"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Cadastrar / Excluir</span>
                    </button>
                  </div>
                </div>

                {/* DATA DE ENTRADA */}
                <div className="col-span-6">
                  <label className="block text-[10px] font-extrabold text-slate-700 uppercase">DATA DE ENTRADA</label>
                  <input
                    type="date"
                    value={entryDate}
                    onChange={(e) => setEntryDate(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-mono font-bold"
                  />
                </div>

                {/* ORDEM DE ENTRADA */}
                <div className="col-span-6">
                  <label className="block text-[10px] font-extrabold text-slate-700 uppercase">ORDEM DE ENTRADA</label>
                  <input
                    type="text"
                    value={entryOSNumber}
                    onChange={(e) => setEntryOSNumber(e.target.value)}
                    className="w-full bg-slate-100 border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-mono font-black text-blue-900"
                  />
                </div>

                {/* RECEBEDOR DO EQUIPAMENTO */}
                <div className="col-span-12">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[10px] font-extrabold text-slate-700 uppercase">
                      PESSOA / ATENDENTE RECEBEDORA DO EQUIPAMENTO
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowReceiversModal(true)}
                      className="text-[10px] font-black text-blue-900 hover:text-blue-700 flex items-center gap-1 underline cursor-pointer"
                      title="Cadastrar ou Excluir Recebedores"
                    >
                      <UserPlus className="w-3 h-3 text-blue-800" />
                      <span>Gerenciar Recebedores</span>
                    </button>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <select
                      value={receiverName}
                      onChange={(e) => {
                        if (e.target.value === 'ADD_NEW') {
                          setShowReceiversModal(true);
                        } else {
                          setReceiverName(e.target.value);
                        }
                      }}
                      className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-extrabold uppercase cursor-pointer focus:border-blue-600 focus:outline-hidden"
                    >
                      {activeReceivers.map((r) => (
                        <option key={r} value={r}>
                          {r}
                        </option>
                      ))}
                      <option value="ADD_NEW" className="font-extrabold text-blue-800">
                        + Cadastrar Novo Recebedor...
                      </option>
                    </select>
                    <button
                      type="button"
                      onClick={() => setShowReceiversModal(true)}
                      className="px-2.5 py-1 bg-[#1b365d] hover:bg-blue-900 text-white font-extrabold text-[10px] uppercase rounded border border-blue-900 shadow-2xs flex items-center gap-1 shrink-0 cursor-pointer"
                      title="Cadastrar / Excluir Recebedores"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Cadastrar / Excluir</span>
                    </button>
                  </div>
                </div>

                {/* CARACTERISTICA E VALOR ESTIMADO */}
                <div className="col-span-12 sm:col-span-8">
                  <label className="block text-[10px] font-extrabold text-slate-700 uppercase">CARACTERÍSTICA DO ATENDIMENTO</label>
                  <select
                    value={caracteristica}
                    onChange={(e) => handleCaracteristicaChange(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-extrabold uppercase cursor-pointer"
                  >
                    <option value="ORÇAMENTO TÉCNICO NORMAL">ORÇAMENTO TÉCNICO NORMAL</option>
                    <option value="SERVIÇO EM GARANTIA">SERVIÇO EM GARANTIA</option>
                    <option value="REVISÃO PREVENTIVA">REVISÃO PREVENTIVA</option>
                    <option value="ATENDIMENTO URGENTE / PRIORITÁRIO">ATENDIMENTO URGENTE / PRIORITÁRIO</option>
                  </select>
                </div>

                <div className="col-span-12 sm:col-span-4">
                  <div className="flex items-center justify-between">
                    <label className="block text-[10px] font-extrabold text-slate-700 uppercase">
                      VALOR ESTIMADO (R$)
                    </label>
                    {caracteristica.includes('GARANTIA') && (
                      <span className="text-[9px] font-black text-emerald-800 uppercase bg-emerald-100 px-1 rounded">
                        GARANTIA
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <span className="absolute left-2 top-1 text-xs font-bold text-slate-500">R$</span>
                    <input
                      type="text"
                      value={estimatedValue}
                      onChange={(e) => setEstimatedValue(e.target.value)}
                      placeholder="0,00"
                      className={`w-full bg-white border rounded pl-8 pr-2 py-1 text-xs font-mono font-black ${
                        caracteristica.includes('GARANTIA') && (estimatedValue === '0,00' || estimatedValue === '0')
                          ? 'border-emerald-500 text-emerald-700 bg-emerald-50/40'
                          : 'border-slate-400 text-slate-900'
                      }`}
                    />
                  </div>
                </div>

                {caracteristica.includes('GARANTIA') && (
                  <div className="col-span-12 p-2.5 bg-amber-50 border-2 border-amber-400 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 text-amber-900 font-bold">
                      <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                      <span>Entrada de equipamento com retorno em garantia.</span>
                    </div>
                    {onOpenWarrantyTab && (
                      <button
                        type="button"
                        onClick={onOpenWarrantyTab}
                        className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase rounded shadow-2xs flex items-center gap-1 cursor-pointer shrink-0"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Consultar no Controle de Garantia ➔</span>
                      </button>
                    )}
                  </div>
                )}

              </div>

            </div>

            {/* PANEL 1 FOOTER ACTIONS */}
            <div className="flex items-center justify-between gap-2 pt-3 mt-2 border-t border-slate-300">
              <div className="bg-[#fef9c3] border border-[#fde047] rounded px-2 py-1 flex items-center gap-1.5 shadow-2xs">
                <Handshake className="w-3.5 h-3.5 text-amber-800 shrink-0" />
                <span className="font-extrabold text-[10px] text-amber-950 uppercase">ATENDIMENTO ATIVO</span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => showToast('Alterações no cliente salvas.', 'success')}
                  className="px-2.5 py-1.5 bg-white hover:bg-emerald-50 border border-emerald-600 text-emerald-700 font-extrabold text-[11px] rounded shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Salvar Cliente</span>
                </button>

                <button
                  type="button"
                  id="btn-limpar-todos-campos-panel1"
                  onClick={() => {
                    handleResetForm();
                    showToast('Janelas limpas para um novo lançamento.', 'info');
                  }}
                  className="px-2.5 py-1.5 bg-white hover:bg-red-50 border border-red-400 text-red-600 font-extrabold text-[11px] rounded shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                  title="Limpar todos os campos para novo lançamento"
                >
                  <X className="w-3.5 h-3.5 text-red-500" />
                  <span>Limpar Tudo</span>
                </button>
              </div>
            </div>

          </div>


          {/* ========================================================================= */}
          {/* PANEL 2: EQUIPAMENTO SECTION */}
          {/* ========================================================================= */}
          <div className="bg-[#e4e9f0] border-2 border-[#b0bec5] rounded-lg p-3 shadow-sm relative flex flex-col justify-between" id="section-equipamento-panel">
            
            {/* Section Legend Label */}
            <div className="absolute -top-3.5 left-4 bg-[#1b365d] text-white px-2 py-0.5 border border-blue-900 rounded text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 shadow-xs z-10">
              <Cpu className="w-3.5 h-3.5 text-cyan-300" />
              <span>2. EQUIPAMENTO E DEFEITO</span>
            </div>

            <div className="space-y-2 mt-1">
              
              {/* ANTIDUPLICITY LIVE ALERT BANNER */}
              {activeEquipDuplicateOrders.length > 0 && (
                <div className="bg-amber-100 border border-amber-500 rounded p-2 text-xs text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1.5 shadow-xs">
                  <div className="flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-amber-700 animate-bounce shrink-0" />
                    <span className="font-extrabold uppercase text-[10px] text-amber-900">
                      OS EM ABERTO ({activeEquipDuplicateOrders.map(o => o.osNumber).join(', ')})
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setDuplicateOrdersFound(activeEquipDuplicateOrders);
                      setShowDuplicateModal(true);
                    }}
                    className="px-2 py-0.5 bg-amber-800 hover:bg-amber-900 text-white rounded text-[9px] font-black uppercase cursor-pointer shrink-0 transition-colors flex items-center gap-1"
                  >
                    <ShieldCheck className="w-3 h-3 text-amber-200" />
                    <span>VER OS</span>
                  </button>
                </div>
              )}

              {/* SEARCH & EQUIPMENT TABLE */}
              <div className="flex flex-col space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-black text-slate-900 uppercase tracking-wider">PESQUISA DE EQUIPAMENTO</label>
                  <button
                    type="button"
                    id="btn-cad-equip-open"
                    onClick={() => setShowAddEquipModal(true)}
                    className="px-2.5 py-0.5 bg-[#1d4ed8] hover:bg-[#1e40af] text-white text-[10px] font-extrabold uppercase rounded border border-blue-400 shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Cpu className="w-3 h-3" />
                    <span>CAD. EQUIP</span>
                  </button>
                </div>
                <div className="relative">
                  <input
                    id="input-search-equip"
                    type="text"
                    placeholder="DIGITE NOME, MODELO OU MARCA..."
                    value={equipSearch}
                    onChange={(e) => setEquipSearch(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded px-2.5 py-1 text-xs text-slate-900 font-bold uppercase tracking-tight focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-500 shadow-inner"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2" />
                </div>

                {/* Equipment Data Grid Table - Compact Height */}
                <div className="border border-slate-400 rounded bg-white overflow-hidden shadow-inner h-36 overflow-y-auto">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="bg-slate-200 border-b border-slate-300 text-slate-950 font-black uppercase sticky top-0 z-10 shadow-2xs">
                        <th className="py-1 px-1.5 w-14 text-center text-slate-950 font-black">CÓDIGO</th>
                        <th className="py-1 px-2 text-slate-950 font-black">EQUIPAMENTO</th>
                        <th className="py-1 px-2 text-slate-950 font-black">PATRIMÔNIO / FILIAL</th>
                        <th className="py-1 px-2 text-slate-950 font-black">MODELO</th>
                        <th className="py-1 px-2 text-slate-950 font-black">FABRICANTE</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredEquipments.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-4 text-center text-slate-500 text-xs">
                            Nenhum equipamento cadastrado.
                          </td>
                        </tr>
                      ) : (
                        filteredEquipments.map((eq) => {
                          const isSelected = (selectedEquipId === eq.id);
                          const code = eq.id.slice(-3).padStart(3, '0');
                          const isEquipActiveInShop = activeClient && orders.some(o => 
                            o.clientId === activeClient.id && 
                            (o.equipmentId === eq.id || equipments.find(e => e.id === o.equipmentId)?.name.toLowerCase() === eq.name.toLowerCase()) &&
                            o.status !== 'CANCELLED' && 
                            !o.isDelivered
                          );
                          return (
                            <tr
                              key={eq.id}
                              id={`row-equip-${eq.id}`}
                              onClick={() => handleSelectEquipment(eq)}
                              className={`cursor-pointer transition-colors font-medium ${
                                isSelected 
                                  ? 'bg-[#0052cc] text-white font-bold' 
                                  : isEquipActiveInShop
                                  ? 'bg-amber-50 hover:bg-amber-100 text-amber-950 font-semibold'
                                  : 'hover:bg-blue-50 text-slate-800'
                              }`}
                            >
                              <td className="py-1 px-1.5 text-center font-mono">
                                <span className="flex items-center justify-center gap-1">
                                  {isSelected ? <Check className="w-3 h-3 text-cyan-200 font-black" /> : null}
                                  <span>EQ-{code}</span>
                                </span>
                              </td>
                              <td className="py-1 px-2 font-bold uppercase truncate max-w-[110px]">
                                <span className="flex items-center gap-1">
                                  <span>{eq.name}</span>
                                  {isEquipActiveInShop && (
                                    <span className="bg-amber-200 text-amber-900 border border-amber-400 text-[9px] font-black px-1 rounded uppercase shrink-0">
                                      OS Aberta
                                    </span>
                                  )}
                                </span>
                              </td>
                              <td className="py-1 px-2 font-mono text-[10px] truncate max-w-[110px]">
                                {eq.patrimonyNumber ? (
                                  <span className={`px-1.5 py-0.5 rounded font-bold border ${
                                    isSelected 
                                      ? 'bg-amber-400 text-slate-950 border-amber-300' 
                                      : 'bg-amber-100 text-amber-900 border-amber-300'
                                  }`} title={`Patrimônio / Filial: ${eq.patrimonyNumber}`}>
                                    {eq.patrimonyNumber}
                                  </span>
                                ) : (
                                  <span className="text-slate-400 italic text-[9px]">S/ Patr</span>
                                )}
                              </td>
                              <td className="py-1 px-2 uppercase truncate max-w-[100px]">{eq.model}</td>
                              <td className="py-1 px-2 uppercase truncate max-w-[90px]">{eq.type || 'JC&F'}</td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SELECTED EQUIPMENT FORM FIELDS */}
              <div className="grid grid-cols-12 gap-2 pt-1">
                
                {/* CODIGO */}
                <div className="col-span-3">
                  <label className="block text-[10px] font-black text-slate-900 uppercase">CÓDIGO</label>
                  <input
                    type="text"
                    readOnly
                    value={`EQ-${equipCode}`}
                    className="w-full bg-slate-100 border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-mono font-bold"
                  />
                </div>

                {/* EQUIPAMENTO */}
                <div className="col-span-9">
                  <label className="block text-[10px] font-black text-slate-900 uppercase">NOME DO EQUIPAMENTO</label>
                  <input
                    type="text"
                    value={equipName}
                    onChange={(e) => setEquipName(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-bold uppercase"
                  />
                </div>

                {/* MODELO */}
                <div className="col-span-4">
                  <label className="block text-[10px] font-black text-slate-900 uppercase">MODELO</label>
                  <input
                    type="text"
                    value={equipModel}
                    onChange={(e) => setEquipModel(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-bold uppercase"
                  />
                </div>

                {/* FABRICANTE */}
                <div className="col-span-4">
                  <label className="block text-[10px] font-black text-slate-900 uppercase">FABRICANTE</label>
                  <input
                    type="text"
                    value={equipBrand}
                    onChange={(e) => setEquipBrand(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded px-2 py-1 text-xs text-slate-900 font-bold uppercase"
                  />
                </div>

                {/* PATRIMÔNIO / TAG / FILIAL */}
                <div className="col-span-4">
                  <label className="block text-[10px] font-black text-amber-900 uppercase flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                      <span>PATRIMÔNIO / FILIAL</span>
                    </span>
                    <span className="text-[9px] font-normal text-slate-500 normal-case">(se houver)</span>
                  </label>
                  <input
                    type="text"
                    id="input-patrimonio-checkin"
                    value={equipPatrimony}
                    onChange={(e) => setEquipPatrimony(e.target.value.toUpperCase())}
                    placeholder="Ex: PAT-014, FILIAL-SP, TAG-02"
                    className="w-full bg-amber-50/50 border border-amber-400 rounded px-2 py-1 text-xs text-amber-950 font-mono font-bold uppercase placeholder:text-slate-400 focus:outline-hidden focus:border-amber-600 focus:ring-1 focus:ring-amber-500 shadow-inner"
                    title="Patrimônio do equipamento, Tag de identificação ou Sigla da Filial"
                  />
                </div>

                {/* DEFEITO APRESENTADO TITLE & SALVAR ACTION */}
                <div className="col-span-12 flex items-center justify-between pt-1">
                  <label className="text-[10px] font-extrabold text-amber-800 uppercase flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    <span>DEFEITO APRESENTADO / RECLAMAÇÃO DO CLIENTE</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleSaveDefect}
                    className="text-[10px] font-black text-blue-700 hover:text-blue-900 uppercase underline cursor-pointer flex items-center gap-1"
                  >
                    <Check className="w-3 h-3 text-emerald-600" />
                    <span>SALVAR ALTERAÇÃO</span>
                  </button>
                </div>

                {/* DEFEITO TEXTAREA */}
                <div className="col-span-12">
                  <textarea
                    rows={2}
                    value={defeitoApresentado}
                    onChange={(e) => setDefeitoApresentado(e.target.value)}
                    className="w-full bg-white border border-slate-400 rounded p-1.5 text-xs font-bold text-slate-900 uppercase font-mono shadow-inner leading-relaxed focus:outline-hidden focus:border-blue-600"
                  />
                </div>

                {/* FOTO DO EQUIPAMENTO (CHECK-IN) */}
                <div className="col-span-12 bg-slate-200/90 border border-slate-400 rounded p-2 shadow-2xs">
                  <div className="flex flex-wrap items-center justify-between gap-1.5 mb-1">
                    <label className="text-[10px] font-black text-slate-800 uppercase flex items-center gap-1">
                      <Camera className="w-3.5 h-3.5 text-blue-700" />
                      <span>FOTO DE RECEPÇÃO / CHECK-IN</span>
                    </label>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        id="btn-open-camera-checkin"
                        onClick={handleStartCamera}
                        className="px-2 py-0.5 bg-blue-700 hover:bg-blue-800 text-white text-[10px] font-black uppercase rounded shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Camera className="w-3 h-3 text-cyan-200" />
                        <span>Câmera</span>
                      </button>

                      <button
                        type="button"
                        id="btn-upload-file-checkin"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-2 py-0.5 bg-slate-700 hover:bg-slate-800 text-white text-[10px] font-black uppercase rounded shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Upload className="w-3 h-3 text-amber-300" />
                        <span>Anexar</span>
                      </button>

                      <input
                        type="file"
                        ref={fileInputRef}
                        accept="image/*"
                        capture="environment"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </div>
                  </div>

                  {/* PHOTO PREVIEW BOX */}
                  {equipmentPhoto ? (
                    <div className="relative group rounded overflow-hidden border-2 border-emerald-500 bg-black/90 min-h-[60px] max-h-28 flex items-center justify-center p-1">
                      <img
                        src={equipmentPhoto}
                        alt="Foto do Equipamento"
                        className="max-h-24 object-contain rounded"
                      />
                      <button
                        type="button"
                        onClick={() => setEquipmentPhoto('')}
                        className="absolute top-1 right-1 px-2 py-0.5 bg-red-600 hover:bg-red-700 text-white text-[9px] font-bold rounded shadow-md flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Remover</span>
                      </button>
                    </div>
                  ) : (
                    <div
                      onClick={handleStartCamera}
                      className="border border-dashed border-slate-400 hover:border-blue-600 rounded p-1.5 bg-white/70 hover:bg-white text-center cursor-pointer transition-all flex items-center justify-center gap-2 text-slate-600 hover:text-blue-800"
                    >
                      <Camera className="w-4 h-4 text-slate-500" />
                      <span className="text-[10px] font-black uppercase">Clique aqui para Tirar ou Anexar Foto do Equipamento</span>
                    </div>
                  )}
                </div>

              </div>

            </div>

            {/* PANEL 2 FOOTER ACTIONS */}
            <div className="flex items-center justify-between gap-2 pt-3 mt-2 border-t border-slate-300">
              <div className="bg-slate-200 border border-slate-400 px-2 py-1 rounded text-[10px] font-extrabold text-slate-700 uppercase">
                MODELOS: <span className="text-blue-900 font-black">{filteredEquipments.length}</span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  id="btn-tab-preco-open"
                  onClick={() => setShowPriceTableModal(true)}
                  className="px-3 py-1.5 bg-[#fef08a] hover:bg-[#fde047] text-amber-950 font-black text-[11px] uppercase tracking-wider rounded border border-amber-400 shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <DollarSign className="w-3.5 h-3.5 text-amber-800" />
                  <span>TAB. PREÇO</span>
                </button>
              </div>
            </div>

          </div>

        </div>

        {/* PERSISTENT FLOATING STICKY ACTION BAR FOR FULL VISIBILITY */}
        <div className="sticky bottom-2 z-30 bg-[#003b7a] border-2 border-blue-900 rounded-xl p-3 shadow-2xl text-white flex flex-col md:flex-row items-center justify-between gap-3 backdrop-blur-md">
          <div className="flex items-center gap-3 text-xs font-mono font-bold truncate">
            <span className="px-2 py-0.5 bg-cyan-900 text-cyan-200 rounded border border-cyan-500/40 text-[10px]">RECEPÇÃO OS</span>
            <span className="truncate">CLIENTE: <strong className="text-cyan-200 uppercase">{clientName || 'NÃO SELECIONADO'}</strong></span>
            <span className="text-slate-400">|</span>
            <span className="truncate">EQUIP: <strong className="text-cyan-200 uppercase">{equipName || 'NÃO SELECIONADO'}</strong></span>
            {equipPatrimony && (
              <>
                <span className="text-slate-400">|</span>
                <span className="truncate text-amber-300">PATR/FILIAL: <strong className="text-amber-200 uppercase font-black">{equipPatrimony}</strong></span>
              </>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2 w-full md:w-auto">
            <button
              type="button"
              id="btn-sticky-cadastrar-gerar-os"
              onClick={() => handleCreateNewOrder()}
              className="flex-1 md:flex-initial px-5 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs uppercase tracking-wider rounded-lg border-2 border-emerald-300 shadow-lg cursor-pointer transition-all flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4 text-white" />
              <span>CADASTRAR E GERAR OS</span>
            </button>

            <button
              type="button"
              id="btn-sticky-novo-lancamento"
              onClick={() => {
                handleResetForm();
                showToast('Janelas limpas para um novo lançamento.', 'info');
              }}
              className="px-3 py-2 bg-slate-700 hover:bg-slate-800 text-white font-black text-xs uppercase tracking-wider rounded-lg border border-slate-500 shadow cursor-pointer transition-all flex items-center justify-center gap-1"
              title="Limpar todos os campos"
            >
              <RefreshCw className="w-3.5 h-3.5 text-cyan-200" />
              <span>NOVO LANÇAMENTO</span>
            </button>

            <button
              type="button"
              id="btn-sticky-imprimir"
              onClick={handlePrintReceipt}
              className="px-3 py-2 bg-[#ea580c] hover:bg-[#c2410c] text-white font-extrabold text-xs uppercase tracking-wider rounded-lg border border-amber-300 shadow cursor-pointer transition-all flex items-center justify-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>COMPROVANTE</span>
            </button>
          </div>
        </div>

      </div>

      {/* BOTTOM SYSTEM STATUS BAR */}
      <div className="bg-[#1b365d] border-t-2 border-blue-950 text-white px-3.5 py-2 rounded-b-lg flex flex-col md:flex-row items-center justify-between text-[11px] font-extrabold font-mono shadow-inner" id="system-statusbar">
        <div className="flex items-center gap-2">
          <span className="text-cyan-300 uppercase">STATUS:</span>
          <span>CLIENTE: <span className="text-white font-black uppercase">{clientName || 'NENHUM'}</span></span>
          <span className="text-cyan-400">•</span>
          <span>EQUIPAMENTO: <span className="text-white font-black uppercase">{equipName || 'NENHUM'}</span></span>
          {equipPatrimony && (
            <>
              <span className="text-cyan-400">•</span>
              <span>PATRIMÔNIO: <span className="text-amber-300 font-black uppercase font-mono">{equipPatrimony}</span></span>
            </>
          )}
        </div>
        <div className="flex items-center gap-3">
          <span>REGISTROS: <span className="text-cyan-200 font-bold">{orders.length} OS</span></span>
          <span className="text-cyan-100 font-bold">JC&F SISTEMAS HIDRÁULICOS E PNEUMÁTICOS</span>
        </div>
      </div>


      {/* ========================================================================= */}
      {/* MODAL: REGISTER NEW CLIENT */}
      {/* ========================================================================= */}
      {showAddClientModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border-2 border-blue-600 max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-extrabold text-sm text-blue-900 uppercase flex items-center gap-1.5">
                <UserPlus className="w-4 h-4 text-blue-600" />
                <span>CADASTRAR NOVO CLIENTE</span>
              </h3>
              <button type="button" onClick={() => setShowAddClientModal(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              const form = e.target as HTMLFormElement;
              const name = (form.elements.namedItem('cname') as HTMLInputElement).value;
              const phone = (form.elements.namedItem('cphone') as HTMLInputElement).value;
              const doc = (form.elements.namedItem('cdoc') as HTMLInputElement).value;
              const act = (form.elements.namedItem('cact') as HTMLSelectElement)?.value || 'PARTICULAR';
              if (name && phone) {
                const created = onAddClient({ name, phone, document: doc || 'N/A', address: 'N/A', activity: act });
                setSelectedClientId(created.id);
                setClientCode(created.id.slice(-3).padStart(3, '0'));
                setClientName(created.name.toUpperCase());
                setClientPhone(formatPhoneNumber(created.phone));
                setClientActivity(created.activity || 'PARTICULAR');
                setShowAddClientModal(false);
                showToast(`Cliente "${name}" cadastrado com sucesso!`, 'success');
              }
            }} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">Nome Completo / Razão *</label>
                <input
                  name="cname"
                  type="text"
                  required
                  placeholder="Ex: MARCOS DA SILVA"
                  className="w-full bg-white border border-slate-400 rounded px-3 py-2 text-xs uppercase font-bold text-black placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">Telefone / WhatsApp *</label>
                <input
                  name="cphone"
                  type="text"
                  required
                  placeholder="Ex: (21) 98369-9728"
                  onChange={(e) => {
                    e.target.value = formatPhoneNumber(e.target.value);
                  }}
                  className="w-full bg-white border border-slate-400 rounded px-3 py-2 text-xs font-mono font-bold text-black placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">CPF ou CNPJ</label>
                <input
                  name="cdoc"
                  type="text"
                  placeholder="Ex: 123.456.789-00"
                  className="w-full bg-white border border-slate-400 rounded px-3 py-2 text-xs font-mono font-bold text-black placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">Ramo / Atividade do Cliente</label>
                <select
                  name="cact"
                  defaultValue="PARTICULAR"
                  className="w-full bg-white border border-slate-400 rounded px-3 py-2 text-xs uppercase font-bold text-black focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner cursor-pointer"
                >
                  {activitiesList.map(a => (
                    <option key={a} value={a} className="bg-white text-black font-bold">{a}</option>
                  ))}
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t">
                <button type="button" onClick={() => setShowAddClientModal(false)} className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded cursor-pointer">CANCELAR</button>
                <button type="submit" className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded cursor-pointer shadow-md">SALVAR CLIENTE</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: REGISTER NEW EQUIPMENT */}
      {/* ========================================================================= */}
      {showAddEquipModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border-2 border-blue-600 max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-extrabold text-sm text-blue-900 uppercase flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-blue-600" />
                <span>CADASTRAR NOVO EQUIPAMENTO</span>
              </h3>
              <button type="button" onClick={() => setShowAddEquipModal(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              const form = e.target as HTMLFormElement;
              const name = (form.elements.namedItem('ename') as HTMLInputElement).value;
              const model = (form.elements.namedItem('emodel') as HTMLInputElement).value;
              const brand = (form.elements.namedItem('ebrand') as HTMLInputElement).value;
              const patrimony = (form.elements.namedItem('epatrimony') as HTMLInputElement)?.value;
              if (name && model) {
                const created = onAddEquipment({ 
                  name, 
                  model, 
                  type: brand || 'JC&F', 
                  patrimonyNumber: patrimony ? patrimony.trim().toUpperCase() : undefined,
                  clientId: selectedClientId 
                });
                setSelectedEquipId(created.id);
                setEquipCode(created.id.slice(-3).padStart(3, '0'));
                setEquipName(created.name.toUpperCase());
                setEquipModel(created.model.toUpperCase());
                setEquipBrand((created.type || 'JC&F').toUpperCase());
                setEquipPatrimony((created.patrimonyNumber || '').toUpperCase());
                setShowAddEquipModal(false);
                showToast(`Equipamento "${name}" cadastrado!`, 'success');
              }
            }} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">Nome do Equipamento *</label>
                <input
                  name="ename"
                  type="text"
                  required
                  placeholder="Ex: MONITOR GAMER 27 ou BOMBA PISTÃO"
                  className="w-full bg-white border border-slate-400 rounded px-3 py-2 text-xs uppercase font-bold text-black placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">Modelo / Nº Série *</label>
                <input
                  name="emodel"
                  type="text"
                  required
                  placeholder="Ex: ODYSSEY G5 ou PV-046"
                  className="w-full bg-white border border-slate-400 rounded px-3 py-2 text-xs uppercase font-bold text-black placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">Fabricante / Marca</label>
                <input
                  name="ebrand"
                  type="text"
                  placeholder="Ex: SAMSUNG, PARKER, REXROTH"
                  className="w-full bg-white border border-slate-400 rounded px-3 py-2 text-xs uppercase font-bold text-black placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-amber-900 uppercase mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                    <span>Nº de Patrimônio / Tag / Filial</span>
                  </span>
                  <span className="text-[10px] font-normal text-slate-500 normal-case">(se houver)</span>
                </label>
                <input
                  name="epatrimony"
                  type="text"
                  placeholder="Ex: PAT-014, FILIAL-SP, TAG-02"
                  className="w-full bg-amber-50/60 border border-amber-400 rounded px-3 py-2 text-xs uppercase font-mono font-bold text-black placeholder-slate-400 focus:outline-hidden focus:border-amber-600 focus:ring-2 focus:ring-amber-500 shadow-inner"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t">
                <button type="button" onClick={() => setShowAddEquipModal(false)} className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded cursor-pointer">CANCELAR</button>
                <button type="submit" className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded cursor-pointer shadow-md">SALVAR EQUIPAMENTO</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: PRICE TABLE POPUP */}
      {/* ========================================================================= */}
      {showPriceTableModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border-2 border-amber-400 max-w-lg w-full p-5 space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-extrabold text-sm text-amber-900 uppercase flex items-center gap-1.5">
                <DollarSign className="w-5 h-5 text-amber-600" />
                <span>TABELA DE PREÇOS DE MANUTENÇÃO TÉCNICA</span>
              </h3>
              <button type="button" onClick={() => setShowPriceTableModal(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-72 overflow-y-auto divide-y text-xs">
              <div className="py-2 flex justify-between font-bold bg-amber-50 px-2 rounded">
                <span>CÓD. • SERVIÇO / PROCEDIMENTO</span>
                <span>VALOR ESTIMADO</span>
              </div>
              {services.length > 0 ? (
                services.map((s) => (
                  <div key={s.id} className="py-2 px-2 flex items-center justify-between hover:bg-slate-50">
                    <div>
                      <span className="font-mono text-[10px] font-bold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded mr-1.5">{s.code}</span>
                      <span className="font-bold text-slate-800">{s.name}</span>
                    </div>
                    <span className="font-mono font-black text-emerald-700">
                      R$ {s.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                ))
              ) : (
                <>
                  <div className="py-2 px-2 flex justify-between"><span>Diagnóstico Técnico em Bancada</span><span className="font-mono font-bold text-emerald-700">R$ 80,00</span></div>
                  <div className="py-2 px-2 flex justify-between"><span>Troca de Conector de Carga / Alimentação</span><span className="font-mono font-bold text-emerald-700">R$ 120,00</span></div>
                  <div className="py-2 px-2 flex justify-between"><span>Reparo de Placa Mãe / Fonte Interna</span><span className="font-mono font-bold text-emerald-700">R$ 250,00</span></div>
                  <div className="py-2 px-2 flex justify-between"><span>Limpeza Interna e Troca de Pasta Térmica</span><span className="font-mono font-bold text-emerald-700">R$ 100,00</span></div>
                </>
              )}
            </div>

            <div className="flex items-center justify-between pt-3 border-t gap-2">
              {onOpenPriceTableTab && (
                <button
                  type="button"
                  onClick={() => {
                    setShowPriceTableModal(false);
                    onOpenPriceTableTab();
                  }}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase rounded-lg border border-emerald-400 shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Briefcase className="w-4 h-4 text-emerald-200" />
                  <span>Cadastrar / Gerenciar Tabela</span>
                </button>
              )}

              <button type="button" onClick={() => setShowPriceTableModal(false)} className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-lg cursor-pointer">
                FECHAR TABELA
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: REGISTERED ORDERS LIST */}
      {/* ========================================================================= */}
      {showOrdersListModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border-2 border-blue-600 max-w-2xl w-full p-5 space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-extrabold text-sm text-blue-900 uppercase flex items-center gap-1.5">
                <FileText className="w-5 h-5 text-blue-600" />
                <span>ORDENS REGISTRADAS NO SISTEMA ({orders.length})</span>
              </h3>
              <button type="button" onClick={() => setShowOrdersListModal(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-80 overflow-y-auto divide-y border rounded text-xs">
              {orders.map((o) => {
                const client = clients.find(c => c.id === o.clientId);
                const equip = equipments.find(e => e.id === o.equipmentId);
                return (
                  <div key={o.id} className="p-3 flex items-center justify-between gap-3 hover:bg-slate-50">
                    <div>
                      <div className="font-mono font-bold text-blue-800">{o.osNumber} — <span className="text-slate-900 font-sans">{o.title}</span></div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex flex-wrap items-center gap-x-2">
                        <span>Cliente: <strong>{client?.name || 'N/A'}</strong></span>
                        <span>|</span>
                        <span>Equipamento: <strong>{equip?.name || 'N/A'}</strong></span>
                        {(o.patrimonyNumber || equip?.patrimonyNumber) && (
                          <>
                            <span>|</span>
                            <span className="text-amber-800 bg-amber-100 border border-amber-300 px-1.5 py-0.2 rounded font-mono font-bold text-[10px]">
                              Patr/Filial: {o.patrimonyNumber || equip?.patrimonyNumber}
                            </span>
                          </>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 italic mt-0.5 max-w-md truncate">"{o.description}"</div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        o.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800' :
                        o.status === 'IN_PROGRESS' ? 'bg-blue-100 text-blue-800' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {o.status}
                      </span>
                      {onDeleteOrder && (
                        <button
                          type="button"
                          id={`registry-btn-delete-os-${o.id}`}
                          onClick={() => {
                            if (window.confirm(`Tem certeza que deseja excluir a Ordem de Serviço ${o.osNumber}?`)) {
                              onDeleteOrder(o.id);
                              showToast(`OS ${o.osNumber} excluída com sucesso!`, 'success');
                            }
                          }}
                          className="px-2 py-1 bg-red-100 hover:bg-red-600 text-red-700 hover:text-white border border-red-300 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                          title="Excluir OS"
                        >
                          <Trash2 className="w-3 h-3 text-red-600 group-hover:text-white" />
                          <span>Excluir</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-2 border-t">
              <button type="button" onClick={() => setShowOrdersListModal(false)} className="px-4 py-1.5 bg-blue-600 text-white font-bold text-xs rounded">FECHAR LISTA</button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: DISPOSITIVO ANTIDUPLICIDADE DE OS */}
      {/* ========================================================================= */}
      {showDuplicateModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border-2 border-amber-500 max-w-xl w-full overflow-hidden space-y-0 animate-in fade-in zoom-in duration-200">
            
            {/* Modal Warning Header */}
            <div className="bg-gradient-to-r from-red-800 via-amber-800 to-red-900 text-white p-4 border-b-2 border-red-950 flex items-center justify-between shadow-md">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-950/80 rounded-lg border border-red-500/50 text-amber-300">
                  <ShieldAlert className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-black text-sm uppercase tracking-wider text-white flex items-center gap-2">
                    <span>DISPOSITIVO ANTIDUPLICIDADE DE OS</span>
                  </h3>
                  <p className="text-[11px] text-amber-200 font-medium">
                    Prevenção contra criação de Ordens de Serviço repetidas
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowDuplicateModal(false);
                  showToast('Criação de OS bloqueada por duplicidade.', 'info');
                }}
                className="text-amber-200 hover:text-white hover:bg-red-900/50 p-1.5 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content Body */}
            <div className="p-5 space-y-4 bg-slate-50">
              
              {/* Alert Callout */}
              <div className="bg-amber-50 border-l-4 border-amber-500 p-3 rounded-r-lg text-xs text-amber-950 space-y-1 shadow-xs">
                <div className="font-black flex items-center gap-1.5 text-amber-900">
                  <FileWarning className="w-4 h-4 text-amber-700" />
                  <span>OS EM ABERTO DETECTADA PARA ESTE CLIENTE / EQUIPAMENTO</span>
                </div>
                <p className="text-slate-700 leading-relaxed">
                  O sistema identificou que já existe <strong>{duplicateOrdersFound.length} OS cadastrada em aberto</strong> para o cliente <strong className="text-blue-900">{activeClient?.name}</strong> com o equipamento <strong className="text-blue-900">{activeEquip?.name} ({activeEquip?.model})</strong>.
                </p>
              </div>

              {/* Table of Existing OS */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-black uppercase text-slate-700 tracking-wider flex items-center gap-1">
                  <Copy className="w-3.5 h-3.5 text-blue-700" />
                  <span>ORDEM(NS) DE SERVIÇO ATIVA(S) ENCONTRADA(S):</span>
                </label>
                <div className="border border-slate-300 rounded-lg overflow-hidden bg-white shadow-inner max-h-40 overflow-y-auto">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="bg-[#1b365d] text-white font-extrabold uppercase">
                        <th className="py-1.5 px-2.5">Nº OS</th>
                        <th className="py-1.5 px-2">DATA</th>
                        <th className="py-1.5 px-2">STATUS</th>
                        <th className="py-1.5 px-2">DEFEITO CADASTRADO</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {duplicateOrdersFound.map((os) => (
                        <tr key={os.id} className="hover:bg-amber-50/60 font-mono">
                          <td className="py-1.5 px-2.5 font-black text-blue-900">{os.osNumber}</td>
                          <td className="py-1.5 px-2 text-slate-700">{os.startDate}</td>
                          <td className="py-1.5 px-2">
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 uppercase">
                              {os.status}
                            </span>
                          </td>
                          <td className="py-1.5 px-2 text-slate-800 font-sans truncate max-w-[180px]">
                            {os.description}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Twin Equipment Authorization Explanation */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-950 space-y-2">
                <div className="font-black text-blue-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>EQUIPAMENTO DA MESMA FAMÍLIA OU SIGLA DE FILIAL? (AUTORIZAÇÃO DE ENTRADA)</span>
                </div>
                <p className="text-slate-700 text-[11px] leading-relaxed">
                  Quando o cliente possui <strong>vários equipamentos idênticos</strong> ou <strong>equipamentos alocados em diferentes filiais com patrimônio/tag próprios</strong>, você pode <strong>AUTORIZAR</strong> o cadastro desta nova Ordem de Serviço sem conflito.
                </p>
                {equipPatrimony && (
                  <div className="bg-amber-100/70 border border-amber-300 rounded px-2.5 py-1 flex items-center justify-between text-[11px]">
                    <span className="font-bold text-amber-900">Patrimônio / Filial informado:</span>
                    <span className="font-mono font-black text-slate-900 uppercase">{equipPatrimony}</span>
                  </div>
                )}
              </div>

            </div>

            {/* Modal Actions Footer */}
            <div className="bg-slate-100 p-4 border-t border-slate-300 flex flex-col sm:flex-row items-center justify-between gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setShowDuplicateModal(false);
                  showToast('Criação de OS bloqueada por duplicidade.', 'info');
                }}
                className="w-full sm:w-auto px-4 py-2 bg-slate-300 hover:bg-slate-400 text-slate-800 font-black text-xs uppercase tracking-wider rounded border border-slate-400 cursor-pointer transition-colors flex items-center justify-center gap-1.5"
              >
                <X className="w-4 h-4 text-red-600" />
                <span>CANCELAR (BLOQUEAR DUPLICIDADE)</span>
              </button>

              <button
                type="button"
                onClick={() => handleCreateNewOrder(true)}
                className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-wider rounded-lg border border-emerald-400 shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4.5 h-4.5 text-emerald-200" />
                <span>AUTORIZAR CRIAÇÃO DE OS DUPLICADA</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* LIVE CAMERA CAPTURE MODAL */}
      {showCameraModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#112847] border-2 border-cyan-400 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden text-white">
            <div className="bg-[#004a99] p-3.5 flex items-center justify-between border-b border-cyan-500/40">
              <div className="flex items-center gap-2 font-black text-sm uppercase text-white tracking-wider">
                <Camera className="w-5 h-5 text-cyan-300" />
                <span>Captura de Foto do Equipamento</span>
              </div>
              <button
                type="button"
                onClick={handleStopCamera}
                className="p-1 hover:bg-white/10 rounded text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 flex flex-col items-center justify-center bg-black/90">
              <div className="relative w-full aspect-4/3 bg-slate-900 rounded-lg overflow-hidden border border-slate-700 flex items-center justify-center">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 border-2 border-dashed border-cyan-400/40 pointer-events-none rounded-lg" />
              </div>
              <p className="text-[11px] text-slate-300 font-medium mt-2 text-center">
                Posicione o equipamento no centro da tela e clique no botão abaixo para fotografar.
              </p>
            </div>

            <div className="p-3 bg-[#0d1e36] border-t border-slate-800 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleStopCamera}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white font-black text-xs uppercase rounded border border-slate-500 cursor-pointer"
              >
                Cancelar
              </button>

              <button
                type="button"
                onClick={handleCapturePhoto}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase rounded-lg border border-emerald-300 shadow-md flex items-center gap-2 cursor-pointer transition-all animate-pulse hover:animate-none"
              >
                <Camera className="w-4 h-4 text-emerald-200" />
                <span>CAPTURAR FOTO AGORA</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: GERENCIAR RECEBEDORES / ATENDENTES */}
      {showReceiversModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border-2 border-slate-300 rounded-2xl max-w-md w-full p-6 shadow-2xl text-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                  <UserPlus className="w-5 h-5" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900">Gerenciar Recebedores / Atendentes</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowReceiversModal(false)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 font-medium">
              Cadastre os nomes dos atendentes que realizam a recepção de equipamentos na entrada ou remova cadastros desatualizados.
            </p>

            {/* FORMULARIO: NOVO RECEBEDOR */}
            <div className="space-y-2">
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wide">Novo Atendente / Recebedor</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Digite o nome do atendente..."
                  value={newReceiverInput}
                  onChange={(e) => setNewReceiverInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddReceiver(newReceiverInput);
                    }
                  }}
                  className="flex-1 px-3 py-2.5 bg-slate-50 border-2 border-slate-300 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 uppercase focus:outline-hidden focus:border-blue-600 focus:bg-white font-bold transition-all"
                />
                <button
                  type="button"
                  onClick={() => handleAddReceiver(newReceiverInput)}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar</span>
                </button>
              </div>
            </div>

            {/* LISTA DE RECEBEDORES */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wide">
                Atendentes Cadastrados ({activeReceivers.length})
              </label>
              <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                {activeReceivers.map((rec) => (
                  <div
                    key={rec}
                    className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 hover:border-blue-300 hover:bg-blue-50/50 transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                      <span className="uppercase text-slate-900">{rec}</span>
                      {rec === receiverName && (
                        <span className="text-[9px] bg-blue-100 text-blue-800 border border-blue-300 px-1.5 py-0.5 rounded uppercase font-extrabold">
                          Selecionado
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteReceiver(rec)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                      title={`Excluir ${rec}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setShowReceiversModal(false)}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-lg cursor-pointer shadow-xs transition-colors"
              >
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: GERENCIAR RAMOS / ATIVIDADES */}
      {showActivitiesModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#11131c] border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl text-white space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-extrabold text-base text-white">Gerenciar Ramos / Atividades</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowActivitiesModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Cadastre novos ramos ou setores de atividade para seleção nos cadastros de clientes e fichas de entrada, ou remova cadastros desatualizados.
            </p>

            {/* FORMULARIO: NOVO RAMO / ATIVIDADE */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-300 uppercase">Novo Ramo / Atividade</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Ex: FARMACÊUTICA, TÊXTIL..."
                  value={newActivityInput}
                  onChange={(e) => setNewActivityInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddActivity(newActivityInput);
                    }
                  }}
                  className="flex-1 px-3 py-2 bg-[#0a0b10] border border-slate-700 rounded-lg text-xs text-white uppercase focus:outline-hidden focus:border-cyan-500 font-bold"
                />
                <button
                  type="button"
                  onClick={() => handleAddActivity(newActivityInput)}
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold text-xs rounded-lg flex items-center gap-1 cursor-pointer transition-colors shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar</span>
                </button>
              </div>
            </div>

            {/* LISTA DE ATIVIDADES */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <label className="block text-xs font-bold text-slate-400 uppercase">
                Atividades Cadastradas ({activitiesList.length})
              </label>
              <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                {activitiesList.map((act) => (
                  <div
                    key={act}
                    className="flex items-center justify-between p-2.5 bg-[#181b26] border border-slate-800 rounded-lg text-xs font-bold text-slate-200 hover:border-slate-700"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                      <span className="uppercase">{act}</span>
                      {act === clientActivity && (
                        <span className="text-[9px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded uppercase font-bold">
                          Selecionado
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteActivity(act)}
                      className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-950/40 rounded transition-colors cursor-pointer"
                      title={`Excluir ${act}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowActivitiesModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-lg cursor-pointer"
              >
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
