import React, { useState } from 'react';
import { Quote, ServiceOrder } from '../types';
import { JCF_COMPANY_INFO } from '../data/companyConfig';
import { MessageSquare, Mail, Copy, Check, ExternalLink, X, Wrench, ShieldCheck, DollarSign } from 'lucide-react';

interface WhatsAppModalProps {
  quote: Quote;
  isOpen: boolean;
  onClose: () => void;
  onMarkAsSent: (quote: Quote) => void;
  onEditQuote?: (quote: Quote) => void;
}

export function QuoteWhatsAppModal({ quote, isOpen, onClose, onMarkAsSent, onEditQuote }: WhatsAppModalProps) {
  if (!isOpen) return null;

  const rawPhone = quote.clientPhone ? quote.clientPhone.replace(/\D/g, '') : '';
  const initialPhone = rawPhone.startsWith('55') ? rawPhone : (rawPhone ? `55${rawPhone}` : '5521');
  const [targetPhone, setTargetPhone] = useState(initialPhone);
  const [copied, setCopied] = useState(false);

  // Build high-impact professional message
  const quoteTypeTitle = {
    VENDA: 'PROPOSTA DE VENDA DE PEÇAS & COMPONENTES',
    MANUTENCAO_CORRETIVA: 'ORÇAMENTO DE MANUTENÇÃO CORRETIVA',
    MANUTENCAO_PREVENTIVA: 'PROPOSTA DE MANUTENÇÃO PREVENTIVA',
    REVISAO_GERAL: 'ORÇAMENTO DE REFORMA & REVISÃO GERAL',
    OUTROS: 'PROPOSTA COMERCIAL & TÉCNICA'
  }[quote.quoteType || 'MANUTENCAO_CORRETIVA'];

  const itemsText = quote.items
    .map((item, idx) => `  ${idx + 1}. *${item.description}* (${item.quantity} ${item.unit || 'un'}) - R$ ${item.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`)
    .join('\n');

  const defaultMessage = `🛠️ *${quoteTypeTitle}*
*${JCF_COMPANY_INFO.name}*

Olá, *${quote.clientName}*! Segue a proposta comercial elaborada para sua aprovação:

📌 *Proposta:* ${quote.quoteNumber}
⚙️ *Equipamento / Aplicação:* ${quote.equipmentName || 'Venda Direta / Balcão'}
📅 *Emissão:* ${new Date(quote.date + 'T12:00:00').toLocaleDateString('pt-BR')} | *Validade:* ${new Date(quote.validUntil + 'T12:00:00').toLocaleDateString('pt-BR')}

📋 *ITENS & SERVIÇOS:*
${itemsText}

💰 *VALOR TOTAL LÍQUIDO:* *R$ ${quote.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}*
💳 *Condições de Pagamento:* ${quote.paymentTerms}
🔑 *Chave PIX (CNPJ):* ${JCF_COMPANY_INFO.pixKey}
⏱️ *Prazo de Execução/Entrega:* ${quote.deliveryTime}
🛡️ *Garantia:* ${quote.warrantyTerms}
${quote.notes ? `📝 *Observações:* ${quote.notes}\n` : ''}
📍 *Endereço da Oficina:* ${JCF_COMPANY_INFO.address}
📞 *Atendimento:* ${JCF_COMPANY_INFO.phone} | ✉️ *E-mail:* ${JCF_COMPANY_INFO.email}

_Para aprovação ou esclarecimentos, basta responder a esta mensagem!_`;

  const [message, setMessage] = useState(defaultMessage);

  const handleCopy = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSendWhatsApp = () => {
    const cleanPhone = targetPhone.replace(/\D/g, '');
    const url = cleanPhone
      ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(message)}`
      : `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
    
    window.open(url, '_blank');
    onMarkAsSent(quote);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white border border-slate-300 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col my-6">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#1b365d] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-emerald-500 text-slate-950 rounded-lg">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Enviar Orçamento via WhatsApp
              </h3>
              <p className="text-[10px] text-cyan-200">
                Proposta {quote.quoteNumber} para {quote.clientName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-cyan-200 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <div>
            <label className="text-xs font-black uppercase text-slate-700 block mb-1">
              Telefone / WhatsApp de Destino (com DDI e DDD)
            </label>
            <input
              type="text"
              value={targetPhone}
              onChange={(e) => setTargetPhone(e.target.value)}
              placeholder="Ex: 5521983699728"
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 font-mono focus:outline-hidden focus:border-blue-600 focus:bg-white"
            />
            <span className="text-[10px] text-slate-500 mt-1 block">
              Formato internacional: 55 + DDD (2 dígitos) + Número.
            </span>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-black uppercase text-slate-700">
                Mensagem Formatada
              </label>
              <button
                type="button"
                onClick={handleCopy}
                className="text-[10px] font-black text-blue-700 hover:text-blue-900 flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copiado!' : 'Copiar Texto'}</span>
              </button>
            </div>
            <textarea
              rows={10}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-xs text-slate-800 font-mono leading-relaxed focus:outline-hidden focus:border-blue-600 focus:bg-white resize-y"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-100 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          {onEditQuote ? (
            <button
              type="button"
              onClick={() => {
                onClose();
                onEditQuote(quote);
              }}
              className="px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 font-bold rounded-lg text-xs uppercase flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Corrigir valores, itens ou condições do orçamento"
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>Fazer Correções no Orçamento</span>
            </button>
          ) : <div />}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-xs uppercase cursor-pointer transition-colors"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleSendWhatsApp}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Abrir no WhatsApp & Enviar</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface EmailModalProps {
  quote: Quote;
  isOpen: boolean;
  onClose: () => void;
  onMarkAsSent: (quote: Quote) => void;
  onEditQuote?: (quote: Quote) => void;
}

export function QuoteEmailModal({ quote, isOpen, onClose, onMarkAsSent, onEditQuote }: EmailModalProps) {
  if (!isOpen) return null;

  const [recipientEmail, setRecipientEmail] = useState(quote.clientEmail || '');
  const [copied, setCopied] = useState(false);

  const subject = `Proposta Comercial Nº ${quote.quoteNumber} - ${JCF_COMPANY_INFO.name}`;

  const quoteTypeTitle = {
    VENDA: 'Proposta de Venda de Peças e Componentes',
    MANUTENCAO_CORRETIVA: 'Orçamento de Manutenção Corretiva',
    MANUTENCAO_PREVENTIVA: 'Proposta de Manutenção Preventiva',
    REVISAO_GERAL: 'Orçamento de Reforma e Revisão Geral',
    OUTROS: 'Proposta Comercial'
  }[quote.quoteType || 'MANUTENCAO_CORRETIVA'];

  const itemsList = quote.items
    .map((item, idx) => `${idx + 1}. ${item.description} - Qtd: ${item.quantity} ${item.unit || 'un'} - Unitário: R$ ${item.unitPrice.toFixed(2)} - Total: R$ ${item.total.toFixed(2)}`)
    .join('\n');

  const body = `Prezados(as) ${quote.clientName},

Apresentamos nossa proposta técnica e comercial para sua apreciação:

DOCUMENTO: ${quote.quoteNumber}
TIPO: ${quoteTypeTitle}
EQUIPAMENTO: ${quote.equipmentName || 'Venda Direta / Balcão'}
EMISSÃO: ${new Date(quote.date + 'T12:00:00').toLocaleDateString('pt-BR')}
VALIDADE: ${new Date(quote.validUntil + 'T12:00:00').toLocaleDateString('pt-BR')}

DETALHAMENTO DOS ITENS E SERVIÇOS:
${itemsList}

VALOR TOTAL LÍQUIDO: R$ ${quote.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
CONDIÇÕES DE PAGAMENTO: ${quote.paymentTerms}
CHAVE PIX (CNPJ): ${JCF_COMPANY_INFO.pixKey}
PRAZO DE ENTREGA/EXECUÇÃO: ${quote.deliveryTime}
GARANTIA: ${quote.warrantyTerms}
${quote.notes ? `OBSERVAÇÕES: ${quote.notes}\n` : ''}

Ficamos à disposição para quaisquer esclarecimentos.

Atenciosamente,

${JCF_COMPANY_INFO.name}
${JCF_COMPANY_INFO.address}
CNPJ: ${JCF_COMPANY_INFO.cnpj}
Tel: ${JCF_COMPANY_INFO.phone}
E-mail: ${JCF_COMPANY_INFO.email}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(body);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSendEmail = () => {
    const mailtoUrl = `mailto:${recipientEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoUrl;
    onMarkAsSent(quote);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white border border-slate-300 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col my-6">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#1b365d] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-blue-500 text-white rounded-lg">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Enviar Orçamento por E-mail
              </h3>
              <p className="text-[10px] text-cyan-200">
                Proposta {quote.quoteNumber}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-cyan-200 hover:text-white p-1 rounded-lg transition-colors cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <div>
            <label className="text-xs font-black uppercase text-slate-700 block mb-1">
              E-mail do Destinatário
            </label>
            <input
              type="email"
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
              placeholder="cliente@empresa.com.br"
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="text-xs font-black uppercase text-slate-700 block mb-1">
              Assunto
            </label>
            <input
              type="text"
              readOnly
              value={subject}
              className="w-full bg-slate-100 border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono text-slate-800"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-black uppercase text-slate-700">
                Corpo da Mensagem
              </label>
              <button
                type="button"
                onClick={handleCopy}
                className="text-[10px] font-black text-blue-700 hover:text-blue-900 flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copiado!' : 'Copiar Texto'}</span>
              </button>
            </div>
            <textarea
              rows={8}
              readOnly
              value={body}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-xs text-slate-800 font-mono leading-relaxed resize-y"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-100 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          {onEditQuote ? (
            <button
              type="button"
              onClick={() => {
                onClose();
                onEditQuote(quote);
              }}
              className="px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 font-bold rounded-lg text-xs uppercase flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Corrigir valores, itens ou condições do orçamento"
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>Fazer Correções no Orçamento</span>
            </button>
          ) : <div />}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-xs uppercase cursor-pointer transition-colors"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleSendEmail}
              className="px-5 py-2 bg-blue-700 hover:bg-blue-600 text-white font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
            >
              <Mail className="w-4 h-4" />
              <span>Abrir no Cliente de E-mail</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
