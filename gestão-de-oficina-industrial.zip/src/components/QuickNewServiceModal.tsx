import React, { useState, useEffect, useRef } from 'react';
import { PlannedService } from '../types';
import { 
  Briefcase, X, DollarSign, Tag, Layers, FileText, 
  Check, AlertCircle, Sparkles, Keyboard, Plus
} from 'lucide-react';

interface QuickNewServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveService: (serviceData: Omit<PlannedService, 'id' | 'createdAt'>) => PlannedService;
  onServiceCreated?: (newService: PlannedService) => void;
  existingServices?: PlannedService[];
}

const SERVICE_CATEGORIES = [
  'Hidráulica',
  'Pneumática',
  'Usinagem & Caldeiraria',
  'Brunimento & Cromagem',
  'Mecânica Industrial',
  'Elétrica & Automação',
  'Testes & Laudos Técnicos',
  'Lavagem & Descontaminação',
  'Outros'
];

const SERVICE_UNITS = [
  'Serviço',
  'Hora',
  'UN',
  'Peça',
  'Verba',
  'Metro',
  'Conjunto'
];

export default function QuickNewServiceModal({
  isOpen,
  onClose,
  onSaveService,
  onServiceCreated,
  existingServices = []
}: QuickNewServiceModalProps) {
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Hidráulica');
  const [unit, setUnit] = useState('Serviço');
  const [estimatedCost, setEstimatedCost] = useState<string>('0.00');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const nameInputRef = useRef<HTMLInputElement>(null);

  // Auto-generate code and reset form on open
  useEffect(() => {
    if (isOpen) {
      const nextNum = existingServices.length > 0 
        ? Math.max(...existingServices.map(s => {
            const num = parseInt(s.code.replace(/\D/g, ''));
            return isNaN(num) ? 0 : num;
          })) + 1
        : 1;

      setCode(`SERV-H${String(nextNum).padStart(2, '0')}`);
      setName('');
      setCategory('Hidráulica');
      setUnit('Serviço');
      setEstimatedCost('0.00');
      setDescription('');
      setError('');
      setSuccessNotice(null);

      setTimeout(() => {
        nameInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, existingServices]);

  // Esc key closes modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanCode = code.trim().toUpperCase();
    const cleanName = name.trim();
    const cleanDesc = description.trim() || cleanName;
    const costNum = parseFloat(estimatedCost.replace(',', '.')) || 0;

    if (!cleanCode) {
      setError('Por favor, informe o Código do serviço.');
      return;
    }

    if (!cleanName) {
      setError('Por favor, informe o Nome ou Título do serviço.');
      nameInputRef.current?.focus();
      return;
    }

    // Check duplicate code
    const isDuplicate = existingServices.some(s => s.code.trim().toUpperCase() === cleanCode);
    if (isDuplicate) {
      setError(`O código "${cleanCode}" já está em uso na tabela de serviços.`);
      return;
    }

    try {
      const created = onSaveService({
        code: cleanCode,
        name: cleanName,
        category,
        unit,
        estimatedCost: costNum,
        description: cleanDesc
      });

      setSuccessNotice(`Serviço "${created.name}" cadastrado com sucesso!`);

      setTimeout(() => {
        if (onServiceCreated) {
          onServiceCreated(created);
        }
        onClose();
      }, 600);
    } catch (err: any) {
      setError(err?.message || 'Ocorreu um erro ao cadastrar o serviço.');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[70] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      id="quick-new-service-backdrop"
    >
      <div 
        className="bg-white border-2 border-slate-400 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col my-6 animate-in fade-in zoom-in-95 duration-150"
        id="quick-new-service-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-quick-service-title"
      >
        {/* Header */}
        <div className="bg-[#1b365d] text-white px-5 py-3.5 flex items-center justify-between border-b border-blue-900">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="modal-quick-service-title" className="text-sm sm:text-base font-black uppercase tracking-wider text-white">
                  Cadastro de Novo Serviço
                </h3>
                <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-800 text-cyan-200 border border-blue-700 text-[10px] font-mono font-black">
                  <Keyboard className="w-3 h-3" />
                  <span>F3</span>
                </span>
              </div>
              <p className="text-[11px] text-cyan-200 mt-0.5">
                Cadastre o serviço e preço sugerido para a tabela e orçamentos
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-close-quick-service-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg text-cyan-200 hover:text-white hover:bg-blue-800 transition-colors cursor-pointer"
            title="Fechar (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 bg-slate-50 text-xs">
          {error && (
            <div className="p-3 bg-red-50 border border-red-300 rounded-xl flex items-center gap-2.5 text-red-700 font-bold">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center gap-2.5 text-emerald-800 font-bold animate-pulse">
              <Check className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successNotice}</span>
            </div>
          )}

          {/* Código & Categoria */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                <Tag className="w-3 h-3 text-slate-500" />
                <span>Código do Serviço <span className="text-red-500">*</span></span>
              </label>
              <input
                id="input-quick-service-code"
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="Ex: SERV-H08"
                className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 shadow-inner uppercase"
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                <Layers className="w-3 h-3 text-indigo-600" />
                <span>Categoria</span>
              </label>
              <select
                id="select-quick-service-category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 shadow-inner cursor-pointer"
              >
                {SERVICE_CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Nome do Serviço */}
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1">
              Nome do Serviço <span className="text-red-500">*</span>
            </label>
            <input
              ref={nameInputRef}
              id="input-quick-service-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Brunimento de Camisa Hidráulica até 200mm"
              className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 shadow-inner"
            />
          </div>

          {/* Preço Sugerido & Unidade */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                <DollarSign className="w-3 h-3 text-emerald-600" />
                <span>Preço Sugerido (R$) <span className="text-red-500">*</span></span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2 font-bold text-slate-500 text-xs">R$</span>
                <input
                  id="input-quick-service-price"
                  type="text"
                  required
                  value={estimatedCost}
                  onChange={(e) => setEstimatedCost(e.target.value)}
                  placeholder="750.00"
                  className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl pl-9 pr-3 py-2 text-xs font-mono font-bold text-emerald-800 shadow-inner"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1">
                Unidade de Cobrança
              </label>
              <select
                id="select-quick-service-unit"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 shadow-inner cursor-pointer"
              >
                {SERVICE_UNITS.map(u => (
                  <option key={u} value={u}>{u}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Descrição Detalhada */}
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
              <FileText className="w-3 h-3 text-blue-600" />
              <span>Descrição do Procedimento Técnico</span>
            </label>
            <textarea
              id="textarea-quick-service-desc"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descreva o escopo, etapas de execução ou materiais inclusos neste serviço..."
              className="w-full bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl p-3 text-xs font-medium text-slate-800 shadow-inner resize-none"
            />
          </div>

          {/* Hint */}
          <div className="p-2.5 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between text-[10px] text-blue-900 font-medium">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Ficará disponível imediatamente na Tabela de Preços e nos Orçamentos.</span>
            </span>
            <span className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-blue-200 text-blue-800 hidden sm:inline">
              Enter = Salvar
            </span>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
            <button
              type="button"
              id="btn-cancel-quick-service"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs uppercase cursor-pointer transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              id="btn-save-quick-service"
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition-all cursor-pointer flex items-center gap-2"
            >
              <Plus className="w-4 h-4 text-slate-950" />
              <span>Salvar Serviço</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
