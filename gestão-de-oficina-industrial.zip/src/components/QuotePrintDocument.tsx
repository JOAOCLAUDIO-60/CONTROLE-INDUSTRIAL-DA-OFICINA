import React from 'react';
import { Quote } from '../types';
import { JCF_COMPANY_INFO } from '../data/companyConfig';
import JCFCompanyLogo from './JCFCompanyLogo';
import { Cpu, Wrench, Package } from 'lucide-react';

interface QuotePrintDocumentProps {
  quote: Quote;
}

export default function QuotePrintDocument({ quote }: QuotePrintDocumentProps) {
  const quoteTypeLabel = {
    VENDA: 'Venda de Peças e Componentes',
    MANUTENCAO_CORRETIVA: 'Manutenção Corretiva',
    MANUTENCAO_PREVENTIVA: 'Manutenção Preventiva',
    REVISAO_GERAL: 'Reforma Geral / Revisão Técnica',
    OUTROS: 'Consultoria / Serviços Técnicos'
  }[quote.quoteType || 'MANUTENCAO_CORRETIVA'];

  const quoteTypeBadgeColor = {
    VENDA: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    MANUTENCAO_CORRETIVA: 'bg-amber-100 text-amber-900 border-amber-300',
    MANUTENCAO_PREVENTIVA: 'bg-blue-100 text-blue-900 border-blue-300',
    REVISAO_GERAL: 'bg-purple-100 text-purple-900 border-purple-300',
    OUTROS: 'bg-slate-100 text-slate-900 border-slate-300'
  }[quote.quoteType || 'MANUTENCAO_CORRETIVA'];

  return (
    <div 
      id="printable-quote-document" 
      className="quote-a4-sheet bg-white text-slate-900 font-sans p-4 sm:p-6 text-xs leading-normal max-w-4xl mx-auto"
      style={{ boxSizing: 'border-box' }}
    >
      <style>{`
        @page {
          size: A4 portrait;
          margin: 8mm 8mm 8mm 8mm;
        }
        @media print {
          html, body {
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
            color: #0f172a !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            font-size: 11px !important;
            width: 100% !important;
          }
          #printable-quote-document {
            padding: 0 !important;
            margin: 0 auto !important;
            max-width: 100% !important;
            box-shadow: none !important;
            border: none !important;
          }
          .print-keep-together {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }
          .print-row-avoid {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>

      {/* 1. Header with Logo & Official Company Info */}
      <div 
        className="print-keep-together flex flex-row items-center justify-between gap-3 border-b-2 border-slate-900 pb-2.5 mb-3"
        style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottom: '2px solid #0f172a', paddingBottom: '10px', marginBottom: '12px' }}
      >
        {/* Logo & Company Name */}
        <div className="flex items-center gap-3.5" style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          {/* Logo Oficial JC&F com subtítulo, sem borda cinza */}
          <div className="shrink-0" style={{ width: '88px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <JCFCompanyLogo size="custom" className="w-22 h-auto" variant="mono-black" showSubtitle={true} />
          </div>
          <div>
            <h1 className="text-sm font-black tracking-tight text-slate-950 uppercase leading-none" style={{ fontSize: '13px', fontWeight: 900, textTransform: 'uppercase', margin: 0 }}>
              {JCF_COMPANY_INFO.name}
            </h1>
            <p className="text-[10px] font-bold text-slate-700 mt-1" style={{ fontSize: '9.5px', fontWeight: 700, margin: '3px 0 0 0' }}>
              {JCF_COMPANY_INFO.address}
            </p>
            <p className="text-[9.5px] font-mono text-slate-600 mt-0.5" style={{ fontSize: '9px', margin: '2px 0 0 0' }}>
              CNPJ: <span className="font-bold text-slate-950">{JCF_COMPANY_INFO.cnpj}</span> | E-mail: <span className="font-bold text-slate-950">{JCF_COMPANY_INFO.email}</span> | Tel: <span className="font-bold text-slate-950">{JCF_COMPANY_INFO.phone}</span>
            </p>
          </div>
        </div>

        {/* Proposal Meta & Badge */}
        <div className="text-right shrink-0" style={{ textAlign: 'right', flexShrink: 0 }}>
          <span 
            className={`inline-block text-[8.5px] font-black uppercase px-2 py-0.5 rounded mb-1 border ${quoteTypeBadgeColor}`}
            style={{ fontSize: '8.5px', fontWeight: 900, textTransform: 'uppercase', padding: '2px 6px', borderRadius: '4px', display: 'inline-block', marginBottom: '4px' }}
          >
            {quoteTypeLabel}
          </span>
          <h2 className="text-lg font-black text-blue-950 font-mono tracking-tight leading-none" style={{ fontSize: '16px', fontWeight: 900, color: '#172554', margin: 0 }}>
            {quote.quoteNumber}
          </h2>
          <p className="text-[9px] text-slate-600 font-mono mt-0.5" style={{ fontSize: '9px', color: '#475569', margin: '2px 0 0 0' }}>
            Emissão: {new Date(quote.date + 'T12:00:00').toLocaleDateString('pt-BR')}
          </p>
          <p className="text-[9px] text-slate-600 font-mono" style={{ fontSize: '9px', color: '#475569', margin: 0 }}>
            Validade: {new Date(quote.validUntil + 'T12:00:00').toLocaleDateString('pt-BR')}
          </p>
        </div>
      </div>

      {/* 2. Client & Equipment Data Grid */}
      <div 
        className="print-keep-together grid grid-cols-2 gap-3 mb-3"
        style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '12px' }}
      >
        {/* Client Box */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5" style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '8px 10px' }}>
          <span className="text-[8px] font-black uppercase tracking-widest text-slate-500 block mb-0.5" style={{ fontSize: '8px', fontWeight: 900, textTransform: 'uppercase', color: '#64748b' }}>
            Dados do Cliente / Solicitante
          </span>
          <p className="text-xs font-black text-slate-950" style={{ fontSize: '12px', fontWeight: 900, margin: '2px 0' }}>{quote.clientName}</p>
          {quote.clientDocument && (
            <p className="text-[10px] text-slate-700 font-mono" style={{ fontSize: '9.5px', margin: '1px 0' }}>CNPJ/CPF: {quote.clientDocument}</p>
          )}
          {quote.clientAddress && (
            <p className="text-[10px] text-slate-700 truncate" style={{ fontSize: '9.5px', margin: '1px 0' }}>Endereço: {quote.clientAddress}</p>
          )}
          <div className="flex flex-wrap gap-x-3 text-[10px] text-slate-700 font-mono mt-0.5" style={{ fontSize: '9.5px', display: 'flex', gap: '8px' }}>
            {quote.clientPhone && <span>Tel: {quote.clientPhone}</span>}
            {quote.clientEmail && <span>E-mail: {quote.clientEmail}</span>}
          </div>
        </div>

        {/* Equipment / Target Box */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 flex flex-col justify-between" style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '8px 10px' }}>
          <div>
            <span className="text-[8px] font-black uppercase tracking-widest text-slate-500 block mb-0.5" style={{ fontSize: '8px', fontWeight: 900, textTransform: 'uppercase', color: '#64748b' }}>
              Ativo Avaliado / Aplicação do Orçamento
            </span>
            <div className="flex items-center gap-1.5" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Cpu className="w-3.5 h-3.5 text-blue-900 shrink-0" />
              <p className="text-xs font-black text-slate-950" style={{ fontSize: '12px', fontWeight: 900, margin: 0 }}>
                {quote.equipmentName || 'Venda Direta / Balcão de Peças'}
              </p>
            </div>
          </div>
          <div className="text-[9.5px] text-slate-600 font-mono mt-1.5 pt-1.5 border-t border-slate-200 flex justify-between" style={{ borderTop: '1px solid #e2e8f0', paddingTop: '4px', marginTop: '6px', display: 'flex', justifyContent: 'space-between', fontSize: '9px' }}>
            <span>Responsável Técnico:</span>
            <span className="font-bold text-slate-900">{quote.technicianName || 'Depto. Técnico JC&F'}</span>
          </div>
        </div>
      </div>

      {/* 3. Items & Services Table */}
      <div className="mb-2.5" style={{ marginBottom: '10px' }}>
        <h3 className="text-[9px] font-black uppercase tracking-widest text-slate-600 mb-1" style={{ fontSize: '8.5px', fontWeight: 900, textTransform: 'uppercase', color: '#475569', marginBottom: '4px' }}>
          Detalhamento dos Itens, Peças e Serviços
        </h3>
        <table className="w-full text-xs border-collapse" style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr className="bg-slate-100 border-y border-slate-300 text-slate-700" style={{ backgroundColor: '#f1f5f9', borderTop: '1px solid #cbd5e1', borderBottom: '1px solid #cbd5e1' }}>
              <th className="py-1.5 px-2 text-center w-8 font-mono text-[9px]" style={{ padding: '4px 6px', textAlign: 'center', width: '30px' }}>#</th>
              <th className="py-1.5 px-2 text-left w-16 text-[9px]" style={{ padding: '4px 6px', textAlign: 'left', width: '60px' }}>Tipo</th>
              <th className="py-1.5 px-2 text-left text-[9px]" style={{ padding: '4px 6px', textAlign: 'left' }}>Descrição do Item / Serviço Técnico</th>
              <th className="py-1.5 px-2 text-center w-12 font-mono text-[9px]" style={{ padding: '4px 6px', textAlign: 'center', width: '45px' }}>Qtd</th>
              <th className="py-1.5 px-2 text-center w-10 font-mono text-[9px]" style={{ padding: '4px 6px', textAlign: 'center', width: '40px' }}>Unid</th>
              <th className="py-1.5 px-2 text-right w-20 font-mono text-[9px]" style={{ padding: '4px 6px', textAlign: 'right', width: '80px' }}>Unitário</th>
              <th className="py-1.5 px-2 text-right w-20 font-mono text-[9px]" style={{ padding: '4px 6px', textAlign: 'right', width: '80px' }}>Total (R$)</th>
            </tr>
          </thead>
          <tbody>
            {quote.items.map((item, idx) => (
              <tr 
                key={item.id} 
                className="print-row-avoid border-b border-slate-200"
                style={{ borderBottom: '1px solid #e2e8f0', backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8fafc' }}
              >
                <td className="py-1.5 px-2 text-center font-mono text-slate-500 text-[9.5px]" style={{ padding: '4px 6px', textAlign: 'center' }}>{idx + 1}</td>
                <td className="py-1.5 px-2" style={{ padding: '4px 6px' }}>
                  <span 
                    className={`inline-flex items-center gap-1 text-[7.5px] font-black uppercase px-1 py-0.2 rounded ${
                      item.type === 'PECA' ? 'bg-amber-100 text-amber-900' :
                      item.type === 'SERVICO' ? 'bg-blue-100 text-blue-900' : 'bg-slate-100 text-slate-800'
                    }`}
                    style={{ fontSize: '7.5px', fontWeight: 900, textTransform: 'uppercase', padding: '1px 4px', borderRadius: '3px', display: 'inline-flex', alignItems: 'center' }}
                  >
                    {item.type === 'PECA' ? <Package className="w-2.5 h-2.5" /> : <Wrench className="w-2.5 h-2.5" />}
                    {item.type || 'ITEM'}
                  </span>
                </td>
                <td className="py-1.5 px-2 font-bold text-slate-900 leading-snug text-[10.5px]" style={{ padding: '4px 6px', fontSize: '10.5px', fontWeight: 700 }}>
                  {item.description}
                </td>
                <td className="py-1.5 px-2 text-center font-mono font-bold text-slate-900 text-[10px]" style={{ padding: '4px 6px', textAlign: 'center' }}>
                  {item.quantity}
                </td>
                <td className="py-1.5 px-2 text-center font-mono text-slate-600 text-[9.5px]" style={{ padding: '4px 6px', textAlign: 'center' }}>
                  {item.unit || 'UN'}
                </td>
                <td className="py-1.5 px-2 text-right font-mono text-slate-700 text-[10px]" style={{ padding: '4px 6px', textAlign: 'right' }}>
                  {item.unitPrice.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="py-1.5 px-2 text-right font-mono font-black text-slate-950 text-[10.5px]" style={{ padding: '4px 6px', textAlign: 'right', fontWeight: 900 }}>
                  {item.total.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* 4. Financial Totals */}
      <div 
        className="print-keep-together flex justify-end mb-3"
        style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '10px' }}
      >
        <div 
          className="w-64 bg-slate-50 border border-slate-200 rounded-lg p-2.5 space-y-1"
          style={{ width: '250px', backgroundColor: '#f8fafc', border: '1px solid #cbd5e1', borderRadius: '6px', padding: '8px 10px' }}
        >
          <div className="flex justify-between text-slate-600 text-[10px]" style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px' }}>
            <span>Subtotal Bruto:</span>
            <span className="font-mono font-bold">
              R$ {quote.subtotal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          {quote.discount > 0 && (
            <div className="flex justify-between text-emerald-700 font-bold text-[10px]" style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', color: '#15803d' }}>
              <span>Desconto Comercial:</span>
              <span className="font-mono">
                - R$ {quote.discount.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          )}
          <div 
            className="flex justify-between text-xs font-black text-slate-950 border-t border-slate-300 pt-1"
            style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid #cbd5e1', paddingTop: '4px', fontSize: '11px', fontWeight: 900 }}
          >
            <span>Total Líquido:</span>
            <span className="font-mono text-blue-950 text-sm font-black" style={{ color: '#172554', fontSize: '13px' }}>
              R$ {quote.total.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
        </div>
      </div>

      {/* 5. Commercial Conditions Grid */}
      <div className="print-keep-together mb-3" style={{ marginBottom: '12px' }}>
        <h3 className="text-[9px] font-black uppercase tracking-widest text-slate-600 mb-1" style={{ fontSize: '8.5px', fontWeight: 900, textTransform: 'uppercase', color: '#475569', marginBottom: '4px' }}>
          Condições Comerciais & Pagamento
        </h3>
        <div 
          className="grid grid-cols-4 gap-2"
          style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}
        >
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2" style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '6px 8px' }}>
            <span className="text-[7.5px] font-black uppercase text-slate-500 block mb-0.5" style={{ fontSize: '7.5px', fontWeight: 900, textTransform: 'uppercase', color: '#64748b' }}>Condições de Pagamento</span>
            <p className="font-bold text-slate-900 text-[9.5px]" style={{ fontSize: '9.5px', fontWeight: 700, margin: 0 }}>{quote.paymentTerms}</p>
            <p className="text-[8px] text-slate-600 font-mono mt-0.5" style={{ fontSize: '8px', color: '#475569', margin: '2px 0 0 0' }}>
              PIX: <span className="font-bold text-slate-900">{JCF_COMPANY_INFO.pixKey}</span>
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2" style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '6px 8px' }}>
            <span className="text-[7.5px] font-black uppercase text-slate-500 block mb-0.5" style={{ fontSize: '7.5px', fontWeight: 900, textTransform: 'uppercase', color: '#64748b' }}>Prazo de Entrega</span>
            <p className="font-bold text-slate-900 text-[9.5px]" style={{ fontSize: '9.5px', fontWeight: 700, margin: 0 }}>{quote.deliveryTime}</p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2" style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '6px 8px' }}>
            <span className="text-[7.5px] font-black uppercase text-slate-500 block mb-0.5" style={{ fontSize: '7.5px', fontWeight: 900, textTransform: 'uppercase', color: '#64748b' }}>Garantia Contratual</span>
            <p className="font-bold text-slate-900 text-[9.5px]" style={{ fontSize: '9.5px', fontWeight: 700, margin: 0 }}>{quote.warrantyTerms}</p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2" style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '6px 8px' }}>
            <span className="text-[7.5px] font-black uppercase text-slate-500 block mb-0.5" style={{ fontSize: '7.5px', fontWeight: 900, textTransform: 'uppercase', color: '#64748b' }}>Observações</span>
            <p className="text-slate-700 text-[9px] leading-tight" style={{ fontSize: '8.5px', color: '#334155', margin: 0 }}>
              {quote.notes || 'Equipamento testado em bancada hidráulica de alta pressão.'}
            </p>
          </div>
        </div>
      </div>

      {/* 6. Formal Signature Block */}
      <div 
        className="print-keep-together grid grid-cols-2 gap-8 pt-4 border-t border-slate-300 text-center"
        style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '32px', borderTop: '1px solid #cbd5e1', paddingTop: '16px', textAlign: 'center' }}
      >
        <div>
          <div className="border-b border-slate-400 w-3/4 mx-auto mb-1" style={{ borderBottom: '1px solid #94a3b8', width: '75%', margin: '0 auto 4px auto' }} />
          <p className="font-black text-slate-950 text-[10.5px]" style={{ fontSize: '10.5px', fontWeight: 900, margin: 0 }}>{JCF_COMPANY_INFO.name}</p>
          <p className="text-[8.5px] font-mono text-slate-500" style={{ fontSize: '8.5px', color: '#64748b', margin: '2px 0 0 0' }}>Depto. Técnico & Comercial</p>
        </div>
        <div>
          <div className="border-b border-slate-400 w-3/4 mx-auto mb-1" style={{ borderBottom: '1px solid #94a3b8', width: '75%', margin: '0 auto 4px auto' }} />
          <p className="font-black text-slate-950 text-[10.5px]" style={{ fontSize: '10.5px', fontWeight: 900, margin: 0 }}>{quote.clientName}</p>
          <p className="text-[8.5px] font-mono text-slate-500" style={{ fontSize: '8.5px', color: '#64748b', margin: '2px 0 0 0' }}>Assinatura do Responsável / Aceite em ___/___/______</p>
        </div>
      </div>
    </div>
  );
}
