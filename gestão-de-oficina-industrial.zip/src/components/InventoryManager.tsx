import React, { useState, useMemo, useEffect } from 'react';
import { googleSignIn } from '../lib/googleAuth';
import { 
  InventoryItem, 
  MaterialGroup, 
  Supplier, 
  InventoryMovement, 
  PhysicalInventory 
} from '../types';
import { 
  Package, 
  Plus, 
  Minus, 
  Search, 
  AlertTriangle, 
  Edit, 
  Trash2, 
  Tag, 
  DollarSign, 
  Check, 
  X, 
  MapPin, 
  Truck, 
  TrendingUp, 
  ShieldAlert,
  ClipboardList,
  Layers,
  Building2,
  ArrowUpRight,
  ArrowDownLeft,
  FileText,
  Printer,
  CheckCircle,
  Calendar,
  Activity,
  ChevronRight,
  FileSpreadsheet,
  Sliders,
  AlertCircle,
  Link,
  Upload,
  LayoutGrid,
  CheckSquare,
  Eye,
  Info
} from 'lucide-react';

interface InventoryManagerProps {
  inventory: InventoryItem[];
  onAddItem: (itemData: Omit<InventoryItem, 'id' | 'createdAt'>) => void;
  onAddItems?: (itemsData: Omit<InventoryItem, 'id' | 'createdAt'>[]) => void;
  onEditItem: (updatedItem: InventoryItem) => void;
  onDeleteItem: (id: string) => void;
}

// PORTUGUESE TRANSLATED SEED DATA FOR EMPTY STORAGE
const INITIAL_GROUPS: MaterialGroup[] = [
  { id: 'gp-1', name: 'Vedações', description: 'O-Rings, Gaxetas, Retentores e Raspadores', createdAt: '2026-01-10T12:00:00Z' },
  { id: 'gp-2', name: 'Fluidos', description: 'Óleos hidráulicos, Lubrificantes, Fluidos de corte e Graxas', createdAt: '2026-01-12T12:00:00Z' },
  { id: 'gp-3', name: 'Válvulas', description: 'Válvulas direcionais, reguladoras de fluxo, de pressão e de retenção', createdAt: '2026-01-15T12:00:00Z' },
  { id: 'gp-4', name: 'Mangueiras', description: 'Mangueiras hidráulicas de alta pressão e conexões de mangueira', createdAt: '2026-01-18T12:00:00Z' },
  { id: 'gp-5', name: 'Conectores', description: 'Engates rápidos, Niples, Cotovelos e Adaptadores roscados', createdAt: '2026-01-20T12:00:00Z' },
  { id: 'gp-6', name: 'Instrumentação', description: 'Manômetros de glicerina, Transdutores de pressão e Termômetros', createdAt: '2026-01-22T12:00:00Z' }
];

const INITIAL_SUPPLIERS: Supplier[] = [
  { id: 'sup-1', name: 'Parker Hannifin Ltda', cnpjOrCpf: '12.345.678/0001-99', phone: '(11) 3915-1000', email: 'vendas@parker.com.br', address: 'Av. das Nações Unidas, 1234, São Paulo - SP', createdAt: '2026-01-10T12:00:00Z' },
  { id: 'sup-2', name: 'Festo Brasil Ltda', cnpjOrCpf: '98.765.432/0001-88', phone: '(11) 5013-1600', email: 'vendas.br@festo.com', address: 'Rua Fritz Johansen, 45, São Paulo - SP', createdAt: '2026-01-11T12:00:00Z' },
  { id: 'sup-3', name: 'Bosch Rexroth Ltda', cnpjOrCpf: '11.222.333/0001-44', phone: '(15) 3415-1100', email: 'vendas@boschrexroth.com.br', address: 'Av. Robert Bosch, 147, Itatiba - SP', createdAt: '2026-01-12T12:00:00Z' },
  { id: 'sup-4', name: 'SMC Pneumáticos Brasil', cnpjOrCpf: '44.333.222/0001-55', phone: '(11) 4082-0600', email: 'atendimento@smc.com.br', address: 'Estrada do Pirajussara, 500, Embu das Artes - SP', createdAt: '2026-01-15T12:00:00Z' }
];

const INITIAL_MOVEMENTS = (inventoryItems: InventoryItem[]): InventoryMovement[] => {
  const getRandId = (code: string) => inventoryItems.find(i => i.code === code)?.id || `inv-${Date.now()}`;
  return [
    { id: 'mov-1', itemId: getRandId('EST-VED01'), itemName: 'Anel O-Ring Nitrílico 1/2', itemCode: 'EST-VED01', type: 'INPUT', quantity: 50, price: 1.50, description: 'Carga inicial para estoque mínimo de segurança', supplier: 'Parker Hannifin Ltda', date: '2026-07-01', createdAt: '2026-07-01T10:00:00Z' },
    { id: 'mov-2', itemId: getRandId('EST-FLU01'), itemName: 'Óleo Hidráulico ISO VG 68', itemCode: 'EST-FLU01', type: 'INPUT', quantity: 100, price: 18.50, description: 'Compra de tambores para estoque de fluidos', supplier: 'Bosch Rexroth Ltda', date: '2026-07-02', createdAt: '2026-07-02T11:00:00Z' },
    { id: 'mov-3', itemId: getRandId('EST-VED01'), itemName: 'Anel O-Ring Nitrílico 1/2', itemCode: 'EST-VED01', type: 'OUTPUT', quantity: 5, price: 5.00, description: 'Consumido na OS-1001 (Reparo de Cilindro)', date: '2026-07-05', createdAt: '2026-07-05T14:30:00Z' },
    { id: 'mov-4', itemId: getRandId('EST-VAL01'), itemName: 'Válvula de Retenção 1/2 NPT', itemCode: 'EST-VAL01', type: 'OUTPUT', quantity: 2, price: 120.00, description: 'Consumido na OS-1002 (Reforma de Válvula)', date: '2026-07-08', createdAt: '2026-07-08T16:20:00Z' }
  ];
};

export default function InventoryManager({ 
  inventory, 
  onAddItem, 
  onAddItems,
  onEditItem, 
  onDeleteItem 
}: InventoryManagerProps) {
  
  // PRIMARY SECTION TABS
  // SECTIONS: 'MATERIALS' (Materiais) | 'GROUPS' (Grupos de Materiais) | 'SUPPLIERS' (Fornecedores) | 'REPORTS' (Relatórios)
  const [activeTab, setActiveTab] = useState<'MATERIALS' | 'GROUPS' | 'SUPPLIERS' | 'REPORTS'>('MATERIALS');
  
  // REPORT SUB-TABS
  const [activeReportTab, setActiveReportTab] = useState<'INPUTS' | 'OUTPUTS' | 'ESTOQUE' | 'AUDITS'>('ESTOQUE');

  // FEEDBACK STATE
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Confirmation states to replace window.confirm (blocked in iframe environments)
  const [itemToDelete, setItemToDelete] = useState<InventoryItem | null>(null);
  const [groupToDelete, setGroupToDelete] = useState<{ id: string; name: string; count: number } | null>(null);
  const [supplierToDelete, setSupplierToDelete] = useState<{ id: string; name: string } | null>(null);
  const [confirmCancelAudit, setConfirmCancelAudit] = useState(false);
  const [confirmFinalizeAudit, setConfirmFinalizeAudit] = useState(false);

  // Spreadsheet import states
  const [showImportModal, setShowImportModal] = useState(false);
  const [importTab, setImportTab] = useState<'PASTE' | 'URL'>('PASTE');
  const [pasteContent, setPasteContent] = useState('');
  const [sheetUrl, setSheetUrl] = useState('https://docs.google.com/spreadsheets/d/1JM9uOKmxDgrlP5UgUOJe3daMeqqEhBa3OsbV9gDcVXg/edit?gid=2003588313');
  const [importLoading, setImportLoading] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [parsedItems, setParsedItems] = useState<Omit<InventoryItem, 'id' | 'createdAt'>[]>([]);

  // Real-time parsing helper for pasted data
  const handlePasteChange = (text: string) => {
    setPasteContent(text);
    if (!text.trim()) {
      setParsedItems([]);
      return;
    }
    
    try {
      const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');
      if (lines.length === 0) {
        setParsedItems([]);
        return;
      }
      
      const items: Omit<InventoryItem, 'id' | 'createdAt'>[] = [];
      let startIndex = 0;
      
      // Check if first line looks like a header
      const firstLineCols = lines[0].split('\t');
      const isHeader = firstLineCols.some(col => {
        const val = col.toLowerCase().trim();
        return val.includes('grupo') || val.includes('nome') || val.includes('componente') || val.includes('código') || val.includes('codigo') || val.includes('localiz') || val.includes('mínimo') || val.includes('segurança');
      });
      
      if (isHeader) {
        startIndex = 1;
      }
      
      for (let i = startIndex; i < lines.length; i++) {
        const cols = lines[i].split('\t');
        if (cols.length === 0 || !cols[1]) continue; // needs name at least
        
        const group = cols[0]?.trim() || 'Outros';
        const name = cols[1]?.trim() || 'Sem nome';
        const code = cols[2]?.trim() || 'EST-' + Math.floor(1000 + Math.random() * 9000);
        const location = cols[3]?.trim() || '';
        const minStockRaw = cols[4]?.replace(/[^\d]/g, '') || '0';
        const minimumStock = parseInt(minStockRaw, 10) || 0;
        const possibleApplications = cols[5]?.trim() || '';
        
        items.push({
          code: code.toUpperCase(),
          name,
          category: group || 'Outros',
          quantity: 0,
          minimumStock,
          purchasePrice: 0,
          salePrice: 0,
          unit: 'un',
          location,
          possibleApplications,
          description: 'Importado via Ctrl+V',
        });
      }
      setParsedItems(items);
      setImportError(null);
    } catch (err: any) {
      setImportError(`Erro ao parsear dados: ${err.message}`);
    }
  };

  // Extract Sheet ID and GID
  const extractSpreadsheetId = (url: string): string | null => {
    const match = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  };

  const extractGid = (url: string): number | null => {
    const match = url.match(/[#&]gid=([0-9]+)/);
    return match ? parseInt(match[1], 10) : null;
  };

  // Google Sheets Fetch logic
  const handleLoadFromGoogleSheets = async () => {
    setImportLoading(true);
    setImportError(null);
    try {
      const spreadsheetId = extractSpreadsheetId(sheetUrl);
      if (!spreadsheetId) {
        throw new Error("URL inválido do Google Sheets. Certifique-se de que contém '/spreadsheets/d/ID_DA_PLANILHA/'");
      }

      let token = sessionStorage.getItem('google_sheets_oauth_token');
      if (!token) {
        // Authenticate
        const loginResult = await googleSignIn();
        if (!loginResult) {
          throw new Error("Não foi possível autenticar a conta Google.");
        }
        token = loginResult.accessToken;
      }

      // 1. Fetch spreadsheet metadata to get the correct sheet title for gid
      const gid = extractGid(sheetUrl);
      let range = "A:F";

      try {
        const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets(properties(title,sheetId))`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (metaRes.ok) {
          const metaData = await metaRes.json();
          const sheet = metaData.sheets?.find((s: any) => s.properties?.sheetId === gid);
          if (sheet) {
            range = `'${sheet.properties.title}'!A:F`;
          } else if (metaData.sheets?.[0]) {
            range = `'${metaData.sheets[0].properties.title}'!A:F`;
          }
        }
      } catch (err) {
        console.warn("Could not fetch metadata, using default range", err);
      }

      // 2. Fetch sheet values
      const valuesRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!valuesRes.ok) {
        const errText = await valuesRes.text();
        throw new Error(`Erro ao buscar dados na API do Google Sheets: ${valuesRes.status}. Verifique as permissões de compartilhamento.`);
      }

      const valuesData = await valuesRes.json();
      const rows = valuesData.values;
      if (!rows || rows.length === 0) {
        throw new Error("A planilha está vazia ou não possui dados legíveis nas colunas A:F.");
      }

      const items: Omit<InventoryItem, 'id' | 'createdAt'>[] = [];
      let startIndex = 0;

      // Check if first row is header
      const firstRow = rows[0];
      const isHeader = firstRow.some((col: any) => {
        const val = String(col).toLowerCase().trim();
        return val.includes('grupo') || val.includes('nome') || val.includes('componente') || val.includes('código') || val.includes('codigo') || val.includes('localiz') || val.includes('mínimo') || val.includes('segurança');
      });

      if (isHeader) {
        startIndex = 1;
      }

      for (let i = startIndex; i < rows.length; i++) {
        const cols = rows[i];
        if (!cols || cols.length === 0 || !cols[1]) continue; // needs name

        const group = cols[0]?.trim() || 'Outros';
        const name = cols[1]?.trim() || 'Sem nome';
        const code = cols[2]?.trim() || 'EST-' + Math.floor(1000 + Math.random() * 9000);
        const location = cols[3]?.trim() || '';
        const minStockRaw = String(cols[4] || '0').replace(/[^\d]/g, '') || '0';
        const minimumStock = parseInt(minStockRaw, 10) || 0;
        const possibleApplications = cols[5]?.trim() || '';

        items.push({
          code: code.toUpperCase(),
          name,
          category: group || 'Outros',
          quantity: 0,
          minimumStock,
          purchasePrice: 0,
          salePrice: 0,
          unit: 'un',
          location,
          possibleApplications,
          description: 'Importado do Google Sheets',
        });
      }

      setParsedItems(items);
      setImportError(null);
    } catch (err: any) {
      setImportError(err.message);
    } finally {
      setImportLoading(false);
    }
  };

  // Perform final import
  const executeImport = () => {
    if (parsedItems.length === 0) return;
    
    // Save materials
    if (onAddItems) {
      onAddItems(parsedItems);
    } else {
      parsedItems.forEach(item => onAddItem(item));
    }

    // Auto-create groups for any category that doesn't exist
    const existingGroupNames = new Set(groups.map(g => g.name.toLowerCase().trim()));
    const newGroupsToAdd: MaterialGroup[] = [];
    const uniqueCategories: string[] = Array.from(new Set(parsedItems.map(item => String(item.category))));

    uniqueCategories.forEach(cat => {
      const cleanCat = cat.trim();
      if (cleanCat && !existingGroupNames.has(cleanCat.toLowerCase())) {
        newGroupsToAdd.push({
          id: `gp-imported-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          name: cleanCat,
          description: 'Grupo cadastrado via importador de planilhas',
          createdAt: new Date().toISOString()
        });
      }
    });

    if (newGroupsToAdd.length > 0) {
      saveGroups([...groups, ...newGroupsToAdd]);
    }

    triggerFeedback(`${parsedItems.length} materiais importados e integrados com absoluto sucesso!`, 'success');
    setShowImportModal(false);
    setPasteContent('');
    setParsedItems([]);
  };

  // --------------------------------------------------------------------
  // PERSISTED STATES FOR CUSTOM MODULES
  // --------------------------------------------------------------------
  const [groups, setGroups] = useState<MaterialGroup[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [movements, setMovements] = useState<InventoryMovement[]>([]);
  const [audits, setAudits] = useState<PhysicalInventory[]>([]);

  // Load from LocalStorage
  useEffect(() => {
    const storedGroups = localStorage.getItem('oficina_inventory_groups');
    const storedSuppliers = localStorage.getItem('oficina_inventory_suppliers');
    const storedMovements = localStorage.getItem('oficina_inventory_movements');
    const storedAudits = localStorage.getItem('oficina_inventory_audits');

    if (storedGroups) {
      setGroups(JSON.parse(storedGroups));
    } else {
      setGroups(INITIAL_GROUPS);
      localStorage.setItem('oficina_inventory_groups', JSON.stringify(INITIAL_GROUPS));
    }

    if (storedSuppliers) {
      setSuppliers(JSON.parse(storedSuppliers));
    } else {
      setSuppliers(INITIAL_SUPPLIERS);
      localStorage.setItem('oficina_inventory_suppliers', JSON.stringify(INITIAL_SUPPLIERS));
    }

    if (storedMovements) {
      setMovements(JSON.parse(storedMovements));
    } else {
      const defaultMovs = INITIAL_MOVEMENTS(inventory);
      setMovements(defaultMovs);
      localStorage.setItem('oficina_inventory_movements', JSON.stringify(defaultMovs));
    }

    if (storedAudits) {
      setAudits(JSON.parse(storedAudits));
    } else {
      // Default empty audits
      setAudits([]);
      localStorage.setItem('oficina_inventory_audits', JSON.stringify([]));
    }
  }, [inventory]);

  // Persistent state savers
  const saveGroups = (newGroups: MaterialGroup[]) => {
    setGroups(newGroups);
    localStorage.setItem('oficina_inventory_groups', JSON.stringify(newGroups));
  };

  const saveSuppliers = (newSuppliers: Supplier[]) => {
    setSuppliers(newSuppliers);
    localStorage.setItem('oficina_inventory_suppliers', JSON.stringify(newSuppliers));
  };

  const saveMovements = (newMovements: InventoryMovement[]) => {
    setMovements(newMovements);
    localStorage.setItem('oficina_inventory_movements', JSON.stringify(newMovements));
  };

  const saveAudits = (newAudits: PhysicalInventory[]) => {
    setAudits(newAudits);
    localStorage.setItem('oficina_inventory_audits', JSON.stringify(newAudits));
  };

  // Show status feedback
  const triggerFeedback = (message: string, type: 'success' | 'error' | 'info') => {
    setFeedback({ message, type });
    setTimeout(() => {
      setFeedback(null);
    }, 4000);
  };

  // --------------------------------------------------------------------
  // SECTION 1: MATERIAIS / PARTS STATES & FUNCTIONS
  // --------------------------------------------------------------------
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [filterAlertOnly, setFilterAlertOnly] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'CRITICAL' | 'OUT_OF_STOCK' | 'HEALTHY' | 'NO_LOCATION' | 'HIGH_MARGIN'>('ALL');
  const [viewMode, setViewMode] = useState<'SEARCH_SELECT' | 'TABLE' | 'GRID'>('SEARCH_SELECT');
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);

  // Quick Movement Modal States
  const [quickMovementModalItem, setQuickMovementModalItem] = useState<InventoryItem | null>(null);
  const [quickMovementType, setQuickMovementType] = useState<'INPUT' | 'OUTPUT'>('OUTPUT');
  const [quickMovementQty, setQuickMovementQty] = useState<number>(1);
  const [quickMovementMotive, setQuickMovementMotive] = useState<string>('');
  const [quickMovementDate, setQuickMovementDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [quickMovementPrice, setQuickMovementPrice] = useState<number>(0);

  // Form states for items
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [quantity, setQuantity] = useState<number>(0);
  const [minimumStock, setMinimumStock] = useState<number>(0);
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [salePrice, setSalePrice] = useState<number>(0);
  const [unit, setUnit] = useState('un');
  const [location, setLocation] = useState('');
  const [supplier, setSupplier] = useState('');
  const [description, setDescription] = useState('');
  const [possibleApplications, setPossibleApplications] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  // Extract unique categories (dynamic fallback)
  const categories = useMemo(() => {
    const listFromInventory = inventory.map(item => item.category.trim()).filter(Boolean);
    const listFromGroups = groups.map(g => g.name.trim()).filter(Boolean);
    const combined = [...listFromInventory, ...listFromGroups];
    return Array.from(new Set(combined)).sort();
  }, [inventory, groups]);

  // Filtered inventory search
  const filteredInventory = useMemo(() => {
    return inventory.filter(item => {
      const matchesSearch = searchQuery.trim() === '' || 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.supplier && item.supplier.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (item.location && item.location.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCategory = selectedCategory === 'ALL' || item.category === selectedCategory;
      
      const isBelowMin = item.quantity <= item.minimumStock;
      const isZero = item.quantity === 0;
      const hasLocation = item.location && item.location.trim() !== '';
      const profitMargin = item.purchasePrice > 0 ? (item.salePrice - item.purchasePrice) / item.purchasePrice : 0;
      
      let matchesStatus = true;
      if (statusFilter === 'CRITICAL') {
        matchesStatus = isBelowMin;
      } else if (statusFilter === 'OUT_OF_STOCK') {
        matchesStatus = isZero;
      } else if (statusFilter === 'HEALTHY') {
        matchesStatus = item.quantity > item.minimumStock;
      } else if (statusFilter === 'NO_LOCATION') {
        matchesStatus = !hasLocation;
      } else if (statusFilter === 'HIGH_MARGIN') {
        matchesStatus = item.purchasePrice > 0 && profitMargin >= 0.5;
      }

      const matchesAlert = !filterAlertOnly || isBelowMin;

      return matchesSearch && matchesCategory && matchesStatus && matchesAlert;
    });
  }, [inventory, searchQuery, selectedCategory, statusFilter, filterAlertOnly]);

  // Selected item for the Search & Select split studio
  const selectedItem = useMemo(() => {
    if (selectedItemId) {
      const found = inventory.find(i => i.id === selectedItemId);
      if (found) return found;
    }
    return filteredInventory.length > 0 ? filteredInventory[0] : null;
  }, [selectedItemId, inventory, filteredInventory]);

  // Quick Movement Modal Handlers
  const openQuickMovementModal = (item: InventoryItem, defaultType: 'INPUT' | 'OUTPUT' = 'OUTPUT') => {
    setQuickMovementModalItem(item);
    setQuickMovementType(defaultType);
    setQuickMovementQty(1);
    setQuickMovementMotive(defaultType === 'OUTPUT' ? 'Consumo em OS / Manutenção' : 'Compra / Reposição de estoque');
    setQuickMovementDate(new Date().toISOString().split('T')[0]);
    setQuickMovementPrice(defaultType === 'OUTPUT' ? item.salePrice : item.purchasePrice);
  };

  const handleExecuteQuickMovement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickMovementModalItem) return;
    if (quickMovementQty <= 0) {
      triggerFeedback('A quantidade informada deve ser maior que zero.', 'error');
      return;
    }

    const isOutput = quickMovementType === 'OUTPUT';
    if (isOutput && quickMovementModalItem.quantity < quickMovementQty) {
      triggerFeedback(`Saldo insuficiente! Estoque atual: ${quickMovementModalItem.quantity} ${quickMovementModalItem.unit}.`, 'error');
      return;
    }

    const newQty = isOutput 
      ? Math.max(0, quickMovementModalItem.quantity - quickMovementQty)
      : quickMovementModalItem.quantity + quickMovementQty;

    const unitPrice = quickMovementPrice > 0 
      ? quickMovementPrice 
      : (isOutput ? quickMovementModalItem.salePrice : quickMovementModalItem.purchasePrice);

    const newMov: InventoryMovement = {
      id: `mov-quick-${Date.now()}`,
      itemId: quickMovementModalItem.id,
      itemName: quickMovementModalItem.name,
      itemCode: quickMovementModalItem.code,
      type: quickMovementType,
      quantity: quickMovementQty,
      price: unitPrice,
      description: quickMovementMotive.trim() || (isOutput ? 'Baixa de estoque avulsa' : 'Entrada de material avulsa'),
      supplier: quickMovementModalItem.supplier || 'N/A',
      date: quickMovementDate || new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString()
    };

    saveMovements([newMov, ...movements]);
    onEditItem({ ...quickMovementModalItem, quantity: newQty });
    triggerFeedback(`Movimentação de ${isOutput ? 'saída' : 'entrada'} de ${quickMovementQty} ${quickMovementModalItem.unit} registrada com sucesso!`, 'success');
    setQuickMovementModalItem(null);
  };

  // Valuation Statistics
  const stats = useMemo(() => {
    const totalItems = inventory.length;
    const totalUnits = inventory.reduce((sum, item) => sum + item.quantity, 0);
    const belowMinCount = inventory.filter(item => item.quantity <= item.minimumStock).length;
    const inventoryValuation = inventory.reduce((sum, item) => sum + (item.quantity * item.purchasePrice), 0);
    const potentialSaleValuation = inventory.reduce((sum, item) => sum + (item.quantity * item.salePrice), 0);
    
    return {
      totalItems,
      totalUnits,
      belowMinCount,
      inventoryValuation,
      potentialProfit: potentialSaleValuation - inventoryValuation
    };
  }, [inventory]);

  // Status Counts for Chips
  const statusCounts = useMemo(() => {
    return {
      all: inventory.length,
      critical: inventory.filter(i => i.quantity <= i.minimumStock).length,
      outOfStock: inventory.filter(i => i.quantity === 0).length,
      healthy: inventory.filter(i => i.quantity > i.minimumStock).length,
      noLocation: inventory.filter(i => !i.location || i.location.trim() === '').length,
      highMargin: inventory.filter(i => i.purchasePrice > 0 && ((i.salePrice - i.purchasePrice) / i.purchasePrice) >= 0.5).length,
    };
  }, [inventory]);

  // Handle item submit
  const handleItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !code) {
      triggerFeedback('Nome e Código são obrigatórios.', 'error');
      return;
    }

    if (editingItem) {
      // Edit mode
      onEditItem({
        ...editingItem,
        code,
        name,
        category: category || 'Outros',
        quantity,
        minimumStock,
        purchasePrice,
        salePrice,
        unit,
        location,
        supplier,
        description,
        possibleApplications,
        imageUrl
      });
      triggerFeedback(`Material ${name} editado com sucesso!`, 'success');
      setEditingItem(null);
    } else {
      // Create mode
      onAddItem({
        code,
        name,
        category: category || 'Outros',
        quantity,
        minimumStock,
        purchasePrice,
        salePrice,
        unit,
        location,
        supplier,
        description,
        possibleApplications,
        imageUrl
      });

      // Log an automatic Entry (Entrada) movement if initial stock was declared > 0
      if (quantity > 0) {
        const autoMovement: InventoryMovement = {
          id: `mov-auto-${Date.now()}`,
          itemId: `inv-temp-${Date.now()}`, // Temporary or resolved on next load
          itemName: name,
          itemCode: code,
          type: 'INPUT',
          quantity,
          price: purchasePrice,
          description: 'Estoque inicial declarado no cadastro',
          supplier: supplier || 'Nenhum',
          date: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString()
        };
        saveMovements([autoMovement, ...movements]);
      }

      triggerFeedback(`Material ${name} incluído com sucesso no estoque!`, 'success');
      setIsAddingItem(false);
    }
    resetItemForm();
  };

  const resetItemForm = () => {
    setCode('');
    setName('');
    setCategory('');
    setQuantity(0);
    setMinimumStock(0);
    setPurchasePrice(0);
    setSalePrice(0);
    setUnit('un');
    setLocation('');
    setSupplier('');
    setDescription('');
    setPossibleApplications('');
    setImageUrl('');
  };

  const openAddItemForm = () => {
    resetItemForm();
    const generatedCode = 'EST-' + Math.floor(1000 + Math.random() * 9000);
    setCode(generatedCode);
    setIsAddingItem(true);
    setEditingItem(null);
  };

  const openEditItemForm = (item: InventoryItem) => {
    setEditingItem(item);
    setCode(item.code);
    setName(item.name);
    setCategory(item.category);
    setQuantity(item.quantity);
    setMinimumStock(item.minimumStock);
    setPurchasePrice(item.purchasePrice);
    setSalePrice(item.salePrice);
    setUnit(item.unit);
    setLocation(item.location || '');
    setSupplier(item.supplier || '');
    setDescription(item.description || '');
    setPossibleApplications(item.possibleApplications || '');
    setImageUrl(item.imageUrl || '');
    setIsAddingItem(false);
  };

  const [isDraggingImage, setIsDraggingImage] = useState(false);

  const handleImageChange = (file: File) => {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      triggerFeedback('Escolha uma imagem menor que 5MB.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 350;
        const MAX_HEIGHT = 350;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
        setImageUrl(compressedBase64);
        triggerFeedback('Imagem otimizada com sucesso!', 'success');
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleQuickQuantityUpdate = (item: InventoryItem, delta: number) => {
    const updatedQty = Math.max(0, item.quantity + delta);
    
    // Log dynamic movement
    const movement: InventoryMovement = {
      id: `mov-quick-${Date.now()}`,
      itemId: item.id,
      itemName: item.name,
      itemCode: item.code,
      type: delta > 0 ? 'INPUT' : 'OUTPUT',
      quantity: Math.abs(delta),
      price: delta > 0 ? item.purchasePrice : item.salePrice,
      description: delta > 0 ? 'Ajuste rápido de entrada (+)' : 'Ajuste rápido de saída (-)',
      date: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString()
    };

    saveMovements([movement, ...movements]);
    onEditItem({ ...item, quantity: updatedQty });
    triggerFeedback(`Estoque de ${item.name} alterado para ${updatedQty}!`, 'info');
  };

  // --------------------------------------------------------------------
  // SECTION 2: GRUPO DE MATERIAIS STATES & FUNCTIONS
  // --------------------------------------------------------------------
  const [groupSearchQuery, setGroupSearchQuery] = useState('');
  const [isAddingGroup, setIsAddingGroup] = useState(false);
  const [editingGroup, setEditingGroup] = useState<MaterialGroup | null>(null);
  const [groupName, setGroupName] = useState('');
  const [groupDesc, setGroupDesc] = useState('');

  const filteredGroups = useMemo(() => {
    return groups.filter(g => 
      g.name.toLowerCase().includes(groupSearchQuery.toLowerCase()) ||
      (g.description && g.description.toLowerCase().includes(groupSearchQuery.toLowerCase()))
    );
  }, [groups, groupSearchQuery]);

  const handleGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim()) {
      triggerFeedback('O nome do grupo é obrigatório.', 'error');
      return;
    }

    if (editingGroup) {
      // Edit
      const updated = groups.map(g => g.id === editingGroup.id ? { ...g, name: groupName, description: groupDesc } : g);
      saveGroups(updated);
      triggerFeedback(`Grupo "${groupName}" editado com sucesso!`, 'success');
      setEditingGroup(null);
    } else {
      // Add
      const newGroup: MaterialGroup = {
        id: `gp-${Date.now()}`,
        name: groupName,
        description: groupDesc,
        createdAt: new Date().toISOString()
      };
      saveGroups([...groups, newGroup]);
      triggerFeedback(`Grupo "${groupName}" criado com sucesso!`, 'success');
      setIsAddingGroup(false);
    }

    setGroupName('');
    setGroupDesc('');
  };

  const handleEditGroup = (g: MaterialGroup) => {
    setEditingGroup(g);
    setGroupName(g.name);
    setGroupDesc(g.description || '');
    setIsAddingGroup(false);
  };

  const handleDeleteGroup = (id: string, name: string) => {
    // Check if any materials are in this group
    const count = inventory.filter(item => item.category === name).length;
    setGroupToDelete({ id, name, count });
  };

  const confirmDeleteGroup = () => {
    if (!groupToDelete) return;
    saveGroups(groups.filter(g => g.id !== groupToDelete.id));
    triggerFeedback(`Grupo "${groupToDelete.name}" excluído!`, 'info');
    setGroupToDelete(null);
  };


  // --------------------------------------------------------------------
  // SECTION 3: FORNECEDORES STATES & FUNCTIONS
  // --------------------------------------------------------------------
  const [supplierSearchQuery, setSupplierSearchQuery] = useState('');
  const [isAddingSupplier, setIsAddingSupplier] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  
  // Supplier Form states
  const [supName, setSupName] = useState('');
  const [supCnpj, setSupCnpj] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supEmail, setSupEmail] = useState('');
  const [supAddress, setSupAddress] = useState('');

  const filteredSuppliers = useMemo(() => {
    return suppliers.filter(s => 
      s.name.toLowerCase().includes(supplierSearchQuery.toLowerCase()) ||
      (s.cnpjOrCpf && s.cnpjOrCpf.includes(supplierSearchQuery)) ||
      (s.email && s.email.toLowerCase().includes(supplierSearchQuery.toLowerCase()))
    );
  }, [suppliers, supplierSearchQuery]);

  const handleSupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supName.trim()) {
      triggerFeedback('O nome do fornecedor é obrigatório.', 'error');
      return;
    }

    if (editingSupplier) {
      // Edit
      const updated = suppliers.map(s => s.id === editingSupplier.id ? {
        ...s,
        name: supName,
        cnpjOrCpf: supCnpj,
        phone: supPhone,
        email: supEmail,
        address: supAddress
      } : s);
      saveSuppliers(updated);
      triggerFeedback(`Fornecedor "${supName}" editado com sucesso!`, 'success');
      setEditingSupplier(null);
    } else {
      // Add
      const newSup: Supplier = {
        id: `sup-${Date.now()}`,
        name: supName,
        cnpjOrCpf: supCnpj,
        phone: supPhone,
        email: supEmail,
        address: supAddress,
        createdAt: new Date().toISOString()
      };
      saveSuppliers([...suppliers, newSup]);
      triggerFeedback(`Fornecedor "${supName}" cadastrado com sucesso!`, 'success');
      setIsAddingSupplier(false);
    }

    resetSupplierForm();
  };

  const resetSupplierForm = () => {
    setSupName('');
    setSupCnpj('');
    setSupPhone('');
    setSupEmail('');
    setSupAddress('');
  };

  const handleEditSupplier = (s: Supplier) => {
    setEditingSupplier(s);
    setSupName(s.name);
    setSupCnpj(s.cnpjOrCpf || '');
    setSupPhone(s.phone || '');
    setSupEmail(s.email || '');
    setSupAddress(s.address || '');
    setIsAddingSupplier(false);
  };

  const handleDeleteSupplier = (id: string, name: string) => {
    setSupplierToDelete({ id, name });
  };

  const confirmDeleteSupplier = () => {
    if (!supplierToDelete) return;
    saveSuppliers(suppliers.filter(s => s.id !== supplierToDelete.id));
    triggerFeedback(`Fornecedor "${supplierToDelete.name}" excluído!`, 'info');
    setSupplierToDelete(null);
  };


  // --------------------------------------------------------------------
  // SECTION 4: RELATORIOS & INVENTARIO SYSTEMS
  // --------------------------------------------------------------------
  
  // MANUAL ENTRADA (INPUT) FORM
  const [manualInItemId, setManualInItemId] = useState('');
  const [manualInQty, setManualInQty] = useState<number>(1);
  const [manualInPrice, setManualInPrice] = useState<number>(0);
  const [manualInSupplier, setManualInSupplier] = useState('');
  const [manualInDesc, setManualInDesc] = useState('');
  const [manualInDate, setManualInDate] = useState(new Date().toISOString().split('T')[0]);
  const [manualInApplication, setManualInApplication] = useState('');
  const [manualInItemsList, setManualInItemsList] = useState<{ id: string; itemId: string; itemName: string; itemCode: string; quantity: number; price: number; application: string }[]>([]);

  // SEARCHABLE SELECT STATES
  const [manualInSearchQuery, setManualInSearchQuery] = useState('');
  const [manualInDropdownOpen, setManualInDropdownOpen] = useState(false);
  const [manualOutSearchQuery, setManualOutSearchQuery] = useState('');
  const [manualOutDropdownOpen, setManualOutDropdownOpen] = useState(false);

  // Sorted inventory in alphabetical order for search
  const sortedInventoryByName = useMemo(() => {
    return [...inventory].sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
  }, [inventory]);

  const filteredInInventory = useMemo(() => {
    if (!manualInSearchQuery) return sortedInventoryByName;
    const query = manualInSearchQuery.toLowerCase();
    return sortedInventoryByName.filter(item => 
      item.name.toLowerCase().includes(query) || 
      item.code.toLowerCase().includes(query) ||
      (item.category && item.category.toLowerCase().includes(query))
    );
  }, [sortedInventoryByName, manualInSearchQuery]);

  const filteredOutInventory = useMemo(() => {
    if (!manualOutSearchQuery) return sortedInventoryByName;
    const query = manualOutSearchQuery.toLowerCase();
    return sortedInventoryByName.filter(item => 
      item.name.toLowerCase().includes(query) || 
      item.code.toLowerCase().includes(query) ||
      (item.category && item.category.toLowerCase().includes(query))
    );
  }, [sortedInventoryByName, manualOutSearchQuery]);

  const handleSelectManualInItem = (item: InventoryItem) => {
    setManualInItemId(item.id);
    setManualInPrice(item.purchasePrice);
    if (item.supplier && !manualInSupplier) {
      setManualInSupplier(item.supplier);
    }
    setManualInSearchQuery('');
    setManualInDropdownOpen(false);
  };

  const handleClearManualInItem = () => {
    setManualInItemId('');
    setManualInPrice(0);
    setManualInSearchQuery('');
  };

  const handleSelectManualOutItem = (item: InventoryItem) => {
    setManualOutItemId(item.id);
    setManualOutSearchQuery('');
    setManualOutDropdownOpen(false);
  };

  const handleClearManualOutItem = () => {
    setManualOutItemId('');
    setManualOutSearchQuery('');
  };

  // QUICK ITEM CREATION FORM IN ENTRADA
  const [isQuickAddingItem, setIsQuickAddingItem] = useState(false);
  const [quickItemCode, setQuickItemCode] = useState('');
  const [quickItemName, setQuickItemName] = useState('');
  const [quickItemCategory, setQuickItemCategory] = useState('');
  const [quickItemMinStock, setQuickItemMinStock] = useState<number>(0);
  const [quickItemUnit, setQuickItemUnit] = useState('un');
  const [quickItemLocation, setQuickItemLocation] = useState('');

  // MANUAL SAIDA (OUTPUT) FORM
  const [manualOutItemId, setManualOutItemId] = useState('');
  const [manualOutQty, setManualOutQty] = useState<number>(1);
  const [manualOutDesc, setManualOutDesc] = useState('');
  const [manualOutDate, setManualOutDate] = useState(new Date().toISOString().split('T')[0]);
  const [manualOutType, setManualOutType] = useState<'Manutenção com OS' | 'Vendas' | 'Acerto de Estoque'>('Manutenção com OS');
  const [manualOutOsId, setManualOutOsId] = useState('');

  // Active OS references from database
  const [activeOrders, setActiveOrders] = useState<{ id: string; osNumber: string; title: string; clientName?: string }[]>([]);

  useEffect(() => {
    const storedOrders = localStorage.getItem('oficina_orders');
    const storedClients = localStorage.getItem('oficina_clients');
    if (storedOrders) {
      try {
        const parsedOrders = JSON.parse(storedOrders);
        const parsedClients = storedClients ? JSON.parse(storedClients) : [];
        const enriched = parsedOrders.map((o: any) => {
          const client = parsedClients.find((c: any) => c.id === o.clientId);
          return {
            id: o.id,
            osNumber: o.osNumber,
            title: o.title,
            clientName: client ? client.name : ''
          };
        });
        setActiveOrders(enriched);
      } catch (e) {
        console.error('Error loading orders inside InventoryManager: ', e);
      }
    }
  }, []);

  // ACERTO DE ESTOQUE (STOCK ADJUSTMENT) FORM
  const [manualAdjItemId, setManualAdjItemId] = useState('');
  const [manualAdjRealQty, setManualAdjRealQty] = useState<number | ''>('');
  const [manualAdjReason, setManualAdjReason] = useState('Divergência física');
  const [manualAdjDesc, setManualAdjDesc] = useState('');

  // PHYSICAL AUDIT CONTROL STATE
  const [activeAudit, setActiveAudit] = useState<Omit<PhysicalInventory, 'id' | 'createdAt'> | null>(null);

  const handleManualAdjustmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualAdjItemId) {
      triggerFeedback('Selecione um material.', 'error');
      return;
    }
    const item = inventory.find(i => i.id === manualAdjItemId);
    if (!item) return;

    if (manualAdjRealQty === '' || manualAdjRealQty < 0) {
      triggerFeedback('Digite uma quantidade física real válida (0 ou superior).', 'error');
      return;
    }

    const currentQty = item.quantity;
    const realQty = manualAdjRealQty;
    const difference = realQty - currentQty;

    if (difference === 0) {
      triggerFeedback('A quantidade informada é idêntica ao saldo atual. Nenhum ajuste necessário.', 'info');
      return;
    }

    // Update item stock quantity
    const updatedItem = {
      ...item,
      quantity: realQty
    };
    onEditItem(updatedItem);

    // Register movement log (INPUT for surplus, OUTPUT for loss)
    const movement: InventoryMovement = {
      id: `mov-adj-${Date.now()}`,
      itemId: item.id,
      itemName: item.name,
      itemCode: item.code,
      type: difference > 0 ? 'INPUT' : 'OUTPUT',
      quantity: Math.abs(difference),
      price: difference > 0 ? item.purchasePrice : item.salePrice,
      description: `Acerto de Estoque [Motivo: ${manualAdjReason}] - ${manualAdjDesc.trim() || 'Ajuste de saldo direto'} (Saldo anterior: ${currentQty} -> Novo saldo: ${realQty})`,
      date: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString()
    };

    saveMovements([movement, ...movements]);
    triggerFeedback(`Estoque de ${item.name} ajustado de ${currentQty} para ${realQty} com sucesso!`, 'success');

    // Reset Form
    setManualAdjItemId('');
    setManualAdjRealQty('');
    setManualAdjReason('Divergência física');
    setManualAdjDesc('');
  };

  // Handle adding an item to the draft list for Entrada (Inclusão de Itens)
  const handleAddDraftInItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInItemId) {
      triggerFeedback('Selecione um material.', 'error');
      return;
    }
    const item = inventory.find(i => i.id === manualInItemId);
    if (!item) return;

    if (manualInQty <= 0) {
      triggerFeedback('A quantidade de entrada deve ser maior que zero.', 'error');
      return;
    }

    const alreadyExists = manualInItemsList.some(d => d.itemId === manualInItemId);
    if (alreadyExists) {
      triggerFeedback('Este material já está na lista. Remova-o ou edite para alterar.', 'error');
      return;
    }

    const draftItem = {
      id: `draft-in-${Date.now()}-${Math.random()}`,
      itemId: item.id,
      itemName: item.name,
      itemCode: item.code,
      quantity: manualInQty,
      price: manualInPrice > 0 ? manualInPrice : item.purchasePrice,
      application: manualInApplication.trim()
    };

    setManualInItemsList([...manualInItemsList, draftItem]);
    
    // Clear item inputs for the next add, but keep supplier, date, description
    setManualInItemId('');
    setManualInQty(1);
    setManualInPrice(0);
    setManualInApplication('');
    triggerFeedback('Item incluído na lista de entrada!', 'success');
  };

  const handleRemoveDraftInItem = (id: string) => {
    setManualInItemsList(manualInItemsList.filter(d => d.id !== id));
  };

  // Handle Quick Material Creation directly from Entrada tab
  const handleQuickItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickItemName || !quickItemCode) {
      triggerFeedback('Nome e Código do SKU são obrigatórios.', 'error');
      return;
    }

    // Call onAddItem to add the material
    onAddItem({
      code: quickItemCode,
      name: quickItemName,
      category: quickItemCategory || 'Outros',
      quantity: 0, // start with 0, they will enter it in the Entrada form!
      minimumStock: quickItemMinStock,
      purchasePrice: 0,
      salePrice: 0,
      unit: quickItemUnit || 'un',
      location: quickItemLocation,
      supplier: manualInSupplier || '',
      description: 'Material cadastrado via Entrada de Peças',
      possibleApplications: manualInApplication || ''
    });

    triggerFeedback(`Material "${quickItemName}" cadastrado! Você já pode selecioná-lo na lista.`, 'success');
    setIsQuickAddingItem(false);

    // Reset fields
    setQuickItemName('');
    setQuickItemCode('');
    setQuickItemCategory('');
    setQuickItemMinStock(0);
    setQuickItemUnit('un');
    setQuickItemLocation('');
  };

  // Handle Manual Input Registration (Lançar Entrada)
  const handleManualInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let itemsToProcess = [...manualInItemsList];
    
    // If list is empty but they filled out the select, let's treat it as a single direct item
    if (itemsToProcess.length === 0) {
      if (!manualInItemId) {
        triggerFeedback('Adicione pelo menos um item à lista ou preencha os dados do material.', 'error');
        return;
      }
      
      if (manualInQty <= 0) {
        triggerFeedback('A quantidade de entrada deve ser maior que zero.', 'error');
        return;
      }
      
      const item = inventory.find(i => i.id === manualInItemId);
      if (!item) return;

      itemsToProcess.push({
        id: `draft-in-direct-${Date.now()}`,
        itemId: item.id,
        itemName: item.name,
        itemCode: item.code,
        quantity: manualInQty,
        price: manualInPrice > 0 ? manualInPrice : item.purchasePrice,
        application: manualInApplication.trim()
      });
    }

    // Process all items
    const newMovements: InventoryMovement[] = [];

    itemsToProcess.forEach(draft => {
      const item = inventory.find(i => i.id === draft.itemId);
      if (!item) return;

      // Update item stock quantity, purchase price, and application
      const updatedApplications = draft.application 
        ? (item.possibleApplications 
          ? Array.from(new Set([...item.possibleApplications.split(',').map(a => a.trim()), draft.application])).join(', ')
          : draft.application)
        : item.possibleApplications;

      const updatedItem: InventoryItem = {
        ...item,
        quantity: item.quantity + draft.quantity,
        purchasePrice: draft.price > 0 ? draft.price : item.purchasePrice,
        possibleApplications: updatedApplications
      };

      // Call parent's edit item function
      onEditItem(updatedItem);

      // Create movement log
      const movement: InventoryMovement = {
        id: `mov-in-${Date.now()}-${Math.random()}`,
        itemId: item.id,
        itemName: item.name,
        itemCode: item.code,
        type: 'INPUT',
        quantity: draft.quantity,
        price: draft.price,
        description: `${manualInDesc.trim() || 'Entrada de mercadoria'}${draft.application ? ` (Aplicação: ${draft.application})` : ''}`,
        supplier: manualInSupplier || 'Nenhum',
        date: manualInDate,
        createdAt: new Date().toISOString()
      };

      newMovements.push(movement);
    });

    saveMovements([...newMovements, ...movements]);
    triggerFeedback(`Entrada lançada com sucesso para ${itemsToProcess.length} item(ns)!`, 'success');

    // Reset Form
    setManualInItemId('');
    setManualInQty(1);
    setManualInPrice(0);
    setManualInSupplier('');
    setManualInDesc('');
    setManualInDate(new Date().toISOString().split('T')[0]);
    setManualInApplication('');
    setManualInItemsList([]);
  };

  // Handle Manual Output Registration (Lançar Saída)
  const handleManualOutputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualOutItemId) {
      triggerFeedback('Selecione um material.', 'error');
      return;
    }
    const item = inventory.find(i => i.id === manualOutItemId);
    if (!item) return;

    if (manualOutQty <= 0) {
      triggerFeedback('A quantidade de saída deve ser maior que zero.', 'error');
      return;
    }

    if (item.quantity < manualOutQty) {
      triggerFeedback(`Estoque insuficiente! Estoque disponível atual: ${item.quantity} ${item.unit}.`, 'error');
      return;
    }

    // Update stock quantity
    const updatedItem = {
      ...item,
      quantity: item.quantity - manualOutQty
    };
    onEditItem(updatedItem);

    // Form description based on Type of Exit
    let finalDesc = '';
    if (manualOutType === 'Manutenção com OS') {
      const selectedOs = activeOrders.find(o => o.id === manualOutOsId);
      const osLabel = selectedOs ? `${selectedOs.osNumber} (${selectedOs.clientName || 'Cliente'})` : manualOutOsId || 'OS';
      finalDesc = `Saída para Manutenção com OS: ${osLabel}. ${manualOutDesc.trim()}`;
    } else if (manualOutType === 'Vendas') {
      finalDesc = `Saída por Venda. ${manualOutDesc.trim()}`;
    } else {
      finalDesc = `Saída por Acerto de Estoque. ${manualOutDesc.trim()}`;
    }

    // Register movement log
    const movement: InventoryMovement = {
      id: `mov-out-${Date.now()}`,
      itemId: item.id,
      itemName: item.name,
      itemCode: item.code,
      type: 'OUTPUT',
      quantity: manualOutQty,
      price: item.salePrice,
      description: finalDesc,
      date: manualOutDate,
      createdAt: new Date().toISOString()
    };

    saveMovements([movement, ...movements]);
    triggerFeedback(`Saída de ${manualOutQty}x ${item.name} lançada com sucesso!`, 'success');

    // Reset Form
    setManualOutItemId('');
    setManualOutQty(1);
    setManualOutDesc('');
    setManualOutDate(new Date().toISOString().split('T')[0]);
    setManualOutType('Manutenção com OS');
    setManualOutOsId('');
  };

  // --------------------------------------------------------------------
  // INVENTÁRIO FÍSICO / CONTROLE DE AUDITORIA DE AUDITS
  // --------------------------------------------------------------------
  const startNewAudit = () => {
    const auditItems = inventory.map(item => ({
      itemId: item.id,
      itemName: item.name,
      itemCode: item.code,
      expectedQty: item.quantity,
      actualQty: item.quantity, // starts matching expected
      difference: 0,
      adjusted: false
    }));

    setActiveAudit({
      title: `Auditoria Física - ${new Date().toLocaleDateString('pt-BR')}`,
      date: new Date().toISOString().split('T')[0],
      status: 'DRAFT',
      items: auditItems
    });
    triggerFeedback('Sessão de Auditoria Física iniciada! Ajuste os valores contados abaixo.', 'info');
  };

  const handleAuditQtyChange = (itemId: string, val: number) => {
    if (!activeAudit) return;
    const updatedItems = activeAudit.items.map(item => {
      if (item.itemId === itemId) {
        const diff = val - item.expectedQty;
        return {
          ...item,
          actualQty: val,
          difference: diff
        };
      }
      return item;
    });

    setActiveAudit({
      ...activeAudit,
      items: updatedItems
    });
  };

  const cancelActiveAudit = () => {
    setConfirmCancelAudit(true);
  };

  const handleConfirmCancelAudit = () => {
    setActiveAudit(null);
    setConfirmCancelAudit(false);
  };

  const finalizeAndSyncAudit = () => {
    if (!activeAudit) return;
    setConfirmFinalizeAudit(true);
  };

  const handleConfirmFinalizeAudit = () => {
    if (!activeAudit) return;

    // Synchronize all items physical count
    const logMovements: InventoryMovement[] = [];
    const today = new Date().toISOString().split('T')[0];

    activeAudit.items.forEach(auditItem => {
      const realItem = inventory.find(i => i.id === auditItem.itemId);
      if (!realItem) return;

      // Only adjust and log if there is a difference
      if (auditItem.difference !== 0) {
        // Adjust the item stock
        onEditItem({
          ...realItem,
          quantity: auditItem.actualQty
        });

        // Register discrepancy movement log
        const direction = auditItem.difference > 0 ? 'INPUT' : 'OUTPUT';
        const discrepancyMovement: InventoryMovement = {
          id: `mov-audit-adj-${Date.now()}-${realItem.id}`,
          itemId: realItem.id,
          itemName: realItem.name,
          itemCode: realItem.code,
          type: direction,
          quantity: Math.abs(auditItem.difference),
          price: direction === 'INPUT' ? realItem.purchasePrice : realItem.salePrice,
          description: `Ajuste de Auditoria de Inventário (${auditItem.difference > 0 ? '+' : ''}${auditItem.difference})`,
          date: today,
          createdAt: new Date().toISOString()
        };
        logMovements.push(discrepancyMovement);
      }
    });

    // Save movements log
    if (logMovements.length > 0) {
      saveMovements([...logMovements, ...movements]);
    }

    // Save persistent completed audit log
    const completedAudit: PhysicalInventory = {
      ...activeAudit,
      id: `audit-${Date.now()}`,
      status: 'COMPLETED',
      createdAt: new Date().toISOString()
    };

    saveAudits([completedAudit, ...audits]);
    setActiveAudit(null);
    setConfirmFinalizeAudit(false);
    triggerFeedback('Estoque sincronizado e inventário finalizado com absoluto sucesso!', 'success');
  };

  // PRINT CURRENT INVENTORY FUNCTION
  const handlePrintInventory = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const itemsRows = inventory.map(item => `
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 8px; font-family: monospace;">${item.code}</td>
        <td style="padding: 8px;"><b>${item.name}</b><br><small style="color: #666;">${item.category}</small></td>
        <td style="padding: 8px; text-align: center;">${item.quantity} ${item.unit}</td>
        <td style="padding: 8px; text-align: right;">R$ ${item.purchasePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
        <td style="padding: 8px; text-align: right;">R$ ${item.salePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
        <td style="padding: 8px; text-align: right; font-weight: bold;">R$ ${(item.quantity * item.purchasePrice).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
        <td style="padding: 8px; color: #666;">${item.location || 'Não definida'}</td>
      </tr>
    `).join('');

    const totalCostVal = inventory.reduce((sum, item) => sum + (item.quantity * item.purchasePrice), 0);
    const totalSaleVal = inventory.reduce((sum, item) => sum + (item.quantity * item.salePrice), 0);

    printWindow.document.write(`
      <html>
        <head>
          <title>Relatório Geral de Estoque - JC&F</title>
          <style>
            body { font-family: 'Helvetica Neue', Arial, sans-serif; color: #333; margin: 30px; }
            h1 { text-align: center; font-size: 20px; text-transform: uppercase; margin-bottom: 5px; }
            h2 { text-align: center; font-size: 14px; color: #666; margin-top: 0; margin-bottom: 30px; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 12px; }
            th { background-color: #f5f5f5; padding: 10px; border-bottom: 2px solid #ddd; text-align: left; }
            .summary-box { display: flex; justify-content: space-between; margin-bottom: 25px; background: #fafafa; padding: 15px; border: 1px solid #eee; border-radius: 5px; }
            .stat { text-align: center; }
            .stat-title { font-size: 10px; color: #888; text-transform: uppercase; font-weight: bold; }
            .stat-value { font-size: 15px; font-weight: bold; margin-top: 5px; color: #000; }
          </style>
        </head>
        <body>
          <h1>JC&F - MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA</h1>
          <h2>RELATÓRIO EMISSÃO DE POSIÇÃO DE ESTOQUE - ${new Date().toLocaleDateString('pt-BR')} ${new Date().toLocaleTimeString('pt-BR')}</h2>
          
          <div class="summary-box">
            <div class="stat">
              <div class="stat-title">Materiais Cadastrados</div>
              <div class="stat-value">${inventory.length}</div>
            </div>
            <div class="stat">
              <div class="stat-title">Unidades Físicas em Estoque</div>
              <div class="stat-value">${inventory.reduce((sum, item) => sum + item.quantity, 0)}</div>
            </div>
            <div class="stat">
              <div class="stat-title">Valorização de Custo Total</div>
              <div class="stat-value">R$ ${totalCostVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            </div>
            <div class="stat">
              <div class="stat-title">Faturamento Potencial de Venda</div>
              <div class="stat-value">R$ ${totalSaleVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width: 12%;">Código</th>
                <th>Nome do Material / Grupo</th>
                <th style="width: 12%; text-align: center;">Quantidade</th>
                <th style="width: 12%; text-align: right;">Custo Unitário</th>
                <th style="width: 12%; text-align: right;">Venda Unitária</th>
                <th style="width: 15%; text-align: right;">Subtotal Custo</th>
                <th style="width: 15%;">Localização</th>
              </tr>
            </thead>
            <tbody>
              ${itemsRows}
            </tbody>
          </table>
          
          <p style="text-align: right; margin-top: 40px; font-size: 10px; color: #999;">Assinatura do Almoxarife Responsável: _________________________________________</p>
          
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Render Category count for stats helper
  const getCategoryCount = (catName: string) => {
    return inventory.filter(item => item.category === catName).length;
  };

  return (
    <div className="space-y-6" id="comprehensive-inventory-system">
      
      {/* Dynamic Feedback Toast */}
      {feedback && (
        <div className={`fixed top-4 right-4 z-50 px-5 py-3 rounded-2xl border flex items-center gap-3 shadow-2xl transition-all duration-300 animate-slide-in ${
          feedback.type === 'success' ? 'bg-emerald-950/90 border-emerald-500/30 text-emerald-200' :
          feedback.type === 'error' ? 'bg-red-950/90 border-red-500/30 text-red-200' :
          'bg-slate-900/90 border-amber-500/30 text-amber-200'
        }`}>
          {feedback.type === 'success' && <CheckCircle className="w-5 h-5 text-emerald-400" />}
          {feedback.type === 'error' && <AlertTriangle className="w-5 h-5 text-red-400" />}
          {feedback.type === 'info' && <Activity className="w-5 h-5 text-amber-400" />}
          <span className="text-xs font-semibold">{feedback.message}</span>
        </div>
      )}

      {/* HEADER SECTION WITH NAVIGATION SHIELDS */}
      <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-amber-500 to-yellow-600 rounded-2xl border border-amber-500/20 text-slate-950 shadow-sm">
            <Package className="w-6 h-6 font-bold" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-black text-slate-900 uppercase tracking-wider">Sistema de Controle Industrial de Estoque</h1>
            <p className="text-[11px] text-slate-600 font-medium">Módulos integrados para rastreamento de peças, fornecedores, entrada/saída e auditorias</p>
          </div>
        </div>

        {/* Primary Navigation System */}
        <div className="flex flex-wrap gap-1.5 bg-slate-100 p-1 border border-slate-300 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab('MATERIALS')}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-300 cursor-pointer flex items-center gap-2 ${activeTab === 'MATERIALS' ? 'bg-amber-500 text-slate-950 shadow-sm font-black' : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200'}`}
          >
            <Package className="w-4 h-4" />
            <span>Materiais</span>
          </button>
          
          <button
            type="button"
            onClick={() => setActiveTab('GROUPS')}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-300 cursor-pointer flex items-center gap-2 ${activeTab === 'GROUPS' ? 'bg-amber-500 text-slate-950 shadow-sm font-black' : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200'}`}
          >
            <Layers className="w-4 h-4" />
            <span>Grupos</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('SUPPLIERS')}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-300 cursor-pointer flex items-center gap-2 ${activeTab === 'SUPPLIERS' ? 'bg-amber-500 text-slate-950 shadow-sm font-black' : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200'}`}
          >
            <Building2 className="w-4 h-4" />
            <span>Fornecedores</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('REPORTS')}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-300 cursor-pointer flex items-center gap-2 ${activeTab === 'REPORTS' ? 'bg-amber-500 text-slate-950 shadow-sm font-black' : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200'}`}
          >
            <FileText className="w-4 h-4" />
            <span>Relatórios / Auditorias</span>
          </button>
        </div>
      </div>

      {/* -------------------------------------------------------------------- */}
      {/* TAB 1: MATERIAIS / PARTS TAB                                        */}
      {/* -------------------------------------------------------------------- */}
      {activeTab === 'MATERIALS' && (
        <div className="space-y-6" id="view-materials-tab">
          
          {/* Overview Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Itens Cadastrados</p>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1 font-mono">{stats.totalItems}</h3>
                </div>
                <div className="p-2 rounded-xl border border-blue-300 bg-blue-50 text-blue-600">
                  <Package className="w-5 h-5" />
                </div>
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-medium">Diferentes referências físicas</p>
            </div>

            <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Unidades Físicas</p>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1 font-mono">{stats.totalUnits}</h3>
                </div>
                <div className="p-2 rounded-xl border border-indigo-300 bg-indigo-50 text-indigo-600">
                  <ClipboardList className="w-5 h-5" />
                </div>
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-medium">Soma física total das peças</p>
            </div>

            <div className={`border rounded-2xl p-4 flex flex-col justify-between transition-all shadow-sm ${stats.belowMinCount > 0 ? 'bg-red-50 border-red-300' : 'bg-white border-slate-300'}`}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Estoques Críticos</p>
                  <h3 className={`text-xl sm:text-2xl font-extrabold mt-1 font-mono ${stats.belowMinCount > 0 ? 'text-red-600 animate-pulse' : 'text-slate-800'}`}>{stats.belowMinCount}</h3>
                </div>
                <div className={`p-2 rounded-xl border ${stats.belowMinCount > 0 ? 'bg-red-100 border-red-300 text-red-600' : 'bg-slate-100 border-slate-300 text-slate-500'}`}>
                  <AlertTriangle className="w-5 h-5" />
                </div>
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-medium">Abaixo do estoque de segurança</p>
            </div>

            <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Custo de Aquisição</p>
                  <h3 className="text-xl font-extrabold text-emerald-700 mt-1 font-mono">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.inventoryValuation)}
                  </h3>
                </div>
                <div className="p-2 rounded-xl border border-emerald-300 bg-emerald-50 text-emerald-600">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-medium">Capital investido imobilizado</p>
            </div>

            <div className="bg-white border border-slate-300 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Faturamento Líquido</p>
                  <h3 className="text-xl font-extrabold text-fuchsia-700 mt-1 font-mono">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.potentialProfit)}
                  </h3>
                </div>
                <div className="p-2 rounded-xl border border-fuchsia-300 bg-fuchsia-50 text-fuchsia-600">
                  <TrendingUp className="w-5 h-5" />
                </div>
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-medium">Margem agregada estimada</p>
            </div>
          </div>

          {/* Critical Stock Alert Banner */}
          {stats.belowMinCount > 0 && (
            <div className="bg-red-50 border-2 border-red-300 rounded-2xl p-4 flex flex-col sm:flex-row items-center gap-3.5 shadow-sm">
              <div className="p-2 bg-red-100 rounded-xl border border-red-300 text-red-600 shrink-0">
                <ShieldAlert className="w-5 h-5 animate-bounce" />
              </div>
              <div className="text-center sm:text-left flex-grow">
                <h4 className="text-xs font-black text-red-900 uppercase tracking-wider">Aviso de Ruptura de Estoque!</h4>
                <p className="text-[11px] text-red-700 mt-0.5 font-medium">
                  Há {stats.belowMinCount} peças industriais com quantidade de estoque abaixo do limite mínimo recomendado.
                </p>
              </div>
              <button 
                type="button"
                onClick={() => setFilterAlertOnly(!filterAlertOnly)}
                className={`px-3 py-1.5 border text-[10px] font-black uppercase tracking-wider rounded-lg transition-colors shrink-0 cursor-pointer ${filterAlertOnly ? 'bg-red-600 border-red-700 text-white' : 'bg-red-100 border-red-300 text-red-800 hover:bg-red-200'}`}
              >
                {filterAlertOnly ? 'Ver Todas as Peças' : 'Ver Apenas Críticos'}
              </button>
            </div>
          )}

          {/* Form and Material Listing Row */}
          <div className="flex flex-col lg:flex-row gap-6 items-start">
            
            {/* Form Drawer (Add/Edit) */}
            {(isAddingItem || editingItem) && (
              <div className="w-full lg:w-96 bg-white border-2 border-amber-400 rounded-2xl p-5 space-y-4 shrink-0 transition-all duration-300 shadow-md text-slate-900">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                    <Package className="w-4 h-4 text-amber-600" />
                    <span>{editingItem ? 'Editar Componente' : 'Novo Componente'}</span>
                  </h3>
                  <button 
                    type="button"
                    onClick={() => {
                      setIsAddingItem(false);
                      setEditingItem(null);
                    }}
                    className="text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleItemSubmit} className="space-y-4 text-xs">
                  
                  {/* Code */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Código do Item / SKU *</label>
                    <input
                      type="text"
                      required
                      value={code}
                      onChange={(e) => setCode(e.target.value.toUpperCase())}
                      placeholder="Ex: EST-VED05"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                    />
                  </div>

                  {/* Name */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Nome do Componente *</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ex: Válvula de Retenção de Esfera 1/2"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                    />
                  </div>

                  {/* Category Selection from dynamic groups */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Grupo / Categoria</label>
                      <select
                        value={category}
                        required
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-xs font-medium"
                      >
                        <option value="">Selecione...</option>
                        {groups.map(g => (
                          <option key={g.id} value={g.name}>{g.name}</option>
                        ))}
                        {groups.length === 0 && <option value="Outros">Outros</option>}
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Unidade</label>
                      <select
                        value={unit}
                        onChange={(e) => setUnit(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-xs font-medium"
                      >
                        <option value="un">un (Unidade)</option>
                        <option value="litro">litro</option>
                        <option value="metro">metro</option>
                        <option value="jogo">jogo</option>
                        <option value="kit">kit</option>
                        <option value="kg">kg</option>
                      </select>
                    </div>
                  </div>

                  {/* Quantity & safety min stock */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Qtd Inicial</label>
                      <input
                        type="number"
                        min="0"
                        required
                        disabled={!!editingItem} // Quantity editing is controlled in edit table or via entries/outputs logs
                        value={quantity === 0 ? '' : quantity}
                        onChange={(e) => setQuantity(parseFloat(e.target.value) || 0)}
                        placeholder="0"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-hidden focus:border-amber-500 focus:bg-white disabled:opacity-50"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Mínimo de Segurança</label>
                      <input
                        type="number"
                        min="0"
                        value={minimumStock === 0 ? '' : minimumStock}
                        onChange={(e) => setMinimumStock(parseFloat(e.target.value) || 0)}
                        placeholder="Ex: 5"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-hidden focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                  </div>

                  {/* Prices */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Preço Custo (R$)</label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={purchasePrice === 0 ? '' : purchasePrice}
                        onChange={(e) => setPurchasePrice(parseFloat(e.target.value) || 0)}
                        placeholder="0.00"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-hidden focus:border-amber-500 focus:bg-white"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Preço Venda (R$)</label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={salePrice === 0 ? '' : salePrice}
                        onChange={(e) => setSalePrice(parseFloat(e.target.value) || 0)}
                        placeholder="0.00"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-hidden focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                  </div>

                  {/* Margin preview */}
                  {purchasePrice > 0 && salePrice > 0 && (
                    <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[10px] flex items-center justify-between">
                      <span className="text-slate-600 font-medium">Margem Estimada:</span>
                      <span className="font-mono font-black text-amber-800">
                        +{purchasePrice > 0 ? Math.round(((salePrice - purchasePrice) / purchasePrice) * 100) : 0}% de lucro
                      </span>
                    </div>
                  )}

                  {/* Supplier select & location */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Fornecedor</label>
                      <select
                        value={supplier}
                        onChange={(e) => setSupplier(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-xs font-medium"
                      >
                        <option value="">Selecione...</option>
                        {suppliers.map(s => (
                          <option key={s.id} value={s.name}>{s.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Localização Física</label>
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="Ex: Armário B-3"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                  </div>

                  {/* Description */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Observações Técnicas</label>
                    <textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Medidas, pressão nominal, materiais metálicos etc..."
                      rows={2}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-xs"
                    />
                  </div>

                  {/* Possible Applications / Usage */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Onde é utilizado possivelmente?</label>
                    <textarea
                      value={possibleApplications}
                      onChange={(e) => setPossibleApplications(e.target.value)}
                      placeholder="Ex: Cilindros de retroescavadeira CASE, prensas hidráulicas Parker, unidades de lubrificação, etc."
                      rows={2}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white text-xs"
                    />
                  </div>

                  {/* Material Photo / Image Option */}
                  <div className="space-y-2">
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Foto / Imagem do Material</label>
                    
                    {imageUrl ? (
                      <div className="relative rounded-xl overflow-hidden border border-slate-300 bg-slate-50 p-1.5">
                        <img 
                          src={imageUrl} 
                          alt="Previsualização do Material" 
                          className="w-full h-32 object-cover rounded-lg"
                          referrerPolicy="no-referrer"
                        />
                        <button
                          type="button"
                          onClick={() => setImageUrl('')}
                          className="absolute top-2.5 right-2.5 p-1.5 bg-red-600 border border-red-700 text-white rounded-lg hover:bg-red-700 transition-colors cursor-pointer"
                          title="Remover Imagem"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onDragOver={(e) => {
                          e.preventDefault();
                          setIsDraggingImage(true);
                        }}
                        onDragLeave={() => setIsDraggingImage(false)}
                        onDrop={(e) => {
                          e.preventDefault();
                          setIsDraggingImage(false);
                          const file = e.dataTransfer.files?.[0];
                          if (file) handleImageChange(file);
                        }}
                        className={`border-2 border-dashed rounded-xl p-4 text-center transition-all cursor-pointer ${
                          isDraggingImage 
                            ? 'border-amber-500 bg-amber-50' 
                            : 'border-slate-300 bg-slate-50 hover:border-slate-400'
                        }`}
                        onClick={() => document.getElementById('material-photo-input')?.click()}
                      >
                        <input
                          id="material-photo-input"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleImageChange(file);
                          }}
                        />
                        <div className="flex flex-col items-center gap-1.5">
                          <Package className="w-6 h-6 text-slate-400" />
                          <span className="text-[10px] text-slate-700 font-bold">
                            Arraste a foto ou clique para buscar
                          </span>
                          <span className="text-[9px] text-slate-500">
                            Imagens JPG/PNG otimizadas automaticamente
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Or Paste URL Option */}
                    <div className="space-y-1">
                      <span className="text-[9px] text-slate-500 block text-center font-mono">OU</span>
                      <input
                        type="url"
                        value={imageUrl && !imageUrl.startsWith('data:') ? imageUrl : ''}
                        onChange={(e) => setImageUrl(e.target.value)}
                        placeholder="Cole o endereço/URL da foto aqui..."
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 text-[11px] placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                  </div>

                  {/* Action row */}
                  <div className="flex items-center gap-2 pt-2 border-t border-slate-200">
                    <button
                      type="submit"
                      className="flex-grow flex items-center justify-center gap-1.5 px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 text-slate-950 font-black uppercase tracking-wider text-[10px] rounded-lg transition-colors cursor-pointer shadow-sm"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{editingItem ? 'Salvar Edição' : 'Cadastrar Peça'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddingItem(false);
                        setEditingItem(null);
                      }}
                      className="px-4 py-2 bg-slate-100 border border-slate-300 text-slate-700 hover:text-slate-900 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>

                </form>
              </div>
            )}

            {/* List Table Grid */}
            <div className="flex-grow w-full space-y-4">
              
              {/* Status Quick Filter Chips with counts */}
              <div className="flex items-center gap-2 pb-1 overflow-x-auto select-none no-scrollbar whitespace-nowrap scrollbar-thin">
                <button
                  type="button"
                  onClick={() => setStatusFilter('ALL')}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1.5 shadow-xs ${
                    statusFilter === 'ALL'
                      ? 'bg-amber-500 border-amber-500 text-slate-950 font-black shadow-md'
                      : 'bg-white border-slate-300 text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Package className="w-3.5 h-3.5" />
                  <span>Todos ({statusCounts.all})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStatusFilter('CRITICAL')}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1.5 shadow-xs ${
                    statusFilter === 'CRITICAL'
                      ? 'bg-red-600 border-red-600 text-white font-black shadow-md'
                      : 'bg-white border-slate-300 text-red-700 hover:bg-red-50'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
                  <span>Críticos ({statusCounts.critical})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStatusFilter('OUT_OF_STOCK')}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1.5 shadow-xs ${
                    statusFilter === 'OUT_OF_STOCK'
                      ? 'bg-rose-600 border-rose-600 text-white font-black shadow-md'
                      : 'bg-white border-slate-300 text-rose-700 hover:bg-rose-50'
                  }`}
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>Sem Estoque ({statusCounts.outOfStock})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStatusFilter('HEALTHY')}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1.5 shadow-xs ${
                    statusFilter === 'HEALTHY'
                      ? 'bg-emerald-600 border-emerald-600 text-white font-black shadow-md'
                      : 'bg-white border-slate-300 text-emerald-700 hover:bg-emerald-50'
                  }`}
                >
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Saudável ({statusCounts.healthy})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStatusFilter('HIGH_MARGIN')}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1.5 shadow-xs ${
                    statusFilter === 'HIGH_MARGIN'
                      ? 'bg-fuchsia-600 border-fuchsia-600 text-white font-black shadow-md'
                      : 'bg-white border-slate-300 text-fuchsia-700 hover:bg-fuchsia-50'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5 text-fuchsia-600" />
                  <span>Alta Margem (+50%) ({statusCounts.highMargin})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStatusFilter('NO_LOCATION')}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer border flex items-center gap-1.5 shadow-xs ${
                    statusFilter === 'NO_LOCATION'
                      ? 'bg-slate-800 border-slate-800 text-white font-black shadow-md'
                      : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <MapPin className="w-3.5 h-3.5 text-slate-500" />
                  <span>Sem Endereço ({statusCounts.noLocation})</span>
                </button>
              </div>

              {/* Search, Filter Bar */}
              <div className="bg-white rounded-2xl border border-slate-300 p-4 space-y-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4 shadow-sm">
                
                {/* Query Input */}
                <div className="relative flex-grow max-w-md">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Pesquisar por nome, código, fornecedor ou armário..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                {/* Dropdowns */}
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:border-amber-500 font-medium focus:bg-white"
                  >
                    <option value="ALL">Todas as Categorias</option>
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>

                  <div className="flex bg-slate-100 border border-slate-300 rounded-xl p-0.5">
                    <button
                      type="button"
                      onClick={() => setViewMode('SEARCH_SELECT')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold ${
                        viewMode === 'SEARCH_SELECT' 
                          ? 'bg-amber-500 text-slate-950 shadow-xs font-black' 
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                      title="Modo Pesquisa & Escolha Dinâmica"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Pesquisa & Escolha</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setViewMode('TABLE')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold ${
                        viewMode === 'TABLE' 
                          ? 'bg-amber-500 text-slate-950 shadow-xs font-black' 
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                      title="Tabela Detalhada"
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Tabela</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setViewMode('GRID')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold ${
                        viewMode === 'GRID' 
                          ? 'bg-amber-500 text-slate-950 shadow-xs font-black' 
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                      title="Grade de Catálogo"
                    >
                      <LayoutGrid className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Catálogo</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowImportModal(true)}
                    className="flex items-center gap-2 px-4 py-2 border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-extrabold text-xs rounded-xl tracking-wider uppercase transition-all cursor-pointer shadow-xs"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                    <span>Importar Planilha</span>
                  </button>

                  <button
                    type="button"
                    onClick={openAddItemForm}
                    className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl tracking-wider uppercase transition-all cursor-pointer shadow-xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Cadastrar Peça</span>
                  </button>
                </div>
              </div>

              {/* View Switcher: SEARCH_SELECT vs TABLE vs GRID */}
              {viewMode === 'SEARCH_SELECT' ? (
                /* INDUSTRIAL SEARCH & SELECT STUDIO - ESTILO PESQUISA DE CLIENTES */
                <div className="bg-[#e9edf2] border-2 border-[#b0bec5] rounded-2xl p-3 md:p-4 shadow-sm space-y-4" id="inventory-search-select-studio">
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
                    
                    {/* LEFT COLUMN: 7 cols on lg - SEARCH & SELECT LIST */}
                    <div className="lg:col-span-7 flex flex-col space-y-3">
                      {/* Blue Industrial Title Bar */}
                      <div className="flex items-center justify-between bg-[#1b365d] text-white px-3.5 py-2.5 rounded-xl border border-blue-900 shadow-xs">
                        <div className="flex items-center gap-2">
                          <Search className="w-4 h-4 text-cyan-300" />
                          <span className="text-xs font-black uppercase tracking-wider">1. Pesquisa & Escolha de Peças</span>
                        </div>
                        <span className="text-[10px] font-mono font-black text-cyan-200 bg-blue-950/70 px-2 py-0.5 rounded border border-blue-800">
                          {filteredInventory.length} {filteredInventory.length === 1 ? 'cadastrada' : 'cadastradas'}
                        </span>
                      </div>

                      {/* Real-time search field with instant clear */}
                      <div className="relative">
                        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="DIGITE O NOME, CÓDIGO SKU, GRUPO, FORNECEDOR OU LOCAL..."
                          className="w-full pl-10 pr-9 py-2.5 bg-white border border-slate-400 rounded-xl text-xs text-slate-900 font-bold uppercase tracking-tight placeholder:text-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 shadow-inner"
                        />
                        {searchQuery && (
                          <button
                            type="button"
                            onClick={() => setSearchQuery('')}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                            title="Limpar pesquisa"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      {/* Scrollable Selector Table */}
                      <div className="border border-slate-300 rounded-xl bg-white overflow-hidden shadow-xs max-h-[580px] overflow-y-auto">
                        <table className="w-full text-left border-collapse text-[11px]">
                          <thead>
                            <tr className="bg-[#1b365d] border-b border-blue-900 text-white text-[10px] font-black uppercase tracking-wider sticky top-0 z-10 shadow-xs">
                              <th className="py-2.5 px-3 text-center w-28">Código SKU</th>
                              <th className="py-2.5 px-3">Peça / Componente</th>
                              <th className="py-2.5 px-2.5 w-28 hidden sm:table-cell">Grupo</th>
                              <th className="py-2.5 px-2.5 text-center w-24">Estoque</th>
                              <th className="py-2.5 px-3 text-right w-24">Preço Venda</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200">
                            {filteredInventory.length === 0 ? (
                              <tr>
                                <td colSpan={5} className="py-12 text-center text-slate-500">
                                  <Package className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                                  <p className="font-extrabold text-xs text-slate-700">Nenhuma peça encontrada na pesquisa.</p>
                                  <p className="text-[11px] text-slate-400 mt-1">Verifique o termo digitado ou cadastre uma nova peça.</p>
                                </td>
                              </tr>
                            ) : (
                              filteredInventory.map((item) => {
                                const isSelected = selectedItem?.id === item.id;
                                const isBelowMin = item.quantity <= item.minimumStock;
                                const isZero = item.quantity === 0;

                                return (
                                  <tr
                                    key={item.id}
                                    id={`search-item-row-${item.id}`}
                                    onClick={() => setSelectedItemId(item.id)}
                                    className={`cursor-pointer transition-all duration-150 select-none ${
                                      isSelected 
                                        ? 'bg-[#0052cc] text-white font-bold shadow-xs' 
                                        : 'hover:bg-blue-50/80 text-slate-800'
                                    }`}
                                  >
                                    {/* Code */}
                                    <td className="py-2.5 px-3 text-center font-mono">
                                      <div className="flex items-center justify-center gap-1.5">
                                        {isSelected ? (
                                          <Check className="w-3.5 h-3.5 text-cyan-200 shrink-0" />
                                        ) : (
                                          <span className="w-1.5 h-1.5 rounded-full bg-slate-300 shrink-0" />
                                        )}
                                        <span className={isSelected ? 'text-cyan-200 font-black' : 'text-amber-700 font-extrabold'}>
                                          {item.code}
                                        </span>
                                      </div>
                                    </td>

                                    {/* Name & Location */}
                                    <td className="py-2.5 px-3">
                                      <div className="flex items-center gap-2">
                                        {item.imageUrl ? (
                                          <img
                                            src={item.imageUrl}
                                            alt={item.name}
                                            className="w-7 h-7 rounded-lg object-cover border border-slate-300 shrink-0 shadow-2xs"
                                            referrerPolicy="no-referrer"
                                          />
                                        ) : (
                                          <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                                            isSelected ? 'bg-blue-900 text-cyan-200' : 'bg-slate-100 text-slate-500 border border-slate-200'
                                          }`}>
                                            <Package className="w-3.5 h-3.5" />
                                          </div>
                                        )}
                                        <div className="min-w-0 flex-1">
                                          <span className={`block truncate max-w-[180px] sm:max-w-[220px] font-black uppercase tracking-tight text-xs ${
                                            isSelected ? 'text-white' : 'text-slate-900'
                                          }`}>
                                            {item.name}
                                          </span>
                                          {item.location && (
                                            <span className={`text-[9px] flex items-center gap-1 font-mono mt-0.5 ${
                                              isSelected ? 'text-cyan-200' : 'text-slate-500'
                                            }`}>
                                              <MapPin className="w-2.5 h-2.5 shrink-0" />
                                              <span className="truncate">{item.location}</span>
                                            </span>
                                          )}
                                        </div>
                                      </div>
                                    </td>

                                    {/* Category */}
                                    <td className="py-2.5 px-2.5 hidden sm:table-cell">
                                      <span className={`text-[9px] uppercase font-black tracking-wider px-2 py-0.5 rounded-md ${
                                        isSelected 
                                          ? 'bg-blue-900/80 text-cyan-200 border border-blue-700' 
                                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                                      }`}>
                                        {item.category}
                                      </span>
                                    </td>

                                    {/* Stock Level */}
                                    <td className="py-2.5 px-2.5 text-center font-mono">
                                      <span className={`inline-flex items-center justify-center min-w-[55px] px-2 py-0.5 rounded-md text-[10px] font-black tracking-tight ${
                                        isSelected
                                          ? (isZero 
                                              ? 'bg-rose-950 text-rose-200 border border-rose-600' 
                                              : isBelowMin 
                                              ? 'bg-red-950 text-red-200 border border-red-600' 
                                              : 'bg-blue-950 text-emerald-300 border border-blue-700')
                                          : (isZero 
                                              ? 'bg-rose-100 text-rose-700 border border-rose-300' 
                                              : isBelowMin 
                                              ? 'bg-red-100 text-red-700 border border-red-300 animate-pulse' 
                                              : 'bg-emerald-100 text-emerald-800 border border-emerald-300')
                                      }`}>
                                        {item.quantity} {item.unit}
                                      </span>
                                    </td>

                                    {/* Price */}
                                    <td className="py-2.5 px-3 text-right font-mono font-bold">
                                      <span className={isSelected ? 'text-white' : 'text-slate-900'}>
                                        R$ {item.salePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                      </span>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>

                      {/* Bottom Helper */}
                      <div className="flex items-center justify-between text-[11px] text-slate-600 bg-white/70 px-3 py-2 rounded-xl border border-slate-300">
                        <span className="flex items-center gap-1.5 font-medium">
                          <Info className="w-3.5 h-3.5 text-blue-700" />
                          Clique em qualquer linha para selecionar e carregar os dados no painel ao lado.
                        </span>
                        <button
                          type="button"
                          onClick={openAddItemForm}
                          className="text-amber-700 hover:text-amber-800 font-extrabold uppercase text-[10px] flex items-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                          Cadastrar Nova Peça
                        </button>
                      </div>
                    </div>

                    {/* RIGHT COLUMN: 5 cols on lg - SELECTED PIECE DETAILS & OPERATIONS STUDIO */}
                    <div className="lg:col-span-5 flex flex-col space-y-3">
                      {/* Title Bar */}
                      <div className="flex items-center justify-between bg-[#1b365d] text-white px-3.5 py-2.5 rounded-xl border border-blue-900 shadow-xs">
                        <div className="flex items-center gap-2">
                          <CheckSquare className="w-4 h-4 text-cyan-300" />
                          <span className="text-xs font-black uppercase tracking-wider">2. Painel da Peça Escolhida</span>
                        </div>
                        {selectedItem && (
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => openEditItemForm(selectedItem)}
                              className="p-1 text-cyan-200 hover:text-white hover:bg-blue-800 rounded transition-colors cursor-pointer"
                              title="Editar Cadastro"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setItemToDelete(selectedItem)}
                              className="p-1 text-red-300 hover:text-white hover:bg-red-800 rounded transition-colors cursor-pointer"
                              title="Excluir Peça"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Selected Item Content Card */}
                      {selectedItem ? (
                        <div className="bg-white border border-slate-300 rounded-2xl p-4 md:p-5 shadow-sm space-y-4">
                          
                          {/* Header with Title & SKU Badge */}
                          <div className="space-y-2 pb-3 border-b border-slate-200">
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <span className="text-[10px] font-black font-mono text-slate-500 uppercase tracking-widest block">
                                  {selectedItem.category}
                                </span>
                                <h3 className="text-base md:text-lg font-black text-slate-900 uppercase tracking-tight leading-snug">
                                  {selectedItem.name}
                                </h3>
                              </div>
                              <span className="bg-[#1b365d] text-cyan-200 border border-blue-900 px-2.5 py-1 text-xs font-mono font-black rounded-lg uppercase tracking-wider shrink-0 shadow-2xs">
                                {selectedItem.code}
                              </span>
                            </div>

                            {/* Tag Badges */}
                            <div className="flex flex-wrap gap-1.5 text-[10px]">
                              {selectedItem.location && (
                                <span className="bg-amber-50 text-amber-900 border border-amber-200 px-2 py-0.5 rounded-md font-mono font-bold flex items-center gap-1">
                                  <MapPin className="w-2.5 h-2.5 text-amber-700" />
                                  Local: {selectedItem.location}
                                </span>
                              )}
                              <span className="bg-slate-100 text-slate-700 border border-slate-200 px-2 py-0.5 rounded-md font-mono font-bold">
                                Unidade: {selectedItem.unit}
                              </span>
                              {selectedItem.supplier && (
                                <span className="bg-blue-50 text-blue-800 border border-blue-200 px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                                  <Truck className="w-2.5 h-2.5 text-blue-600" />
                                  {selectedItem.supplier}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Photo / Visual Media Preview */}
                          <div className="relative w-full h-36 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center shadow-inner group">
                            {selectedItem.imageUrl ? (
                              <img
                                src={selectedItem.imageUrl}
                                alt={selectedItem.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className="flex flex-col items-center justify-center text-slate-400">
                                <Package className="w-10 h-10 mb-1" />
                                <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-slate-400">Sem Foto Cadastrada</span>
                              </div>
                            )}
                            <button
                              type="button"
                              onClick={() => openEditItemForm(selectedItem)}
                              className="absolute bottom-2 right-2 bg-slate-900/80 hover:bg-slate-900 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg border border-slate-700 shadow-sm flex items-center gap-1 cursor-pointer transition-all"
                            >
                              <Edit className="w-3 h-3 text-amber-400" />
                              <span>{selectedItem.imageUrl ? 'Alterar Foto' : 'Adicionar Foto'}</span>
                            </button>
                          </div>

                          {/* STOCK LEVEL GAUGE & METERS */}
                          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2.5">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-black uppercase font-mono tracking-wider text-slate-600">
                                Status Físico do Estoque
                              </span>
                              {selectedItem.quantity === 0 ? (
                                <span className="text-[10px] font-black uppercase text-rose-700 bg-rose-100 border border-rose-300 px-2 py-0.5 rounded">
                                  Ruptura / Zerado
                                </span>
                              ) : selectedItem.quantity <= selectedItem.minimumStock ? (
                                <span className="text-[10px] font-black uppercase text-red-700 bg-red-100 border border-red-300 px-2 py-0.5 rounded animate-pulse">
                                  Abaixo do Mínimo
                                </span>
                              ) : (
                                <span className="text-[10px] font-black uppercase text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded">
                                  Estoque Saudável
                                </span>
                              )}
                            </div>

                            {/* Numbers Row */}
                            <div className="grid grid-cols-2 gap-3 py-1">
                              <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-center">
                                <span className="text-[9px] uppercase font-bold text-slate-500 font-mono block">Saldo Atual</span>
                                <span className={`text-xl font-black font-mono ${
                                  selectedItem.quantity === 0 ? 'text-rose-600' : selectedItem.quantity <= selectedItem.minimumStock ? 'text-red-600' : 'text-slate-900'
                                }`}>
                                  {selectedItem.quantity} <span className="text-xs text-slate-500 font-bold">{selectedItem.unit}</span>
                                </span>
                              </div>

                              <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-center">
                                <span className="text-[9px] uppercase font-bold text-slate-500 font-mono block">Mínimo de Segurança</span>
                                <span className="text-xl font-black font-mono text-slate-700">
                                  {selectedItem.minimumStock} <span className="text-xs text-slate-500 font-bold">{selectedItem.unit}</span>
                                </span>
                              </div>
                            </div>

                            {/* Progress Bar */}
                            <div className="space-y-1">
                              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden border border-slate-300 p-[1px]">
                                <div
                                  className={`h-full rounded-full transition-all duration-500 ${
                                    selectedItem.quantity === 0 ? 'w-0' :
                                    selectedItem.quantity <= selectedItem.minimumStock ? 'bg-gradient-to-r from-red-600 to-rose-500' :
                                    selectedItem.quantity <= selectedItem.minimumStock * 1.5 ? 'bg-gradient-to-r from-amber-500 to-yellow-500' :
                                    'bg-gradient-to-r from-emerald-500 to-teal-500'
                                  }`}
                                  style={{ width: `${selectedItem.quantity === 0 ? 0 : Math.min((selectedItem.quantity / Math.max(selectedItem.minimumStock * 2, selectedItem.quantity, 1)) * 100, 100)}%` }}
                                />
                              </div>
                            </div>

                            {/* Quick Actions Buttons Row */}
                            <div className="pt-2 border-t border-slate-200 grid grid-cols-2 gap-2">
                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleQuickQuantityUpdate(selectedItem, -1)}
                                  className="flex-1 py-1.5 px-2 bg-white hover:bg-rose-50 border border-slate-300 hover:border-rose-300 text-slate-700 hover:text-rose-700 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
                                  title="Dar saída de 1 unidade"
                                >
                                  <Minus className="w-3 h-3" />
                                  <span>- 1 {selectedItem.unit}</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleQuickQuantityUpdate(selectedItem, 1)}
                                  className="flex-1 py-1.5 px-2 bg-white hover:bg-emerald-50 border border-slate-300 hover:border-emerald-300 text-slate-700 hover:text-emerald-700 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
                                  title="Dar entrada de 1 unidade"
                                >
                                  <Plus className="w-3 h-3" />
                                  <span>+ 1 {selectedItem.unit}</span>
                                </button>
                              </div>

                              <button
                                type="button"
                                onClick={() => openQuickMovementModal(selectedItem, 'OUTPUT')}
                                className="py-1.5 px-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs uppercase tracking-wider"
                                title="Registrar movimentação personalizada"
                              >
                                <ArrowDownLeft className="w-3.5 h-3.5" />
                                <span>Lançar Movimento</span>
                              </button>
                            </div>
                          </div>

                          {/* FINANCIAL VALUATION BOX */}
                          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                            <span className="text-[10px] font-black uppercase font-mono tracking-wider text-slate-600 block">
                              Dados Financeiros & Margem
                            </span>

                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                              <div className="bg-white p-2 rounded-lg border border-slate-200">
                                <span className="text-[8px] uppercase font-bold text-slate-400 font-mono block">Custo Unit.</span>
                                <span className="text-xs font-black font-mono text-slate-900">
                                  R$ {selectedItem.purchasePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                </span>
                              </div>

                              <div className="bg-white p-2 rounded-lg border border-slate-200">
                                <span className="text-[8px] uppercase font-bold text-slate-400 font-mono block">Venda Sugerida</span>
                                <span className="text-xs font-black font-mono text-slate-900">
                                  R$ {selectedItem.salePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                </span>
                              </div>

                              <div className="bg-white p-2 rounded-lg border border-slate-200">
                                <span className="text-[8px] uppercase font-bold text-slate-400 font-mono block">Margem Bruta</span>
                                <span className={`text-xs font-black font-mono ${
                                  selectedItem.purchasePrice > 0 && selectedItem.salePrice > selectedItem.purchasePrice
                                    ? 'text-emerald-700'
                                    : 'text-slate-600'
                                }`}>
                                  {selectedItem.purchasePrice > 0
                                    ? `+${Math.round(((selectedItem.salePrice - selectedItem.purchasePrice) / selectedItem.purchasePrice) * 100)}%`
                                    : '0%'}
                                </span>
                              </div>

                              <div className="bg-white p-2 rounded-lg border border-slate-200">
                                <span className="text-[8px] uppercase font-bold text-slate-400 font-mono block">Total Saldo</span>
                                <span className="text-xs font-black font-mono text-amber-800">
                                  R$ {(selectedItem.quantity * selectedItem.purchasePrice).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* TECHNICAL DETAILS & APPLICATIONS */}
                          <div className="space-y-2 text-xs">
                            {selectedItem.possibleApplications && (
                              <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-3 text-amber-950 flex items-start gap-2">
                                <span className="font-extrabold text-amber-800 shrink-0 text-xs">💡 Onde é Utilizado:</span>
                                <span className="italic font-medium leading-relaxed">{selectedItem.possibleApplications}</span>
                              </div>
                            )}

                            {selectedItem.description && (
                              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-700">
                                <span className="font-bold text-slate-900 block mb-1 text-[11px] uppercase tracking-wider font-mono">
                                  📝 Especificações / Notas:
                                </span>
                                <p className="text-xs leading-relaxed text-slate-600">{selectedItem.description}</p>
                              </div>
                            )}
                          </div>

                          {/* Action Buttons Footer */}
                          <div className="pt-2 flex items-center justify-between gap-3 border-t border-slate-200">
                            <button
                              type="button"
                              onClick={() => setItemToDelete(selectedItem)}
                              className="text-red-600 hover:text-red-700 text-xs font-bold flex items-center gap-1.5 px-3 py-2 rounded-xl hover:bg-red-50 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Excluir do Catálogo</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => openEditItemForm(selectedItem)}
                              className="bg-[#1b365d] hover:bg-blue-900 text-white text-xs font-black px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs uppercase tracking-wider"
                            >
                              <Edit className="w-3.5 h-3.5 text-amber-400" />
                              <span>Editar Cadastro Completo</span>
                            </button>
                          </div>

                        </div>
                      ) : (
                        <div className="bg-white border border-slate-300 rounded-2xl p-12 text-center text-slate-500 shadow-sm space-y-3">
                          <Package className="w-12 h-12 text-slate-300 mx-auto" />
                          <h4 className="font-black text-sm text-slate-700">Nenhuma Peça Selecionada</h4>
                          <p className="text-xs text-slate-500 max-w-xs mx-auto">
                            Pesquise no campo ao lado e clique sobre qualquer componente cadastrado para inspecionar fotos, saldo e lançar movimentações.
                          </p>
                        </div>
                      )}
                    </div>

                  </div>
                </div>
              ) : viewMode === 'TABLE' ? (
                <div className="bg-white rounded-2xl border border-slate-300 overflow-hidden shadow-md">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-100 text-[9px] font-black uppercase tracking-wider text-slate-700 font-mono">
                          <th className="py-3.5 px-4 w-32">Código SKU</th>
                          <th className="py-3.5 px-4">Componente</th>
                          <th className="py-3.5 px-4 w-32 text-center">Controle Físico</th>
                          <th className="py-3.5 px-4 w-36 hidden sm:table-cell">Financeiro</th>
                          <th className="py-3.5 px-4 w-32 hidden md:table-cell">Endereço</th>
                          <th className="py-3.5 px-4 w-28 text-right">Ações</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 text-xs text-slate-800">
                        {filteredInventory.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="py-12 text-center text-slate-500 text-xs font-semibold">
                              Nenhum componente correspondente aos filtros.
                            </td>
                          </tr>
                        ) : (
                          filteredInventory.map((item) => {
                            const isBelowMin = item.quantity <= item.minimumStock;
                            return (
                              <tr key={item.id} className={`hover:bg-amber-50/60 transition-colors ${isBelowMin ? 'bg-red-50/60' : ''}`}>
                                
                                {/* SKU & Category */}
                                <td className="py-3.5 px-4 font-mono font-bold">
                                  <span className="text-amber-700 block tracking-wide font-extrabold">{item.code}</span>
                                  <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono mt-0.5 block font-bold">{item.category}</span>
                                </td>

                                {/* Info */}
                                <td className="py-3.5 px-4">
                                  <div className="flex items-start gap-3">
                                    {item.imageUrl && (
                                      <div className="w-12 h-12 rounded-lg overflow-hidden border border-slate-300 bg-slate-100 shrink-0 shadow-xs">
                                        <img 
                                          src={item.imageUrl} 
                                          alt={item.name} 
                                          className="w-full h-full object-cover"
                                          referrerPolicy="no-referrer"
                                        />
                                      </div>
                                    )}
                                    <div className="space-y-1">
                                      <span className="font-extrabold text-slate-900 block leading-snug">{item.name}</span>
                                      {item.description && (
                                        <span className="text-[10px] text-slate-600 block font-medium">{item.description}</span>
                                      )}
                                      {item.possibleApplications && (
                                        <span className="text-[10px] text-amber-900 block italic font-semibold">
                                          💡 Aplicação: {item.possibleApplications}
                                        </span>
                                      )}
                                      {item.supplier && (
                                        <span className="text-[9px] text-slate-600 flex items-center gap-1 font-bold">
                                          <Truck className="w-3 h-3 text-amber-600" />
                                          <span>{item.supplier}</span>
                                        </span>
                                      )}

                                      {/* Visual Stock Level Progress mini-bar */}
                                      <div className="mt-2 max-w-[180px] space-y-1">
                                        <div className="flex justify-between items-center text-[8px] font-black uppercase tracking-wider text-slate-600 font-mono">
                                          <span>Estoque: {item.quantity} {item.unit}</span>
                                          <span className={item.quantity === 0 ? 'text-rose-600 font-extrabold' : isBelowMin ? 'text-red-600 font-extrabold animate-pulse' : 'text-emerald-700 font-extrabold'}>
                                            {item.quantity === 0 ? 'Zerado' : isBelowMin ? 'Crítico' : 'Saudável'}
                                          </span>
                                        </div>
                                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden border border-slate-300">
                                          <div 
                                            className={`h-full transition-all duration-500 rounded-full ${
                                              item.quantity === 0 ? 'w-0' :
                                              isBelowMin ? 'bg-gradient-to-r from-red-500 to-rose-500' : 
                                              item.quantity <= item.minimumStock * 1.5 ? 'bg-gradient-to-r from-amber-500 to-yellow-500' : 
                                              'bg-gradient-to-r from-emerald-500 to-teal-500'
                                            }`}
                                            style={{ width: `${item.quantity === 0 ? 0 : Math.min((item.quantity / Math.max(item.minimumStock * 2, item.quantity, 1)) * 100, 100)}%` }}
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>

                                {/* Quantity Adjustment Controls */}
                                <td className="py-3.5 px-4 text-center">
                                  <div className="flex flex-col items-center gap-1.5">
                                    <div className="flex items-center bg-slate-100 border border-slate-300 rounded-lg p-0.5 shadow-xs">
                                      <button
                                        type="button"
                                        onClick={() => handleQuickQuantityUpdate(item, -1)}
                                        className="p-1 text-slate-600 hover:text-red-600 hover:bg-red-100 rounded-md transition-colors cursor-pointer"
                                        title="Dar Saída rápida (1 un)"
                                      >
                                        <Minus className="w-3 h-3" />
                                      </button>
                                      
                                      <span className={`w-10 text-center font-mono font-black text-xs ${isBelowMin ? 'text-red-700 font-black' : 'text-slate-900'}`}>
                                        {item.quantity}
                                      </span>

                                      <button
                                        type="button"
                                        onClick={() => handleQuickQuantityUpdate(item, 1)}
                                        className="p-1 text-slate-600 hover:text-emerald-600 hover:bg-emerald-100 rounded-md transition-colors cursor-pointer"
                                        title="Lançar Entrada rápida (1 un)"
                                      >
                                        <Plus className="w-3 h-3" />
                                      </button>
                                    </div>

                                    <span className="text-[9px] font-mono text-slate-600 uppercase font-bold tracking-wider">
                                      {item.unit}s • mín: {item.minimumStock}
                                    </span>

                                    {isBelowMin && (
                                      <span className="text-[8px] font-black uppercase text-red-700 bg-red-100 border border-red-300 px-1 py-0.5 rounded-sm tracking-wider animate-pulse">
                                        Estoq. Crítico
                                      </span>
                                    )}
                                  </div>
                                </td>

                                {/* Financial details */}
                                <td className="py-3.5 px-4 font-mono hidden sm:table-cell">
                                  <div className="space-y-0.5 text-[10px]">
                                    <div className="flex justify-between gap-2 text-slate-600 font-medium">
                                      <span>Compra:</span>
                                      <span className="font-bold text-slate-900">R$ {item.purchasePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                                    </div>
                                    <div className="flex justify-between gap-2 text-emerald-700 font-bold">
                                      <span>Venda:</span>
                                      <span className="font-extrabold text-emerald-800">R$ {item.salePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                                    </div>
                                    <div className="text-[8px] text-right text-amber-800 font-extrabold border-t border-slate-200 pt-0.5">
                                      Lucro: {item.purchasePrice > 0 ? Math.round(((item.salePrice - item.purchasePrice) / item.purchasePrice) * 100) : 0}%
                                    </div>
                                  </div>
                                </td>

                                {/* Location */}
                                <td className="py-3.5 px-4 text-slate-600 hidden md:table-cell">
                                  {item.location ? (
                                    <div className="flex items-center gap-1.5 text-[10px] text-slate-800 font-medium">
                                      <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                      <span>{item.location}</span>
                                    </div>
                                  ) : (
                                    <span className="text-slate-400 italic">Não definida</span>
                                  )}
                                </td>

                                {/* Operations */}
                                <td className="py-3.5 px-4 text-right">
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      type="button"
                                      onClick={() => openEditItemForm(item)}
                                      className="p-1.5 bg-slate-100 hover:bg-amber-100 border border-slate-300 hover:border-amber-400 text-slate-700 hover:text-amber-800 rounded-lg transition-all cursor-pointer shadow-2xs"
                                      title="Editar Dados do Material"
                                    >
                                      <Edit className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setItemToDelete(item)}
                                      className="p-1.5 bg-slate-100 hover:bg-red-100 border border-slate-300 hover:border-red-400 text-slate-700 hover:text-red-700 rounded-lg transition-all cursor-pointer shadow-2xs"
                                      title="Remover Material do Catálogo"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </td>

                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                /* BEAUTIFUL MODERN BENTO GRID CATALOGUE VIEW */
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5" id="inventory-grid-container">
                  {filteredInventory.length === 0 ? (
                    <div className="col-span-full bg-white border border-slate-300 rounded-2xl p-12 text-center text-slate-500 font-semibold shadow-sm">
                      Nenhum componente correspondente aos filtros encontrados.
                    </div>
                  ) : (
                    filteredInventory.map((item) => {
                      const isBelowMin = item.quantity <= item.minimumStock;
                      const profitMargin = item.purchasePrice > 0 ? Math.round(((item.salePrice - item.purchasePrice) / item.purchasePrice) * 100) : 0;
                      
                      return (
                        <div 
                          key={item.id} 
                          className={`bg-white border hover:shadow-xl hover:border-amber-500/50 transition-all duration-300 rounded-2xl overflow-hidden p-4 flex flex-col justify-between group relative ${
                            isBelowMin ? 'border-red-300 bg-red-50/20' : 'border-slate-300'
                          }`}
                        >
                          <div>
                            {/* Card Image and SKU / Stock Level Badges */}
                            <div className="relative w-full h-40 rounded-xl overflow-hidden mb-4 bg-slate-100 border border-slate-200 flex items-center justify-center select-none shadow-inner">
                              {item.imageUrl ? (
                                <img 
                                  src={item.imageUrl} 
                                  alt={item.name} 
                                  className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                <div className="flex flex-col items-center justify-center text-slate-400 group-hover:text-amber-600 transition-colors">
                                  <Package className="w-12 h-12 mb-2" />
                                  <span className="text-[9px] uppercase tracking-widest font-black font-mono text-slate-500">{item.category}</span>
                                </div>
                              )}

                              {/* SKU Code Overlay badge */}
                              <span className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur-md text-amber-300 border border-amber-400/30 px-2 py-0.5 text-[9px] font-bold font-mono rounded-md uppercase tracking-wider shadow-sm">
                                {item.code}
                              </span>

                              {/* Stock status badge overlay */}
                              {isBelowMin ? (
                                <span className="absolute top-3 right-3 bg-red-600 text-white border border-red-700 px-2 py-0.5 text-[8px] font-black uppercase rounded-md tracking-wider shadow-sm animate-pulse">
                                  Abaixo do Mínimo
                                </span>
                              ) : (
                                <span className="absolute top-3 right-3 bg-emerald-600 text-white border border-emerald-700 px-2 py-0.5 text-[8px] font-black uppercase rounded-md tracking-wider shadow-sm">
                                  Estoque Saudável
                                </span>
                              )}
                            </div>

                            {/* Category & Component Name */}
                            <div className="space-y-1">
                              <span className="text-[10px] font-black font-mono text-slate-500 uppercase tracking-widest block">{item.category}</span>
                              <h4 className="font-extrabold text-sm text-slate-900 group-hover:text-amber-700 transition-colors line-clamp-1 leading-tight">{item.name}</h4>
                              
                              {item.description && (
                                <p className="text-[11px] text-slate-600 line-clamp-2 mt-1 leading-snug">{item.description}</p>
                              )}

                             {/* Potential Application tooltip */}
                              {item.possibleApplications && (
                                <div className="text-[10px] text-amber-900 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5 mt-2.5 flex items-start gap-1.5 leading-snug">
                                  <span className="text-amber-800 font-bold shrink-0">💡 Aplicação:</span>
                                  <span className="italic">{item.possibleApplications}</span>
                                </div>
                              )}

                              {/* Stock level progress indicator bar */}
                              <div className="space-y-1.5 mt-3 pt-3 border-t border-slate-200">
                                <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-wider text-slate-500 font-mono">
                                  <span>Progresso do Estoque</span>
                                  <span className={item.quantity === 0 ? 'text-rose-600 font-extrabold' : isBelowMin ? 'text-red-600 font-extrabold animate-pulse' : 'text-emerald-700 font-bold'}>
                                    {item.quantity === 0 ? 'Zerado' : `${item.quantity} / ${item.minimumStock} ${item.unit}`}
                                  </span>
                                </div>
                                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-300 p-[1px]">
                                  <div 
                                    className={`h-full rounded-full transition-all duration-500 ${
                                      item.quantity === 0 ? 'w-0' :
                                      isBelowMin ? 'bg-gradient-to-r from-red-600 to-rose-500' : 
                                      item.quantity <= item.minimumStock * 1.5 ? 'bg-gradient-to-r from-amber-500 to-yellow-500' : 
                                      'bg-gradient-to-r from-emerald-500 to-teal-500'
                                    }`}
                                    style={{ width: `${item.quantity === 0 ? 0 : Math.min((item.quantity / Math.max(item.minimumStock * 2, item.quantity, 1)) * 100, 100)}%` }}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Action and stats section */}
                          <div className="mt-4 pt-4 border-t border-slate-200 space-y-3">
                            <div className="grid grid-cols-2 gap-3">
                              
                              {/* Stock Control Column */}
                              <div className="bg-slate-50 p-2 rounded-xl border border-slate-200 flex flex-col justify-between items-center text-center">
                                <span className="text-[8px] text-slate-500 uppercase tracking-widest font-black font-mono block mb-1">Unidades ({item.unit})</span>
                                
                                <div className="flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => handleQuickQuantityUpdate(item, -1)}
                                    className="w-6 h-6 flex items-center justify-center text-slate-600 hover:text-red-600 bg-white hover:bg-red-50 rounded-md border border-slate-300 hover:border-red-300 transition-all cursor-pointer shadow-xs"
                                    title="Remover 1 unidade"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  
                                  <span className={`font-mono font-black text-sm text-center min-w-[20px] ${isBelowMin ? 'text-red-600' : 'text-slate-900'}`}>
                                    {item.quantity}
                                  </span>

                                  <button
                                    type="button"
                                    onClick={() => handleQuickQuantityUpdate(item, 1)}
                                    className="w-6 h-6 flex items-center justify-center text-slate-600 hover:text-emerald-600 bg-white hover:bg-emerald-50 rounded-md border border-slate-300 hover:border-emerald-300 transition-all cursor-pointer shadow-xs"
                                    title="Adicionar 1 unidade"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                                <span className="text-[8px] text-slate-500 font-mono font-bold mt-1">Limite mín: {item.minimumStock}</span>
                              </div>

                              {/* Pricing Info Column */}
                              <div className="bg-slate-50 p-2 rounded-xl border border-slate-200 flex flex-col justify-between">
                                <span className="text-[8px] text-slate-500 uppercase tracking-widest font-black font-mono block mb-1">Preço Sugerido</span>
                                <div className="space-y-0.5 text-right font-mono">
                                  <div className="text-[9px] text-slate-500 flex justify-between gap-1">
                                    <span>Custo:</span>
                                    <span className="font-bold text-slate-800">R$ {item.purchasePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                                  </div>
                                  <div className="text-[10px] text-emerald-700 flex justify-between gap-1">
                                    <span>Venda:</span>
                                    <span className="font-extrabold text-emerald-800">R$ {item.salePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                                  </div>
                                  <div className="text-[8px] text-amber-800 font-bold border-t border-slate-200 pt-0.5 flex justify-between gap-1">
                                    <span>Lucro:</span>
                                    <span>{profitMargin}%</span>
                                  </div>
                                </div>
                              </div>

                            </div>

                            {/* Location and Operations */}
                            <div className="flex items-center justify-between gap-2 text-[10px] bg-slate-100 p-1.5 rounded-xl border border-slate-200">
                              <div className="flex items-center gap-1 text-slate-700 font-mono">
                                <MapPin className="w-3 h-3 text-amber-600 shrink-0" />
                                <span className="truncate max-w-[110px]" title={item.location || 'Sem localização'}>
                                  {item.location || 'Não definida'}
                                </span>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => openEditItemForm(item)}
                                  className="p-1.5 bg-white hover:bg-amber-100 border border-slate-300 hover:border-amber-400 text-slate-700 hover:text-amber-800 rounded-lg transition-all cursor-pointer shadow-xs"
                                  title="Editar"
                                >
                                  <Edit className="w-3 h-3" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setItemToDelete(item)}
                                  className="p-1.5 bg-white hover:bg-red-100 border border-slate-300 hover:border-red-400 text-slate-700 hover:text-red-700 rounded-lg transition-all cursor-pointer shadow-xs"
                                  title="Excluir"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>

                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}

            </div>

          </div>

        </div>
      )}

      {/* -------------------------------------------------------------------- */}
      {/* TAB 2: GRUPOS DE MATERIAIS TAB                                      */}
      {/* -------------------------------------------------------------------- */}
      {activeTab === 'GROUPS' && (
        <div className="space-y-6" id="view-groups-tab">
          
          <div className="flex flex-col lg:flex-row gap-6 items-start">
            
            {/* Form Section */}
            <div className="w-full lg:w-96 bg-white border border-slate-300 rounded-2xl p-5 space-y-4 shrink-0 shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-amber-600" />
                  <span>{editingGroup ? 'Editar Grupo' : 'Novo Grupo de Materiais'}</span>
                </h3>
                {(isAddingGroup || editingGroup) && (
                  <button 
                    type="button"
                    onClick={() => {
                      setIsAddingGroup(false);
                      setEditingGroup(null);
                      setGroupName('');
                      setGroupDesc('');
                    }}
                    className="text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              <form onSubmit={handleGroupSubmit} className="space-y-4 text-xs">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Nome do Grupo *</label>
                  <input
                    type="text"
                    required
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                    placeholder="Ex: Conectores Rápidos"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Descrição Comercial / Aplicação</label>
                  <textarea
                    value={groupDesc}
                    onChange={(e) => setGroupDesc(e.target.value)}
                    placeholder="Descrição sobre os tipos de peças neste grupo..."
                    rows={3}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black uppercase tracking-wider text-[10px] rounded-lg transition-colors cursor-pointer shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{editingGroup ? 'Salvar Alteração' : 'Criar Novo Grupo'}</span>
                </button>
              </form>
            </div>

            {/* List & Search View Section */}
            <div className="flex-grow w-full space-y-4">
              
              <div className="bg-white rounded-2xl border border-slate-300 p-4 flex items-center justify-between gap-4 shadow-sm">
                <div className="relative flex-grow max-w-md">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={groupSearchQuery}
                    onChange={(e) => setGroupSearchQuery(e.target.value)}
                    placeholder="Pesquisar por nome do grupo ou descrição..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-300 overflow-hidden shadow-md">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-100 text-[9px] font-black uppercase tracking-wider text-slate-700 font-mono">
                      <th className="py-3.5 px-4">Nome do Grupo</th>
                      <th className="py-3.5 px-4">Descrição Geral</th>
                      <th className="py-3.5 px-4 w-32 text-center">Peças Vinculadas</th>
                      <th className="py-3.5 px-4 w-28 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-xs text-slate-800">
                    {filteredGroups.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-12 text-center text-slate-500 font-semibold">
                          Nenhum grupo de materiais cadastrado.
                        </td>
                      </tr>
                    ) : (
                      filteredGroups.map(g => {
                        const count = getCategoryCount(g.name);
                        return (
                          <tr key={g.id} className="hover:bg-amber-50/60 transition-colors">
                            <td className="py-4 px-4 font-extrabold text-slate-900 flex items-center gap-2">
                              <Tag className="w-3.5 h-3.5 text-amber-600" />
                              <span>{g.name}</span>
                            </td>
                            <td className="py-4 px-4 text-slate-600 leading-relaxed max-w-sm truncate font-medium">
                              {g.description || <span className="italic text-slate-400">Sem descrição adicional</span>}
                            </td>
                            <td className="py-4 px-4 text-center">
                              <span className={`px-2.5 py-0.5 rounded-full font-mono font-bold text-[10px] ${count > 0 ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-slate-100 text-slate-600 border border-slate-300'}`}>
                                {count} {count === 1 ? 'item' : 'itens'}
                              </span>
                            </td>
                            <td className="py-4 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleEditGroup(g)}
                                  className="p-1.5 bg-slate-100 hover:bg-amber-100 border border-slate-300 hover:border-amber-400 text-slate-700 hover:text-amber-800 rounded-lg transition-all cursor-pointer shadow-2xs"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteGroup(g.id, g.name)}
                                  className="p-1.5 bg-slate-100 hover:bg-red-100 border border-slate-300 hover:border-red-400 text-slate-700 hover:text-red-700 rounded-lg transition-all cursor-pointer shadow-2xs"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* -------------------------------------------------------------------- */}
      {/* TAB 3: FORNECEDORES TAB                                              */}
      {/* -------------------------------------------------------------------- */}
      {activeTab === 'SUPPLIERS' && (
        <div className="space-y-6" id="view-suppliers-tab">
          
          <div className="flex flex-col lg:flex-row gap-6 items-start">
            
            {/* Form Drawer (Inclusão / Alteração) */}
            <div className="w-full lg:w-96 bg-white border border-slate-300 rounded-2xl p-5 space-y-4 shrink-0 shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-amber-600" />
                  <span>{editingSupplier ? 'Editar Fornecedor' : 'Novo Fornecedor'}</span>
                </h3>
                {(isAddingSupplier || editingSupplier) && (
                  <button 
                    type="button"
                    onClick={() => {
                      setIsAddingSupplier(false);
                      setEditingSupplier(null);
                      resetSupplierForm();
                    }}
                    className="text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              <form onSubmit={handleSupplierSubmit} className="space-y-3.5 text-xs">
                
                {/* Name */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Nome da Empresa / Fantasia *</label>
                  <input
                    type="text"
                    required
                    value={supName}
                    onChange={(e) => setSupName(e.target.value)}
                    placeholder="Ex: Parker Hannifin Ltda"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                {/* CNPJ / CPF */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">CNPJ / CPF</label>
                  <input
                    type="text"
                    value={supCnpj}
                    onChange={(e) => setSupCnpj(e.target.value)}
                    placeholder="Ex: 00.000.000/0001-00"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                {/* Phone */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Telefone Comercial</label>
                  <input
                    type="text"
                    value={supPhone}
                    onChange={(e) => setSupPhone(e.target.value)}
                    placeholder="Ex: (11) 3333-3333"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                {/* Email */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">E-mail para Orçamentos</label>
                  <input
                    type="email"
                    value={supEmail}
                    onChange={(e) => setSupEmail(e.target.value)}
                    placeholder="Ex: vendas@fornecedor.com.br"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                {/* Address */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Endereço Principal / CD</label>
                  <input
                    type="text"
                    value={supAddress}
                    onChange={(e) => setSupAddress(e.target.value)}
                    placeholder="Rua, Número, Cidade - Estado"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-1.5 px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 text-slate-950 font-black uppercase tracking-wider text-[10px] rounded-lg transition-colors cursor-pointer animate-pulse-once"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{editingSupplier ? 'Salvar Cadastro' : 'Salvar Novo Fornecedor'}</span>
                </button>
              </form>
            </div>

            {/* Consulta Table */}
            <div className="flex-grow w-full space-y-4">
              
              {/* Search */}
              <div className="bg-white rounded-2xl border border-slate-300 p-4 shadow-sm">
                <div className="relative flex-grow max-w-md">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={supplierSearchQuery}
                    onChange={(e) => setSupplierSearchQuery(e.target.value)}
                    placeholder="Pesquisar fornecedor por nome, CNPJ ou e-mail comercial..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Suppler Grid Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredSuppliers.length === 0 ? (
                  <div className="col-span-2 bg-white border border-slate-300 rounded-2xl p-12 text-center text-slate-500 text-xs font-semibold shadow-sm">
                    Nenhum fornecedor catalogado correspondente.
                  </div>
                ) : (
                  filteredSuppliers.map(s => {
                    // count total materials supplied
                    const count = inventory.filter(item => item.supplier === s.name).length;
                    return (
                      <div key={s.id} className="bg-white border border-slate-300 rounded-2xl p-4.5 space-y-3 hover:border-amber-400 transition-all flex flex-col justify-between shadow-xs hover:shadow-md">
                        <div className="space-y-2">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide leading-tight">{s.name}</h3>
                              {s.cnpjOrCpf && (
                                <span className="font-mono text-[9px] text-slate-500 font-bold mt-1 block">CNPJ: {s.cnpjOrCpf}</span>
                              )}
                            </div>
                            <span className="bg-amber-100 border border-amber-300 text-amber-900 font-mono text-[10px] font-extrabold px-2 py-0.5 rounded-lg shrink-0">
                              {count} {count === 1 ? 'peça' : 'peças'}
                            </span>
                          </div>

                          <div className="space-y-1.5 pt-2 border-t border-slate-200 text-[11px] text-slate-600">
                            {s.phone && (
                              <div className="flex items-center gap-2">
                                <span className="text-[9px] text-slate-500 uppercase font-black w-14 shrink-0">Contato:</span>
                                <span className="font-mono font-bold text-slate-800">{s.phone}</span>
                              </div>
                            )}
                            {s.email && (
                              <div className="flex items-center gap-2">
                                <span className="text-[9px] text-slate-500 uppercase font-black w-14 shrink-0">E-mail:</span>
                                <span className="text-amber-800 select-all font-bold truncate">{s.email}</span>
                              </div>
                            )}
                            {s.address && (
                              <div className="flex items-start gap-2">
                                <span className="text-[9px] text-slate-500 uppercase font-black w-14 shrink-0 mt-0.5">Endereço:</span>
                                <span className="text-xs text-slate-700 leading-snug truncate max-w-[240px]">{s.address}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Controls */}
                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 pt-3 mt-1.5">
                          <button
                            type="button"
                            onClick={() => handleEditSupplier(s)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 border border-slate-300 hover:border-amber-400 hover:bg-amber-50 text-slate-700 hover:text-amber-800 text-[10px] font-black uppercase rounded-lg transition-colors cursor-pointer shadow-2xs"
                          >
                            <Edit className="w-3 h-3" />
                            <span>Editar</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteSupplier(s.id, s.name)}
                            className="p-1.5 bg-slate-50 border border-slate-300 hover:bg-red-50 hover:border-red-400 text-slate-600 hover:text-red-700 rounded-lg transition-colors cursor-pointer shadow-2xs"
                            title="Remover Fornecedor"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

            </div>

          </div>

        </div>
      )}

      {/* -------------------------------------------------------------------- */}
      {/* TAB 4: RELATORIOS / AUDITS TAB                                       */}
      {/* -------------------------------------------------------------------- */}
      {activeTab === 'REPORTS' && (
        <div className="space-y-6" id="view-reports-and-audits-tab">
          
          {/* Sub Navigation Bar */}
          <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3" id="reports-subnav">
            <button
              type="button"
              onClick={() => setActiveReportTab('ESTOQUE')}
              className={`px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-2xs ${activeReportTab === 'ESTOQUE' ? 'bg-amber-500 border border-amber-600 text-slate-950 font-black' : 'text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300'}`}
            >
              <ClipboardList className="w-4 h-4 text-cyan-700" />
              <span>Status & Posição do Estoque</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveReportTab('INPUTS')}
              className={`px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-2xs ${activeReportTab === 'INPUTS' ? 'bg-amber-500 border border-amber-600 text-slate-950 font-black' : 'text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300'}`}
            >
              <ArrowUpRight className="w-4 h-4 text-emerald-700" />
              <span>Entradas (Histórico & Lançar)</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveReportTab('OUTPUTS')}
              className={`px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-2xs ${activeReportTab === 'OUTPUTS' ? 'bg-amber-500 border border-amber-600 text-slate-950 font-black' : 'text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300'}`}
            >
              <ArrowDownLeft className="w-4 h-4 text-red-600" />
              <span>Saídas (Histórico & Lançar)</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveReportTab('AUDITS')}
              className={`px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-2xs ${activeReportTab === 'AUDITS' ? 'bg-amber-500 border border-amber-600 text-slate-950 font-black' : 'text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300'}`}
            >
              <Activity className="w-4 h-4 text-amber-700" />
              <span>Inventário Físico & Auditorias</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveReportTab('ADJUSTMENTS')}
              className={`px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-2xs ${activeReportTab === 'ADJUSTMENTS' ? 'bg-amber-500 border border-amber-600 text-slate-950 font-black' : 'text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300'}`}
            >
              <Sliders className="w-4 h-4 text-slate-700" />
              <span>Acerto de Estoque</span>
            </button>
          </div>

          {/* SUB-VIEW A: POSIÇÃO DO ESTOQUE (ESTOQUE) */}
          {activeReportTab === 'ESTOQUE' && (
            <div className="space-y-6 animate-fade-in" id="report-subview-stock">
              
              {/* Report Stats Row */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white border border-slate-300 p-4.5 rounded-2xl shadow-sm">
                  <span className="text-[9px] font-black uppercase text-slate-500 font-mono tracking-widest">Total de Ativos de Estoque</span>
                  <div className="text-xl font-black text-slate-900 mt-1.5 font-mono">{inventory.length} Peças</div>
                  <span className="text-[10px] text-slate-500 font-medium mt-1 block">Componentes catalogados ativos</span>
                </div>
                <div className="bg-white border border-slate-300 p-4.5 rounded-2xl shadow-sm">
                  <span className="text-[9px] font-black uppercase text-slate-500 font-mono tracking-widest">Custo de Aquisição Físico</span>
                  <div className="text-xl font-black text-emerald-700 mt-1.5 font-mono">
                    R$ {inventory.reduce((sum, item) => sum + (item.quantity * item.purchasePrice), 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium mt-1 block">Total de capital investido</span>
                </div>
                <div className="bg-white border border-slate-300 p-4.5 rounded-2xl shadow-sm">
                  <span className="text-[9px] font-black uppercase text-slate-500 font-mono tracking-widest">Potencial Bruto de Venda</span>
                  <div className="text-xl font-black text-cyan-800 mt-1.5 font-mono">
                    R$ {inventory.reduce((sum, item) => sum + (item.quantity * item.salePrice), 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium mt-1 block">Previsão bruta de comercialização</span>
                </div>
                <div className="bg-white border border-slate-300 p-4.5 rounded-2xl shadow-sm">
                  <span className="text-[9px] font-black uppercase text-slate-500 font-mono tracking-widest">Ações Operacionais</span>
                  <div className="mt-2.5">
                    <button
                      type="button"
                      onClick={handlePrintInventory}
                      className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Exportar e Imprimir Posição</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Categorized Stock Breakdown Table */}
              <div className="bg-white border border-slate-300 rounded-2xl p-5 space-y-4 shadow-md">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-900">Posição de Valorização por Categoria</h3>
                    <p className="text-[10px] text-slate-500 mt-0.5">Visão consolidada de capital por tipo de material hidráulico/pneumático</p>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-100 text-[9px] font-black uppercase text-slate-700 tracking-wider font-mono">
                        <th className="py-2.5 px-2">Grupo / Categoria</th>
                        <th className="py-2.5 px-2 text-center">Peças Distintas</th>
                        <th className="py-2.5 px-2 text-center">Unidades Totais</th>
                        <th className="py-2.5 px-2 text-right">Valor em Custo</th>
                        <th className="py-2.5 px-2 text-right">Valor em Venda</th>
                        <th className="py-2.5 px-2 text-right">Rentabilidade Bruta</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-slate-800">
                      {categories.map(cat => {
                        const catItems = inventory.filter(i => i.category === cat);
                        const count = catItems.length;
                        const units = catItems.reduce((sum, i) => sum + i.quantity, 0);
                        const costVal = catItems.reduce((sum, i) => sum + (i.quantity * i.purchasePrice), 0);
                        const saleVal = catItems.reduce((sum, i) => sum + (i.quantity * i.salePrice), 0);
                        const markup = costVal > 0 ? Math.round(((saleVal - costVal) / costVal) * 100) : 0;

                        if (count === 0) return null;

                        return (
                          <tr key={cat} className="hover:bg-amber-50/60 transition-colors">
                            <td className="py-3 px-2 font-extrabold text-slate-900">{cat}</td>
                            <td className="py-3 px-2 text-center font-mono font-bold text-slate-600">{count}</td>
                            <td className="py-3 px-2 text-center font-mono font-extrabold">{units}</td>
                            <td className="py-3 px-2 text-right font-mono font-bold">R$ {costVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                            <td className="py-3 px-2 text-right font-mono font-extrabold text-emerald-800">R$ {saleVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                            <td className="py-3 px-2 text-right font-mono font-black text-amber-800">+{markup}%</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* SUB-VIEW B: ENTRADAS HISTÓRICO & LANÇAR */}
          {activeReportTab === 'INPUTS' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in" id="report-subview-inputs">
              
              {/* Lançar Entrada manual form */}
              <div className="bg-[#11131c] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-850 pb-3">
                  <div className="flex items-center gap-2">
                    <ArrowUpRight className="w-5 h-5 text-emerald-400" />
                    <div>
                      <h3 className="text-xs font-black uppercase tracking-wider text-slate-100">Entrada de Peças</h3>
                      <p className="text-[9px] text-slate-500 mt-0.5">Entrada de mercadorias no estoque físico</p>
                    </div>
                  </div>
                  {/* Quick add button */}
                  <button
                    type="button"
                    onClick={() => setIsQuickAddingItem(!isQuickAddingItem)}
                    className="px-2.5 py-1 bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/30 hover:border-cyan-500/50 text-cyan-300 hover:text-white rounded text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    {isQuickAddingItem ? 'Cancelar' : 'Cadastrar Novo Item'}
                  </button>
                </div>

                {isQuickAddingItem ? (
                  /* Quick item creation form inline! */
                  <form onSubmit={handleQuickItemSubmit} className="space-y-3 bg-slate-950/40 p-3.5 rounded-xl border border-slate-900 text-xs">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-cyan-400 mb-2">Cadastrar Novo Item no Catálogo</h4>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="block text-[9px] font-bold uppercase text-slate-400">Código SKU / Referência *</label>
                        <input
                          type="text"
                          required
                          placeholder="Ex: EST-VAL55"
                          value={quickItemCode}
                          onChange={(e) => setQuickItemCode(e.target.value.toUpperCase())}
                          className="w-full px-2 py-1.5 bg-[#0c0d10] border border-slate-800 rounded text-white text-xs font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[9px] font-bold uppercase text-slate-400">Nome do Material *</label>
                        <input
                          type="text"
                          required
                          placeholder="Ex: Válvula de Alívio..."
                          value={quickItemName}
                          onChange={(e) => setQuickItemName(e.target.value)}
                          className="w-full px-2 py-1.5 bg-[#0c0d10] border border-slate-800 rounded text-white text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="block text-[9px] font-bold uppercase text-slate-400">Categoria / Grupo</label>
                        <select
                          value={quickItemCategory}
                          onChange={(e) => setQuickItemCategory(e.target.value)}
                          className="w-full px-2 py-1.5 bg-[#0c0d10] border border-slate-800 rounded text-white text-xs"
                        >
                          <option value="">Selecione...</option>
                          {categories.map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[9px] font-bold uppercase text-slate-400">Estoque Mínimo</label>
                        <input
                          type="number"
                          min="0"
                          value={quickItemMinStock}
                          onChange={(e) => setQuickItemMinStock(parseInt(e.target.value) || 0)}
                          className="w-full px-2 py-1.5 bg-[#0c0d10] border border-slate-800 rounded text-white text-xs font-mono"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="block text-[9px] font-bold uppercase text-slate-400">Unidade Medida</label>
                        <input
                          type="text"
                          placeholder="un, jogo, metro, litro"
                          value={quickItemUnit}
                          onChange={(e) => setQuickItemUnit(e.target.value)}
                          className="w-full px-2 py-1.5 bg-[#0c0d10] border border-slate-800 rounded text-white text-xs"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[9px] font-bold uppercase text-slate-400">Localização Física</label>
                        <input
                          type="text"
                          placeholder="Ex: Prateleira B3"
                          value={quickItemLocation}
                          onChange={(e) => setQuickItemLocation(e.target.value)}
                          className="w-full px-2 py-1.5 bg-[#0c0d10] border border-slate-800 rounded text-white text-xs"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-black text-[10px] uppercase tracking-wider rounded transition-colors cursor-pointer"
                    >
                      Cadastrar e Voltar à Entrada
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleManualInputSubmit} className="space-y-4 text-xs">
                    {/* Step 1: General Header Data */}
                    <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-900 space-y-3">
                      <h4 className="text-[9px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-900 pb-1">1. Informações da Compra</h4>
                      
                      <div className="grid grid-cols-2 gap-2.5">
                        <div className="space-y-1">
                          <label className="block text-[9px] font-bold uppercase text-slate-400">Fornecedor</label>
                          <select
                            value={manualInSupplier}
                            onChange={(e) => setManualInSupplier(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-[#0c0d10] border border-slate-800 rounded-lg text-white text-xs focus:outline-hidden focus:border-emerald-500"
                          >
                            <option value="">Selecione...</option>
                            {suppliers.map(s => (
                              <option key={s.id} value={s.name}>{s.name}</option>
                            ))}
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[9px] font-bold uppercase text-slate-400">Data da Entrada *</label>
                          <input
                            type="date"
                            required
                            value={manualInDate}
                            onChange={(e) => setManualInDate(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-[#0c0d10] border border-slate-800 rounded-lg text-white font-mono text-xs focus:outline-hidden focus:border-emerald-500"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[9px] font-bold uppercase text-slate-400">Nº do Documento / Nota Fiscal / Justificativa</label>
                        <input
                          type="text"
                          value={manualInDesc}
                          onChange={(e) => setManualInDesc(e.target.value)}
                          placeholder="Ex: NF-e 4910, Reposição de estoque..."
                          className="w-full px-3 py-1.5 bg-[#0c0d10] border border-slate-800 rounded-lg text-white focus:outline-hidden focus:border-emerald-500 text-xs"
                        />
                      </div>
                    </div>

                    {/* Step 2: Inclusion of Items block */}
                    <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-900 space-y-3">
                      <h4 className="text-[9px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-900 pb-1">2. Inclusão de Itens</h4>
                      
                      {/* Material select */}
                      {manualInItemId ? (
                        <div className="space-y-1">
                          <label className="block text-[9px] font-bold uppercase text-slate-400">Material Selecionado</label>
                          {(() => {
                            const selectedItem = inventory.find(i => i.id === manualInItemId);
                            if (!selectedItem) return null;
                            return (
                              <div className="flex items-center justify-between p-2.5 bg-emerald-950/20 border border-emerald-500/30 rounded-lg text-xs">
                                <div className="space-y-0.5 text-left">
                                  <div className="font-bold text-slate-100 flex flex-wrap items-center gap-1.5">
                                    <span className="px-1.5 py-0.5 bg-emerald-950 text-emerald-400 font-mono text-[9px] font-extrabold rounded border border-emerald-500/20 uppercase">
                                      {selectedItem.code}
                                    </span>
                                    <span>{selectedItem.name}</span>
                                  </div>
                                  <div className="text-[10px] text-slate-400">
                                    Categoria: <span className="text-slate-300">{selectedItem.category}</span> • Saldo: <span className="font-bold text-emerald-400">{selectedItem.quantity} {selectedItem.unit}</span>
                                    {selectedItem.location && ` • Local: ${selectedItem.location}`}
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={handleClearManualInItem}
                                  className="p-1.5 bg-slate-900 hover:bg-red-950/40 border border-slate-850 hover:border-red-500/20 text-slate-400 hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                                  title="Trocar material"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            );
                          })()}
                        </div>
                      ) : (
                        <div className="space-y-1 relative">
                          <label className="block text-[9px] font-bold uppercase text-slate-400">Selecionar Material (Busque pelo Nome, Categoria ou SKU)</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={manualInSearchQuery}
                              onFocus={() => setManualInDropdownOpen(true)}
                              onChange={(e) => {
                                setManualInSearchQuery(e.target.value);
                                setManualInDropdownOpen(true);
                              }}
                              placeholder="Digite o nome ou código da peça para pesquisar..."
                              className="w-full px-3 py-1.5 bg-[#0c0d10] border border-slate-800 focus:border-emerald-500 rounded-lg text-white text-xs focus:outline-hidden"
                            />
                            {manualInSearchQuery && (
                              <button
                                type="button"
                                onClick={() => setManualInSearchQuery('')}
                                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>

                          {manualInDropdownOpen && (
                            <>
                              <div className="fixed inset-0 z-10" onClick={() => setManualInDropdownOpen(false)} />
                              <div className="absolute left-0 right-0 top-full mt-1 bg-[#0c0d12] border border-slate-800 rounded-lg shadow-2xl max-h-56 overflow-y-auto z-20 divide-y divide-slate-900 custom-scrollbar">
                                {filteredInInventory.length === 0 ? (
                                  <div className="p-3 text-center text-[10px] text-slate-500">
                                    Nenhum item cadastrado com "{manualInSearchQuery}"
                                  </div>
                                ) : (
                                  filteredInInventory.map(item => (
                                    <button
                                      key={item.id}
                                      type="button"
                                      onClick={() => handleSelectManualInItem(item)}
                                      className="w-full px-3 py-2 text-left hover:bg-slate-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-1 transition-colors text-[11px]"
                                    >
                                      <div className="space-y-0.5 text-left">
                                        <span className="font-bold text-slate-200 block sm:inline">{item.name}</span>
                                        <span className="text-[9px] text-slate-400 block">
                                          Grupo: <span className="text-slate-300">{item.category}</span>
                                          {item.location && ` • Box: ${item.location}`}
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-2 self-end sm:self-auto">
                                        <span className="font-mono text-[9px] px-1 bg-slate-900 border border-slate-800 rounded text-amber-500">
                                          {item.code}
                                        </span>
                                        <span className="font-mono text-[10px] font-bold text-emerald-400">
                                          Saldo: {item.quantity} {item.unit}
                                        </span>
                                      </div>
                                    </button>
                                  ))
                                )}
                              </div>
                            </>
                          )}
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-2">
                        {/* Qty & Price */}
                        <div className="space-y-1">
                          <label className="block text-[9px] font-bold uppercase text-slate-400">Quantidade *</label>
                          <input
                            type="number"
                            min="1"
                            value={manualInQty}
                            onChange={(e) => setManualInQty(parseInt(e.target.value) || 1)}
                            className="w-full px-2.5 py-1.5 bg-[#0c0d10] border border-slate-800 rounded-lg text-white font-mono text-xs focus:outline-hidden focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[9px] font-bold uppercase text-slate-400">Preço Unitário (R$)</label>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={manualInPrice === 0 ? '' : manualInPrice}
                            placeholder="Ex: 12.50"
                            onChange={(e) => setManualInPrice(parseFloat(e.target.value) || 0)}
                            className="w-full px-2.5 py-1.5 bg-[#0c0d10] border border-slate-800 rounded-lg text-white font-mono text-xs focus:outline-hidden focus:border-emerald-500"
                          />
                        </div>
                      </div>

                      {/* Aplicação */}
                      <div className="space-y-1">
                        <label className="block text-[9px] font-bold uppercase text-slate-400">Aplicação da Peça (Máquina, Veículo, Cilindro)</label>
                        <input
                          type="text"
                          value={manualInApplication}
                          onChange={(e) => setManualInApplication(e.target.value)}
                          placeholder="Ex: Cilindro Hidr. Case 580N, Prensa Parker, etc"
                          className="w-full px-3 py-1.5 bg-[#0c0d10] border border-slate-800 rounded-lg text-white focus:outline-hidden focus:border-emerald-500 text-xs"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={handleAddDraftInItem}
                        className="w-full py-1.5 bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/20 text-cyan-300 font-bold text-[10px] uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Adicionar Item à Lista</span>
                      </button>
                    </div>

                    {/* Draft Item List Preview */}
                    {manualInItemsList.length > 0 && (
                      <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-900 space-y-2">
                        <div className="flex justify-between items-center border-b border-slate-900 pb-1">
                          <h4 className="text-[9px] font-black uppercase tracking-widest text-amber-500">Itens Prontos para Entrada</h4>
                          <span className="text-[10px] font-bold text-slate-400">{manualInItemsList.length} itens</span>
                        </div>
                        <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                          {manualInItemsList.map((draft) => (
                            <div key={draft.id} className="flex justify-between items-center bg-[#0c0d10] border border-slate-850 p-2 rounded-lg text-[10px]">
                              <div className="space-y-0.5 max-w-[80%] text-left">
                                <div className="font-bold text-slate-100">{draft.itemName}</div>
                                <div className="text-[9px] text-slate-500 font-mono">
                                  SKU: {draft.itemCode} • Qtd: <span className="text-emerald-400 font-bold">{draft.quantity}</span> • Preço: <span className="text-slate-300">R$ {draft.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                                </div>
                                {draft.application && (
                                  <div className="text-[8px] text-cyan-400 font-medium">Aplicação: {draft.application}</div>
                                )}
                              </div>
                              <button
                                type="button"
                                onClick={() => handleRemoveDraftInItem(draft.id)}
                                className="p-1 hover:bg-red-950/40 rounded text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                        <div className="border-t border-slate-900 pt-2 flex justify-between items-center text-[10px] font-bold">
                          <span className="text-slate-400">VALOR TOTAL DA ENTRADA:</span>
                          <span className="text-emerald-400 font-mono text-xs">
                            R$ {manualInItemsList.reduce((sum, d) => sum + (d.quantity * d.price), 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-[10px] uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-lg shadow-emerald-500/10"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{manualInItemsList.length > 0 ? `Lançar Entrada (${manualInItemsList.length} Itens)` : 'Lançar Entrada Rápida'}</span>
                    </button>
                  </form>
                )}
              </div>

              {/* Movement History Log List */}
              <div className="col-span-2 bg-[#11131c] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-100 flex items-center gap-2">
                    <ArrowUpRight className="w-4 h-4 text-emerald-400" />
                    <span>Livro de Registro de Entradas (Inputs)</span>
                  </h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Histórico completo de reabastecimentos, compras e ajustes de saldo</p>
                </div>

                <div className="overflow-hidden border border-slate-850 rounded-xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs min-w-[600px]">
                      <thead className="bg-slate-900/50 text-[9px] font-black uppercase text-slate-500 tracking-wider font-mono">
                        <tr className="border-b border-slate-850">
                          <th className="py-2.5 px-3">Data</th>
                          <th className="py-2.5 px-3">Material / Código</th>
                          <th className="py-2.5 px-3 text-center">Quant.</th>
                          <th className="py-2.5 px-3 text-right">Custo Un.</th>
                          <th className="py-2.5 px-3 text-right">Subtotal</th>
                          <th className="py-2.5 px-3">Origem / Descrição</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850/55 text-slate-300 font-medium">
                        {movements.filter(m => m.type === 'INPUT').length === 0 ? (
                          <tr>
                            <td colSpan={6} className="py-8 text-center text-slate-500">Nenhuma entrada registrada ainda</td>
                          </tr>
                        ) : (
                          movements.filter(m => m.type === 'INPUT').map(m => (
                            <tr key={m.id} className="hover:bg-slate-900/10">
                              <td className="py-2.5 px-3 font-mono text-[10px] text-slate-400">
                                {m.date ? new Date(m.date + 'T12:00:00').toLocaleDateString('pt-BR') : 'Manual'}
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="font-bold text-slate-100 block">{m.itemName}</span>
                                <span className="font-mono text-[9px] text-amber-500 mt-0.5 block">{m.itemCode}</span>
                              </td>
                              <td className="py-2.5 px-3 text-center font-mono text-emerald-400 font-bold">+{m.quantity}</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">R$ {m.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                              <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-400">R$ {(m.quantity * m.price).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                              <td className="py-2.5 px-3 text-[10px]">
                                <span className="text-slate-300 block font-semibold">{m.description}</span>
                                {m.supplier && <span className="text-[9px] text-slate-500 flex items-center gap-1 font-mono uppercase mt-0.5">Fornec: {m.supplier}</span>}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* SUB-VIEW C: SAÍDAS HISTÓRICO & LANÇAR */}
          {activeReportTab === 'OUTPUTS' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in" id="report-subview-outputs">
              
              {/* Lançar Saída manual form */}
              <div className="bg-[#11131c] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-850 pb-3">
                  <ArrowDownLeft className="w-5 h-5 text-red-400" />
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-100">Saída de Peças</h3>
                    <p className="text-[9px] text-slate-500 mt-0.5">Retire peças do estoque para ordens de serviço, vendas ou ajustes</p>
                  </div>
                </div>

                <form onSubmit={handleManualOutputSubmit} className="space-y-4 text-xs">
                  
                  {/* Select item */}
                  {manualOutItemId ? (
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase text-slate-400">Material Selecionado *</label>
                      {(() => {
                        const selectedItem = inventory.find(i => i.id === manualOutItemId);
                        if (!selectedItem) return null;
                        return (
                          <div className="flex items-center justify-between p-2.5 bg-red-950/10 border border-red-500/20 rounded-lg text-xs">
                            <div className="space-y-0.5 text-left">
                              <div className="font-bold text-slate-100 flex flex-wrap items-center gap-1.5">
                                <span className="px-1.5 py-0.5 bg-red-950 text-red-400 font-mono text-[9px] font-extrabold rounded border border-red-500/10 uppercase">
                                  {selectedItem.code}
                                </span>
                                <span>{selectedItem.name}</span>
                              </div>
                              <div className="text-[10px] text-slate-400">
                                Categoria: <span className="text-slate-300">{selectedItem.category}</span> • Disponível: <span className={`font-bold ${selectedItem.quantity > 0 ? 'text-emerald-400' : 'text-red-400'}`}>{selectedItem.quantity} {selectedItem.unit}</span>
                                {selectedItem.location && ` • Local: ${selectedItem.location}`}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={handleClearManualOutItem}
                              className="p-1.5 bg-slate-900 hover:bg-red-950/40 border border-slate-850 hover:border-red-500/20 text-slate-400 hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                              title="Trocar material"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        );
                      })()}
                    </div>
                  ) : (
                    <div className="space-y-1.5 relative">
                      <label className="block text-[10px] font-bold uppercase text-slate-400">Selecionar Material * (Busque pelo Nome, Categoria ou SKU)</label>
                      <div className="relative">
                        <input
                          type="text"
                          value={manualOutSearchQuery}
                          onFocus={() => setManualOutDropdownOpen(true)}
                          onChange={(e) => {
                            setManualOutSearchQuery(e.target.value);
                            setManualOutDropdownOpen(true);
                          }}
                          placeholder="Digite o nome ou código da peça para pesquisar..."
                          className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 focus:border-red-500 rounded-lg text-white text-xs focus:outline-hidden"
                        />
                        {manualOutSearchQuery && (
                          <button
                            type="button"
                            onClick={() => setManualOutSearchQuery('')}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      {manualOutDropdownOpen && (
                        <>
                          <div className="fixed inset-0 z-10" onClick={() => setManualOutDropdownOpen(false)} />
                          <div className="absolute left-0 right-0 top-full mt-1 bg-[#0c0d12] border border-slate-800 rounded-lg shadow-2xl max-h-56 overflow-y-auto z-20 divide-y divide-slate-900 custom-scrollbar">
                            {filteredOutInventory.length === 0 ? (
                              <div className="p-3 text-center text-[10px] text-slate-500">
                                Nenhum item cadastrado com "{manualOutSearchQuery}"
                              </div>
                            ) : (
                              filteredOutInventory.map(item => (
                                <button
                                  key={item.id}
                                  type="button"
                                  onClick={() => handleSelectManualOutItem(item)}
                                  className="w-full px-3 py-2 text-left hover:bg-slate-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-1 transition-colors text-[11px]"
                                >
                                  <div className="space-y-0.5 text-left">
                                    <span className="font-bold text-slate-200 block sm:inline">{item.name}</span>
                                    <span className="text-[9px] text-slate-400 block">
                                      Grupo: <span className="text-slate-300">{item.category}</span>
                                      {item.location && ` • Box: ${item.location}`}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2 self-end sm:self-auto">
                                    <span className="font-mono text-[9px] px-1 bg-slate-900 border border-slate-800 rounded text-amber-500">
                                      {item.code}
                                    </span>
                                    <span className={`font-mono text-[10px] font-bold ${item.quantity > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                      Qtd: {item.quantity} {item.unit}
                                    </span>
                                  </div>
                                </button>
                              ))
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  )}

                  {/* Date and Type of Exit */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase text-slate-400">Data da Saída *</label>
                      <input
                        type="date"
                        required
                        value={manualOutDate}
                        onChange={(e) => setManualOutDate(e.target.value)}
                        className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white font-mono focus:outline-hidden focus:border-red-500 text-xs"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase text-slate-400">Tipo de Saída *</label>
                      <select
                        value={manualOutType}
                        required
                        onChange={(e) => setManualOutType(e.target.value as any)}
                        className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white focus:outline-hidden focus:border-red-500 text-xs"
                      >
                        <option value="Manutenção com OS">Manutenção com OS</option>
                        <option value="Vendas">Vendas</option>
                        <option value="Acerto de Estoque">Acerto de Estoque</option>
                      </select>
                    </div>
                  </div>

                  {/* Conditional OS dropdown if Type of Exit is Maintenance */}
                  {manualOutType === 'Manutenção com OS' && (
                    <div className="space-y-1.5 animate-in slide-in-from-top-1 duration-150">
                      <label className="block text-[10px] font-bold uppercase text-slate-400">Vincular a Ordem de Serviço (OS) *</label>
                      <select
                        value={manualOutOsId}
                        required={manualOutType === 'Manutenção com OS'}
                        onChange={(e) => setManualOutOsId(e.target.value)}
                        className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white focus:outline-hidden focus:border-red-500 text-xs"
                      >
                        <option value="">Selecione a OS...</option>
                        {activeOrders.map(o => (
                          <option key={o.id} value={o.osNumber}>{o.osNumber} - {o.title} {o.clientName ? `(${o.clientName})` : ''}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* Qty */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold uppercase text-slate-400">Quantidade a Retirar *</label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={manualOutQty}
                      onChange={(e) => setManualOutQty(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white font-mono focus:outline-hidden focus:border-red-500 text-xs"
                    />
                  </div>

                  {/* Justificativa */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold uppercase text-slate-400">Justificativa / Observações</label>
                    <textarea
                      value={manualOutDesc}
                      onChange={(e) => setManualOutDesc(e.target.value)}
                      placeholder={manualOutType === 'Vendas' ? "Ex: Venda direta balcão..." : manualOutType === 'Acerto de Estoque' ? "Ex: Ajuste após contagem..." : "Ex: Instalado na máquina de testes..."}
                      rows={2}
                      className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white focus:outline-hidden focus:border-red-500 text-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-red-500 hover:bg-red-400 text-slate-950 font-black text-[10px] uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-lg shadow-red-500/10"
                  >
                    <Minus className="w-3.5 h-3.5" />
                    <span>Lançar Saída de Peças</span>
                  </button>
                </form>
              </div>

              {/* Movement History Log List */}
              <div className="col-span-2 bg-[#11131c] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-100 flex items-center gap-2">
                    <ArrowDownLeft className="w-4 h-4 text-red-400" />
                    <span>Livro de Registro de Saídas (Outputs)</span>
                  </h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Histórico completo de consumos em ordens de serviço, descartes e ajustes negativos</p>
                </div>

                <div className="overflow-hidden border border-slate-850 rounded-xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs min-w-[600px]">
                      <thead className="bg-slate-900/50 text-[9px] font-black uppercase text-slate-500 tracking-wider font-mono">
                        <tr className="border-b border-slate-850">
                          <th className="py-2.5 px-3">Data</th>
                          <th className="py-2.5 px-3">Material / Código</th>
                          <th className="py-2.5 px-3 text-center">Quant.</th>
                          <th className="py-2.5 px-3 text-right">Preço Un.</th>
                          <th className="py-2.5 px-3 text-right">Subtotal</th>
                          <th className="py-2.5 px-3">Destino / Motivo</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850/55 text-slate-300 font-medium">
                        {movements.filter(m => m.type === 'OUTPUT').length === 0 ? (
                          <tr>
                            <td colSpan={6} className="py-8 text-center text-slate-500">Nenhuma saída registrada ainda</td>
                          </tr>
                        ) : (
                          movements.filter(m => m.type === 'OUTPUT').map(m => (
                            <tr key={m.id} className="hover:bg-slate-900/10">
                              <td className="py-2.5 px-3 font-mono text-[10px] text-slate-400">
                                {m.date ? new Date(m.date + 'T12:00:00').toLocaleDateString('pt-BR') : 'Manual'}
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="font-bold text-slate-100 block">{m.itemName}</span>
                                <span className="font-mono text-[9px] text-amber-500 mt-0.5 block">{m.itemCode}</span>
                              </td>
                              <td className="py-2.5 px-3 text-center font-mono text-red-400 font-bold">-{m.quantity}</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">R$ {m.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                              <td className="py-2.5 px-3 text-right font-mono font-bold text-red-400">R$ {(m.quantity * m.price).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                              <td className="py-2.5 px-3 text-[10px] font-semibold">
                                {m.description}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* SUB-VIEW D: INVENTÁRIOS FÍSICOS & CONTROLES DE AUDITORIAS */}
          {activeReportTab === 'AUDITS' && (
            <div className="space-y-6 animate-fade-in" id="report-subview-audits">
              
              {/* Top Action Box */}
              {!activeAudit ? (
                <div className="bg-[#11131c] border border-slate-800 rounded-2xl p-6 text-center space-y-4">
                  <div className="max-w-md mx-auto space-y-2">
                    <Activity className="w-10 h-10 text-amber-500 mx-auto animate-pulse" />
                    <h3 className="text-sm font-black text-white uppercase tracking-wider">Auditoria Física e Ajuste de Balanço</h3>
                    <p className="text-xs text-slate-400">
                      Inicie uma sessão de inventário geral para contar as peças fisicamente, calcular divergências do estoque digital e reajustar os saldos reais em lote.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={startNewAudit}
                    className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center gap-1.5 mx-auto"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Iniciar Novo Inventário Físico</span>
                  </button>
                </div>
              ) : (
                <div className="bg-[#11131c] border border-amber-500/20 rounded-2xl p-5 space-y-4">
                  
                  {/* Active audit headers */}
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-850 pb-4">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-amber-950 text-amber-400 rounded-xl border border-amber-500/30">
                        <Activity className="w-5 h-5 animate-spin-slow" />
                      </div>
                      <div>
                        <h4 className="text-xs font-black uppercase text-white tracking-widest">{activeAudit.title}</h4>
                        <p className="text-[10px] text-slate-400 mt-0.5">Sessão em Rascunho • Registre as quantidades contadas nas prateleiras físicas</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={finalizeAndSyncAudit}
                        className="px-4.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        <span>Sincronizar e Finalizar</span>
                      </button>
                      <button
                        type="button"
                        onClick={cancelActiveAudit}
                        className="px-4.5 py-2 bg-[#0c0d10] hover:bg-red-950/20 border border-slate-800 hover:border-red-500/30 text-slate-400 hover:text-red-400 text-xs font-black uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>

                  {/* Counting adjustment lists */}
                  <div className="overflow-hidden border border-slate-850 bg-[#0c0d10] rounded-xl">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#11131c] text-[9px] font-black uppercase text-slate-500 tracking-wider font-mono border-b border-slate-850">
                        <tr>
                          <th className="py-2.5 px-3">Código SKU</th>
                          <th className="py-2.5 px-3">Nome do Componente</th>
                          <th className="py-2.5 px-3 text-center">Saldo Sistema</th>
                          <th className="py-2.5 px-3 text-center w-40">Saldo Contado Fisicamente</th>
                          <th className="py-2.5 px-3 text-center">Divergência</th>
                          <th className="py-2.5 px-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850 text-slate-300 font-medium">
                        {activeAudit.items.map(item => (
                          <tr key={item.itemId} className="hover:bg-slate-900/10">
                            <td className="py-2.5 px-3 font-mono font-bold text-amber-500">{item.itemCode}</td>
                            <td className="py-2.5 px-3 font-bold text-slate-200">{item.itemName}</td>
                            <td className="py-2.5 px-3 text-center font-mono text-slate-400 font-bold">{item.expectedQty}</td>
                            <td className="py-2.5 px-3 text-center">
                              <input
                                type="number"
                                min="0"
                                value={item.actualQty}
                                onChange={(e) => handleAuditQtyChange(item.itemId, parseInt(e.target.value) || 0)}
                                className="w-24 px-2 py-1 bg-[#11131c] border border-slate-800 rounded text-center font-mono font-black text-white focus:outline-hidden focus:border-amber-500 text-xs"
                              />
                            </td>
                            <td className="py-2.5 px-3 text-center font-mono">
                              {item.difference === 0 ? (
                                <span className="text-slate-500 font-bold">0</span>
                              ) : item.difference > 0 ? (
                                <span className="text-emerald-400 font-black font-mono">+{item.difference} (Sobra)</span>
                              ) : (
                                <span className="text-red-400 font-black font-mono">{item.difference} (Falta)</span>
                              )}
                            </td>
                            <td className="py-2.5 px-3">
                              {item.difference === 0 ? (
                                <span className="text-[10px] text-slate-500 font-bold uppercase">Consistente</span>
                              ) : (
                                <span className="text-[10px] text-amber-500 font-bold uppercase animate-pulse">Ajustar Saldo</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                </div>
              )}

              {/* Historic Audits Log List */}
              <div className="bg-[#11131c] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-100 flex items-center gap-2">
                    <ClipboardList className="w-4 h-4 text-amber-500" />
                    <span>Registro Histórico de Auditorias de Inventários Realizados</span>
                  </h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Visão consolidada de inventários anteriores com o balanço consolidado</p>
                </div>

                <div className="space-y-4">
                  {audits.length === 0 ? (
                    <div className="py-8 text-center text-slate-500 text-xs">Nenhum inventário histórico cadastrado ou executado</div>
                  ) : (
                    audits.map(audit => {
                      const discrepanciesCount = audit.items.filter(i => i.difference !== 0).length;
                      return (
                        <div key={audit.id} className="border border-slate-850 rounded-xl p-4 bg-[#0c0d10]/40 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                          <div className="space-y-1">
                            <span className="text-[9px] font-mono text-slate-500 uppercase font-black">{audit.date}</span>
                            <h4 className="text-xs font-black text-slate-200 uppercase">{audit.title}</h4>
                            <div className="flex items-center gap-3 text-[10px] text-slate-400">
                              <span>Itens Auditados: <strong className="text-slate-200">{audit.items.length}</strong></span>
                              <span>Divergências Ajustadas: <strong className={discrepanciesCount > 0 ? 'text-amber-500' : 'text-slate-200'}>{discrepanciesCount}</strong></span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-0.5 rounded-full font-mono font-black text-[9px] bg-emerald-950/40 text-emerald-400 border border-emerald-500/20 uppercase">
                              Concluído & Sincronizado
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

            </div>
          )}

          {/* SUB-VIEW E: ACERTO DE ESTOQUE (ADJUSTMENTS) */}
          {activeReportTab === 'ADJUSTMENTS' && (
            <div className="space-y-6 animate-fade-in" id="report-subview-adjustments">
              
              {/* Header explanation card */}
              <div className="bg-[#11131c] border border-slate-800 rounded-2xl p-4.5 space-y-1.5">
                <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-amber-500" />
                  <span>Acerto de Estoque (Ajuste Direto de Saldo)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Utilize este módulo para efetuar acertos diretos de saldo físico no sistema, corrigindo inventários danificados, perdas, extravios, erros de digitação ou ajustes pontuais sem a necessidade de simular compras ou vendas. Cada acerto gera um registro de movimentação especial do tipo entrada ou saída.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Form column */}
                <div className="lg:col-span-5 bg-[#11131c] border border-slate-800 rounded-2xl p-5 space-y-4">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-100 pb-2 border-b border-slate-850">
                    Lançar Ajuste Pontual de Peça
                  </h4>

                  <form onSubmit={handleManualAdjustmentSubmit} className="space-y-4">
                    {/* Material Item Selector */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">Selecionar Material</label>
                      <select
                        value={manualAdjItemId}
                        onChange={(e) => {
                          const id = e.target.value;
                          setManualAdjItemId(id);
                          const it = inventory.find(i => i.id === id);
                          if (it) {
                            setManualAdjRealQty(it.quantity);
                          } else {
                            setManualAdjRealQty('');
                          }
                        }}
                        className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white text-xs focus:outline-hidden focus:border-amber-500"
                        required
                      >
                        <option value="">Selecione o componente...</option>
                        {inventory.map(item => (
                          <option key={item.id} value={item.id}>
                            [{item.code}] {item.name} (Saldo atual: {item.quantity} {item.unit})
                          </option>
                        ))}
                      </select>
                    </div>

                    {manualAdjItemId && (
                      <>
                        {/* Current & Future Quantities Info */}
                        {(() => {
                          const item = inventory.find(i => i.id === manualAdjItemId);
                          if (!item) return null;
                          const currentQty = item.quantity;
                          const realQty = manualAdjRealQty === '' ? 0 : manualAdjRealQty;
                          const diff = realQty - currentQty;

                          return (
                            <div className="grid grid-cols-2 gap-3 bg-[#0c0d10] border border-slate-850 rounded-xl p-3 text-[11px]">
                              <div>
                                <span className="text-slate-500 block">Saldo Atual (Digital):</span>
                                <strong className="text-white text-sm font-mono">{currentQty} {item.unit}</strong>
                              </div>
                              <div>
                                <span className="text-slate-500 block">Diferença / Impacto:</span>
                                {diff === 0 ? (
                                  <strong className="text-slate-400 text-sm font-mono">Sem alteração</strong>
                                ) : diff > 0 ? (
                                  <strong className="text-emerald-400 text-sm font-mono">+{diff} {item.unit} (Sobra)</strong>
                                ) : (
                                  <strong className="text-red-400 text-sm font-mono">{diff} {item.unit} (Falta)</strong>
                                )}
                              </div>
                            </div>
                          );
                        })()}

                        {/* Real physical stock count */}
                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">Nova Quantidade Física Real</label>
                          <input
                            type="number"
                            min="0"
                            value={manualAdjRealQty}
                            onChange={(e) => setManualAdjRealQty(e.target.value === '' ? '' : Number(e.target.value))}
                            placeholder="Ex: 15"
                            className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white font-mono text-xs focus:outline-hidden focus:border-amber-500"
                            required
                          />
                          <p className="text-[9px] text-slate-500">Defina o saldo final exato que está fisicamente na prateleira.</p>
                        </div>

                        {/* Reason select */}
                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">Motivo do Ajuste</label>
                          <select
                            value={manualAdjReason}
                            onChange={(e) => setManualAdjReason(e.target.value)}
                            className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white text-xs focus:outline-hidden focus:border-amber-500"
                            required
                          >
                            <option value="Divergência física">Divergência física (Inventário)</option>
                            <option value="Avaria/Quebra">Material danificado / Avaria / Quebra</option>
                            <option value="Perda/Extravio">Perda / Extravio</option>
                            <option value="Correção de cadastro">Correção de cadastro / Digitação</option>
                            <option value="Outros">Outros motivos</option>
                          </select>
                        </div>

                        {/* Description field */}
                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">Observação / Justificativa</label>
                          <textarea
                            value={manualAdjDesc}
                            onChange={(e) => setManualAdjDesc(e.target.value)}
                            placeholder="Descreva detalhes ou justificativas adicionais..."
                            rows={3}
                            className="w-full px-3 py-2 bg-[#0c0d10] border border-slate-800 rounded-lg text-white text-xs focus:outline-hidden focus:border-amber-500"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-600 text-slate-950 font-black uppercase tracking-wider text-[10px] rounded-lg transition-colors cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Aplicar Acerto de Estoque</span>
                        </button>
                      </>
                    )}
                  </form>
                </div>

                {/* History log list */}
                <div className="lg:col-span-7 bg-[#11131c] border border-slate-800 rounded-2xl p-5 space-y-4">
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider text-slate-100 flex items-center gap-1.5">
                      <ClipboardList className="w-4 h-4 text-amber-500" />
                      <span>Histórico de Acertos e Ajustes de Estoque</span>
                    </h4>
                    <p className="text-[10px] text-slate-500 mt-0.5 font-sans">
                      Histórico dos ajustes manuais diretos efetuados na prateleira de inventários.
                    </p>
                  </div>

                  <div className="overflow-hidden border border-slate-850 rounded-xl">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-900/50 text-[9px] font-black uppercase text-slate-500 tracking-wider font-mono">
                        <tr className="border-b border-slate-850">
                          <th className="py-2.5 px-3">Data</th>
                          <th className="py-2.5 px-3">Material</th>
                          <th className="py-2.5 px-3 text-center">Ajuste</th>
                          <th className="py-2.5 px-3">Motivo / Detalhes</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850/55 text-slate-300 font-medium">
                        {(() => {
                          const adjMovements = movements.filter(m => 
                            m.id.startsWith('mov-adj-') || 
                            m.description?.includes('Acerto de Estoque') || 
                            m.description?.includes('Auditoria')
                          );

                          if (adjMovements.length === 0) {
                            return (
                              <tr>
                                <td colSpan={4} className="py-12 text-center text-slate-500">Nenhum acerto de estoque registrado ainda</td>
                              </tr>
                            );
                          }

                          return adjMovements.map(m => {
                            const isPositive = m.type === 'INPUT';
                            return (
                              <tr key={m.id} className="hover:bg-slate-900/5">
                                <td className="py-2.5 px-3 font-mono text-[10px] text-slate-500">
                                  {m.date ? new Date(m.date + 'T12:00:00').toLocaleDateString('pt-BR') : 'Manual'}
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="font-bold text-slate-200 block">{m.itemName}</span>
                                  <span className="font-mono text-[9px] text-amber-500 block mt-0.5">{m.itemCode}</span>
                                </td>
                                <td className="py-2.5 px-3 text-center font-mono">
                                  {isPositive ? (
                                    <span className="text-emerald-400 font-black">+{m.quantity}</span>
                                  ) : (
                                    <span className="text-red-400 font-black">-{m.quantity}</span>
                                  )}
                                </td>
                                <td className="py-2.5 px-3 text-[10px] text-slate-400 leading-snug">
                                  {m.description}
                                </td>
                              </tr>
                            );
                          });
                        })()}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* ========================================== */}
      {/* STATE-BASED CONFIRMATION DIALOGS (MODALS)  */}
      {/* ========================================== */}

      {/* 1. Item Deletion Confirmation */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-left">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-red-950/50 border border-red-500/30 text-red-400 rounded-xl">
                <AlertTriangle className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider">Confirmar Exclusão</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Tem certeza de que deseja remover permanentemente o material <strong className="text-white">{itemToDelete.name}</strong> (<span className="text-amber-500 font-mono">{itemToDelete.code}</span>) do catálogo do estoque? Esta ação não pode ser desfeita.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 justify-end border-t border-slate-850 pt-3.5">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 bg-[#0c0d10] border border-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteItem(itemToDelete.id);
                  triggerFeedback('Material removido!', 'info');
                  setItemToDelete(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-red-900/20"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Excluir Material</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Group Deletion Confirmation */}
      {groupToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-left">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-amber-950/50 border border-amber-500/30 text-amber-400 rounded-xl">
                <AlertTriangle className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider">Confirmar Exclusão de Grupo</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {groupToDelete.count > 0 ? (
                    <span>
                      Existem <strong className="text-white">{groupToDelete.count} material(is)</strong> cadastrados na categoria <strong className="text-white">"{groupToDelete.name}"</strong>. Se você excluir este grupo, essas peças continuarão no estoque, mas ficarão sem categoria definida. Deseja continuar?
                    </span>
                  ) : (
                    <span>
                      Deseja excluir permanentemente o grupo de materiais <strong className="text-white">"{groupToDelete.name}"</strong>? Esta ação não pode ser desfeita.
                    </span>
                  )}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 justify-end border-t border-slate-850 pt-3.5">
              <button
                type="button"
                onClick={() => setGroupToDelete(null)}
                className="px-4 py-2 bg-[#0c0d10] border border-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDeleteGroup}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-red-900/20"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Excluir Grupo</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Supplier Deletion Confirmation */}
      {supplierToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-left">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-red-950/50 border border-red-500/30 text-red-400 rounded-xl">
                <AlertTriangle className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider">Confirmar Exclusão de Fornecedor</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Tem certeza de que deseja remover permanentemente o fornecedor <strong className="text-white">{supplierToDelete.name}</strong>? Esta ação é irreversível.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 justify-end border-t border-slate-850 pt-3.5">
              <button
                type="button"
                onClick={() => setSupplierToDelete(null)}
                className="px-4 py-2 bg-[#0c0d10] border border-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDeleteSupplier}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-red-900/20"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Excluir Fornecedor</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Cancel Audit Confirmation */}
      {confirmCancelAudit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-left">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-amber-950/50 border border-amber-500/30 text-amber-400 rounded-xl">
                <AlertTriangle className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider">Cancelar Auditoria?</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Deseja realmente cancelar esta sessão de auditoria física? Todos os dados contados nesta sessão serão perdidos de forma irreversível.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 justify-end border-t border-slate-850 pt-3.5">
              <button
                type="button"
                onClick={() => setConfirmCancelAudit(false)}
                className="px-4 py-2 bg-[#0c0d10] border border-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider"
              >
                Continuar Auditoria
              </button>
              <button
                type="button"
                onClick={handleConfirmCancelAudit}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-red-900/20"
              >
                <X className="w-3.5 h-3.5" />
                <span>Sim, Cancelar e Perder Dados</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. Finalize Audit Confirmation */}
      {confirmFinalizeAudit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-left">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-emerald-950/50 border border-emerald-500/30 text-emerald-400 rounded-xl">
                <CheckCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider">Finalizar Auditoria de Estoque?</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Deseja realmente <strong className="text-emerald-400">FINALIZAR</strong> esta auditoria física? O estoque físico do sistema será imediatamente atualizado com os valores contados e quaisquer divergências serão registradas no histórico.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 justify-end border-t border-slate-850 pt-3.5">
              <button
                type="button"
                onClick={() => setConfirmFinalizeAudit(false)}
                className="px-4 py-2 bg-[#0c0d10] border border-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider"
              >
                Revisar Valores
              </button>
              <button
                type="button"
                onClick={handleConfirmFinalizeAudit}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-emerald-900/20"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Sim, Salvar e Sincronizar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* SPREADSHEET IMPORT MODAL                    */}
      {/* ========================================== */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl max-w-3xl w-full p-6 space-y-5 shadow-2xl animate-fade-in text-left flex flex-col max-h-[90vh]">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 rounded-xl">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider">Importador Inteligente de Planilha</h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">Alimente seu estoque rapidamente copiando/colando células ou vinculando uma planilha Google.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowImportModal(false);
                  setParsedItems([]);
                  setPasteContent('');
                }}
                className="text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mappings Info Box */}
            <div className="bg-slate-900/30 border border-slate-800 p-3.5 rounded-xl space-y-2 text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider text-[10px] block">Mapeamento Esperado de Colunas:</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] text-slate-400 font-mono">
                <div className="flex items-center gap-1.5"><span className="px-1.5 py-0.5 bg-slate-850 text-amber-400 rounded font-bold">Col A</span> <span>GRUPO</span></div>
                <div className="flex items-center gap-1.5"><span className="px-1.5 py-0.5 bg-slate-850 text-amber-400 rounded font-bold">Col B</span> <span>NOME COMPONENTE</span></div>
                <div className="flex items-center gap-1.5"><span className="px-1.5 py-0.5 bg-slate-850 text-amber-400 rounded font-bold">Col C</span> <span>CÓDIGO ITEM (SKU)</span></div>
                <div className="flex items-center gap-1.5"><span className="px-1.5 py-0.5 bg-slate-850 text-amber-400 rounded font-bold">Col D</span> <span>LOCALIZAÇÃO</span></div>
                <div className="flex items-center gap-1.5"><span className="px-1.5 py-0.5 bg-slate-850 text-amber-400 rounded font-bold">Col E</span> <span>MÍN. SEGURANÇA</span></div>
                <div className="flex items-center gap-1.5"><span className="px-1.5 py-0.5 bg-slate-850 text-amber-400 rounded font-bold">Col F</span> <span>ONDE É UTILIZADO</span></div>
              </div>
            </div>

            {/* Tab Switches */}
            <div className="flex border-b border-slate-800">
              <button
                type="button"
                onClick={() => { setImportTab('PASTE'); setImportError(null); }}
                className={`flex-1 py-2.5 text-center text-xs font-black uppercase tracking-wider border-b-2 cursor-pointer transition-colors ${importTab === 'PASTE' ? 'border-emerald-500 text-emerald-400 bg-emerald-950/5' : 'border-transparent text-slate-500 hover:text-slate-300'}`}
              >
                Opção 1: Colar Células (Ctrl+C / Ctrl+V)
              </button>
              <button
                type="button"
                onClick={() => { setImportTab('URL'); setImportError(null); }}
                className={`flex-1 py-2.5 text-center text-xs font-black uppercase tracking-wider border-b-2 cursor-pointer transition-colors ${importTab === 'URL' ? 'border-emerald-500 text-emerald-400 bg-emerald-950/5' : 'border-transparent text-slate-500 hover:text-slate-300'}`}
              >
                Opção 2: Link do Google Sheets (Automático)
              </button>
            </div>

            {/* Form Area */}
            <div className="space-y-4 flex-1 overflow-y-auto pr-1">
              {importTab === 'PASTE' ? (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 font-mono">Copie e cole os dados da planilha abaixo:</label>
                    <textarea
                      value={pasteContent}
                      onChange={(e) => handlePasteChange(e.target.value)}
                      rows={6}
                      placeholder="Selecione as colunas da planilha (A até F), dê Ctrl+C e cole aqui (Ctrl+V)..."
                      className="w-full p-3 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-hidden focus:border-emerald-500 font-mono"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 font-mono">Link ou URL da Planilha Google:</label>
                    <div className="flex gap-2">
                      <div className="relative flex-grow">
                        <Link className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <input
                          type="text"
                          value={sheetUrl}
                          onChange={(e) => setSheetUrl(e.target.value)}
                          placeholder="https://docs.google.com/spreadsheets/d/..."
                          className="w-full pl-10 pr-4 py-2.5 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-hidden focus:border-emerald-500"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={handleLoadFromGoogleSheets}
                        disabled={importLoading || !sheetUrl.trim()}
                        className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
                      >
                        {importLoading ? (
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Upload className="w-4 h-4" />
                        )}
                        <span>{importLoading ? 'Conectando...' : 'Carregar Dados'}</span>
                      </button>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-500 leading-relaxed italic">
                    * Caso ainda não esteja logado, ao clicar em "Carregar Dados" uma tela pop-up do Google solicitará autorização segura para leitura da sua planilha. Certifique-se de que a planilha está compartilhada com permissão de visualização.
                  </p>
                </div>
              )}

              {/* Feedback messages inside modal */}
              {importError && (
                <div className="p-3.5 bg-red-950/20 border border-red-500/10 text-red-400 rounded-xl flex items-start gap-2.5 text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div className="font-mono tracking-tight">{importError}</div>
                </div>
              )}

              {/* Preview Table for Parsed Items */}
              {parsedItems.length > 0 && (
                <div className="space-y-2 border-t border-slate-850 pt-3">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                    <span className="uppercase tracking-wider flex items-center gap-1.5 text-emerald-400">
                      <CheckCircle className="w-4 h-4" />
                      Pronto para Importação ({parsedItems.length} componentes encontrados)
                    </span>
                  </div>
                  <div className="border border-slate-800 rounded-xl overflow-hidden max-h-48 overflow-y-auto">
                    <table className="w-full text-left border-collapse text-[11px]">
                      <thead>
                        <tr className="bg-slate-900/60 border-b border-slate-800 text-[9px] font-black uppercase tracking-wider text-slate-400 font-mono">
                          <th className="py-2.5 px-3">Grupo</th>
                          <th className="py-2.5 px-3">Nome do Componente</th>
                          <th className="py-2.5 px-3">Código (SKU)</th>
                          <th className="py-2.5 px-3">Localização</th>
                          <th className="py-2.5 px-3 text-right">Mín. Seg.</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850/50 bg-[#0d0f17]/40 text-slate-300">
                        {parsedItems.slice(0, 15).map((item, index) => (
                          <tr key={index} className="hover:bg-slate-800/10">
                            <td className="py-2 px-3 font-bold text-slate-400">{item.category}</td>
                            <td className="py-2 px-3 truncate max-w-[200px]" title={item.name}>{item.name}</td>
                            <td className="py-2 px-3 font-mono text-amber-500 font-bold">{item.code}</td>
                            <td className="py-2 px-3 text-slate-400">{item.location || '-'}</td>
                            <td className="py-2 px-3 text-right font-mono text-slate-400">{item.minimumStock}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {parsedItems.length > 15 && (
                      <div className="text-center py-2 bg-slate-900/20 text-[10px] text-slate-500 italic font-mono border-t border-slate-800">
                        ... e mais {parsedItems.length - 15} itens listados abaixo
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-end gap-3 border-t border-slate-850 pt-4">
              <button
                type="button"
                onClick={() => {
                  setShowImportModal(false);
                  setParsedItems([]);
                  setPasteContent('');
                }}
                className="px-4 py-2.5 bg-[#0c0d10] border border-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer text-xs font-black uppercase tracking-wider"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={parsedItems.length === 0}
                onClick={executeImport}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black rounded-xl transition-colors cursor-pointer text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-emerald-900/10"
              >
                <Check className="w-4 h-4 font-bold" />
                <span>Importar e Sincronizar ({parsedItems.length} itens)</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* -------------------------------------------------------------------- */}
      {/* MODAL: MOVIMENTAÇÃO RÁPIDA DE ESTOQUE (ENTRADA / SAÍDA)              */}
      {/* -------------------------------------------------------------------- */}
      {quickMovementModalItem && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200" 
          id="modal-quick-movement"
          onClick={() => setQuickMovementModalItem(null)}
        >
          <div 
            className="bg-white border-2 border-slate-300 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between border-b border-slate-200 pb-4">
              <div>
                <span className="text-[10px] font-black font-mono text-slate-500 uppercase tracking-widest block">
                  Lançar Movimentação de Estoque
                </span>
                <h3 className="text-base font-black text-slate-900 uppercase">
                  {quickMovementModalItem.name}
                </h3>
                <span className="text-xs font-mono font-bold text-amber-700">
                  Código: {quickMovementModalItem.code} | Saldo Atual: {quickMovementModalItem.quantity} {quickMovementModalItem.unit}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setQuickMovementModalItem(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExecuteQuickMovement} className="space-y-4">
              {/* Type Switcher */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setQuickMovementType('OUTPUT');
                    setQuickMovementPrice(quickMovementModalItem.salePrice);
                    if (!quickMovementMotive || quickMovementMotive.includes('Compra')) {
                      setQuickMovementMotive('Consumo em OS / Manutenção');
                    }
                  }}
                  className={`py-2.5 px-3 rounded-lg text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    quickMovementType === 'OUTPUT'
                      ? 'bg-rose-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ArrowDownLeft className="w-4 h-4" />
                  <span>Saída (-) Consumo</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setQuickMovementType('INPUT');
                    setQuickMovementPrice(quickMovementModalItem.purchasePrice);
                    if (!quickMovementMotive || quickMovementMotive.includes('Consumo')) {
                      setQuickMovementMotive('Compra / Reposição de estoque');
                    }
                  }}
                  className={`py-2.5 px-3 rounded-lg text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    quickMovementType === 'INPUT'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ArrowUpRight className="w-4 h-4" />
                  <span>Entrada (+) Reposição</span>
                </button>
              </div>

              {/* Quantity & Unit */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-700 font-mono">
                    Quantidade a Movimentar ({quickMovementModalItem.unit}):
                  </label>
                  <div className="flex gap-1">
                    {[1, 2, 5, 10].map(qty => (
                      <button
                        key={qty}
                        type="button"
                        onClick={() => setQuickMovementQty(qty)}
                        className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded text-[10px] font-mono font-bold text-slate-700 cursor-pointer"
                      >
                        +{qty}
                      </button>
                    ))}
                  </div>
                </div>
                <input
                  type="number"
                  min="1"
                  max={quickMovementType === 'OUTPUT' ? quickMovementModalItem.quantity : 999999}
                  value={quickMovementQty || ''}
                  onChange={(e) => setQuickMovementQty(Math.max(1, parseInt(e.target.value) || 0))}
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-black font-mono text-slate-900 focus:outline-hidden focus:border-blue-600 focus:bg-white"
                />
                {quickMovementType === 'OUTPUT' && quickMovementQty > quickMovementModalItem.quantity && (
                  <p className="text-[11px] text-red-600 font-bold">
                    Aviso: Quantidade informada excede o saldo atual em estoque ({quickMovementModalItem.quantity} {quickMovementModalItem.unit}).
                  </p>
                )}
              </div>

              {/* Price & Date Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-700 font-mono">
                    Preço Unitário (R$):
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={quickMovementPrice || ''}
                    onChange={(e) => setQuickMovementPrice(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:bg-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-700 font-mono">
                    Data da Movimentação:
                  </label>
                  <input
                    type="date"
                    value={quickMovementDate}
                    onChange={(e) => setQuickMovementDate(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:bg-white"
                  />
                </div>
              </div>

              {/* Motive / OS */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-700 font-mono">
                  Motivo / Ordem de Serviço / Observação:
                </label>
                <input
                  type="text"
                  value={quickMovementMotive}
                  onChange={(e) => setQuickMovementMotive(e.target.value)}
                  placeholder={quickMovementType === 'OUTPUT' ? 'Ex: OS-1025 - Troca de retentor em escavadeira' : 'Ex: Compra NF 4589 - Reposição de estoque'}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 font-medium placeholder:text-slate-400 focus:outline-hidden focus:border-blue-600 focus:bg-white"
                />
              </div>

              {/* Total Calculation summary box */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
                <span className="text-xs font-mono uppercase font-bold text-slate-600">Total da Movimentação:</span>
                <span className={`text-base font-black font-mono ${quickMovementType === 'OUTPUT' ? 'text-rose-600' : 'text-emerald-700'}`}>
                  R$ {(quickMovementQty * quickMovementPrice).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setQuickMovementModalItem(null)}
                  className="px-4 py-2.5 border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider"
                >
                  Cancelar
                </button>

                <button
                  type="submit"
                  disabled={quickMovementType === 'OUTPUT' && quickMovementQty > quickMovementModalItem.quantity}
                  className={`px-5 py-2.5 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center gap-2 shadow-md disabled:opacity-50 ${
                    quickMovementType === 'OUTPUT' 
                      ? 'bg-rose-600 hover:bg-rose-700' 
                      : 'bg-emerald-600 hover:bg-emerald-700'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>Confirmar {quickMovementType === 'OUTPUT' ? 'Saída' : 'Entrada'}</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
