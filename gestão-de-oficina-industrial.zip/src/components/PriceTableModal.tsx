import React, { useState, useMemo, useEffect, useRef } from 'react';
import { PlannedService, InventoryItem, QuoteItemType } from '../types';
import { 
  Search, X, Plus, Check, DollarSign, Tag, Layers, 
  Briefcase, Package, ShoppingBag, FileSpreadsheet, 
  ArrowRight, Sparkles, Filter, CheckCircle2, ChevronRight,
  SlidersHorizontal, PlusCircle, UserPlus, Info
} from 'lucide-react';

export interface PriceTableItem {
  id: string;
  sourceType: 'SERVICO' | 'PECA';
  code: string;
  name: string;
  category: string;
  description: string;
  unit: string;
  price: number;
  stockQty?: number;
}

export interface SelectedQuoteItem {
  type: QuoteItemType;
  description: string;
  unitPrice: number;
  quantity: number;
  unit: string;
}

interface PriceTableModalProps {
  isOpen: boolean;
  onClose: () => void;
  services: PlannedService[];
  inventory?: InventoryItem[];
  onInsertItems?: (items: SelectedQuoteItem[]) => void;
  onOpenNewService?: () => void;
  title?: string;
  subtitle?: string;
}

export default function PriceTableModal({
  isOpen,
  onClose,
  services,
  inventory = [],
  onInsertItems,
  onOpenNewService,
  title = 'Tabela de Preços & Catálogo de Serviços',
  subtitle = 'Pesquise serviços e peças para inserir diretamente no orçamento'
}: PriceTableModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'SERVICO' | 'PECA'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  
  // Quantities mapped by item id
  const [quantities, setQuantities] = useState<{ [id: string]: number }>({});
  
  // Multi-selection set
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  
  // Flash feedback for inserted items
  const [justInsertedId, setJustInsertedId] = useState<string | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Focus on search input when modal opens
  useEffect(() => {
    if (isOpen) {
      setSearchQuery('');
      setSelectedIds(new Set());
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  // Esc key closes modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Merge services and inventory into unified PriceTableItem array
  const unifiedItems: PriceTableItem[] = useMemo(() => {
    const serviceItems: PriceTableItem[] = services.map(s => ({
      id: `srv-${s.id}`,
      sourceType: 'SERVICO',
      code: s.code,
      name: s.name,
      category: s.category || 'Hidráulica',
      description: s.description || s.name,
      unit: s.unit || 'UN',
      price: s.estimatedCost || 0
    }));

    const inventoryItems: PriceTableItem[] = inventory.map(i => ({
      id: `inv-${i.id}`,
      sourceType: 'PECA',
      code: i.code,
      name: i.name,
      category: i.category || 'Peças & Vedações',
      description: i.description || i.name,
      unit: i.unit || 'un',
      price: i.salePrice || 0,
      stockQty: i.quantity
    }));

    return [...serviceItems, ...inventoryItems];
  }, [services, inventory]);

  // Available categories for filtering
  const availableCategories = useMemo(() => {
    const set = new Set<string>();
    unifiedItems.forEach(item => {
      if (item.category) set.add(item.category);
    });
    return Array.from(set).sort();
  }, [unifiedItems]);

  // Filter items
  const filteredItems = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return unifiedItems.filter(item => {
      // Type filter
      if (typeFilter !== 'ALL' && item.sourceType !== typeFilter) {
        return false;
      }
      // Category filter
      if (categoryFilter !== 'ALL' && item.category !== categoryFilter) {
        return false;
      }
      // Text query
      if (!q) return true;
      return (
        item.name.toLowerCase().includes(q) ||
        item.code.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q)
      );
    });
  }, [unifiedItems, searchQuery, typeFilter, categoryFilter]);

  const getItemQty = (id: string) => {
    return quantities[id] !== undefined ? quantities[id] : 1;
  };

  const handleQtyChange = (id: string, delta: number) => {
    setQuantities(prev => {
      const current = prev[id] !== undefined ? prev[id] : 1;
      const next = Math.max(1, current + delta);
      return { ...prev, [id]: next };
    });
  };

  const handleSetDirectQty = (id: string, value: string) => {
    const num = Math.max(1, parseInt(value, 10) || 1);
    setQuantities(prev => ({ ...prev, [id]: num }));
  };

  // Insert single item
  const handleInsertSingle = (item: PriceTableItem) => {
    if (!onInsertItems) return;
    const qty = getItemQty(item.id);
    const quoteItem: SelectedQuoteItem = {
      type: item.sourceType === 'SERVICO' ? 'SERVICO' : 'PECA',
      description: `${item.name} (${item.code})${item.description && item.description !== item.name ? ` - ${item.description}` : ''}`,
      unitPrice: item.price,
      quantity: qty,
      unit: item.unit
    };

    onInsertItems([quoteItem]);

    setJustInsertedId(item.id);
    setTimeout(() => setJustInsertedId(null), 1500);
  };

  // Toggle multi-select
  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Insert all selected items
  const handleInsertSelected = () => {
    if (!onInsertItems || selectedIds.size === 0) return;

    const itemsToInsert: SelectedQuoteItem[] = [];
    selectedIds.forEach(id => {
      const item = unifiedItems.find(i => i.id === id);
      if (item) {
        const qty = getItemQty(item.id);
        itemsToInsert.push({
          type: item.sourceType === 'SERVICO' ? 'SERVICO' : 'PECA',
          description: `${item.name} (${item.code})${item.description && item.description !== item.name ? ` - ${item.description}` : ''}`,
          unitPrice: item.price,
          quantity: qty,
          unit: item.unit
        });
      }
    });

    onInsertItems(itemsToInsert);
    setSelectedIds(new Set());
    onClose();
  };

  // Calculate sum of selected items
  const selectedSummary = useMemo(() => {
    let count = 0;
    let total = 0;
    selectedIds.forEach(id => {
      const item = unifiedItems.find(i => i.id === id);
      if (item) {
        const qty = getItemQty(item.id);
        count += qty;
        total += item.price * qty;
      }
    });
    return { count, total, itemsCount: selectedIds.size };
  }, [selectedIds, quantities, unifiedItems]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
      id="price-table-modal-backdrop"
    >
      <div 
        className="bg-white border-2 border-slate-400 rounded-2xl w-full max-w-5xl max-h-[92vh] shadow-2xl overflow-hidden flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150"
        id="price-table-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-price-table-title"
      >
        {/* Header */}
        <div className="bg-[#1b365d] text-white px-4 sm:px-6 py-4 flex items-center justify-between border-b border-blue-900 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="modal-price-table-title" className="text-sm sm:text-base font-black uppercase tracking-wider text-white">
                  {title}
                </h3>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded bg-blue-800 text-cyan-200 border border-blue-700 text-[10px] font-mono font-black">
                  {filteredItems.length} {filteredItems.length === 1 ? 'item' : 'itens'}
                </span>
              </div>
              <p className="text-xs text-cyan-200 mt-0.5">
                {subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenNewService && (
              <button
                type="button"
                id="btn-price-table-new-service"
                onClick={onOpenNewService}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider shadow-sm transition-all cursor-pointer"
                title="Cadastrar Novo Serviço na Tabela (F3)"
              >
                <Plus className="w-3.5 h-3.5 text-slate-950" />
                <span>Novo Serviço</span>
                <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1 rounded">F3</span>
              </button>
            )}

            <button
              type="button"
              id="btn-close-price-table-modal"
              onClick={onClose}
              className="p-2 rounded-lg text-cyan-200 hover:text-white hover:bg-blue-800 transition-colors cursor-pointer"
              title="Fechar (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search & Filters Bar */}
        <div className="p-3 sm:p-4 bg-slate-100 border-b border-slate-200 space-y-3 shrink-0">
          {/* Main Search Input */}
          <div className="relative">
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3" />
            <input
              ref={searchInputRef}
              id="input-price-table-search"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Digite o código, nome do serviço, peça, vedação, óleo ou descrição técnica..."
              className="w-full pl-11 pr-10 py-2.5 bg-white border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 rounded-xl text-xs sm:text-sm font-bold text-slate-900 shadow-inner placeholder:text-slate-400"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                title="Limpar pesquisa"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Filter Chips & Type Selector */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            {/* Type selector */}
            <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-300 shadow-2xs">
              <button
                type="button"
                onClick={() => setTypeFilter('ALL')}
                className={`px-3 py-1 rounded-lg font-black uppercase text-[10px] sm:text-xs transition-all cursor-pointer ${
                  typeFilter === 'ALL'
                    ? 'bg-[#1b365d] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Todos ({unifiedItems.length})
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('SERVICO')}
                className={`flex items-center gap-1 px-3 py-1 rounded-lg font-black uppercase text-[10px] sm:text-xs transition-all cursor-pointer ${
                  typeFilter === 'SERVICO'
                    ? 'bg-blue-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Briefcase className="w-3 h-3" />
                <span>Serviços ({services.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('PECA')}
                className={`flex items-center gap-1 px-3 py-1 rounded-lg font-black uppercase text-[10px] sm:text-xs transition-all cursor-pointer ${
                  typeFilter === 'PECA'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Package className="w-3 h-3" />
                <span>Peças/Estoque ({inventory.length})</span>
              </button>
            </div>

            {/* Category Dropdown Filter */}
            {availableCategories.length > 0 && (
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black uppercase text-slate-500 hidden sm:inline">Categoria:</span>
                <select
                  id="select-price-table-category"
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="bg-white border border-slate-300 rounded-xl px-2.5 py-1 text-xs font-bold text-slate-800 cursor-pointer shadow-2xs"
                >
                  <option value="ALL">Todas as Categorias</option>
                  {availableCategories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Items List / Table */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-2 bg-slate-50">
          {filteredItems.length === 0 ? (
            <div className="text-center py-12 px-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <FileSpreadsheet className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h4 className="text-sm font-black uppercase tracking-wider text-slate-800">
                Nenhum item localizado na tabela de preços
              </h4>
              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                Não encontramos serviços ou peças com o termo "{searchQuery}". Verifique a ortografia ou adicione um novo serviço.
              </p>
              {onOpenNewService && (
                <button
                  type="button"
                  onClick={onOpenNewService}
                  className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-md transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar Este Novo Serviço (F3)</span>
                </button>
              )}
            </div>
          ) : (
            filteredItems.map(item => {
              const isSelected = selectedIds.has(item.id);
              const isJustInserted = justInsertedId === item.id;
              const currentQty = getItemQty(item.id);
              const isService = item.sourceType === 'SERVICO';

              return (
                <div
                  key={item.id}
                  className={`bg-white border rounded-xl p-3 sm:p-3.5 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isSelected 
                      ? 'border-blue-500 ring-2 ring-blue-500/20 shadow-sm bg-blue-50/20' 
                      : isJustInserted
                        ? 'border-emerald-500 ring-2 ring-emerald-500/30 bg-emerald-50/30'
                        : 'border-slate-200 hover:border-slate-300 hover:shadow-xs'
                  }`}
                >
                  {/* Left: Checkbox + Badges + Title + Description */}
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    {onInsertItems && (
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelect(item.id)}
                        className="mt-1 w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 cursor-pointer shrink-0"
                        title="Marcar para inserção múltipla"
                      />
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="font-mono text-[10px] font-black uppercase px-2 py-0.5 rounded bg-slate-900 text-amber-300 border border-slate-800">
                          {item.code}
                        </span>

                        <span className={`inline-flex items-center gap-1 text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                          isService
                            ? 'bg-blue-100 text-blue-900 border border-blue-200'
                            : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                        }`}>
                          {isService ? <Briefcase className="w-3 h-3" /> : <Package className="w-3 h-3" />}
                          <span>{isService ? 'Serviço' : 'Peça / Material'}</span>
                        </span>

                        <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                          {item.category}
                        </span>

                        {item.stockQty !== undefined && (
                          <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                            item.stockQty <= 2 
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : 'bg-slate-100 text-slate-700'
                          }`}>
                            Estoque: {item.stockQty} {item.unit}
                          </span>
                        )}
                      </div>

                      <h4 className="text-xs sm:text-sm font-black text-slate-900 leading-tight">
                        {item.name}
                      </h4>

                      {item.description && item.description !== item.name && (
                        <p className="text-[11px] text-slate-600 mt-1 line-clamp-2 leading-relaxed font-medium">
                          {item.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right: Quantity Controls + Price + Insert Button */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    {/* Unit Price */}
                    <div className="text-right">
                      <span className="text-[10px] font-black uppercase text-slate-400 block">
                        Preço Sugerido / {item.unit}
                      </span>
                      <span className="text-sm sm:text-base font-mono font-black text-slate-950">
                        R$ {item.price.toFixed(2).replace('.', ',')}
                      </span>
                    </div>

                    {/* Quantity controls */}
                    {onInsertItems && (
                      <div className="flex items-center bg-slate-100 rounded-xl p-1 border border-slate-300">
                        <button
                          type="button"
                          onClick={() => handleQtyChange(item.id, -1)}
                          className="w-6 h-6 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors"
                          title="Diminuir quantidade"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="1"
                          value={currentQty}
                          onChange={(e) => handleSetDirectQty(item.id, e.target.value)}
                          className="w-10 text-center font-mono font-bold text-xs bg-transparent text-slate-900 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => handleQtyChange(item.id, 1)}
                          className="w-6 h-6 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors"
                          title="Aumentar quantidade"
                        >
                          +
                        </button>
                      </div>
                    )}

                    {/* Individual Insert Button */}
                    {onInsertItems && (
                      <button
                        type="button"
                        onClick={() => handleInsertSingle(item)}
                        className={`px-3 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs ${
                          isJustInserted
                            ? 'bg-emerald-600 text-white shadow-md'
                            : 'bg-[#1b365d] hover:bg-blue-800 text-white'
                        }`}
                        title="Inserir este item imediatamente no orçamento"
                      >
                        {isJustInserted ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Inserido!</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5 text-amber-400" />
                            <span>Inserir</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer / Multi-selection Action Bar */}
        <div className="bg-slate-100 border-t border-slate-200 px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            {selectedIds.size > 0 ? (
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse"></span>
                <span className="text-xs font-black text-slate-900 uppercase">
                  {selectedSummary.itemsCount} {selectedSummary.itemsCount === 1 ? 'item marcado' : 'itens marcados'}
                </span>
                <span className="font-mono text-xs font-bold text-blue-900 bg-blue-100 px-2 py-0.5 rounded-md border border-blue-200">
                  Total Estimado: R$ {selectedSummary.total.toFixed(2).replace('.', ',')}
                </span>
              </div>
            ) : (
              <span className="text-xs text-slate-500 font-medium">
                Dica: Clique em <strong>"Inserir"</strong> para adicionar direto ou marque as caixas de seleção para adicionar vários de uma vez.
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {selectedIds.size > 0 && onInsertItems && (
              <button
                type="button"
                id="btn-insert-selected-price-items"
                onClick={handleInsertSelected}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
              >
                <Check className="w-4 h-4 text-emerald-100" />
                <span>Inserir {selectedSummary.itemsCount} {selectedSummary.itemsCount === 1 ? 'Item' : 'Itens'} no Orçamento</span>
              </button>
            )}

            <button
              type="button"
              id="btn-close-footer-price-table"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-slate-200 border border-slate-300 text-slate-800 font-bold rounded-xl text-xs uppercase cursor-pointer transition-colors"
            >
              Fechar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
