import { Client, Equipment, ServiceOrder } from '../types';
import { Users, Cpu, FileText, CheckCircle2, TrendingUp } from 'lucide-react';

interface DashboardStatsProps {
  clients: Client[];
  equipments: Equipment[];
  orders: ServiceOrder[];
}

export default function DashboardStats({ clients, equipments, orders }: DashboardStatsProps) {
  const activeOrders = orders.filter(o => o.status === 'PENDING' || o.status === 'IN_PROGRESS');
  const completedOrders = orders.filter(o => o.status === 'COMPLETED');
  
  // Calculate total estimated revenue from active & completed orders
  const totalValue = orders
    .filter(o => o.status !== 'CANCELLED')
    .reduce((sum, o) => sum + o.estimatedCost, 0);

  const stats = [
    {
      id: 'stat-clients',
      title: 'Clientes Ativos',
      value: clients.length,
      icon: Users,
      color: 'text-sky-400 border-sky-500/20 bg-sky-500/5',
      glow: 'shadow-[0_0_15px_rgba(56,189,248,0.1)]',
      description: 'Parceiros industriais integrados',
    },
    {
      id: 'stat-equipments',
      title: 'Equipamentos',
      value: equipments.length,
      icon: Cpu,
      color: 'text-indigo-400 border-indigo-500/20 bg-indigo-500/5',
      glow: 'shadow-[0_0_15px_rgba(129,140,248,0.1)]',
      description: 'Ativos sob monitoramento ativo',
    },
    {
      id: 'stat-orders',
      title: 'Ordens em Aberto',
      value: activeOrders.length,
      icon: FileText,
      color: 'text-amber-400 border-amber-500/20 bg-amber-500/5',
      glow: 'shadow-[0_0_15px_rgba(251,191,36,0.1)]',
      description: 'Serviços em andamento ou triagem',
    },
    {
      id: 'stat-completed',
      title: 'OS Concluídas',
      value: completedOrders.length,
      icon: CheckCircle2,
      color: 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5',
      glow: 'shadow-[0_0_15px_rgba(52,211,153,0.1)]',
      description: 'Manutenções consolidadas',
    },
    {
      id: 'stat-revenue',
      title: 'Faturamento Estimado',
      value: new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalValue),
      icon: TrendingUp,
      color: 'text-fuchsia-400 border-fuchsia-500/20 bg-fuchsia-500/5',
      glow: 'shadow-[0_0_15px_rgba(232,121,249,0.1)]',
      description: 'Soma total acumulada das OS',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <div
            id={stat.id}
            key={stat.id}
            className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm flex flex-col justify-between hover:border-blue-600 transition-all duration-200 group"
          >
            <div className="bg-[#1b365d] text-white px-3 py-1.5 flex items-center justify-between border-b border-blue-900">
              <span className="text-[10px] font-black uppercase tracking-wider text-white">{stat.title}</span>
              <Icon className="w-3.5 h-3.5 text-white" />
            </div>
            <div className="p-3.5 flex flex-col justify-between flex-grow bg-[#f4f7fa]">
              <h3 className="text-xl sm:text-2xl font-black text-[#003b7a] font-mono tracking-tight">{stat.value}</h3>
              <p className="text-[10px] text-slate-600 mt-2 font-bold">
                {stat.description}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

