import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Client, Equipment, ServiceOrder, OSStatus, Technician, TechnicalDiagnostic } from '../types';
import { formatPhoneNumber } from '../utils/phoneFormatter';
import { ShareContactModal } from './ShareContactModal';
import { 
  UserPlus, Smartphone, Plus, Search, FileText, CheckCircle2, Clock, X, AlertTriangle, 
  User, DollarSign, Calendar, Cpu, Tag, Layers, Send, MessageSquare, PlusCircle, 
  ArrowRight, ArrowLeft, Check, FileCheck, Camera, Phone, MapPin, UserCheck, 
  Sparkles, Share2, Printer, Image, RefreshCw, ClipboardList, Mail, XCircle, Save
} from 'lucide-react';

interface MobileOrderCreatorProps {
  clients: Client[];
  equipments: Equipment[];
  orders: ServiceOrder[];
  technicians?: Technician[];
  diagnostics?: TechnicalDiagnostic[];
  onAddClient: (client: Omit<Client, 'id' | 'createdAt'>) => Client;
  onAddEquipment: (equipment: Omit<Equipment, 'id' | 'createdAt'>) => Equipment;
  onAddOrder: (order: Omit<ServiceOrder, 'id' | 'osNumber' | 'createdAt'>) => ServiceOrder;
  onEditOrder: (order: ServiceOrder) => void;
}

// Preset machine photos for quick testing in AI Studio or desktop browsers
const PRESET_PHOTOS = [
  { id: 'cilindro', name: 'Cilindro Hidráulico', url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=300' },
  { id: 'bomba', name: 'Bomba de Engrenagens', url: 'https://images.unsplash.com/photo-1537462715879-360eeb61a0bc?auto=format&fit=crop&q=80&w=300' },
  { id: 'valvula', name: 'Bloco de Válvulas', url: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=300' },
  { id: 'motor', name: 'Motor Hidráulico', url: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&q=80&w=300' }
];

export default function MobileOrderCreator({
  clients,
  equipments,
  orders,
  technicians = [],
  diagnostics = [],
  onAddClient,
  onAddEquipment,
  onAddOrder,
  onEditOrder,
}: MobileOrderCreatorProps) {
  // Wizard steps: 1 = Client, 2 = Equipment, 3 = Photo & Issue, 4 = Success
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // STEP 1 STATE: Client selection or creation
  const [clientMode, setClientMode] = useState<'SELECT' | 'CREATE'>('SELECT');
  const [selectedClientId, setSelectedClientId] = useState('');
  const [clientSearch, setClientSearch] = useState('');
  // New Client Form
  const [newClientName, setNewClientName] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');
  const [newClientDoc, setNewClientDoc] = useState('');
  const [newClientAddress, setNewClientAddress] = useState('');

  // STEP 2 STATE: Equipment selection or creation
  const [equipMode, setEquipMode] = useState<'SELECT' | 'CREATE'>('SELECT');
  const [selectedEquipId, setSelectedEquipId] = useState('');
  const [equipSearch, setEquipSearch] = useState('');
  const [equipFilterMode, setEquipFilterMode] = useState<'CLIENT' | 'ALL'>('ALL');
  // New Equipment Form
  const [newEquipName, setNewEquipName] = useState('');
  const [newEquipModel, setNewEquipModel] = useState('');
  const [newEquipType, setNewEquipType] = useState('Hidráulico');

  // STEP 3 STATE: Order details
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [orderType, setOrderType] = useState<'SERVICE' | 'WARRANTY'>('SERVICE');
  const [priority, setPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('MEDIUM');
  const [technician, setTechnician] = useState('João Carlos');
  const [estimatedCost, setEstimatedCost] = useState<number>(0);
  const [photo, setPhoto] = useState<string>('');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [isCapturing, setIsCapturing] = useState(false);

  // STEP 4 STATE: Completed Order Details
  const [createdOrder, setCreatedOrder] = useState<ServiceOrder | null>(null);
  const [createdClient, setCreatedClient] = useState<Client | null>(null);
  const [createdEquip, setCreatedEquip] = useState<Equipment | null>(null);

  // STEP 4 Interactive Budget States
  const [budgetDiagnostic, setBudgetDiagnostic] = useState('');
  const [budgetServices, setBudgetServices] = useState('');
  const [budgetCost, setBudgetCost] = useState<number>(0);
  const [clientEmail, setClientEmail] = useState('');
  const [budgetStatus, setBudgetStatus] = useState<'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED'>('PENDING_APPROVAL');

  useEffect(() => {
    if (createdOrder) {
      setBudgetDiagnostic(createdOrder.diagnostic || '');
      setBudgetServices(createdOrder.plannedServices || '');
      setBudgetCost(createdOrder.estimatedCost || 0);
      setBudgetStatus(createdOrder.budgetStatus || 'PENDING_APPROVAL');
    }
  }, [createdOrder]);

  // Notification feedback
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [shareModalConfig, setShareModalConfig] = useState<{
    isOpen: boolean;
    title: string;
    subtitle?: string;
    docType: 'ORCAMENTO' | 'RECIBO_GARANTIA' | 'FICHA_ENTRADA' | 'GERAL';
    clientName: string;
    clientPhone: string;
    clientEmail?: string;
    defaultChannel: 'WHATSAPP' | 'EMAIL';
    defaultMessage: string;
    subject: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-set initial selected client if list not empty
  useEffect(() => {
    if (clients.length > 0 && !selectedClientId) {
      setSelectedClientId(clients[0].id);
    }
  }, [clients, selectedClientId]);

  // Handle client selection search
  const filteredClientsForSelection = clients.filter(c => 
    c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
    c.phone.includes(clientSearch) ||
    c.document.includes(clientSearch)
  ).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));

  // Handle equipment selection search (filtered by selected client)
  const filteredEquipsForSelection = equipments.filter(e => {
    const matchesSearch = 
      e.name.toLowerCase().includes(equipSearch.toLowerCase()) || 
      e.model.toLowerCase().includes(equipSearch.toLowerCase()) ||
      (e.type && e.type.toLowerCase().includes(equipSearch.toLowerCase()));
    
    if (equipFilterMode === 'CLIENT' && selectedClientId) {
      return matchesSearch && e.clientId === selectedClientId;
    }
    return matchesSearch;
  }).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));

  // Unique machine templates (by name and model) grouped as types/models
  const uniqueMachineTemplates = useMemo(() => {
    const seen = new Set<string>();
    const templates: { name: string; model: string; type: string }[] = [];
    
    equipments.forEach(e => {
      const key = `${e.name.trim().toLowerCase()}||${e.model.trim().toLowerCase()}`;
      if (!seen.has(key)) {
        seen.add(key);
        templates.push({
          name: e.name,
          model: e.model,
          type: e.type || 'Hidráulico'
        });
      }
    });
    
    // Add default hydraulic/pneumatic templates to make sure we always have professional choices
    const defaults = [
      { name: 'Cilindro Hidráulico Haste', model: 'Standard JC&F', type: 'Cilindro Hidráulico' },
      { name: 'Unidade Hidráulica de Força', model: 'UHF-Parker', type: 'Unidade Hidráulica' },
      { name: 'Bomba de Engrenagens', model: 'Rexroth S10', type: 'Bomba Rotativa' },
      { name: 'Válvula Direcional Solenóide', model: 'VDS-06', type: 'Válvula Reguladora' },
      { name: 'Cilindro Pneumático de Dupla Ação', model: 'CP-Festo', type: 'Cilindro Pneumático' },
    ];
    
    defaults.forEach(d => {
      const key = `${d.name.trim().toLowerCase()}||${d.model.trim().toLowerCase()}`;
      if (!seen.has(key)) {
        seen.add(key);
        templates.push(d);
      }
    });

    return templates;
  }, [equipments]);

  // Handle template search
  const filteredTemplates = useMemo(() => {
    return uniqueMachineTemplates.filter(t => 
      t.name.toLowerCase().includes(equipSearch.toLowerCase()) || 
      t.model.toLowerCase().includes(equipSearch.toLowerCase()) ||
      t.type.toLowerCase().includes(equipSearch.toLowerCase())
    ).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
  }, [uniqueMachineTemplates, equipSearch]);

  const handleSelectTemplate = (template: { name: string; model: string; type: string }) => {
    setNewEquipName(template.name);
    setNewEquipModel(template.model);
    setNewEquipType(template.type);
    setEquipMode('CREATE'); // Switch to registration/creation mode with prefilled values!
    setSelectedEquipId(''); // Clear selected existing equipment ID
    showFeedback(`Modelo "${template.name}" selecionado! Revise e clique em Avançar.`, 'success');
  };

  // Trigger file upload/camera on mobile
  const handlePhotoClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
        showFeedback('Foto capturada com sucesso!', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const selectPresetPhoto = (url: string) => {
    setPhoto(url);
    showFeedback('Foto predefinida selecionada!', 'success');
  };

  const showFeedback = (message: string, type: 'success' | 'error' = 'success') => {
    setFeedback({ message, type });
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleEquipSelect = (equip: Equipment) => {
    setSelectedEquipId(equip.id);
    showFeedback(`Equipamento "${equip.name}" selecionado!`, 'success');
  };

  // Step Navigations & Validations
  const handleNextToStep2 = () => {
    if (clientMode === 'CREATE') {
      if (!newClientName.trim() || !newClientPhone.trim()) {
        showFeedback('Por favor, preencha o nome e telefone do cliente.', 'error');
        return;
      }
      try {
        const clientPayload = {
          name: newClientName,
          phone: newClientPhone,
          document: newClientDoc || 'N/A',
          address: newClientAddress || 'N/A'
        };
        const created = onAddClient(clientPayload);
        setSelectedClientId(created.id);
        setClientMode('SELECT'); // set to SELECT with newly created client
        showFeedback('Cliente cadastrado com sucesso!', 'success');
        
        // Keep equipMode as SELECT so user can choose any registered equipment or switch to CREATE
        setEquipMode('SELECT');
      } catch (err: any) {
        showFeedback(`Erro ao cadastrar cliente: ${err.message || err}`, 'error');
        return;
      }
    } else {
      if (!selectedClientId) {
        showFeedback('Por favor, selecione um cliente da lista.', 'error');
        return;
      }
      
      // Auto-switch to CREATE if selected client has no equipments
      const hasEquipments = equipments.some(e => e.clientId === selectedClientId);
      if (!hasEquipments) {
        setEquipMode('CREATE');
      } else {
        setEquipMode('SELECT');
      }
    }
    setStep(2);
  };

  const handleNextToStep3 = () => {
    if (equipMode === 'CREATE') {
      if (!newEquipName.trim() || !newEquipModel.trim()) {
        showFeedback('Por favor, preencha o nome e modelo do equipamento.', 'error');
        return;
      }
      try {
        const equipPayload = {
          name: newEquipName,
          model: newEquipModel,
          type: newEquipType,
          clientId: selectedClientId
        };
        const created = onAddEquipment(equipPayload);
        setSelectedEquipId(created.id);
        setEquipMode('SELECT'); // normalize mode
        showFeedback('Equipamento cadastrado com sucesso!', 'success');
      } catch (err: any) {
        showFeedback(`Erro ao cadastrar equipamento: ${err.message || err}`, 'error');
        return;
      }
    } else {
      if (!selectedEquipId) {
        showFeedback('Por favor, selecione um equipamento da lista.', 'error');
        return;
      }
    }
    // Pre-fill general title if empty
    const currentEquipName = equipMode === 'CREATE' ? newEquipName : (equipments.find(e => e.id === selectedEquipId)?.name || 'Equipamento');
    if (!title) {
      setTitle(`Reparo de ${currentEquipName}`);
    }
    setStep(3);
  };

  // Submit and create
  const handleSubmitOrder = () => {
    if (!description.trim()) {
      showFeedback('Por favor, descreva o problema apresentado pelo cliente.', 'error');
      return;
    }

    try {
      let finalClient: Client | undefined;
      let finalEquip: Equipment | undefined;

      // Both client and equipment are already created and selected!
      finalClient = clients.find(c => c.id === selectedClientId);
      finalEquip = equipments.find(e => e.id === selectedEquipId);

      if (!finalClient) {
        // Fallback if they managed to get here with CREATE state
        if (clientMode === 'CREATE' && newClientName.trim() && newClientPhone.trim()) {
          const clientPayload = {
            name: newClientName,
            phone: newClientPhone,
            document: newClientDoc || 'N/A',
            address: newClientAddress || 'N/A'
          };
          finalClient = onAddClient(clientPayload);
        } else {
          throw new Error('Cliente inválido ou não selecionado.');
        }
      }

      if (!finalEquip) {
        // Fallback if they managed to get here with CREATE state
        if (equipMode === 'CREATE' && newEquipName.trim() && newEquipModel.trim()) {
          const equipPayload = {
            name: newEquipName,
            model: newEquipModel,
            type: newEquipType,
            clientId: finalClient.id
          };
          finalEquip = onAddEquipment(equipPayload);
        } else {
          throw new Error('Equipamento inválido ou não selecionado.');
        }
      }

      // Antiduplicity check for same client + same equipment simultaneously active
      const existingDuplicates = orders.filter(o =>
        o.clientId === finalClient.id &&
        (o.equipmentId === finalEquip.id ||
         equipments.find(e => e.id === o.equipmentId)?.name.toLowerCase() === finalEquip.name.toLowerCase()) &&
        o.status !== 'CANCELLED' &&
        !o.isDelivered
      );

      const isDuplicate = existingDuplicates.length > 0;

      // 3. Create Service Order
      const osPayload = {
        clientId: finalClient.id,
        equipmentId: finalEquip.id,
        title: isDuplicate 
          ? `${title || `Reparo de ${finalEquip.name}`} (2º Equipamento)`
          : (title || `Reparo de ${finalEquip.name}`),
        description: isDuplicate
          ? `${description}\n\n[DISPOSITIVO ANTIDUPLICIDADE: OS Autorizada no Mobile - Cliente possui 2º equipamento idêntico]`
          : description,
        orderType: orderType,
        status: 'PENDING' as OSStatus, // PENDING makes it appear in the backlog queue/kanban
        priority: priority,
        technician: technician,
        estimatedCost: Number(estimatedCost) || 0,
        startDate: startDate,
        equipmentPhoto: photo || undefined,
        budgetStatus: 'PENDING_APPROVAL' as const, // For sending estimate later
        isDelivered: false,
        isDuplicateAuthorized: isDuplicate,
        duplicateNote: isDuplicate ? 'Autorizado no Mobile: 2º equipamento idêntico do cliente' : undefined
      };

      const finalOrder = onAddOrder(osPayload);

      // Save references for Step 4 success summary
      setCreatedClient(finalClient);
      setCreatedEquip(finalEquip);
      setCreatedOrder(finalOrder);

      // Transition to success step
      setStep(4);
      showFeedback('✅ Equipamento recebido, registrado com sucesso no sistema da JC&F e encaminhado para avaliação técnica.', 'success');
    } catch (err: any) {
      showFeedback(`Erro ao salvar: ${err.message || err}`, 'error');
    }
  };

  // Reset the form
  const handleReset = () => {
    setStep(1);
    setClientMode('SELECT');
    setEquipMode('SELECT');
    setNewClientName('');
    setNewClientPhone('');
    setNewClientDoc('');
    setNewClientAddress('');
    setNewEquipName('');
    setNewEquipModel('');
    setNewEquipType('Hidráulico');
    setTitle('');
    setDescription('');
    setOrderType('SERVICE');
    setPriority('MEDIUM');
    setTechnician('João Carlos');
    setEstimatedCost(0);
    setPhoto('');
    setCreatedOrder(null);
    setCreatedClient(null);
    setCreatedEquip(null);
    setBudgetDiagnostic('');
    setBudgetServices('');
    setBudgetCost(0);
    setClientEmail('');
    setBudgetStatus('PENDING_APPROVAL');
  };

  // Share entry receipt via WhatsApp URL generator
  const getWhatsAppShareUrl = () => {
    if (!createdOrder || !createdClient || !createdEquip) return '';

    const phone = createdClient.phone.replace(/\D/g, '');
    const currencyFormatter = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
    const formattedCost = createdOrder.estimatedCost > 0 ? currencyFormatter.format(createdOrder.estimatedCost) : 'A definir após diagnóstico detalhado';

    const message = `🛠️ *JC&F - MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA*
--------------------------------------------
Olá, *${createdClient.name}*!

Recebemos o seu equipamento para check-in e abertura de diagnóstico. Seguem os dados cadastrados:

📌 *Ordem de Serviço:* ${createdOrder.osNumber}
⚙️ *Equipamento:* ${createdEquip.name}
🏷️ *Modelo/Série:* ${createdEquip.model}
⚠️ *Problema Informado:*
_"${createdOrder.description}"_

📋 *Estimativa Inicial de Reparo:*
*${formattedCost}*

Nosso técnico *${createdOrder.technician}* está conduzindo a análise minuciosa. Enviaremos o laudo técnico completo e a solicitação de aprovação formal de orçamento em breve!

Se tiver alguma dúvida, entre em contato conosco.
Obrigado pela preferência!`;

    return `https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(message)}`;
  };

  // Share detailed estimate via WhatsApp URL generator
  const getDetailedWhatsAppUrl = () => {
    if (!createdOrder || !createdClient || !createdEquip) return '';

    const phone = createdClient.phone.replace(/\D/g, '');
    const currencyFormatter = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
    const formattedCost = budgetCost > 0 ? currencyFormatter.format(budgetCost) : 'A calcular';

    const message = `🛠️ *ORÇAMENTO TÉCNICO - JC&F MANUTENÇÃO*
--------------------------------------------
Olá, *${createdClient.name}*!

Apresentamos o laudo técnico e orçamento para o reparo do seu equipamento sob a *OS ${createdOrder.osNumber}*:

⚙️ *Equipamento:* ${createdEquip.name} (${createdEquip.model})

🔍 *DIAGNÓSTICO TÉCNICO:*
_${budgetDiagnostic || 'Análise técnica preliminar concluída.'}_

📋 *SERVIÇOS & PEÇAS A EXECUTAR:*
_${budgetServices || 'Manutenção e troca de componentes conforme avaliação.'}_

💰 *VALOR TOTAL DO ORÇAMENTO:*
*${formattedCost}*

⚠️ *AGUARDANDO SUA APROVAÇÃO:*
Para darmos início aos procedimentos de manutenção, por favor responda a esta mensagem autorizando os serviços descritos acima.

Estamos à disposição para tirar qualquer dúvida!
Obrigado!`;

    return `https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(message)}`;
  };

  // Share detailed estimate via Email URL generator
  const getDetailedEmailUrl = () => {
    if (!createdOrder || !createdClient || !createdEquip) return '';

    const subject = encodeURIComponent(`Orçamento de Manutenção JC&F - OS ${createdOrder.osNumber}`);
    const currencyFormatter = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
    const formattedCost = budgetCost > 0 ? currencyFormatter.format(budgetCost) : 'A calcular';

    const body = encodeURIComponent(`Prezado(a) ${createdClient.name},

Apresentamos o orçamento técnico e proposta de reparos para o seu equipamento:

Orçamento Técnico - OS ${createdOrder.osNumber}
Equipamento: ${createdEquip.name}
Modelo/Série: ${createdEquip.model}

1. DIAGNÓSTICO / PROBLEMA CONSTATADO:
${budgetDiagnostic || 'Análise técnica preliminar concluída.'}

2. PROCEDIMENTOS & PEÇAS A SEREM EXECUTADOS:
${budgetServices || 'Manutenção e troca de consumíveis.'}

3. VALOR TOTAL DO ORÇAMENTO:
${formattedCost}

Por favor, responda a este e-mail aprovando ou rejeitando a continuidade dos serviços de manutenção.

Caso tenha dúvidas, estamos à inteira disposição.

Atenciosamente,
Equipe Técnica JC&F
Manutenção Hidráulica e Pneumática`);

    return `mailto:${clientEmail || ''}?subject=${subject}&body=${body}`;
  };

  // Save/Update budget details to the main order
  const handleUpdateBudgetDetails = () => {
    if (!createdOrder) return;

    const updatedOrder: ServiceOrder = {
      ...createdOrder,
      diagnostic: budgetDiagnostic,
      plannedServices: budgetServices,
      estimatedCost: Number(budgetCost) || 0,
      budgetStatus: budgetStatus,
    };

    onEditOrder(updatedOrder);
    setCreatedOrder(updatedOrder);
    showFeedback('Orçamento técnico salvo com sucesso!', 'success');
  };

  // Set budget status manually and update the OSStatus
  const handleSetBudgetStatus = (status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED') => {
    if (!createdOrder) return;

    const updatedOrder: ServiceOrder = {
      ...createdOrder,
      diagnostic: budgetDiagnostic,
      plannedServices: budgetServices,
      estimatedCost: Number(budgetCost) || 0,
      budgetStatus: status,
    };

    if (status === 'APPROVED') {
      updatedOrder.status = 'IN_PROGRESS'; // Continuar manutenção
    } else if (status === 'REJECTED') {
      updatedOrder.status = 'CANCELLED'; // Não continuar manutenção
    } else {
      updatedOrder.status = 'PENDING'; // Aguardar
    }

    onEditOrder(updatedOrder);
    setCreatedOrder(updatedOrder);
    setBudgetStatus(status);

    if (status === 'APPROVED') {
      showFeedback('Orçamento APROVADO! OS alterada para "Em Execução" com sucesso.', 'success');
    } else if (status === 'REJECTED') {
      showFeedback('Orçamento REJEITADO! OS foi cancelada conforme decisão do cliente.', 'error');
    } else {
      showFeedback('Orçamento alterado para Aguardando Resposta.', 'success');
    }
  };

  // Print mock invoice/ticket for entry
  const handlePrintReceipt = () => {
    if (!createdOrder || !createdClient || !createdEquip) return;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Comprovante de Entrada - ${createdOrder.osNumber}</title>
            <style>
              body { font-family: 'Courier New', Courier, monospace; color: #000; padding: 20px; font-size: 14px; max-width: 400px; margin: 0 auto; }
              .header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 15px; }
              .header h2 { margin: 0; font-size: 18px; }
              .header p { margin: 5px 0 0 0; font-size: 11px; }
              .section { margin-bottom: 15px; }
              .row { display: flex; justify-content: space-between; margin-bottom: 5px; }
              .title { font-weight: bold; }
              .footer { text-align: center; border-top: 1px dashed #000; padding-top: 10px; margin-top: 20px; font-size: 11px; }
              @media print {
                body { padding: 0; }
              }
            </style>
          </head>
          <body onload="window.print()">
            <div class="header">
              <h2>JC&F</h2>
              <p>MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA</p>
              <p>COMPROVANTE DE ENTRADA DE EQUIPAMENTO</p>
            </div>
            <div class="section">
              <div class="row"><span class="title">OS NÚMERO:</span><span>${createdOrder.osNumber}</span></div>
              <div class="row"><span class="title">DATA:</span><span>${new Date(createdOrder.createdAt || '').toLocaleString('pt-BR')}</span></div>
              <div class="row"><span class="title">TÉCNICO:</span><span>${createdOrder.technician}</span></div>
            </div>
            <div class="section" style="border-top: 1px dashed #000; padding-top: 10px;">
              <span class="title">CLIENTE:</span>
              <p style="margin: 3px 0;">${createdClient.name}</p>
              <p style="margin: 3px 0;">Tel: ${createdClient.phone}</p>
            </div>
            <div class="section" style="border-top: 1px dashed #000; padding-top: 10px;">
              <span class="title">EQUIPAMENTO:</span>
              <p style="margin: 3px 0;">${createdEquip.name} (${createdEquip.model})</p>
              <p style="margin: 3px 0;">Tipo: ${createdEquip.type}</p>
            </div>
            <div class="section" style="border-top: 1px dashed #000; padding-top: 10px;">
              <span class="title">PROBLEMA RELATADO:</span>
              <p style="margin: 5px 0; font-style: italic;">"${createdOrder.description}"</p>
            </div>
            <div class="footer">
              <p>Agradecemos a confiança!</p>
              <p>JC&F Assistência Especializada</p>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  };

  return (
    <div className="space-y-6" id="mobile-order-creator-root">
      
      {/* Toast Feedback */}
      {feedback && (
        <div 
          className={`fixed top-4 right-4 z-[100] px-4 py-3 rounded-xl border shadow-xl flex items-center gap-2.5 animate-in slide-in-from-top-4 ${
            feedback.type === 'success' 
              ? 'bg-emerald-950/90 border-emerald-500/30 text-emerald-300' 
              : 'bg-red-950/90 border-red-500/30 text-red-300'
          }`}
          id="mobile-order-creator-feedback"
        >
          {feedback.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" /> : <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />}
          <span className="text-xs font-bold font-mono uppercase tracking-wider">{feedback.message}</span>
        </div>
      )}

      {/* Dynamic Header specifically calling out Tablet/Mobile optimization */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-[#11131c] border border-slate-800/80 rounded-2xl shadow-xs" id="mobile-tab-header">
        <div className="flex items-start gap-3.5">
          <div className="p-3 bg-cyan-950/40 rounded-xl border border-cyan-500/15 text-cyan-400 shrink-0">
            <Smartphone className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-100 uppercase tracking-widest flex items-center gap-2">
              <span>Check-in Móvel</span>
              <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">Tablet & Celular</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Interface rápida otimizada para telas sensíveis ao toque. Cadastre o cliente, máquina, anexe uma foto e o problema e já inicie o orçamento de manutenção na hora.
            </p>
          </div>
        </div>

        {step < 4 && (
          <div className="flex items-center gap-1.5 self-end md:self-auto" id="wizard-progress-dots">
            {[1, 2, 3].map((s) => (
              <div 
                key={s} 
                className={`h-2 rounded-full transition-all duration-300 ${
                  step === s 
                    ? 'w-8 bg-cyan-400' 
                    : step > s 
                      ? 'w-2 bg-emerald-500' 
                      : 'w-2 bg-slate-800'
                }`}
              />
            ))}
            <span className="text-[10px] font-mono font-bold text-slate-500 ml-2">Passo {step}/3</span>
          </div>
        )}
      </div>

      {/* STEP 1: CLIENT IDENTIFICATION */}
      {step === 1 && (
        <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl p-6 shadow-sm space-y-6" id="mobile-step-1">
          <div className="flex items-center justify-between border-b border-slate-800/50 pb-3">
            <h3 className="font-bold text-slate-100 text-sm uppercase tracking-wider flex items-center gap-2">
              <User className="w-4 h-4 text-cyan-400" />
              <span>Passo 1: Identificação do Cliente</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-extrabold bg-[#0c0d10] px-2.5 py-1 rounded-lg border border-slate-800">Check-in</span>
          </div>

          {/* Selector Segment Buttons */}
          <div className="grid grid-cols-2 gap-2.5" id="client-mode-selector">
            <button
              type="button"
              id="btn-client-mode-select"
              onClick={() => setClientMode('SELECT')}
              className={`py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider border transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                clientMode === 'SELECT'
                  ? 'bg-cyan-950/20 border-cyan-500/35 text-cyan-400 shadow-md shadow-cyan-950/20'
                  : 'bg-[#0c0d10] border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserCheck className="w-5 h-5" />
              <span>Cliente Cadastrado</span>
            </button>
            <button
              type="button"
              id="btn-client-mode-create"
              onClick={() => setClientMode('CREATE')}
              className={`py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider border transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                clientMode === 'CREATE'
                  ? 'bg-cyan-950/20 border-cyan-500/35 text-cyan-400 shadow-md shadow-cyan-950/20'
                  : 'bg-[#0c0d10] border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserPlus className="w-5 h-5" />
              <span>Cadastrar Novo</span>
            </button>
          </div>

          {/* VIEW A: SELECT EXISTING CLIENT */}
          {clientMode === 'SELECT' && (
            <div className="space-y-4" id="client-select-view">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4" />
                <input
                  id="search-client-input"
                  type="text"
                  placeholder="Buscar cliente pelo nome, CPF/CNPJ..."
                  value={clientSearch}
                  onChange={(e) => setClientSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-white border border-slate-300 rounded-xl text-xs text-black font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>

              <div className="max-h-64 overflow-y-auto divide-y divide-slate-900 border border-slate-800 rounded-xl bg-[#0c0d10]" id="client-list-scroll">
                {filteredClientsForSelection.length === 0 ? (
                  <p className="text-xs text-slate-500 text-center py-8">Nenhum cliente encontrado.</p>
                ) : (
                  filteredClientsForSelection.map((c) => (
                    <div
                      id={`client-card-item-${c.id}`}
                      key={c.id}
                      onClick={() => setSelectedClientId(c.id)}
                      className={`p-3.5 flex items-center justify-between gap-4 cursor-pointer transition-colors ${
                        selectedClientId === c.id 
                          ? 'bg-cyan-950/20 text-cyan-300 border-l-4 border-cyan-500' 
                          : 'hover:bg-slate-900/10 text-slate-300'
                      }`}
                    >
                      <div className="space-y-1 overflow-hidden">
                        <p className="font-bold text-xs truncate">{c.name}</p>
                        <div className="flex items-center gap-3 text-[10px] text-slate-500 font-mono">
                          <span className="flex items-center gap-1"><Phone className="w-2.5 h-2.5" />{c.phone}</span>
                          <span className="flex items-center gap-1"><FileText className="w-2.5 h-2.5" />{c.document}</span>
                        </div>
                      </div>
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                        selectedClientId === c.id ? 'border-cyan-500 bg-cyan-950/50' : 'border-slate-800'
                      }`}>
                        {selectedClientId === c.id && <Check className="w-3.5 h-3.5 text-cyan-400 font-black" />}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* VIEW B: CREATE NEW CLIENT */}
          {clientMode === 'CREATE' && (
            <div className="space-y-4 border border-slate-800/60 p-4 rounded-2xl bg-[#0c0d10]" id="client-create-view">
              <div className="flex items-center gap-2 mb-2 text-cyan-400">
                <Sparkles className="w-4 h-4" />
                <span className="text-[10px] font-black uppercase tracking-wider">Novo Cadastro Expresso</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-300 uppercase tracking-wider">Nome Completo / Razão Social *</label>
                  <input
                    id="new-client-name"
                    type="text"
                    required
                    placeholder="Ex: Carlos Eduardo de Oliveira"
                    value={newClientName}
                    onChange={(e) => setNewClientName(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-black font-bold uppercase placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-300 uppercase tracking-wider">Celular / WhatsApp *</label>
                  <input
                    id="new-client-phone"
                    type="text"
                    required
                    placeholder="Ex: (21) 98369-9728"
                    value={newClientPhone}
                    onChange={(e) => setNewClientPhone(formatPhoneNumber(e.target.value))}
                    className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-black font-bold font-mono placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-300 uppercase tracking-wider">CPF ou CNPJ</label>
                  <input
                    id="new-client-document"
                    type="text"
                    placeholder="Ex: 123.456.789-00"
                    value={newClientDoc}
                    onChange={(e) => setNewClientDoc(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-black font-bold font-mono placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-300 uppercase tracking-wider">Endereço Completo</label>
                  <input
                    id="new-client-address"
                    type="text"
                    placeholder="Ex: Av. Industrial, 450 - São Paulo"
                    value={newClientAddress}
                    onChange={(e) => setNewClientAddress(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-black font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end pt-2">
            <button
              type="button"
              id="btn-step-1-next"
              onClick={handleNextToStep2}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-cyan-950/35 flex items-center gap-1.5 cursor-pointer"
            >
              <span>Avançar Máquina</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: EQUIPMENT IDENTIFICATION */}
      {step === 2 && (
        <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl p-6 shadow-sm space-y-6" id="mobile-step-2">
          <div className="flex items-center justify-between border-b border-slate-800/50 pb-3">
            <h3 className="font-bold text-slate-100 text-sm uppercase tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>Passo 2: Identificação do Equipamento</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-extrabold bg-[#0c0d10] px-2.5 py-1 rounded-lg border border-slate-800">Check-in</span>
          </div>

          {/* Selected Client Summary info card */}
          <div className="p-3 bg-slate-900/30 border border-slate-800 rounded-xl flex items-center gap-3" id="step-2-client-summary">
            <div className="p-2 bg-emerald-950/20 border border-emerald-500/10 text-emerald-400 rounded-lg shrink-0">
              <User className="w-4 h-4" />
            </div>
            <div className="overflow-hidden">
              <span className="text-[8px] uppercase tracking-wider font-bold text-slate-500">Cliente do Check-in</span>
              <p className="text-xs font-bold text-slate-200 truncate">
                {clientMode === 'CREATE' ? newClientName : clients.find(c => c.id === selectedClientId)?.name}
              </p>
            </div>
          </div>

          {/* Selector Segment Buttons */}
          <div className="grid grid-cols-2 gap-2.5" id="equip-mode-selector">
            <button
              type="button"
              id="btn-equip-mode-select"
              onClick={() => setEquipMode('SELECT')}
              className={`py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider border transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                equipMode === 'SELECT'
                  ? 'bg-cyan-950/20 border-cyan-500/35 text-cyan-400 shadow-md shadow-cyan-950/20'
                  : 'bg-[#0c0d10] border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCheck className="w-5 h-5" />
              <span>Máquina já Cadastrada</span>
            </button>
            <button
              type="button"
              id="btn-equip-mode-create"
              onClick={() => setEquipMode('CREATE')}
              className={`py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider border transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                equipMode === 'CREATE'
                  ? 'bg-cyan-950/20 border-cyan-500/35 text-cyan-400 shadow-md shadow-cyan-950/20'
                  : 'bg-[#0c0d10] border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <PlusCircle className="w-5 h-5" />
              <span>Cadastrar Nova Máquina</span>
            </button>
          </div>

          {/* VIEW A: SELECT EXISTING EQUIPMENT */}
          {equipMode === 'SELECT' && (
            <div className="space-y-4" id="equip-select-view">
              {/* Filter Mode Toggle */}
              <div className="flex items-center gap-1.5 bg-[#0c0d10] p-1.5 rounded-xl border border-slate-800/80" id="equip-filter-mode-toggle">
                <button
                  type="button"
                  id="btn-equip-filter-client"
                  onClick={() => setEquipFilterMode('CLIENT')}
                  className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                    equipFilterMode === 'CLIENT'
                      ? 'bg-cyan-950/40 text-cyan-400 border border-cyan-500/25 shadow-[0_0_10px_rgba(6,182,212,0.1)]'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Do Cliente Selecionado
                </button>
                <button
                  type="button"
                  id="btn-equip-filter-all"
                  onClick={() => setEquipFilterMode('ALL')}
                  className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                    equipFilterMode === 'ALL'
                      ? 'bg-cyan-950/40 text-cyan-400 border border-cyan-500/25 shadow-[0_0_10px_rgba(6,182,212,0.1)]'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Modelos de Máquinas ({uniqueMachineTemplates.length})
                </button>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4" />
                <input
                  id="search-equip-input"
                  type="text"
                  placeholder={equipFilterMode === 'CLIENT' ? "Buscar na máquina deste cliente..." : "Buscar tipo ou modelo de máquina..."}
                  value={equipSearch}
                  onChange={(e) => setEquipSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="max-h-64 overflow-y-auto divide-y divide-slate-900 border border-slate-800 rounded-xl bg-[#0c0d10]" id="equip-list-scroll">
                {equipFilterMode === 'CLIENT' ? (
                  filteredEquipsForSelection.length === 0 ? (
                    <div className="py-8 text-center text-slate-500 space-y-1">
                      <p className="text-xs">Nenhum equipamento cadastrado para este cliente.</p>
                      <button 
                        type="button"
                        onClick={() => setEquipFilterMode('ALL')}
                        className="text-[10px] text-cyan-400 hover:underline font-bold uppercase tracking-wider block mx-auto mt-2 cursor-pointer"
                      >
                        Ver Modelos de Máquinas Comuns ({uniqueMachineTemplates.length})
                      </button>
                      <button 
                        type="button"
                        onClick={() => setEquipMode('CREATE')}
                        className="text-[10px] text-cyan-400 hover:underline font-bold uppercase tracking-wider block mx-auto mt-1 cursor-pointer"
                      >
                        Cadastrar uma Nova Máquina Agora
                      </button>
                    </div>
                  ) : (
                    filteredEquipsForSelection.map((e) => {
                      return (
                        <div
                          id={`equip-card-item-${e.id}`}
                          key={e.id}
                          onClick={() => handleEquipSelect(e)}
                          className={`p-3.5 flex items-center justify-between gap-4 cursor-pointer transition-colors ${
                            selectedEquipId === e.id 
                              ? 'bg-cyan-950/20 text-cyan-300 border-l-4 border-cyan-500' 
                              : 'hover:bg-slate-900/10 text-slate-300'
                          }`}
                        >
                          <div className="space-y-1 overflow-hidden">
                            <p className="font-bold text-xs truncate">{e.name}</p>
                            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-slate-500 font-mono">
                              <span className="flex items-center gap-1"><Tag className="w-2.5 h-2.5 text-slate-400" />{e.model}</span>
                              <span className="flex items-center gap-1"><Layers className="w-2.5 h-2.5 text-slate-400" />{e.type}</span>
                            </div>
                          </div>
                          <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                            selectedEquipId === e.id ? 'border-cyan-500 bg-cyan-950/50' : 'border-slate-800'
                          }`}>
                            {selectedEquipId === e.id && <Check className="w-3.5 h-3.5 text-cyan-400 font-black" />}
                          </div>
                        </div>
                      );
                    })
                  )
                ) : (
                  // DISPLAY GENERIC MACHINE TYPES & MODELS
                  filteredTemplates.length === 0 ? (
                    <div className="py-8 text-center text-slate-500 space-y-1">
                      <p className="text-xs">Nenhum modelo ou tipo de máquina encontrado.</p>
                      <button 
                        type="button"
                        onClick={() => setEquipMode('CREATE')}
                        className="text-[10px] text-cyan-400 hover:underline font-bold uppercase tracking-wider block mx-auto mt-1 cursor-pointer"
                      >
                        Cadastrar Máquina Manualmente
                      </button>
                    </div>
                  ) : (
                    filteredTemplates.map((t, idx) => (
                      <div
                        id={`equip-template-item-${idx}`}
                        key={idx}
                        onClick={() => handleSelectTemplate(t)}
                        className="p-3.5 flex items-center justify-between gap-4 cursor-pointer transition-colors hover:bg-slate-900/10 text-slate-300 group"
                      >
                        <div className="space-y-1 overflow-hidden">
                          <p className="font-bold text-xs truncate text-cyan-400 group-hover:text-cyan-300">{t.name}</p>
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-slate-500 font-mono">
                            <span className="flex items-center gap-1"><Tag className="w-2.5 h-2.5 text-slate-400" />Modelo: {t.model}</span>
                            <span className="flex items-center gap-1"><Layers className="w-2.5 h-2.5 text-slate-400" />Tipo: {t.type}</span>
                          </div>
                        </div>
                        <div className="px-2.5 py-1 bg-cyan-950/40 border border-cyan-500/20 text-cyan-400 text-[9px] font-black uppercase tracking-wider rounded-md shrink-0 group-hover:bg-cyan-500 group-hover:text-black group-hover:border-cyan-400 transition-all">
                          Usar Modelo
                        </div>
                      </div>
                    ))
                  )
                )}
              </div>
            </div>
          )}

          {/* VIEW B: CREATE NEW EQUIPMENT */}
          {equipMode === 'CREATE' && (
            <div className="space-y-4 border border-slate-800/60 p-4 rounded-2xl bg-[#0c0d10]" id="equip-create-view">
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 text-cyan-400">
                  <Sparkles className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-wider">Novo Cadastro de Ativo Expresso</span>
                </div>
                {uniqueMachineTemplates.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setEquipMode('SELECT')}
                    className="text-[9px] text-slate-500 hover:text-slate-300 font-bold uppercase tracking-wider cursor-pointer"
                  >
                    Ver Modelos Frequentes
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Nome da Máquina / Equipamento *</label>
                  <input
                    id="new-equip-name"
                    type="text"
                    required
                    placeholder="Ex: Bloco de Distribuição Parker"
                    value={newEquipName}
                    onChange={(e) => setNewEquipName(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#11131c] border border-slate-800 rounded-lg text-xs text-white placeholder-slate-700 focus:outline-hidden focus:border-cyan-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Modelo / Número de Série *</label>
                  <input
                    id="new-equip-model"
                    type="text"
                    required
                    placeholder="Ex: MOD-HID-4099-X"
                    value={newEquipModel}
                    onChange={(e) => setNewEquipModel(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#11131c] border border-slate-800 rounded-lg text-xs text-white placeholder-slate-700 focus:outline-hidden focus:border-cyan-500 font-mono"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tipo / Divisão de Serviço</label>
                  <select
                    id="new-equip-type"
                    value={newEquipType}
                    onChange={(e) => setNewEquipType(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#11131c] border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Hidráulico">Sistemas Hidráulicos</option>
                    <option value="Pneumático">Sistemas Pneumáticos</option>
                    <option value="Cilindro Hidráulico">Cilindros e Hastes</option>
                    <option value="Cilindro Pneumático">Cilindros de Ar</option>
                    <option value="Válvula Reguladora">Válvulas e Servo</option>
                    <option value="Bomba Rotativa">Bombas Hidráulicas</option>
                    <option value="Unidade Hidráulica">Unidades de Força</option>
                    <option value="Outros">Outros Dispositivos</option>
                  </select>
                </div>
              </div>

              {/* QUICK SUGGESTIONS FROM FREQUENT TYPES & MODELS */}
              {uniqueMachineTemplates.length > 0 && (
                <div className="mt-3 pt-3 border-t border-slate-800/40">
                  <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-2">Modelos & Tipos Cadastrados (Preencher rápido):</span>
                  <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                    {uniqueMachineTemplates.slice(0, 8).map((template, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setNewEquipName(template.name);
                          setNewEquipModel(template.model);
                          setNewEquipType(template.type);
                          showFeedback(`Dados do modelo "${template.name}" inseridos!`, 'success');
                        }}
                        className="px-2.5 py-1.5 bg-[#11131c] hover:bg-slate-900 border border-slate-800 rounded-lg text-[10px] text-slate-300 font-medium transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <Layers className="w-3 h-3 text-cyan-400 shrink-0" />
                        <span className="font-bold">{template.name}</span>
                        <span className="text-[9px] text-slate-500">({template.model})</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              id="btn-step-2-back"
              onClick={() => setStep(1)}
              className="px-4.5 py-3 bg-[#0c0d10] border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar</span>
            </button>
            <button
              type="button"
              id="btn-step-2-next"
              onClick={handleNextToStep3}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-cyan-950/35 flex items-center gap-1.5 cursor-pointer"
            >
              <span>Avançar Diagnóstico</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: PHOTO, PROBLEM DESCRIPTION & FINALIZE */}
      {step === 3 && (
        <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl p-6 shadow-sm space-y-6" id="mobile-step-3">
          <div className="flex items-center justify-between border-b border-slate-800/50 pb-3">
            <h3 className="font-bold text-slate-100 text-sm uppercase tracking-wider flex items-center gap-2">
              <ClipboardList className="w-4 h-4 text-cyan-400" />
              <span>Passo 3: Entrada & Problema Apresentado</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-extrabold bg-[#0c0d10] px-2.5 py-1 rounded-lg border border-slate-800">Check-in</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Left Col: Photo Area */}
            <div className="space-y-4">
              <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Foto de Entrada do Equipamento</span>
              
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                capture="environment" // Forces native camera on mobile/tablet
                className="hidden"
                id="camera-capture-input"
              />

              {photo ? (
                <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-[#0c0d10] group aspect-video flex items-center justify-center max-h-56">
                  <img 
                    src={photo} 
                    alt="Equipamento" 
                    className="object-contain w-full h-full max-h-56"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-[#000000]/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      onClick={handlePhotoClick}
                      className="p-3 bg-cyan-950/80 text-cyan-400 rounded-full border border-cyan-500/30 hover:bg-cyan-900 transition-all cursor-pointer flex items-center gap-2 text-xs font-bold uppercase tracking-wider"
                    >
                      <Camera className="w-4 h-4" />
                      <span>Refazer Foto</span>
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPhoto('')}
                    className="absolute top-2 right-2 p-1.5 bg-red-950/80 hover:bg-red-900 border border-red-500/30 rounded-xl text-red-400 transition-colors cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  id="btn-photo-capture"
                  onClick={handlePhotoClick}
                  className="w-full aspect-video max-h-56 rounded-2xl border border-dashed border-slate-800 hover:border-cyan-500/50 bg-[#0c0d10] flex flex-col items-center justify-center text-slate-400 hover:text-cyan-400 transition-all cursor-pointer space-y-2.5 p-4"
                >
                  <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-full text-slate-500 group-hover:text-cyan-400 transition-colors">
                    <Camera className="w-6 h-6" />
                  </div>
                  <div className="text-center">
                    <span className="text-xs font-bold block">Tirar Foto ou Carregar Arquivo</span>
                    <span className="text-[10px] text-slate-600 block mt-0.5">Captura direta pela câmera do celular/tablet</span>
                  </div>
                </button>
              )}

              {/* Preset Selects for Quick testing without uploading */}
              <div className="space-y-1.5">
                <span className="block text-[8px] font-black uppercase tracking-wider text-slate-500">Ou use fotos de demonstração rápida:</span>
                <div className="grid grid-cols-4 gap-1.5" id="presets-container">
                  {PRESET_PHOTOS.map((preset) => (
                    <button
                      type="button"
                      key={preset.id}
                      onClick={() => selectPresetPhoto(preset.url)}
                      className={`p-1 bg-[#0c0d10] border rounded-lg overflow-hidden flex flex-col items-center gap-1 cursor-pointer transition-all ${
                        photo === preset.url ? 'border-cyan-500 scale-95 shadow-md shadow-cyan-950/20' : 'border-slate-800 hover:border-slate-700'
                      }`}
                      title={preset.name}
                    >
                      <img src={preset.url} alt={preset.name} className="w-full h-8 object-cover rounded-md" referrerPolicy="no-referrer" />
                      <span className="text-[7px] text-slate-500 truncate w-full text-center">{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Col: Issue description & Cost */}
            <div className="space-y-4">
              
              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Título Resumido do Serviço *</label>
                <input
                  id="mobile-os-title"
                  type="text"
                  required
                  placeholder="Ex: Brunimento de Cilindro / Substituição de Anel"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-white placeholder-slate-700 focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">Descrição Detalhada do Problema / Sintomas *</label>
                <textarea
                  id="mobile-os-description"
                  required
                  rows={4}
                  placeholder="Descreva exatamente o que o cliente relatou (Ex: Vazamento sob pressão elevada, barulho excessivo no curso, cilindro travando no retorno, etc.)"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold placeholder-slate-500 focus:border-blue-600 focus:outline-none leading-relaxed font-mono"
                />

                {diagnostics && diagnostics.length > 0 && (
                  <div className="mt-2 p-2.5 bg-[#06070a] border border-slate-900 rounded-xl">
                    <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                      Usar Modelo de Diagnóstico Cadastrado:
                    </span>
                    <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                      {diagnostics.map((diag) => (
                        <button
                          key={diag.id}
                          type="button"
                          onClick={() => {
                            if (!description || description.trim() === '' || description === 'N/A') {
                              setDescription(diag.description);
                            } else {
                              setDescription(prev => `${prev}\n\n${diag.description}`);
                            }
                            if (!title || title.trim() === '') {
                              setTitle(diag.title);
                            }
                          }}
                          className="px-2 py-1 bg-[#11131c] hover:bg-cyan-950/40 hover:text-cyan-300 border border-slate-800 hover:border-cyan-500/30 text-[10px] text-slate-300 rounded-lg font-medium transition-all text-left flex items-center gap-1.5 cursor-pointer"
                        >
                          <ClipboardList className="w-3 h-3 text-cyan-500 shrink-0" />
                          <span className="truncate max-w-[150px]">{diag.title}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Priority Cards (Huge Touch Friendly selection) */}
              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Prioridade do Atendimento</label>
                <div className="grid grid-cols-3 gap-2.5" id="priority-selector">
                  <button
                    type="button"
                    onClick={() => setPriority('LOW')}
                    className={`py-2 px-3 rounded-xl text-[10px] font-bold uppercase transition-all border cursor-pointer text-center ${
                      priority === 'LOW'
                        ? 'bg-blue-950/30 border-blue-500/50 text-blue-400 font-extrabold shadow-sm'
                        : 'bg-[#0c0d10] border-slate-800 text-slate-500'
                    }`}
                  >
                    Baixa
                  </button>
                  <button
                    type="button"
                    onClick={() => setPriority('MEDIUM')}
                    className={`py-2 px-3 rounded-xl text-[10px] font-bold uppercase transition-all border cursor-pointer text-center ${
                      priority === 'MEDIUM'
                        ? 'bg-amber-950/30 border-amber-500/50 text-amber-400 font-extrabold shadow-sm'
                        : 'bg-[#0c0d10] border-slate-800 text-slate-500'
                    }`}
                  >
                    Média
                  </button>
                  <button
                    type="button"
                    onClick={() => setPriority('HIGH')}
                    className={`py-2 px-3 rounded-xl text-[10px] font-bold uppercase transition-all border cursor-pointer text-center ${
                      priority === 'HIGH'
                        ? 'bg-red-950/30 border-red-500/50 text-red-400 font-extrabold shadow-sm animate-pulse'
                        : 'bg-[#0c0d10] border-slate-800 text-slate-500'
                    }`}
                  >
                    Crítica
                  </button>
                </div>
              </div>

              {/* Order Type Selector (Touch Friendly segmented control) */}
              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tipo de Ordem de Serviço *</label>
                <div className="grid grid-cols-2 gap-2.5" id="mobile-order-type-selector">
                  <button
                    type="button"
                    onClick={() => setOrderType('SERVICE')}
                    className={`py-3 px-4 rounded-xl text-[11px] font-black uppercase transition-all border cursor-pointer text-center ${
                      orderType === 'SERVICE'
                        ? 'bg-cyan-950/30 border-cyan-500/50 text-cyan-400 font-black shadow-sm'
                        : 'bg-[#0c0d10] border-slate-800 text-slate-500'
                    }`}
                  >
                    Serviço Padrão
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderType('WARRANTY')}
                    className={`py-3 px-4 rounded-xl text-[11px] font-black uppercase transition-all border cursor-pointer text-center ${
                      orderType === 'WARRANTY'
                        ? 'bg-amber-950/30 border-amber-500/50 text-amber-400 font-black shadow-sm'
                        : 'bg-[#0c0d10] border-slate-800 text-slate-500'
                    }`}
                  >
                    Garantia Assistência
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Data de Entrada *</label>
                <input
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-cyan-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Técnico de Entrada</label>
                  <select
                    id="mobile-os-technician"
                    value={technician}
                    onChange={(e) => setTechnician(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-slate-300 focus:outline-hidden focus:border-cyan-500"
                  >
                    {technicians.filter(t => t.status === 'ACTIVE').map(t => (
                      <option key={t.id} value={t.name}>{t.name} - {t.specialty}</option>
                    ))}
                    {technician && !technicians.some(t => t.name === technician && t.status === 'ACTIVE') && (
                      <option value={technician}>{technician} (Atual)</option>
                    )}
                    {technicians.length === 0 && (
                      <>
                        <option value="João Carlos">João Carlos</option>
                        <option value="Felipe">Felipe</option>
                        <option value="Suporte Técnico">Suporte Técnico</option>
                        <option value="Terceirizado">Terceirizado</option>
                      </>
                    )}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Estimativa de Orçamento (R$)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-xs">R$</span>
                    <input
                      id="mobile-os-cost"
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="Ex: 1500,00 (0 para definir depois)"
                      value={estimatedCost || ''}
                      onChange={(e) => setEstimatedCost(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full pl-8 pr-3 py-2.5 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-hidden focus:border-cyan-500"
                    />
                  </div>
                </div>
              </div>

            </div>

          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800/50">
            <button
              type="button"
              id="btn-step-3-back"
              onClick={() => setStep(2)}
              className="px-4.5 py-3 bg-[#0c0d10] border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar</span>
            </button>
            <button
              type="button"
              id="btn-confirm-and-submit"
              onClick={handleSubmitOrder}
              className="px-7 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-emerald-950/35 flex items-center gap-2 cursor-pointer border border-emerald-500/20"
            >
              <CheckCircle2 className="w-4.5 h-4.5 text-emerald-300" />
              <span>Salvar Check-in & Criar OS</span>
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: SUCCESS SUMMARY & SHARE BUDGET OPTIONS */}
      {step === 4 && createdOrder && createdClient && createdEquip && (
        <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl p-6 shadow-sm space-y-6 animate-in fade-in zoom-in-95 duration-200" id="mobile-success-view">
          
          {/* Animated Success Checkmark Ring */}
          <div className="flex flex-col items-center justify-center text-center py-6">
            <div className="w-16 h-16 bg-emerald-950/45 border-2 border-emerald-500 rounded-full flex items-center justify-center text-emerald-400 shadow-md shadow-emerald-500/10 mb-4 animate-bounce">
              <Check className="w-8 h-8 font-black stroke-[3]" />
            </div>
            
            {/* Highly Prominent OS CRIADA COM SUCESSO Display Banner */}
            <div className="w-full max-w-md bg-emerald-500/10 border border-emerald-500/30 rounded-2xl py-3.5 px-4 mb-4 shadow-inner">
              <h2 className="text-xl font-black text-emerald-400 font-mono tracking-widest animate-pulse">
                OS CRIADA COM SUCESSO
              </h2>
            </div>

            <h3 className="font-extrabold text-slate-100 text-sm uppercase tracking-wider">Ordem de Serviço Registrada!</h3>
            <span className="font-mono text-cyan-400 font-extrabold text-xs uppercase tracking-wider bg-slate-900 border border-slate-850 px-3 py-1 rounded-full mt-2">
              Número Gerado: {createdOrder.osNumber}
            </span>
          </div>

          {/* Quick Details Recibo Card */}
          <div className="p-5 bg-[#0c0d10] border border-slate-850 rounded-2xl space-y-4 max-w-lg mx-auto" id="created-os-receipt-summary">
            <div className="flex items-center justify-between border-b border-slate-900 pb-2">
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">Ficha de Entrada</span>
              <span className="text-[9px] font-mono text-slate-500 font-bold">{new Date().toLocaleDateString('pt-BR')}</span>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="space-y-1">
                <span className="block text-[8px] uppercase tracking-wider font-bold text-slate-500">Cliente</span>
                <p className="font-bold text-slate-200">{createdClient.name}</p>
                <p className="text-[10px] text-slate-400 font-mono">{createdClient.phone}</p>
              </div>

              <div className="space-y-1">
                <span className="block text-[8px] uppercase tracking-wider font-bold text-slate-500">Equipamento</span>
                <p className="font-bold text-slate-200">{createdEquip.name}</p>
                <p className="text-[10px] text-slate-400 font-mono">Série: {createdEquip.model}</p>
              </div>
            </div>

            <div className="border-t border-slate-900 pt-3 space-y-2">
              <span className="block text-[8px] uppercase tracking-wider font-bold text-slate-500">Problema Informado</span>
              <p className="text-[11px] font-mono leading-relaxed text-slate-300 italic bg-[#11131c]/50 p-2.5 rounded-lg border border-slate-900">
                "{createdOrder.description}"
              </p>
            </div>

            <div className="border-t border-slate-900 pt-3 flex items-center justify-between text-xs">
              <div>
                <span className="block text-[8px] uppercase tracking-wider font-bold text-slate-500">Técnico Responsável</span>
                <p className="font-bold text-slate-300">{createdOrder.technician}</p>
              </div>
              <div className="text-right">
                <span className="block text-[8px] uppercase tracking-wider font-bold text-slate-500">Estimativa do Orçamento</span>
                <p className="font-mono font-bold text-emerald-400">
                  {createdOrder.estimatedCost > 0 
                    ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(createdOrder.estimatedCost)
                    : 'A Definir'
                  }
                </p>
              </div>
            </div>
          </div>

          {/* INTERACTIVE BUDGET & DIAGNOSTIC FORM PANEL */}
          <div className="max-w-lg mx-auto bg-[#0c0d10] border border-slate-850 p-5 rounded-2xl space-y-4" id="budget-drafting-panel">
            <div className="flex items-center gap-2 border-b border-slate-900 pb-3">
              <FileText className="w-4 h-4 text-cyan-400" />
              <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider">Laudo Técnico & Orçamento do Ativo</h4>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">
                  Descrição do Diagnóstico / Laudo Técnico *
                </label>
                <textarea
                  id="budget-diagnostic-input"
                  rows={3}
                  placeholder="Ex: Desgaste severo do jogo de gaxetas e anéis guia. Haste com riscos profundos necessitando polimento..."
                  value={budgetDiagnostic}
                  onChange={(e) => setBudgetDiagnostic(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold placeholder-slate-500 focus:border-blue-600 focus:outline-none font-mono"
                />

                {diagnostics && diagnostics.length > 0 && (
                  <div className="mt-2 p-2.5 bg-[#06070a] border border-slate-900 rounded-xl">
                    <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                      Preencher Laudo com Diagnóstico Cadastrado:
                    </span>
                    <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                      {diagnostics.map((diag) => (
                        <button
                          key={diag.id}
                          type="button"
                          onClick={() => {
                            if (!budgetDiagnostic || budgetDiagnostic.trim() === '') {
                              setBudgetDiagnostic(diag.description);
                            } else {
                              setBudgetDiagnostic(prev => `${prev}\n\n${diag.description}`);
                            }
                          }}
                          className="px-2 py-1 bg-[#11131c] hover:bg-cyan-950/40 hover:text-cyan-300 border border-slate-800 hover:border-cyan-500/30 text-[10px] text-slate-300 rounded-lg font-medium transition-all text-left flex items-center gap-1.5 cursor-pointer"
                        >
                          <ClipboardList className="w-3 h-3 text-cyan-500 shrink-0" />
                          <span className="truncate max-w-[150px]">{diag.title}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">
                  O que será efetuado no Equipamento (Serviços e Peças) *
                </label>
                <textarea
                  id="budget-services-input"
                  rows={3}
                  placeholder="Ex: Brunimento químico de camisa de cilindro, substituição de vedação em poliuretano, polimento de haste..."
                  value={budgetServices}
                  onChange={(e) => setBudgetServices(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold placeholder-slate-500 focus:border-blue-600 focus:outline-none font-mono"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Valor Final do Orçamento (R$)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-xs">R$</span>
                    <input
                      id="budget-cost-input"
                      type="number"
                      step="0.01"
                      min="0"
                      value={budgetCost || ''}
                      onChange={(e) => setBudgetCost(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full pl-8 pr-3 py-2 bg-[#11131c] border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-hidden focus:border-cyan-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5 flex items-end">
                  <button
                    type="button"
                    onClick={handleUpdateBudgetDetails}
                    className="w-full py-2 px-3 bg-cyan-950/40 hover:bg-cyan-900/40 text-cyan-400 border border-cyan-500/30 hover:border-cyan-500/50 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    id="btn-save-budget-details"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Salvar Dados</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* SHARE OPTIONS: WHATSAPP OR EMAIL */}
          <div className="max-w-lg mx-auto bg-[#0c0d10] border border-slate-850 p-5 rounded-2xl space-y-4" id="budget-sharing-panel">
            <div className="flex items-center gap-2 border-b border-slate-900 pb-3">
              <Share2 className="w-4 h-4 text-emerald-400" />
              <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider">Enviar Orçamento Técnico ao Cliente</h4>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2.5">
                {/* WhatsApp button */}
                <button
                  type="button"
                  onClick={() => {
                    const currencyFormatter = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
                    const formattedCost = budgetCost > 0 ? currencyFormatter.format(budgetCost) : 'A calcular';
                    const message = `🛠️ *ORÇAMENTO TÉCNICO - JC&F MANUTENÇÃO*\n--------------------------------------------\nOlá, *${createdClient.name}*!\n\nApresentamos o laudo técnico e orçamento para o reparo do seu equipamento sob a *OS ${createdOrder.osNumber}*:\n\n⚙️ *Equipamento:* ${createdEquip.name} (${createdEquip.model})\n\n🔍 *DIAGNÓSTICO TÉCNICO:*\n_${budgetDiagnostic || 'Análise técnica preliminar concluída.'}_\n\n📋 *SERVIÇOS & PEÇAS A EXECUTAR:*\n_${budgetServices || 'Manutenção e troca de componentes conforme avaliação.'}_\n\n💰 *VALOR TOTAL DO ORÇAMENTO:*\n*${formattedCost}*\n\n⚠️ *AGUARDANDO SUA APROVAÇÃO:*\nPara darmos início aos procedimentos de manutenção, por favor responda a esta mensagem autorizando os serviços descritos acima.\n\nEstamos à disposição para tirar qualquer dúvida!\nObrigado!`;

                    setShareModalConfig({
                      isOpen: true,
                      title: 'Compartilhar Diagnóstico & Orçamento',
                      subtitle: `OS ${createdOrder.osNumber} • ${createdEquip.name}`,
                      docType: 'ORCAMENTO',
                      clientName: createdClient.name,
                      clientPhone: createdClient.phone,
                      clientEmail: clientEmail,
                      defaultChannel: 'WHATSAPP',
                      defaultMessage: message,
                      subject: `Orçamento de Manutenção JC&F - OS ${createdOrder.osNumber}`,
                    });
                  }}
                  className="py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-950/25 cursor-pointer"
                  id="btn-whatsapp-send-laudo"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>WhatsApp</span>
                </button>

                {/* Email button */}
                <button
                  type="button"
                  onClick={() => {
                    const currencyFormatter = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
                    const formattedCost = budgetCost > 0 ? currencyFormatter.format(budgetCost) : 'A calcular';
                    const message = `Prezado(a) ${createdClient.name},\n\nApresentamos o orçamento técnico e proposta de reparos para o seu equipamento:\n\nOrçamento Técnico - OS ${createdOrder.osNumber}\nEquipamento: ${createdEquip.name}\nModelo/Série: ${createdEquip.model}\n\n1. DIAGNÓSTICO / PROBLEMA CONSTATADO:\n${budgetDiagnostic || 'Análise técnica preliminar concluída.'}\n\n2. PROCEDIMENTOS & PEÇAS A SEREM EXECUTADOS:\n${budgetServices || 'Manutenção e troca de consumíveis.'}\n\n3. VALOR TOTAL DO ORÇAMENTO:\n${formattedCost}\n\nPor favor, responda a este e-mail aprovando ou rejeitando a continuidade dos serviços de manutenção.\n\nCaso tenha dúvidas, estamos à inteira disposição.\n\nAtenciosamente,\nEquipe Técnica JC&F\nManutenção Hidráulica e Pneumática`;

                    setShareModalConfig({
                      isOpen: true,
                      title: 'Compartilhar Diagnóstico & Orçamento',
                      subtitle: `OS ${createdOrder.osNumber} • ${createdEquip.name}`,
                      docType: 'ORCAMENTO',
                      clientName: createdClient.name,
                      clientPhone: createdClient.phone,
                      clientEmail: clientEmail,
                      defaultChannel: 'EMAIL',
                      defaultMessage: message,
                      subject: `Orçamento de Manutenção JC&F - OS ${createdOrder.osNumber}`,
                    });
                  }}
                  className="py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-md shadow-blue-950/25 cursor-pointer"
                  id="btn-email-send-laudo"
                >
                  <Mail className="w-4 h-4" />
                  <span>E-mail</span>
                </button>
              </div>
            </div>
          </div>

          {/* BUDGET APPROVAL DECISION STATE COUNTER */}
          <div className="max-w-lg mx-auto bg-[#0c0d10] border border-slate-850 p-5 rounded-2xl space-y-4" id="budget-decision-workflow-panel">
            <div className="flex items-center gap-2 border-b border-slate-900 pb-3">
              <Clock className="w-4 h-4 text-amber-400" />
              <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider">Aprovação & Continuidade dos Serviços</h4>
            </div>

            <div className="space-y-4">
              {/* Display current state with badge */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#11131c]/60 p-3.5 border border-slate-850 rounded-xl">
                <div>
                  <span className="block text-[8px] uppercase tracking-wider font-bold text-slate-500 mb-1">Status Atual do Orçamento</span>
                  <div className="flex items-center gap-2">
                    {budgetStatus === 'PENDING_APPROVAL' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-950/45 border border-amber-500/20 text-amber-400 rounded-full text-[10px] font-bold uppercase tracking-wider animate-pulse">
                        <Clock className="w-3 h-3 text-amber-400 animate-spin" />
                        Aguardando Resposta
                      </span>
                    )}
                    {budgetStatus === 'APPROVED' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-950/45 border border-emerald-500/20 text-emerald-400 rounded-full text-[10px] font-bold uppercase tracking-wider">
                        <Check className="w-3 h-3 text-emerald-400 font-black" />
                        Orçamento Aprovado
                      </span>
                    )}
                    {budgetStatus === 'REJECTED' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-950/45 border border-red-500/20 text-red-400 rounded-full text-[10px] font-bold uppercase tracking-wider">
                        <XCircle className="w-3 h-3 text-red-400" />
                        Orçamento Recusado
                      </span>
                    )}
                  </div>
                </div>

                <div className="text-left sm:text-right">
                  <span className="block text-[8px] uppercase tracking-wider font-bold text-slate-500 mb-1">Situação da Manutenção</span>
                  <p className="text-[11px] font-bold text-slate-300 font-mono">
                    {budgetStatus === 'PENDING_APPROVAL' && 'Aguardando aprovação do cliente.'}
                    {budgetStatus === 'APPROVED' && 'EM EXECUÇÃO (Serviços autorizados!)'}
                    {budgetStatus === 'REJECTED' && 'CANCELADA (Serviços recusados.)'}
                  </p>
                </div>
              </div>

              {/* Action Buttons to Decide */}
              <div className="space-y-2">
                <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider text-center">
                  Registrar Resposta Recebida do Cliente:
                </span>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => handleSetBudgetStatus('APPROVED')}
                    className={`py-3.5 px-4 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all border cursor-pointer flex items-center justify-center gap-2 ${
                      budgetStatus === 'APPROVED'
                        ? 'bg-emerald-600 border-emerald-500 text-white shadow-md shadow-emerald-950/20'
                        : 'bg-emerald-950/15 border-emerald-500/20 text-emerald-400 hover:bg-emerald-950/30'
                    }`}
                    id="btn-register-approved"
                  >
                    <Check className="w-4 h-4 font-black" />
                    <span>Aprovar Reparo</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSetBudgetStatus('REJECTED')}
                    className={`py-3.5 px-4 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all border cursor-pointer flex items-center justify-center gap-2 ${
                      budgetStatus === 'REJECTED'
                        ? 'bg-red-600 border-red-500 text-white shadow-md shadow-red-950/20'
                        : 'bg-red-950/15 border-red-500/20 text-red-400 hover:bg-red-950/30'
                    }`}
                    id="btn-register-rejected"
                  >
                    <XCircle className="w-4 h-4" />
                    <span>Reprovar Reparo</span>
                  </button>
                </div>

                {budgetStatus !== 'PENDING_APPROVAL' && (
                  <button
                    type="button"
                    onClick={() => handleSetBudgetStatus('PENDING_APPROVAL')}
                    className="w-full text-[9px] text-slate-500 hover:text-slate-300 font-bold uppercase tracking-wider text-center block mt-1 hover:underline cursor-pointer"
                    id="btn-reset-to-pending"
                  >
                    Reverter para Aguardando Aprovação
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* AUXILIARY ACTIONS (PRINT & COPY RECEIPT & RESET) */}
          <div className="max-w-lg mx-auto space-y-3" id="success-auxiliary-actions">
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={handlePrintReceipt}
                className="py-3 px-3.5 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-850 hover:border-slate-800 rounded-xl text-[11px] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                id="btn-print-receipt"
              >
                <Printer className="w-4 h-4 text-cyan-400" />
                <span>Imprimir Recibo de Entrada</span>
              </button>
              
              <button
                type="button"
                onClick={() => {
                  const url = getDetailedWhatsAppUrl();
                  // Extract raw message content
                  const messageText = decodeURIComponent(url.split('&text=')[1] || '');
                  navigator.clipboard.writeText(messageText);
                  showFeedback('Texto do orçamento copiado!', 'success');
                }}
                className="py-3 px-3.5 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-850 hover:border-slate-800 rounded-xl text-[11px] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                id="btn-copy-receipt-link"
              >
                <Share2 className="w-4 h-4 text-emerald-400" />
                <span>Copiar Orçamento</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleReset}
              className="w-full py-3.5 bg-slate-950 hover:bg-[#0c0d10] text-slate-400 hover:text-white border border-slate-850 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer mt-4"
              id="btn-reset-and-new"
            >
              <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin-slow" />
              <span>Abrir Novo Check-in de Equipamento</span>
            </button>

          </div>

        </div>
      )}

      {/* Share Contact Selection Modal */}
      {shareModalConfig && (
        <ShareContactModal
          isOpen={shareModalConfig.isOpen}
          onClose={() => setShareModalConfig(null)}
          title={shareModalConfig.title}
          subtitle={shareModalConfig.subtitle}
          docType={shareModalConfig.docType}
          clientName={shareModalConfig.clientName}
          clientPhone={shareModalConfig.clientPhone}
          clientEmail={shareModalConfig.clientEmail}
          defaultChannel={shareModalConfig.defaultChannel}
          defaultMessage={shareModalConfig.defaultMessage}
          subject={shareModalConfig.subject}
        />
      )}

    </div>
  );
}
