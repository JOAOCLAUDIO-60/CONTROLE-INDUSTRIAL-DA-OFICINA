import React, { useState } from 'react';
import { Technician } from '../types';
import { formatPhoneNumber } from '../utils/phoneFormatter';
import { 
  Users, Plus, Search, Edit2, Trash2, X, Check, Phone, Mail, Award, Shield, UserCheck, UserPlus
} from 'lucide-react';

interface TechnicianManagerProps {
  technicians: Technician[];
  receivers?: string[];
  onSaveReceivers?: (receivers: string[]) => void;
  onAddTechnician: (data: Omit<Technician, 'id' | 'createdAt'>) => void;
  onEditTechnician: (technician: Technician) => void;
  onDeleteTechnician: (id: string) => void;
}

export default function TechnicianManager({
  technicians,
  receivers = [],
  onSaveReceivers,
  onAddTechnician,
  onEditTechnician,
  onDeleteTechnician
}: TechnicianManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'ALL' | 'TECHS' | 'RECEIVERS'>('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTechnician, setEditingTechnician] = useState<Technician | null>(null);

  // Recebedores state
  const [newReceiverInput, setNewReceiverInput] = useState('');
  const [receiverSearch, setReceiverSearch] = useState('');
  const [receiverFeedback, setReceiverFeedback] = useState<string | null>(null);
  const [editingReceiverOriginal, setEditingReceiverOriginal] = useState<string | null>(null);
  const [editingReceiverInput, setEditingReceiverInput] = useState('');

  const handleAddReceiver = () => {
    const trimmed = newReceiverInput.trim();
    if (!trimmed) return;
    if (receivers.some(r => r.toLowerCase() === trimmed.toLowerCase())) {
      setReceiverFeedback('Este atendente já está cadastrado!');
      setTimeout(() => setReceiverFeedback(null), 3500);
      return;
    }
    const updated = [...receivers, trimmed];
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    setNewReceiverInput('');
    setReceiverFeedback(`Atendente "${trimmed}" cadastrado e salvo com sucesso!`);
    setTimeout(() => setReceiverFeedback(null), 3500);
  };

  const handleStartEditReceiver = (currentName: string) => {
    setEditingReceiverOriginal(currentName);
    setEditingReceiverInput(currentName);
  };

  const handleSaveEditReceiver = () => {
    if (!editingReceiverOriginal) return;
    const trimmed = editingReceiverInput.trim();
    if (!trimmed) {
      setReceiverFeedback('O nome do atendente não pode ficar vazio.');
      setTimeout(() => setReceiverFeedback(null), 3500);
      return;
    }
    if (
      trimmed.toLowerCase() !== editingReceiverOriginal.toLowerCase() &&
      receivers.some(r => r.toLowerCase() === trimmed.toLowerCase())
    ) {
      setReceiverFeedback('Já existe outro atendente com este nome!');
      setTimeout(() => setReceiverFeedback(null), 3500);
      return;
    }

    const updated = receivers.map(r => r === editingReceiverOriginal ? trimmed : r);
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    setEditingReceiverOriginal(null);
    setEditingReceiverInput('');
    setReceiverFeedback(`Atendente renomeado para "${trimmed}" com sucesso!`);
    setTimeout(() => setReceiverFeedback(null), 3500);
  };

  const handleDeleteReceiver = (nameToDelete: string) => {
    if (receivers.length <= 1) {
      setReceiverFeedback('É necessário manter pelo menos um atendente cadastrado.');
      setTimeout(() => setReceiverFeedback(null), 3500);
      return;
    }
    if (!window.confirm(`Tem certeza que deseja excluir o atendente "${nameToDelete}"?`)) {
      return;
    }
    const updated = receivers.filter(r => r !== nameToDelete);
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    setReceiverFeedback(`Atendente "${nameToDelete}" removido.`);
    setTimeout(() => setReceiverFeedback(null), 3500);
  };

  // Form State
  const [name, setName] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'ACTIVE' | 'INACTIVE'>('ACTIVE');
  const [formError, setFormError] = useState('');

  const handleOpenAddModal = () => {
    setEditingTechnician(null);
    setName('');
    setSpecialty('');
    setPhone('');
    setEmail('');
    setStatus('ACTIVE');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (tech: Technician) => {
    setEditingTechnician(tech);
    setName(tech.name);
    setSpecialty(tech.specialty);
    setPhone(formatPhoneNumber(tech.phone));
    setEmail(tech.email);
    setStatus(tech.status);
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('Por favor, preencha o nome do técnico.');
      return;
    }

    if (editingTechnician) {
      onEditTechnician({
        ...editingTechnician,
        name: name.trim(),
        specialty: specialty.trim() || 'Geral',
        phone: phone.trim(),
        email: email.trim(),
        status
      });
    } else {
      onAddTechnician({
        name: name.trim(),
        specialty: specialty.trim() || 'Geral',
        phone: phone.trim(),
        email: email.trim(),
        status
      });
    }

    setIsModalOpen(false);
  };

  // Search filtering across BOTH Technicians and Receivers
  const q = searchQuery.trim().toLowerCase();
  const rq = receiverSearch.trim().toLowerCase();

  const filtered = technicians.filter(t => 
    !q ||
    t.name.toLowerCase().includes(q) ||
    t.specialty.toLowerCase().includes(q) ||
    (t.email && t.email.toLowerCase().includes(q)) ||
    (t.phone && t.phone.includes(q))
  );

  const filteredReceivers = receivers.filter(r => {
    const matchesMain = !q || r.toLowerCase().includes(q);
    const matchesLocal = !rq || r.toLowerCase().includes(rq);
    return matchesMain && matchesLocal;
  });

  const totalTeamCount = technicians.length + receivers.length;

  return (
    <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="technician-manager-root">
      
      {/* Header Banner */}
      <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-blue-900" id="tech-header-banner">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-cyan-300" />
            <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider">Gestão de Equipe: Técnicos & Atendentes</h2>
          </div>
          <p className="text-xs text-cyan-100 max-w-xl">
            Cadastre e gerencie os técnicos especializados e atendentes da recepção/balcão de entrada.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              setActiveTab('RECEIVERS');
              const el = document.getElementById('new-receiver-input-field');
              if (el) el.focus();
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider rounded-lg transition-all shadow-md cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ NOVO ATENDENTE</span>
          </button>
          <button
            id="btn-add-technician"
            onClick={handleOpenAddModal}
            className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition-all shadow-md cursor-pointer"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>CADASTRAR TÉCNICO</span>
          </button>
        </div>
      </div>

      <div className="p-4 sm:p-6 bg-[#e9edf2] space-y-4">
        {/* Search & Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3" id="tech-search-and-stats">
          <div className="md:col-span-2 relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
              <Search className="w-4 h-4" />
            </span>
            <input
              id="tech-search-input"
              type="text"
              placeholder="Buscar por nome de técnico ou atendente..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-9 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 transition-all shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          
          <div className="bg-white border border-slate-300 rounded-xl px-4 py-2.5 flex items-center justify-between shadow-xs">
            <span className="text-[10px] text-slate-600 uppercase font-black tracking-wider">Técnicos Ativos</span>
            <span className="font-mono text-base font-black text-emerald-600">
              {technicians.filter(t => t.status === 'ACTIVE').length}
            </span>
          </div>

          <div className="bg-white border border-slate-300 rounded-xl px-4 py-2.5 flex items-center justify-between shadow-xs">
            <span className="text-[10px] text-slate-600 uppercase font-black tracking-wider">Atendentes Cadastrados</span>
            <span className="font-mono text-base font-black text-[#003b7a]">
              {receivers.length}
            </span>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1.5 border-b border-slate-300 pb-1">
          <button
            type="button"
            onClick={() => setActiveTab('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'ALL'
                ? 'bg-[#1b365d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            Todos ({totalTeamCount})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('TECHS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'TECHS'
                ? 'bg-[#1b365d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            Técnicos ({technicians.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('RECEIVERS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'RECEIVERS'
                ? 'bg-[#1b365d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            Atendentes & Balcão ({receivers.length})
          </button>
        </div>

        {/* Technicians Grid */}
        {(activeTab === 'ALL' || activeTab === 'TECHS') && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#1b365d]" />
                <span>Técnicos de Bancada ({filtered.length})</span>
              </h3>
            </div>

            {filtered.length === 0 ? (
              <div className="bg-white rounded-xl border border-dashed border-slate-300 p-8 text-center" id="tech-empty-state">
                <Users className="w-10 h-10 text-slate-400 mx-auto mb-3" />
                <p className="text-xs font-bold text-slate-700">Nenhum técnico encontrado</p>
                <p className="text-[11px] text-slate-500 mt-1">Experimente mudar o termo de busca ou cadastre novos profissionais no botão acima.</p>
              </div>
            ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="tech-grid-list">
            {filtered.map((tech) => (
              <div 
                id={`tech-card-${tech.id}`} 
                key={tech.id} 
                className={`bg-white rounded-xl border ${tech.status === 'ACTIVE' ? 'border-slate-300 hover:border-blue-600' : 'border-slate-300 opacity-80'} p-4 flex flex-col justify-between hover:shadow-md transition-all duration-200 relative`}
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#1b365d] border border-blue-900 flex items-center justify-center font-black text-white font-mono shrink-0 shadow-sm">
                        {tech.name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase()}
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-sm">{tech.name}</h4>
                        <span className="inline-flex items-center gap-1 text-[9px] font-black text-blue-800 uppercase tracking-wider bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-md mt-1">
                          <Award className="w-2.5 h-2.5 text-blue-600" />
                          {tech.specialty}
                        </span>
                      </div>
                    </div>
                    
                    <span className={`text-[8px] font-black tracking-widest px-2 py-0.5 rounded-full uppercase border ${
                      tech.status === 'ACTIVE' 
                        ? 'text-emerald-800 bg-emerald-100 border-emerald-300' 
                        : 'text-red-700 bg-red-100 border-red-300'
                    }`}>
                      {tech.status === 'ACTIVE' ? 'Ativo' : 'Inativo'}
                    </span>
                  </div>

                  <div className="space-y-1.5 pt-2 text-xs text-slate-600 border-t border-slate-200">
                    {tech.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-mono font-bold text-slate-800">{tech.phone}</span>
                      </div>
                    )}
                    {tech.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        <span className="truncate text-slate-700">{tech.email}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-1.5 mt-4 pt-3 border-t border-slate-100">
                  <button
                    id={`btn-edit-tech-${tech.id}`}
                    onClick={() => handleOpenEditModal(tech)}
                    className="p-1.5 hover:bg-blue-50 text-slate-500 hover:text-blue-700 rounded-lg transition-all cursor-pointer"
                    title="Editar dados"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    id={`btn-delete-tech-${tech.id}`}
                    onClick={() => onDeleteTechnician(tech.id)}
                    className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-all cursor-pointer"
                    title="Excluir técnico"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
          </div>
        )}

        {/* SEÇÃO: ATENDENTES E RECEBEDORES DO BALCÃO / CHECK-IN */}
        {(activeTab === 'ALL' || activeTab === 'RECEIVERS') && (
          <div className={`space-y-4 ${activeTab === 'ALL' ? 'mt-8 pt-6 border-t-2 border-slate-300' : ''}`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-[#1b365d]" />
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">
                    Atendentes & Recebedores (Entrada de Equipamentos / Balcão)
                  </h3>
                </div>
                <p className="text-xs text-slate-600">
                  Nomes cadastrados para seleção rápida no Check-in de entrada e criação de Ordens de Serviço. Salvo com persistência permanente no servidor central.
                </p>
              </div>
            </div>

            {/* Form para adicionar novo atendente */}
            <div className="bg-white border border-slate-300 rounded-xl p-4 shadow-sm">
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-2">
                Cadastrar Novo Atendente
              </label>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  id="new-receiver-input-field"
                  type="text"
                  placeholder="Nome do novo atendente/recebedor (ex: JOÃO CARLOS, Ana Paula)..."
                  value={newReceiverInput}
                  onChange={(e) => setNewReceiverInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddReceiver();
                    }
                  }}
                  className="flex-1 px-3 py-2.5 bg-slate-50 border-2 border-slate-300 rounded-lg text-xs font-bold text-slate-900 uppercase focus:bg-white focus:border-blue-600 focus:outline-hidden"
                />
                <button
                  type="button"
                  onClick={handleAddReceiver}
                  className="px-5 py-2.5 bg-[#1b365d] hover:bg-blue-900 text-white font-black text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar Atendente</span>
                </button>
              </div>
            </div>

            {/* Busca rápida se houver mais de 3 atendentes */}
            {receivers.length > 3 && (
              <div className="flex items-center justify-between gap-3">
                <div className="relative max-w-sm flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <Search className="w-3.5 h-3.5" />
                  </span>
                  <input
                    type="text"
                    placeholder="Filtrar na lista de atendentes..."
                    value={receiverSearch}
                    onChange={(e) => setReceiverSearch(e.target.value)}
                    className="w-full pl-9 pr-8 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600"
                  />
                  {receiverSearch && (
                    <button
                      type="button"
                      onClick={() => setReceiverSearch('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
                <span className="text-[11px] font-bold text-slate-500">
                  Mostrando {filteredReceivers.length} de {receivers.length}
                </span>
              </div>
            )}

            {/* Grid de Atendentes Cadastrados */}
            {filteredReceivers.length === 0 ? (
              <div className="bg-white rounded-xl border border-dashed border-slate-300 p-8 text-center">
                <UserCheck className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-700">Nenhum atendente encontrado.</p>
                {searchQuery || receiverSearch ? (
                  <p className="text-[11px] text-slate-500 mt-1">Verifique o termo digitado ou cadastre um novo atendente no campo acima.</p>
                ) : null}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {filteredReceivers.map((rec) => (
                  <div
                    key={rec}
                    className="bg-white border border-slate-300 rounded-lg p-3 flex items-center justify-between shadow-2xs hover:border-blue-400 transition-all"
                  >
                    <div className="flex items-center gap-2 overflow-hidden mr-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-cyan-600 shrink-0"></span>
                      <span className="text-xs font-black text-slate-800 uppercase truncate" title={rec}>
                        {rec}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleStartEditReceiver(rec)}
                        className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors cursor-pointer"
                        title={`Editar nome de ${rec}`}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteReceiver(rec)}
                        className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors cursor-pointer"
                        title={`Excluir ${rec}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modal: Editar Nome de Atendente */}
      {editingReceiverOriginal && (
        <div className="fixed inset-0 bg-[#000000]/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white border border-slate-300 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs font-black uppercase text-slate-800 tracking-wider">Editar Nome do Atendente</h4>
              </div>
              <button
                type="button"
                onClick={() => setEditingReceiverOriginal(null)}
                className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-600 uppercase">Nome do Atendente</label>
              <input
                type="text"
                value={editingReceiverInput}
                onChange={(e) => setEditingReceiverInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSaveEditReceiver();
                  }
                }}
                className="w-full px-3 py-2 bg-slate-50 border-2 border-slate-300 rounded-lg text-xs font-bold text-slate-900 uppercase focus:bg-white focus:border-blue-600 focus:outline-hidden"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingReceiverOriginal(null)}
                className="px-3.5 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveEditReceiver}
                className="px-4 py-1.5 bg-[#1b365d] hover:bg-blue-900 text-white text-xs font-black uppercase rounded-lg shadow-xs cursor-pointer"
              >
                Salvar Nome
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-[#000000]/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" id="tech-modal-overlay">
          <div className="bg-white border border-slate-300 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl relative" id="tech-modal-container">
            
            {/* Modal Header */}
            <div className="px-5 py-3.5 bg-[#1b365d] text-white border-b border-blue-900 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-cyan-300" />
                <h3 className="font-black text-sm text-white uppercase tracking-wider">
                  {editingTechnician ? 'Editar Técnico' : 'Cadastrar Novo Técnico'}
                </h3>
              </div>
              <button
                id="btn-close-tech-modal"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-cyan-200 hover:text-white rounded-lg transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-5 space-y-4 bg-slate-50">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-bold">
                  {formError}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Nome Completo *</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: João Carlos"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Especialidade / Cargo</label>
                <input
                  type="text"
                  placeholder="Ex: Hidráulica & Pneumática"
                  value={specialty}
                  onChange={(e) => setSpecialty(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Telefone de Contato</label>
                  <input
                    type="text"
                    placeholder="Ex: (21) 98369-9728"
                    value={phone}
                    onChange={(e) => setPhone(formatPhoneNumber(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold font-mono placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Email</label>
                  <input
                    type="email"
                    placeholder="Ex: joao@empresa.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                >
                  <option value="ACTIVE">Ativo (Disponível para OS)</option>
                  <option value="INACTIVE">Inativo</option>
                </select>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  id="btn-cancel-tech"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  id="btn-save-tech"
                  className="px-5 py-2.5 text-xs font-black uppercase tracking-wider text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-xl transition-all shadow-md cursor-pointer"
                >
                  {editingTechnician ? 'SALVAR ALTERAÇÕES' : 'CADASTRAR TÉCNICO'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
