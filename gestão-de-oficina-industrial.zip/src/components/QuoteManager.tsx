import React, { useState, useMemo, useEffect } from 'react';
import { Client, Equipment, Quote, QuoteItem, QuoteStatus, QuoteType, QuoteItemType, Technician, PlannedService, ServiceOrder, InventoryItem } from '../types';
import { JCF_COMPANY_INFO } from '../data/companyConfig';
import JCFCompanyLogo from './JCFCompanyLogo';
import QuotePrintDocument from './QuotePrintDocument';
import { QuoteWhatsAppModal, QuoteEmailModal } from './QuoteShareModals';
import QuickNewClientModal from './QuickNewClientModal';
import QuickNewServiceModal from './QuickNewServiceModal';
import QuickNewEquipmentModal from './QuickNewEquipmentModal';
import PriceTableModal, { SelectedQuoteItem } from './PriceTableModal';
import { generateQuotePDF } from '../utils/pdfGenerator';
import { 
  Plus, Search, Calendar, User, UserPlus, Cpu, FileText, Trash2, Edit2, Copy, 
  Check, X, DollarSign, Send, Eye, FileSpreadsheet, Printer, Download,
  TrendingUp, AlertCircle, FileCheck, RefreshCw, Layers, ShieldCheck, 
  Clock, Briefcase, Tag, MessageSquare, Mail, Package, Wrench, ChevronRight,
  SlidersHorizontal, Sparkles
} from 'lucide-react';

interface QuoteManagerProps {
  quotes: Quote[];
  clients: Client[];
  equipments: Equipment[];
  technicians: Technician[];
  services?: PlannedService[];
  inventory?: InventoryItem[];
  orders?: ServiceOrder[];
  onAddQuote: (quote: Quote) => void;
  onUpdateQuote: (quote: Quote) => void;
  onDeleteQuote: (id: string) => void;
  onAddOrder?: (order: ServiceOrder) => void;
  onAddClient?: (client: Omit<Client, 'id' | 'createdAt'>) => Client;
  onAddService?: (service: Omit<PlannedService, 'id' | 'createdAt'>) => PlannedService;
  onAddEquipment?: (equipment: Omit<Equipment, 'id' | 'createdAt'>) => Equipment;
  onNavigateTab?: (tab: any) => void;
}

export default function QuoteManager({
  quotes,
  clients,
  equipments,
  technicians,
  services = [],
  inventory = [],
  orders = [],
  onAddQuote,
  onUpdateQuote,
  onDeleteQuote,
  onAddOrder,
  onAddClient,
  onAddService,
  onAddEquipment,
  onNavigateTab
}: QuoteManagerProps) {
  // Navigation & Filtering
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<'ALL' | QuoteType>('ALL');
  const [activeStatusTab, setActiveStatusTab] = useState<'ALL' | 'DRAFT' | 'SENT' | 'ACCEPTED' | 'REJECTED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isNewClientModalOpen, setIsNewClientModalOpen] = useState(false);
  const [isNewServiceModalOpen, setIsNewServiceModalOpen] = useState(false);
  const [isNewEquipmentModalOpen, setIsNewEquipmentModalOpen] = useState(false);
  const [isPriceTableModalOpen, setIsPriceTableModalOpen] = useState(false);
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const showFeedback = (message: string, type: 'success' | 'error' | 'info' = 'success', duration = 3000) => {
    setFeedback({ message, type });
    setTimeout(() => setFeedback(null), duration);
  };
  const [currentQuote, setCurrentQuote] = useState<Quote | null>(null);
  const [activeActionQuote, setActiveActionQuote] = useState<Quote | null>(null);

  // Helper to insert items directly from Price Table Modal into current quote
  const handleInsertFromPriceTable = (selectedItems: SelectedQuoteItem[]) => {
    const formatted: QuoteItem[] = selectedItems.map(item => ({
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      type: item.type,
      description: item.description,
      quantity: item.quantity,
      unit: item.unit || 'UN',
      unitPrice: item.unitPrice,
      total: item.quantity * item.unitPrice
    }));
    setFormItems(prev => [...prev, ...formatted]);
  };

  // Form states
  const [formQuoteNumber, setFormQuoteNumber] = useState('');
  const [formQuoteType, setFormQuoteType] = useState<QuoteType>('MANUTENCAO_CORRETIVA');
  const [formClientId, setFormClientId] = useState('');
  const [formClientName, setFormClientName] = useState('');
  const [formClientDocument, setFormClientDocument] = useState('');
  const [formClientPhone, setFormClientPhone] = useState('');
  const [formClientEmail, setFormClientEmail] = useState('');
  const [formClientAddress, setFormClientAddress] = useState('');
  const [formEquipmentId, setFormEquipmentId] = useState('');
  const [formEquipmentName, setFormEquipmentName] = useState('');
  const [formDate, setFormDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [formValidUntil, setFormValidUntil] = useState(() => {
    const nextDate = new Date();
    nextDate.setDate(nextDate.getDate() + 30);
    return nextDate.toISOString().split('T')[0];
  });
  const [formStatus, setFormStatus] = useState<QuoteStatus>('DRAFT');
  const [formItems, setFormItems] = useState<QuoteItem[]>([]);
  const [formDiscount, setFormDiscount] = useState<number>(0);
  const [formPaymentTerms, setFormPaymentTerms] = useState('PIX à vista ou Faturado 30 dias');
  const [formDeliveryTime, setFormDeliveryTime] = useState('3 a 5 dias úteis');
  const [formWarrantyTerms, setFormWarrantyTerms] = useState('180 dias de garantia contra vazamentos e defeitos de montagem');
  const [formNotes, setFormNotes] = useState('Equipamento testado em bancada de alta pressão.');
  const [formTechnicianId, setFormTechnicianId] = useState('');

  // Item builder states
  const [itemType, setItemType] = useState<QuoteItemType>('SERVICO');
  const [itemDesc, setItemDesc] = useState('');
  const [itemQty, setItemQty] = useState<number>(1);
  const [itemUnit, setItemUnit] = useState('UN');
  const [itemPrice, setItemPrice] = useState<number>(0);
  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  // Memoized Alphabetically Sorted Lists (A-Z)
  const sortedClients = useMemo(() => {
    return [...clients].sort((a, b) => a.name.localeCompare(b.name, 'pt-BR', { sensitivity: 'base' }));
  }, [clients]);

  const sortedEquipments = useMemo(() => {
    return [...equipments].sort((a, b) => a.name.localeCompare(b.name, 'pt-BR', { sensitivity: 'base' }));
  }, [equipments]);

  const sortedServices = useMemo(() => {
    return [...services].sort((a, b) => a.name.localeCompare(b.name, 'pt-BR', { sensitivity: 'base' }));
  }, [services]);

  // Keyboard shortcut listener when Quote Modal is active
  useEffect(() => {
    if (!isModalOpen) return;
    const handleModalKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        e.stopPropagation();
        setIsNewClientModalOpen(true);
      } else if (e.key === 'F3') {
        e.preventDefault();
        e.stopPropagation();
        setIsNewServiceModalOpen(true);
      } else if (e.key === 'F4') {
        e.preventDefault();
        e.stopPropagation();
        setIsNewEquipmentModalOpen(true);
      } else if (e.key === 'F7') {
        e.preventDefault();
        e.stopPropagation();
        setIsPriceTableModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleModalKeyDown, true);
    return () => window.removeEventListener('keydown', handleModalKeyDown, true);
  }, [isModalOpen]);

  // Auto-increment quote number generator
  const generateNextQuoteNumber = () => {
    const year = new Date().getFullYear();
    const prefix = `ORC-${year}-`;
    const yearQuotes = quotes.filter(q => q.quoteNumber.startsWith(prefix));
    let nextNum = 1;
    if (yearQuotes.length > 0) {
      const numbers = yearQuotes.map(q => {
        const parts = q.quoteNumber.split('-');
        return parts.length >= 3 ? parseInt(parts[2], 10) : 0;
      });
      nextNum = Math.max(...numbers, 0) + 1;
    }
    return `${prefix}${String(nextNum).padStart(3, '0')}`;
  };

  // Quick Days Adder for Validity
  const handleSetValidityDays = (days: number) => {
    const date = new Date(formDate || new Date());
    date.setDate(date.getDate() + days);
    setFormValidUntil(date.toISOString().split('T')[0]);
  };

  // Open modal for new quote
  const handleOpenNewQuoteModal = (defaultType?: QuoteType) => {
    setCurrentQuote(null);
    setFormQuoteNumber(generateNextQuoteNumber());
    setFormQuoteType(defaultType || (selectedTypeFilter !== 'ALL' ? selectedTypeFilter : 'MANUTENCAO_CORRETIVA'));
    setFormClientId('');
    setFormClientName('');
    setFormClientDocument('');
    setFormClientPhone('');
    setFormClientEmail('');
    setFormClientAddress('');
    setFormEquipmentId('');
    setFormEquipmentName('');
    setFormDate(new Date().toISOString().split('T')[0]);
    const nextDate = new Date();
    nextDate.setDate(nextDate.getDate() + 30);
    setFormValidUntil(nextDate.toISOString().split('T')[0]);
    setFormStatus('DRAFT');
    setFormItems([]);
    setFormDiscount(0);
    setFormPaymentTerms('PIX à vista (5% desc.) ou Faturado 30 dias');
    setFormDeliveryTime('3 a 5 dias úteis');
    setFormWarrantyTerms('180 dias de garantia contra defeitos de montagem e vazamentos');
    setFormNotes('Equipamento testado e pressurizado em bancada hidráulica.');
    setFormTechnicianId('');
    setItemType('SERVICO');
    setItemDesc('');
    setItemQty(1);
    setItemUnit('UN');
    setItemPrice(0);
    setEditingItemId(null);
    setIsModalOpen(true);
  };

  // Open modal for editing quote
  const handleOpenEditQuoteModal = (quote: Quote) => {
    setCurrentQuote(quote);
    setFormQuoteNumber(quote.quoteNumber);
    setFormQuoteType(quote.quoteType || 'MANUTENCAO_CORRETIVA');
    setFormClientId(quote.clientId);
    setFormClientName(quote.clientName);
    setFormClientDocument(quote.clientDocument || '');
    setFormClientPhone(quote.clientPhone || '');
    setFormClientEmail(quote.clientEmail || '');
    setFormClientAddress(quote.clientAddress || '');
    setFormEquipmentId(quote.equipmentId || '');
    setFormEquipmentName(quote.equipmentName || '');
    setFormDate(quote.date);
    setFormValidUntil(quote.validUntil);
    setFormStatus(quote.status);
    setFormItems([...quote.items]);
    setFormDiscount(quote.discount);
    setFormPaymentTerms(quote.paymentTerms);
    setFormDeliveryTime(quote.deliveryTime);
    setFormWarrantyTerms(quote.warrantyTerms);
    setFormNotes(quote.notes || '');
    setFormTechnicianId(quote.technicianId || '');
    setItemType('SERVICO');
    setItemDesc('');
    setItemQty(1);
    setItemUnit('UN');
    setItemPrice(0);
    setEditingItemId(null);
    setIsModalOpen(true);
  };

  // Open modal for inspecting/previewing quote before sending
  const handleOpenPreviewModal = (quote: Quote) => {
    setActiveActionQuote(quote);
    setIsPreviewModalOpen(true);
  };

  // Delete quote with explicit confirmation
  const handleDeleteQuoteWithConfirm = (quote: Quote): boolean => {
    const confirmMsg = `Tem certeza que deseja EXCLUIR o orçamento ${quote.quoteNumber}?\n\n` +
      `• Cliente: ${quote.clientName}\n` +
      `• Equipamento: ${quote.equipmentName || 'Venda de Balcão'}\n` +
      `• Valor Total: R$ ${quote.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}\n\n` +
      `Esta ação é definitiva e removerá a proposta.`;
    
    if (window.confirm(confirmMsg)) {
      onDeleteQuote(quote.id);
      if (activeActionQuote?.id === quote.id) {
        setIsPreviewModalOpen(false);
        setIsPrintModalOpen(false);
        setActiveActionQuote(null);
      }
      if (currentQuote?.id === quote.id) {
        setIsModalOpen(false);
        setCurrentQuote(null);
      }
      return true;
    }
    return false;
  };

  // Client dropdown selection handler
  const handleClientSelect = (clientId: string) => {
    setFormClientId(clientId);
    const selected = clients.find(c => c.id === clientId);
    if (selected) {
      setFormClientName(selected.name);
      setFormClientDocument(selected.document || '');
      setFormClientPhone(selected.phone || '');
      setFormClientEmail(selected.email || '');
      setFormClientAddress(selected.address || '');
    }
  };

  // Equipment dropdown selection handler
  const handleEquipmentSelect = (equipmentId: string) => {
    setFormEquipmentId(equipmentId);
    const selected = equipments.find(e => e.id === equipmentId);
    if (selected) {
      setFormEquipmentName(`${selected.name} (${selected.model})`);
    } else {
      setFormEquipmentName('');
    }
  };

  // Add or Update Item in quote
  const handleAddItem = () => {
    if (!itemDesc.trim()) {
      alert('Por favor, informe a descrição da peça ou serviço.');
      return;
    }
    if (itemQty <= 0) {
      alert('A quantidade deve ser maior que zero.');
      return;
    }
    const cleanPrice = Math.max(0, itemPrice || 0);
    const total = itemQty * cleanPrice;

    if (editingItemId) {
      // Update existing item
      setFormItems(prev => prev.map(item => {
        if (item.id === editingItemId) {
          return {
            ...item,
            type: itemType,
            description: itemDesc.trim(),
            quantity: itemQty,
            unit: itemUnit.trim() || 'UN',
            unitPrice: cleanPrice,
            total: total
          };
        }
        return item;
      }));
      setEditingItemId(null);
    } else {
      // Add new item
      const newItem: QuoteItem = {
        id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        type: itemType,
        description: itemDesc.trim(),
        quantity: itemQty,
        unit: itemUnit.trim() || 'UN',
        unitPrice: cleanPrice,
        total: total
      };
      setFormItems(prev => [...prev, newItem]);
    }

    setItemDesc('');
    setItemQty(1);
    setItemUnit('UN');
    setItemPrice(0);
  };

  // Start editing a specific item in the quote
  const handleStartEditItem = (item: QuoteItem) => {
    setEditingItemId(item.id);
    setItemType(item.type || 'SERVICO');
    setItemDesc(item.description);
    setItemQty(item.quantity);
    setItemUnit(item.unit || 'UN');
    setItemPrice(item.unitPrice);
  };

  // Cancel editing the current item
  const handleCancelEditItem = () => {
    setEditingItemId(null);
    setItemDesc('');
    setItemQty(1);
    setItemUnit('UN');
    setItemPrice(0);
  };

  // Remove Item from quote
  const handleRemoveItem = (itemId: string) => {
    if (editingItemId === itemId) {
      handleCancelEditItem();
    }
    setFormItems(prev => prev.filter(i => i.id !== itemId));
  };

  // Calculations
  const calculatedSubtotal = useMemo(() => {
    return formItems.reduce((acc, item) => acc + item.total, 0);
  }, [formItems]);

  const calculatedTotal = useMemo(() => {
    return Math.max(0, calculatedSubtotal - (formDiscount || 0));
  }, [calculatedSubtotal, formDiscount]);

  // Form Submission
  const handleFormSubmit = (e: React.FormEvent, openPreview = false) => {
    e.preventDefault();
    if (!formClientName.trim()) {
      alert('Por favor, informe ou selecione o cliente.');
      return;
    }
    if (formItems.length === 0) {
      alert('Por favor, adicione pelo menos um item ou serviço ao orçamento.');
      return;
    }

    const tech = technicians.find(t => t.id === formTechnicianId);

    const quoteData: Quote = {
      id: currentQuote ? currentQuote.id : `orc-${Date.now()}`,
      quoteNumber: formQuoteNumber,
      quoteType: formQuoteType,
      clientId: formClientId || `cli-temp-${Date.now()}`,
      clientName: formClientName,
      clientDocument: formClientDocument,
      clientPhone: formClientPhone,
      clientEmail: formClientEmail,
      clientAddress: formClientAddress,
      equipmentId: formEquipmentId || undefined,
      equipmentName: formEquipmentName || (formQuoteType === 'VENDA' ? 'Venda de Balcão / Peças' : undefined),
      date: formDate,
      validUntil: formValidUntil,
      status: formStatus,
      items: formItems,
      subtotal: calculatedSubtotal,
      discount: formDiscount,
      total: calculatedTotal,
      paymentTerms: formPaymentTerms,
      deliveryTime: formDeliveryTime,
      warrantyTerms: formWarrantyTerms,
      notes: formNotes,
      pixKey: JCF_COMPANY_INFO.pixKey,
      technicianId: formTechnicianId || undefined,
      technicianName: tech ? tech.name : undefined,
      createdAt: currentQuote ? currentQuote.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (currentQuote) {
      onUpdateQuote(quoteData);
    } else {
      onAddQuote(quoteData);
    }
    setActiveActionQuote(quoteData);
    setIsModalOpen(false);
    if (openPreview) {
      setIsPreviewModalOpen(true);
    }
  };

  // Clone quote
  const handleDuplicateQuote = (quote: Quote) => {
    const nextNumber = generateNextQuoteNumber();
    const cloned: Quote = {
      ...quote,
      id: `orc-${Date.now()}`,
      quoteNumber: nextNumber,
      date: new Date().toISOString().split('T')[0],
      status: 'DRAFT',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    onAddQuote(cloned);
  };

  // Convert Approved Quote directly into a Service Order (OS)
  const handleConvertToOS = (quote: Quote) => {
    if (!onAddOrder) return;
    const year = new Date().getFullYear();
    const osNumber = `OS-${year}-${String(orders.length + 1).padStart(3, '0')}`;
    
    const plannedServicesText = quote.items
      .map(i => `[${i.type || 'ITEM'}] ${i.description} (Qtd: ${i.quantity}) - R$ ${i.total.toFixed(2)}`)
      .join('\n');

    const newOrder: ServiceOrder = {
      id: `os-${Date.now()}`,
      osNumber,
      clientId: quote.clientId,
      equipmentId: quote.equipmentId || '',
      title: `${quote.quoteType === 'VENDA' ? 'Venda' : 'Manutenção'} ref. ${quote.quoteNumber}`,
      description: `Gerada a partir do orçamento aprovado ${quote.quoteNumber}.\nCliente: ${quote.clientName}.\nAtivo: ${quote.equipmentName || 'Balcão'}.\nObservações: ${quote.notes || 'Sem observações'}`,
      status: 'PENDING',
      priority: 'MEDIUM',
      technician: quote.technicianName || 'Técnico Oficina',
      estimatedCost: quote.total,
      startDate: new Date().toISOString().split('T')[0],
      budgetStatus: 'APPROVED',
      budgetDate: quote.date,
      plannedServices: plannedServicesText,
      paymentMethod: quote.paymentTerms.includes('PIX') ? 'PIX' : 'Boleto',
      paymentStatus: 'PENDING',
      orderType: 'SERVICE',
      createdAt: new Date().toISOString()
    };

    onAddOrder(newOrder);
    // Mark quote as accepted if not already
    if (quote.status !== 'ACCEPTED') {
      onUpdateQuote({ ...quote, status: 'ACCEPTED', updatedAt: new Date().toISOString() });
    }
    alert(`Ordem de Serviço ${osNumber} gerada com sucesso a partir da proposta ${quote.quoteNumber}!`);
    if (onNavigateTab) {
      onNavigateTab('OS');
    }
  };

  // Status toggle
  const handleUpdateStatus = (quote: Quote, newStatus: QuoteStatus) => {
    onUpdateQuote({
      ...quote,
      status: newStatus,
      updatedAt: new Date().toISOString()
    });
  };

  // Filtering quotes
  const filteredQuotes = useMemo(() => {
    return quotes.filter(quote => {
      // Type Filter
      if (selectedTypeFilter !== 'ALL' && (quote.quoteType || 'MANUTENCAO_CORRETIVA') !== selectedTypeFilter) {
        return false;
      }
      // Status Filter
      if (activeStatusTab !== 'ALL' && quote.status !== activeStatusTab) {
        return false;
      }
      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesNum = quote.quoteNumber.toLowerCase().includes(q);
        const matchesClient = quote.clientName.toLowerCase().includes(q);
        const matchesEquip = (quote.equipmentName || '').toLowerCase().includes(q);
        const matchesItem = quote.items.some(i => i.description.toLowerCase().includes(q));
        if (!matchesNum && !matchesClient && !matchesEquip && !matchesItem) return false;
      }
      return true;
    });
  }, [quotes, selectedTypeFilter, activeStatusTab, searchQuery]);

  // Statistics
  const stats = useMemo(() => {
    const totalCount = quotes.length;
    const sentCount = quotes.filter(q => q.status === 'SENT').length;
    const acceptedCount = quotes.filter(q => q.status === 'ACCEPTED').length;
    const draftCount = quotes.filter(q => q.status === 'DRAFT').length;

    const totalValue = quotes.reduce((acc, q) => acc + q.total, 0);
    const acceptedValue = quotes.filter(q => q.status === 'ACCEPTED').reduce((acc, q) => acc + q.total, 0);
    const sentValue = quotes.filter(q => q.status === 'SENT').reduce((acc, q) => acc + q.total, 0);

    return { totalCount, sentCount, acceptedCount, draftCount, totalValue, acceptedValue, sentValue };
  }, [quotes]);

  // Direct Download A4 PDF
  const handleDownloadPDF = (quoteToDownload?: Quote | null) => {
    const q = quoteToDownload || activeActionQuote;
    if (!q) return;
    try {
      generateQuotePDF(q);
      showFeedback(`PDF do Orçamento ${q.quoteNumber} gerado em formato A4 com sucesso!`, 'success');
    } catch (err) {
      console.error('Erro ao gerar PDF do orçamento:', err);
      showFeedback('Não foi possível gerar o PDF diretamente. Tente a opção de impressão.', 'error');
    }
  };

  // Trigger Native Print Window calibrated for A4
  const handleTriggerPrint = () => {
    const printContent = document.getElementById('printable-quote-document');
    if (!printContent) return;

    // Use a dedicated invisible iframe for seamless print inside iframes or popups
    let printFrame = document.getElementById('quote-print-iframe') as HTMLIFrameElement;
    if (!printFrame) {
      printFrame = document.createElement('iframe');
      printFrame.id = 'quote-print-iframe';
      printFrame.style.position = 'fixed';
      printFrame.style.right = '0';
      printFrame.style.bottom = '0';
      printFrame.style.width = '0';
      printFrame.style.height = '0';
      printFrame.style.border = '0';
      document.body.appendChild(printFrame);
    }

    const frameDoc = printFrame.contentWindow?.document;
    if (frameDoc) {
      frameDoc.open();
      frameDoc.write(`<!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <title>Orçamento JC&F - ${activeActionQuote?.quoteNumber || 'Proposta'}</title>
            <style>
              @page {
                size: A4 portrait;
                margin: 8mm 8mm 8mm 8mm;
              }
              * {
                box-sizing: border-box;
              }
              body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                color: #0f172a;
                background-color: #ffffff;
                margin: 0;
                padding: 0;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                font-size: 11px;
                line-height: 1.35;
              }
              .quote-a4-sheet {
                width: 100% !important;
                max-width: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
              }
              .print-keep-together {
                break-inside: avoid !important;
                page-break-inside: avoid !important;
              }
              .print-row-avoid {
                break-inside: avoid !important;
                page-break-inside: avoid !important;
              }
              table {
                width: 100%;
                border-collapse: collapse;
              }
              th, td {
                padding: 4px 6px;
              }
              .no-print {
                display: none !important;
              }
            </style>
          </head>
          <body>
            ${printContent.innerHTML}
          </body>
        </html>
      `);
      frameDoc.close();

      setTimeout(() => {
        try {
          printFrame.contentWindow?.focus();
          printFrame.contentWindow?.print();
        } catch (e) {
          // Fallback to window.open if iframe print is restricted
          const printWindow = window.open('', '_blank');
          if (printWindow) {
            printWindow.document.write(frameDoc.documentElement.outerHTML);
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
          }
        }
      }, 250);
    } else {
      window.print();
    }
  };

  return (
    <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="quote-manager-container">
      {/* Toast Feedback Notification */}
      {feedback && (
        <div 
          className={`fixed top-4 right-4 z-[9999] px-4 py-3 rounded-xl shadow-2xl font-bold text-xs flex items-center gap-2 border animate-in fade-in slide-in-from-top-4 duration-200 ${
            feedback.type === 'success' ? 'bg-emerald-600 text-white border-emerald-500' :
            feedback.type === 'error' ? 'bg-rose-600 text-white border-rose-500' :
            'bg-blue-600 text-white border-blue-500'
          }`}
        >
          {feedback.type === 'success' && <Check className="w-4 h-4" />}
          {feedback.type === 'error' && <AlertCircle className="w-4 h-4" />}
          {feedback.type === 'info' && <AlertCircle className="w-4 h-4" />}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* 1. Header Banner with Company Identity & Creation Button */}
      <div className="bg-[#1b365d] text-white px-4 py-3 sm:px-6 sm:py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-blue-900">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 shrink-0 bg-white rounded-lg p-0.5 flex items-center justify-center border border-white/20 shadow-xs">
            <JCFCompanyLogo size="custom" className="w-10 h-10" variant="mono-black" showSubtitle={false} />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black text-white flex items-center gap-2 uppercase tracking-wider">
              <span>{JCF_COMPANY_INFO.name}</span>
            </h2>
            <p className="text-xs text-cyan-200">
              Dispositivo de Emissão de Orçamentos de Venda, Manutenção Corretiva e Preventiva
            </p>
            <p className="text-[10px] text-cyan-100/80 font-mono mt-0.5">
              {JCF_COMPANY_INFO.address} | CNPJ: {JCF_COMPANY_INFO.cnpj} | Tel: {JCF_COMPANY_INFO.phone}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={() => setIsPriceTableModalOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-800 hover:bg-blue-700 text-white font-black rounded-lg text-xs uppercase tracking-wider border border-blue-600 shadow-sm transition-all cursor-pointer shrink-0"
            id="btn-quote-header-price-table"
            title="Consultar Tabela de Preços e Catálogo da Oficina (F7)"
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-300" />
            <span>Tabela de Preços</span>
          </button>

          <button
            type="button"
            onClick={() => handleOpenNewQuoteModal()}
            className="flex items-center justify-center gap-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider shadow-md transition-all cursor-pointer shrink-0"
            id="btn-new-quote"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>ELABORAR ORÇAMENTO</span>
          </button>
        </div>
      </div>

      <div className="p-4 sm:p-6 bg-[#e9edf2] space-y-4">
        {/* 2. Top Tabs by Quote Type (Venda, Corretiva, Preventiva, Reforma, Outros) */}
        <div className="flex flex-wrap items-center gap-2 bg-white p-2 rounded-xl border border-slate-300 shadow-xs">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-2">Tipo:</span>
          
          <button
            onClick={() => setSelectedTypeFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase transition-all cursor-pointer ${
              selectedTypeFilter === 'ALL'
                ? 'bg-[#1b365d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100'
            }`}
          >
            Todos ({quotes.length})
          </button>

          <button
            onClick={() => setSelectedTypeFilter('VENDA')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black uppercase transition-all cursor-pointer ${
              selectedTypeFilter === 'VENDA'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-emerald-800 hover:bg-emerald-50'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Venda de Peças ({quotes.filter(q => q.quoteType === 'VENDA').length})</span>
          </button>

          <button
            onClick={() => setSelectedTypeFilter('MANUTENCAO_CORRETIVA')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black uppercase transition-all cursor-pointer ${
              selectedTypeFilter === 'MANUTENCAO_CORRETIVA'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-amber-800 hover:bg-amber-50'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>Manutenção Corretiva ({quotes.filter(q => (q.quoteType || 'MANUTENCAO_CORRETIVA') === 'MANUTENCAO_CORRETIVA').length})</span>
          </button>

          <button
            onClick={() => setSelectedTypeFilter('MANUTENCAO_PREVENTIVA')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black uppercase transition-all cursor-pointer ${
              selectedTypeFilter === 'MANUTENCAO_PREVENTIVA'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-blue-800 hover:bg-blue-50'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Manutenção Preventiva ({quotes.filter(q => q.quoteType === 'MANUTENCAO_PREVENTIVA').length})</span>
          </button>

          <button
            onClick={() => setSelectedTypeFilter('REVISAO_GERAL')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black uppercase transition-all cursor-pointer ${
              selectedTypeFilter === 'REVISAO_GERAL'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-purple-800 hover:bg-purple-50'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reforma / Revisão ({quotes.filter(q => q.quoteType === 'REVISAO_GERAL').length})</span>
          </button>

          <button
            onClick={() => setSelectedTypeFilter('OUTROS')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black uppercase transition-all cursor-pointer ${
              selectedTypeFilter === 'OUTROS'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Outros / Consultoria ({quotes.filter(q => q.quoteType === 'OUTROS').length})</span>
          </button>
        </div>

        {/* 3. Operational KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="bg-white border-2 border-slate-300 rounded-xl p-3.5 flex items-center justify-between shadow-xs">
            <div>
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Volume de Propostas</span>
              <div className="text-base font-black text-slate-900">{stats.totalCount} orçamentos</div>
              <div className="text-xs font-black font-mono text-blue-900">
                R$ {stats.totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-blue-700">
              <Layers className="w-4 h-4" />
            </div>
          </div>

          <div className="bg-white border-2 border-slate-300 rounded-xl p-3.5 flex items-center justify-between shadow-xs">
            <div>
              <span className="text-[10px] font-black uppercase text-emerald-700 tracking-wider">Aprovados / Fechados</span>
              <div className="text-base font-black text-slate-900">{stats.acceptedCount} fechados</div>
              <div className="text-xs font-black font-mono text-emerald-700">
                R$ {stats.acceptedValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-700">
              <FileCheck className="w-4 h-4" />
            </div>
          </div>

          <div className="bg-white border-2 border-slate-300 rounded-xl p-3.5 flex items-center justify-between shadow-xs">
            <div>
              <span className="text-[10px] font-black uppercase text-amber-700 tracking-wider">Enviados ao Cliente</span>
              <div className="text-base font-black text-slate-900">{stats.sentCount} em negociação</div>
              <div className="text-xs font-black font-mono text-amber-700">
                R$ {stats.sentValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-700">
              <Send className="w-4 h-4" />
            </div>
          </div>

          <div className="bg-white border-2 border-slate-300 rounded-xl p-3.5 flex items-center justify-between shadow-xs">
            <div>
              <span className="text-[10px] font-black uppercase text-purple-700 tracking-wider">Rascunhos / Controle</span>
              <div className="text-base font-black text-slate-900">{stats.draftCount} em elaboração</div>
              <div className="text-xs font-black font-mono text-purple-700">
                Chave PIX: {JCF_COMPANY_INFO.pixKey}
              </div>
            </div>
            <div className="p-2.5 bg-purple-50 border border-purple-200 rounded-xl text-purple-700">
              <Clock className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* 4. Search & Status Filter Row */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Buscar orçamento por número, cliente, equipamento ou peça..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 shadow-inner"
            />
          </div>

          <div className="flex items-center gap-1.5 self-end sm:self-auto bg-white p-1 rounded-xl border border-slate-300 shadow-xs">
            <button
              onClick={() => setActiveStatusTab('ALL')}
              className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase transition-all cursor-pointer ${
                activeStatusTab === 'ALL' ? 'bg-[#1b365d] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Todos
            </button>
            <button
              onClick={() => setActiveStatusTab('SENT')}
              className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase transition-all cursor-pointer ${
                activeStatusTab === 'SENT' ? 'bg-amber-500 text-slate-950 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Enviados
            </button>
            <button
              onClick={() => setActiveStatusTab('ACCEPTED')}
              className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase transition-all cursor-pointer ${
                activeStatusTab === 'ACCEPTED' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Aprovados
            </button>
            <button
              onClick={() => setActiveStatusTab('DRAFT')}
              className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase transition-all cursor-pointer ${
                activeStatusTab === 'DRAFT' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Rascunhos
            </button>
          </div>
        </div>

        {/* 5. Primary Quotes Grid */}
        {filteredQuotes.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 px-4 border-2 border-dashed border-slate-300 rounded-xl bg-white text-center">
            <div className="p-3 bg-slate-100 rounded-full text-slate-500 mb-3 border border-slate-200">
              <FileSpreadsheet className="w-8 h-8" />
            </div>
            <p className="text-xs font-black text-slate-800 uppercase tracking-widest">Nenhum orçamento encontrado</p>
            <p className="text-[11px] text-slate-500 mt-1 max-w-sm">
              Crie uma nova proposta de venda ou manutenção para começar o envio profissional aos clientes.
            </p>
            <button
              type="button"
              onClick={() => handleOpenNewQuoteModal()}
              className="mt-4 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider rounded-lg transition-all shadow-md cursor-pointer"
            >
              Criar Primeiro Orçamento
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4" id="quotes-cards-grid">
            {filteredQuotes.map((quote) => {
              const quoteTypeBadge = {
                VENDA: { label: 'Venda de Peças', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300' },
                MANUTENCAO_CORRETIVA: { label: 'Manutenção Corretiva', bg: 'bg-amber-100 text-amber-900 border-amber-300' },
                MANUTENCAO_PREVENTIVA: { label: 'Manutenção Preventiva', bg: 'bg-blue-100 text-blue-900 border-blue-300' },
                REVISAO_GERAL: { label: 'Reforma / Revisão', bg: 'bg-purple-100 text-purple-900 border-purple-300' },
                OUTROS: { label: 'Consultoria / Outros', bg: 'bg-slate-100 text-slate-900 border-slate-300' }
              }[quote.quoteType || 'MANUTENCAO_CORRETIVA'];

              return (
                <div
                  key={quote.id}
                  className="bg-white border-2 border-slate-300 hover:border-blue-600 rounded-xl p-4 transition-all duration-200 flex flex-col justify-between shadow-xs hover:shadow-md relative"
                >
                  <div className="space-y-3">
                    {/* Header: ID, Type & Status */}
                    <div className="flex justify-between items-start gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-black text-slate-950 font-mono tracking-wider">
                            {quote.quoteNumber}
                          </span>
                          <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${quoteTypeBadge.bg}`}>
                            {quoteTypeBadge.label}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                          Emissão: {new Date(quote.date + 'T12:00:00').toLocaleDateString('pt-BR')} • Validade: {new Date(quote.validUntil + 'T12:00:00').toLocaleDateString('pt-BR')}
                        </span>
                      </div>

                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md border ${
                        quote.status === 'ACCEPTED' ? 'bg-emerald-100 text-emerald-900 border-emerald-300' :
                        quote.status === 'SENT' ? 'bg-amber-100 text-amber-900 border-amber-300' :
                        quote.status === 'REJECTED' ? 'bg-red-100 text-red-900 border-red-300' :
                        'bg-slate-100 text-slate-700 border-slate-300'
                      }`}>
                        {quote.status === 'ACCEPTED' ? 'Aprovado' : quote.status === 'SENT' ? 'Enviado' : quote.status === 'REJECTED' ? 'Recusado' : 'Rascunho'}
                      </span>
                    </div>

                    {/* Client & Target info */}
                    <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 space-y-1 text-xs">
                      <div className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5 text-blue-900 shrink-0" />
                        <span className="font-black text-slate-900 truncate">{quote.clientName}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-600 text-[11px]">
                        <Cpu className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span className="truncate">{quote.equipmentName || 'Venda de Balcão / Peças'}</span>
                      </div>
                    </div>

                    {/* Items List Preview */}
                    <div className="space-y-1 text-[11px]">
                      <span className="text-[9px] uppercase font-black text-slate-400 tracking-wider block">
                        Itens da Proposta ({quote.items.length})
                      </span>
                      <div className="max-h-20 overflow-y-auto space-y-1 pr-1">
                        {quote.items.map((item) => (
                          <div key={item.id} className="flex justify-between items-center text-[10px] text-slate-700 border-b border-slate-100 pb-0.5">
                            <span className="truncate flex-1">• {item.description}</span>
                            <span className="font-mono font-bold text-slate-900 shrink-0 ml-2">
                              R$ {item.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Totals */}
                    <div className="flex justify-between items-baseline pt-2 border-t border-slate-200">
                      <span className="text-[10px] uppercase font-bold text-slate-500">Total Líquido</span>
                      <span className="text-base font-black text-blue-950 font-mono">
                        R$ {quote.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                  {/* Actions & Dispatch Channels */}
                  <div className="mt-4 pt-3 border-t border-slate-200 space-y-2">
                    {/* Primary Operations: Visualizar (Conferência Pré-Envio), Editar, Excluir */}
                    <div className="grid grid-cols-12 gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleOpenPreviewModal(quote)}
                        className="col-span-6 flex items-center justify-center gap-1.5 py-2 px-2.5 bg-[#1b365d] hover:bg-[#254573] text-white rounded-lg text-[11px] font-black uppercase tracking-wider transition-all cursor-pointer shadow-xs"
                        title="Visualizar Orçamento Completo e Conferir antes do Envio"
                      >
                        <Eye className="w-3.5 h-3.5 text-cyan-300" />
                        <span>Visualizar</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleOpenEditQuoteModal(quote)}
                        className="col-span-3 flex items-center justify-center gap-1 py-2 px-1 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded-lg text-[10px] font-black uppercase tracking-wider transition-colors cursor-pointer"
                        title="Editar Orçamento e Fazer Correções"
                      >
                        <Edit2 className="w-3 h-3 text-blue-700" />
                        <span>Editar</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteQuoteWithConfirm(quote)}
                        className="col-span-3 flex items-center justify-center gap-1 py-2 px-1 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-lg text-[10px] font-black uppercase tracking-wider transition-colors cursor-pointer"
                        title="Excluir Orçamento"
                      >
                        <Trash2 className="w-3 h-3 text-red-600" />
                        <span>Excluir</span>
                      </button>
                    </div>

                    {/* Secondary Channels: WhatsApp, Email, Print, Gerar OS, Duplicar */}
                    <div className="flex items-center justify-between gap-1 pt-1">
                      <div className="grid grid-cols-3 gap-1 flex-1">
                        <button
                          type="button"
                          onClick={() => {
                            setActiveActionQuote(quote);
                            setIsWhatsAppModalOpen(true);
                          }}
                          className="flex items-center justify-center gap-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md text-[10px] font-black uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
                          title="Enviar Proposta via WhatsApp"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>WhatsApp</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setActiveActionQuote(quote);
                            setIsEmailModalOpen(true);
                          }}
                          className="flex items-center justify-center gap-1 py-1.5 px-2 bg-blue-700 hover:bg-blue-600 text-white rounded-md text-[10px] font-black uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
                          title="Enviar Proposta por E-mail"
                        >
                          <Mail className="w-3 h-3" />
                          <span>E-mail</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDownloadPDF(quote)}
                          className="flex items-center justify-center gap-1 py-1.5 px-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-md text-[10px] font-black uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
                          title="Baixar arquivo PDF oficial calibrado para folha A4"
                        >
                          <Download className="w-3 h-3" />
                          <span>PDF A4</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setActiveActionQuote(quote);
                            setIsPrintModalOpen(true);
                          }}
                          className="flex items-center justify-center gap-1 py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-white rounded-md text-[10px] font-black uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
                          title="Visualizar e Imprimir em Folha A4 com Logomarca"
                        >
                          <Printer className="w-3 h-3" />
                          <span>Imprimir</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-1 pl-1">
                        <button
                          type="button"
                          onClick={() => handleDuplicateQuote(quote)}
                          className="p-1.5 bg-slate-100 hover:bg-blue-100 text-slate-700 hover:text-blue-900 rounded-md border border-slate-300 transition-colors cursor-pointer"
                          title="Duplicar Orçamento"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleConvertToOS(quote)}
                          className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-md text-[10px] font-black uppercase tracking-wider shadow-xs transition-colors cursor-pointer"
                          title="Gerar Ordem de Serviço (OS) a partir deste orçamento"
                        >
                          <Wrench className="w-3 h-3" />
                          <span>OS</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 6. MODAL: ELABORAR / EDITAR ORÇAMENTO */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white border-2 border-slate-400 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col my-6 max-h-[92vh]">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-[#1b365d] text-white flex items-center justify-between border-b border-blue-900">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white rounded-lg p-0.5 flex items-center justify-center">
                  <JCFCompanyLogo size="custom" className="w-8 h-8" variant="mono-black" showSubtitle={false} />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-black text-white uppercase tracking-wider">
                    {currentQuote ? `Editar Proposta ${currentQuote.quoteNumber}` : 'Elaborar Nova Proposta Comercial'}
                  </h3>
                  <p className="text-[10px] text-cyan-200">
                    {JCF_COMPANY_INFO.name} • {JCF_COMPANY_INFO.address}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-cyan-200 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleFormSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
              {/* Row 1: Quote Type Selector */}
              <div>
                <label className="text-xs font-black uppercase text-slate-700 block mb-2">
                  Tipo de Atendimento / Escopo da Proposta *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {[
                    { type: 'VENDA' as QuoteType, label: 'Venda de Peças', icon: Package },
                    { type: 'MANUTENCAO_CORRETIVA' as QuoteType, label: 'Manutenção Corretiva', icon: Wrench },
                    { type: 'MANUTENCAO_PREVENTIVA' as QuoteType, label: 'Manutenção Preventiva', icon: ShieldCheck },
                    { type: 'REVISAO_GERAL' as QuoteType, label: 'Reforma Geral', icon: RefreshCw },
                    { type: 'OUTROS' as QuoteType, label: 'Outros / Consultoria', icon: Briefcase }
                  ].map(item => {
                    const Icon = item.icon;
                    const isSelected = formQuoteType === item.type;
                    return (
                      <button
                        key={item.type}
                        type="button"
                        onClick={() => setFormQuoteType(item.type)}
                        className={`p-2.5 rounded-xl border-2 flex flex-col items-center text-center gap-1.5 transition-all cursor-pointer ${
                          isSelected
                            ? 'border-blue-600 bg-blue-50 text-blue-950 font-black shadow-xs'
                            : 'border-slate-300 bg-white text-slate-700 hover:border-slate-400 font-bold'
                        }`}
                      >
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-blue-600' : 'text-slate-500'}`} />
                        <span className="text-[11px] leading-tight">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Row 2: Quote Number, Dates & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Nº do Orçamento *</label>
                  <input
                    type="text"
                    required
                    value={formQuoteNumber}
                    onChange={(e) => setFormQuoteNumber(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold text-slate-900 shadow-inner"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Data de Emissão *</label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold text-slate-900 shadow-inner"
                  />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[10px] font-black uppercase text-slate-600">Validade *</label>
                    <div className="flex gap-1 text-[9px] font-bold">
                      <button type="button" onClick={() => handleSetValidityDays(7)} className="text-blue-700 hover:underline">7d</button>
                      <button type="button" onClick={() => handleSetValidityDays(15)} className="text-blue-700 hover:underline">15d</button>
                      <button type="button" onClick={() => handleSetValidityDays(30)} className="text-blue-700 hover:underline">30d</button>
                    </div>
                  </div>
                  <input
                    type="date"
                    required
                    value={formValidUntil}
                    onChange={(e) => setFormValidUntil(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold text-slate-900 shadow-inner"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Status da Proposta</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as QuoteStatus)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-900 shadow-inner"
                  >
                    <option value="DRAFT">Rascunho / Controle</option>
                    <option value="SENT">Enviado ao Cliente</option>
                    <option value="ACCEPTED">Aprovado / Fechado</option>
                    <option value="REJECTED">Recusado</option>
                  </select>
                </div>
              </div>

              {/* Row 3: Client Information */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-blue-900" />
                    <span>Identificação do Cliente / Solicitante *</span>
                  </h4>
                  <div className="flex items-center gap-2 flex-wrap">
                    {clients.length > 0 && (
                      <select
                        id="select-quote-client"
                        value={formClientId}
                        onChange={(e) => handleClientSelect(e.target.value)}
                        className="text-xs bg-white border border-blue-300 rounded-lg px-2 py-1.5 font-bold text-blue-900 max-w-xs truncate cursor-pointer shadow-2xs"
                      >
                        <option value="">-- Carregar de Clientes Cadastrados (A-Z) --</option>
                        {sortedClients.map(c => (
                          <option key={c.id} value={c.id}>{c.name} {c.document ? `(${c.document})` : ''}</option>
                        ))}
                      </select>
                    )}
                    {onAddClient && (
                      <button
                        type="button"
                        id="btn-quote-register-new-client"
                        onClick={() => setIsNewClientModalOpen(true)}
                        className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all shadow-2xs shrink-0"
                        title="Cadastrar Novo Cliente no Sistema (F2)"
                      >
                        <UserPlus className="w-3.5 h-3.5 text-slate-950" />
                        <span>Novo Cliente</span>
                        <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1 py-0.2 rounded">F2</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Nome / Razão Social *</label>
                    <input
                      type="text"
                      required
                      value={formClientName}
                      onChange={(e) => setFormClientName(e.target.value)}
                      placeholder="Ex: Indústria Metalúrgica Ltda"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 shadow-inner"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">CNPJ / CPF</label>
                    <input
                      type="text"
                      value={formClientDocument}
                      onChange={(e) => setFormClientDocument(e.target.value)}
                      placeholder="00.000.000/0001-00"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 shadow-inner"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Telefone / WhatsApp *</label>
                    <input
                      type="text"
                      value={formClientPhone}
                      onChange={(e) => setFormClientPhone(e.target.value)}
                      placeholder="(21) 98369-9728"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 shadow-inner"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">E-mail para Envio</label>
                    <input
                      type="email"
                      value={formClientEmail}
                      onChange={(e) => setFormClientEmail(e.target.value)}
                      placeholder="compras@empresa.com.br"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 shadow-inner"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Endereço Completo</label>
                    <input
                      type="text"
                      value={formClientAddress}
                      onChange={(e) => setFormClientAddress(e.target.value)}
                      placeholder="Rua, Número, Bairro, Cidade - UF"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 shadow-inner"
                    />
                  </div>
                </div>
              </div>

              {/* Row 4: Equipment / Asset Target */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-blue-900" />
                    <span>Equipamento / Ativo Relacionado</span>
                  </h4>
                  <div className="flex items-center gap-2 flex-wrap">
                    {equipments.length > 0 && (
                      <select
                        value={formEquipmentId}
                        onChange={(e) => handleEquipmentSelect(e.target.value)}
                        className="text-xs bg-white border border-blue-300 rounded-lg px-2 py-1 font-bold text-blue-900 max-w-xs truncate cursor-pointer"
                      >
                        <option value="">-- Selecionar Equipamento Cadastrado (A-Z) --</option>
                        {sortedEquipments.map(e => (
                          <option key={e.id} value={e.id}>{e.name} • {e.model}</option>
                        ))}
                      </select>
                    )}

                    {onAddEquipment && (
                      <button
                        type="button"
                        id="btn-quote-add-equipment"
                        onClick={() => setIsNewEquipmentModalOpen(true)}
                        className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all shadow-2xs shrink-0"
                        title="Cadastrar Novo Equipamento no Sistema (F4)"
                      >
                        <Cpu className="w-3.5 h-3.5 text-slate-950" />
                        <span>Novo Equipamento</span>
                        <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1 rounded">F4</span>
                      </button>
                    )}
                  </div>
                </div>
                <div>
                  <input
                    type="text"
                    value={formEquipmentName}
                    onChange={(e) => setFormEquipmentName(e.target.value)}
                    placeholder="Ex: Prensa Hidráulica 100T, Cilindro Telescópico, Venda de Balcão..."
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 shadow-inner"
                  />
                </div>
              </div>

              {/* Row 5: Items & Services Builder */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-blue-900" />
                    <span>Composição da Proposta (Peças, Materiais & Serviços)</span>
                  </h4>

                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Botão Pesquisar na Tabela de Preços */}
                    <button
                      type="button"
                      id="btn-quote-open-price-table"
                      onClick={() => setIsPriceTableModalOpen(true)}
                      className="px-3 py-1.5 bg-[#1b365d] hover:bg-blue-800 text-white font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-sm hover:shadow transition-all"
                      title="Pesquisar Preços e Inserir Itens no Orçamento"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-amber-300" />
                      <span>Tabela de Preços (Buscar & Inserir)</span>
                      <span className="bg-amber-500 text-slate-950 font-mono text-[9px] font-black px-1.5 py-0.2 rounded">Pesquisar</span>
                    </button>

                    {/* Botão Atalho Novo Serviço F3 */}
                    {onAddService && (
                      <button
                        type="button"
                        id="btn-quote-add-service"
                        onClick={() => setIsNewServiceModalOpen(true)}
                        className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all shadow-2xs shrink-0"
                        title="Cadastrar Novo Serviço na Tabela (F3)"
                      >
                        <Briefcase className="w-3.5 h-3.5 text-slate-950" />
                        <span>Novo Serviço</span>
                        <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1 rounded">F3</span>
                      </button>
                    )}

                    {services.length > 0 && (
                      <select
                        onChange={(e) => {
                          const srv = services.find(s => s.id === e.target.value);
                          if (srv) {
                            setItemType('SERVICO');
                            const desc = srv.description && srv.description !== srv.name
                              ? `${srv.name} - ${srv.description}`
                              : srv.name;
                            setItemDesc(desc);
                            setItemPrice(srv.estimatedCost);
                            setItemQty(1);
                            setItemUnit(srv.unit || 'UN');
                          }
                          e.target.value = '';
                        }}
                        className="text-xs bg-blue-50 border border-blue-300 rounded-lg px-2 py-1 font-bold text-blue-900 cursor-pointer"
                      >
                        <option value="">+ Seleção Rápida de Serviços (A-Z)...</option>
                        {sortedServices.map(s => (
                          <option key={s.id} value={s.id}>
                            {s.name} (R$ {s.estimatedCost.toFixed(2)})
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                </div>

                {/* Input row for building or editing an item */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 bg-white p-3 rounded-lg border border-slate-300 items-end">
                  {editingItemId && (
                    <div className="sm:col-span-12 p-2 bg-amber-50 border border-amber-300 rounded-lg flex items-center justify-between text-xs text-amber-900 mb-1">
                      <div className="flex items-center gap-1.5">
                        <Edit2 className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                        <span className="font-bold">Corrigindo item existente:</span>
                        <span className="truncate max-w-sm italic text-amber-950">"{itemDesc || 'Item selecionado'}"</span>
                      </div>
                      <button
                        type="button"
                        onClick={handleCancelEditItem}
                        className="text-[10px] font-black uppercase text-amber-800 hover:text-amber-950 px-2 py-0.5 rounded bg-amber-200/70 hover:bg-amber-200 transition-colors cursor-pointer"
                      >
                        Cancelar Correção
                      </button>
                    </div>
                  )}

                  <div className="sm:col-span-2">
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Tipo</label>
                    <select
                      value={itemType}
                      onChange={(e) => setItemType(e.target.value as QuoteItemType)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-slate-900"
                    >
                      <option value="SERVICO">Serviço</option>
                      <option value="PECA">Peça</option>
                      <option value="PRODUTO">Produto</option>
                      <option value="OUTRO">Outro</option>
                    </select>
                  </div>
                  <div className={editingItemId ? "sm:col-span-4" : "sm:col-span-5"}>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Descrição Detalhada</label>
                    <input
                      type="text"
                      value={itemDesc}
                      onChange={(e) => setItemDesc(e.target.value)}
                      placeholder="Ex: Brunimento de camisa, Jogo de vedações Viton..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-900"
                    />
                  </div>
                  <div className="sm:col-span-1">
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Qtd</label>
                    <input
                      type="number"
                      min="1"
                      value={itemQty}
                      onChange={(e) => setItemQty(parseInt(e.target.value, 10) || 1)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-slate-900 font-mono text-center"
                    />
                  </div>
                  <div className="sm:col-span-1">
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Unid</label>
                    <input
                      type="text"
                      value={itemUnit}
                      onChange={(e) => setItemUnit(e.target.value.toUpperCase())}
                      placeholder="UN"
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-slate-900 font-mono text-center"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Unitário (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={itemPrice}
                      onChange={(e) => setItemPrice(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-slate-900 font-mono text-right"
                    />
                  </div>
                  <div className={editingItemId ? "sm:col-span-2 flex items-center gap-1" : "sm:col-span-1"}>
                    {editingItemId ? (
                      <>
                        <button
                          type="button"
                          onClick={handleAddItem}
                          className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg text-[11px] uppercase flex items-center justify-center gap-1 cursor-pointer shadow-xs transition-colors"
                          title="Salvar correção deste item"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Salvar</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleCancelEditItem}
                          className="p-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs cursor-pointer transition-colors"
                          title="Cancelar edição"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={handleAddItem}
                        className="w-full py-1.5 bg-blue-700 hover:bg-blue-600 text-white font-black rounded-lg text-xs uppercase flex items-center justify-center cursor-pointer shadow-xs"
                        title="Adicionar Item à Proposta"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Items Table */}
                <div className="border border-slate-300 rounded-lg overflow-hidden bg-white">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-100 text-slate-600 border-b border-slate-200 font-bold">
                      <tr>
                        <th className="py-2 px-2 text-center w-8">#</th>
                        <th className="py-2 px-2 text-left w-20">Tipo</th>
                        <th className="py-2 px-2 text-left">Descrição</th>
                        <th className="py-2 px-2 text-center w-14">Qtd</th>
                        <th className="py-2 px-2 text-center w-12">Unid</th>
                        <th className="py-2 px-2 text-right w-24">Unitário</th>
                        <th className="py-2 px-2 text-right w-24">Total</th>
                        <th className="py-2 px-2 text-center w-16">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {formItems.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="text-center py-6 text-slate-400 font-bold">
                            Nenhum item adicionado à proposta ainda.
                          </td>
                        </tr>
                      ) : (
                        formItems.map((item, idx) => (
                          <tr
                            key={item.id}
                            className={`border-b border-slate-100 last:border-b-0 transition-colors ${
                              item.id === editingItemId
                                ? 'bg-amber-50/90 border-amber-300 font-bold'
                                : 'hover:bg-slate-50'
                            }`}
                          >
                            <td className="py-2 px-2 text-center font-mono text-slate-400">{idx + 1}</td>
                            <td className="py-2 px-2">
                              <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${
                                item.type === 'PECA' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                              }`}>
                                {item.type || 'ITEM'}
                              </span>
                            </td>
                            <td className="py-2 px-2 font-bold text-slate-900">{item.description}</td>
                            <td className="py-2 px-2 text-center font-mono font-bold text-slate-800">{item.quantity}</td>
                            <td className="py-2 px-2 text-center font-mono text-slate-600">{item.unit || 'UN'}</td>
                            <td className="py-2 px-2 text-right font-mono text-slate-700">
                              R$ {item.unitPrice.toFixed(2)}
                            </td>
                            <td className="py-2 px-2 text-right font-mono font-black text-blue-950">
                              R$ {item.total.toFixed(2)}
                            </td>
                            <td className="py-2 px-2 text-center">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleStartEditItem(item)}
                                  className="text-blue-600 hover:text-blue-800 p-1 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                                  title="Editar / Corrigir este item"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleRemoveItem(item.id)}
                                  className="text-red-500 hover:text-red-700 p-1 hover:bg-red-50 rounded transition-colors cursor-pointer"
                                  title="Excluir este item"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Subtotal, Discount & Total Calculation */}
                <div className="flex justify-end pt-2">
                  <div className="w-72 bg-white border border-slate-300 rounded-lg p-3 space-y-2">
                    <div className="flex justify-between text-xs text-slate-700">
                      <span>Subtotal Bruto:</span>
                      <span className="font-mono font-bold">R$ {calculatedSubtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-slate-700 gap-2">
                      <span>Desconto (R$):</span>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={formDiscount}
                        onChange={(e) => setFormDiscount(parseFloat(e.target.value) || 0)}
                        className="w-24 bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs font-mono font-bold text-right"
                      />
                    </div>
                    <div className="flex justify-between text-sm font-black text-slate-950 border-t border-slate-200 pt-2">
                      <span>Total Líquido:</span>
                      <span className="font-mono text-blue-950 text-base">R$ {calculatedTotal.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Row 6: Commercial Conditions & Terms */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-800">
                  Condições Comerciais, Prazos & Chave PIX
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Condição de Pagamento</label>
                    <input
                      type="text"
                      value={formPaymentTerms}
                      onChange={(e) => setFormPaymentTerms(e.target.value)}
                      placeholder="Ex: PIX à vista ou Faturado 30 dias"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 shadow-inner"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Prazo de Entrega / Execução</label>
                    <input
                      type="text"
                      value={formDeliveryTime}
                      onChange={(e) => setFormDeliveryTime(e.target.value)}
                      placeholder="Ex: 3 a 5 dias úteis"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 shadow-inner"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Termo de Garantia</label>
                    <input
                      type="text"
                      value={formWarrantyTerms}
                      onChange={(e) => setFormWarrantyTerms(e.target.value)}
                      placeholder="Ex: 180 dias contra vazamentos"
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 shadow-inner"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-slate-600 block mb-1">Observações Técnicas & Escopo</label>
                  <textarea
                    rows={2}
                    value={formNotes}
                    onChange={(e) => setFormNotes(e.target.value)}
                    placeholder="Instruções adicionais, bancada de teste, frete por conta do cliente..."
                    className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs font-medium text-slate-900 shadow-inner"
                  />
                </div>
              </div>

              {/* Modal Footer Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-200">
                <div>
                  {currentQuote && (
                    <button
                      type="button"
                      onClick={() => handleDeleteQuoteWithConfirm(currentQuote)}
                      className="px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold rounded-lg text-xs uppercase flex items-center gap-1.5 cursor-pointer transition-colors"
                      title="Excluir este orçamento definitivamente"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-600" />
                      <span>Excluir Orçamento</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-xs uppercase cursor-pointer transition-colors"
                  >
                    Cancelar
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      handleFormSubmit(e, true);
                    }}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-200 hover:text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Salvar alterações e abrir visualização para conferência antes do envio"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Salvar e Conferir</span>
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-blue-700 hover:bg-blue-600 text-white font-black rounded-lg text-xs uppercase tracking-wider shadow-md transition-all cursor-pointer"
                  >
                    {currentQuote ? 'Salvar Alterações' : 'Emitir Orçamento'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7. MODAL: IMPRESSÃO & PDF COM LOGOTIPO */}
      {isPrintModalOpen && activeActionQuote && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white border-2 border-slate-400 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col my-6 max-h-[92vh]">
            {/* Action Bar */}
            <div className="px-6 py-3.5 bg-[#1b365d] text-white flex items-center justify-between no-print border-b border-blue-900">
              <div className="flex items-center gap-3">
                <Printer className="w-5 h-5 text-cyan-300" />
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Ficha da Proposta Comercial - {activeActionQuote.quoteNumber}
                  </h3>
                  <p className="text-[10px] text-cyan-200">
                    Layout A4 com logomarca e dados oficiais da JC&F
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsPrintModalOpen(false);
                    handleOpenEditQuoteModal(activeActionQuote);
                  }}
                  className="px-3 py-2 bg-blue-800 hover:bg-blue-700 text-cyan-100 hover:text-white font-bold rounded-lg text-xs uppercase tracking-wider cursor-pointer flex items-center gap-1.5 transition-all border border-blue-600"
                  title="Editar este orçamento e fazer correções"
                >
                  <Edit2 className="w-3.5 h-3.5 text-cyan-300" />
                  <span>Fazer Correções</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDownloadPDF(activeActionQuote)}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg text-xs uppercase tracking-wider shadow-md cursor-pointer flex items-center gap-1.5 transition-all"
                  title="Baixar diretamente o arquivo PDF (calibrado em folha A4 oficial)"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar PDF (A4)</span>
                </button>
                <button
                  type="button"
                  onClick={handleTriggerPrint}
                  className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider shadow-md cursor-pointer flex items-center gap-1.5 transition-all"
                  title="Abrir tela de impressão do navegador em folha A4"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Imprimir (A4)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintModalOpen(false)}
                  className="text-cyan-200 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Content */}
            <div className="p-6 overflow-y-auto max-h-[80vh] bg-white">
              <QuotePrintDocument quote={activeActionQuote} />
            </div>
          </div>
        </div>
      )}

      {/* 8. MODAL: VISUALIZAÇÃO & CONFERÊNCIA PRÉ-ENVIO */}
      {isPreviewModalOpen && activeActionQuote && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white border-2 border-slate-400 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col my-6 max-h-[92vh]">
            {/* Modal Header */}
            <div className="px-6 py-3.5 bg-[#1b365d] text-white flex items-center justify-between border-b border-blue-900">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-white rounded-lg p-0.5 flex items-center justify-center shrink-0">
                  <JCFCompanyLogo size="custom" className="w-7 h-7" variant="mono-black" showSubtitle={false} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase bg-blue-800 text-cyan-200 px-2 py-0.5 rounded tracking-wider">
                      Visualização Pré-Envio
                    </span>
                    <h3 className="text-sm font-black text-white uppercase tracking-wider">
                      {activeActionQuote.quoteNumber}
                    </h3>
                  </div>
                  <p className="text-[10px] text-cyan-200">
                    Conferência da proposta para {activeActionQuote.clientName} antes de disparar
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsPreviewModalOpen(false)}
                className="text-cyan-200 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Action / Correction Toolbar */}
            <div className="bg-slate-100 border-b border-slate-300 px-6 py-2.5 flex flex-wrap items-center justify-between gap-2">
              {/* Left: Edit & Delete controls */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsPreviewModalOpen(false);
                    handleOpenEditQuoteModal(activeActionQuote);
                  }}
                  className="px-3.5 py-1.5 bg-blue-700 hover:bg-blue-600 text-white font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  title="Abrir formulário de edição para fazer correções neste orçamento"
                >
                  <Edit2 className="w-3.5 h-3.5 text-cyan-300" />
                  <span>Fazer Correções</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleDeleteQuoteWithConfirm(activeActionQuote);
                  }}
                  className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition-colors"
                  title="Excluir este orçamento"
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-600" />
                  <span>Excluir</span>
                </button>
              </div>

              {/* Right: Dispatch channels */}
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase text-slate-500 hidden sm:inline">Disparar:</span>
                <button
                  type="button"
                  onClick={() => {
                    setIsPreviewModalOpen(false);
                    setIsWhatsAppModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  title="Enviar proposta formatada para o cliente via WhatsApp"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsPreviewModalOpen(false);
                    setIsEmailModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-blue-800 hover:bg-blue-700 text-white font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  title="Enviar proposta com layout oficial por E-mail"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>E-mail</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDownloadPDF(activeActionQuote)}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  title="Baixar diretamente o arquivo PDF (Folha A4)"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar PDF (A4)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsPreviewModalOpen(false);
                    setIsPrintModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-black rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  title="Imprimir ou Salvar em PDF"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Imprimir (A4)</span>
                </button>
              </div>
            </div>

            {/* Document Body */}
            <div className="p-6 overflow-y-auto max-h-[75vh] bg-white">
              <QuotePrintDocument quote={activeActionQuote} />
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium">
                Verifique atentamente os valores, garantia e dados antes do envio.
              </span>
              <button
                type="button"
                onClick={() => setIsPreviewModalOpen(false)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-lg uppercase tracking-wider transition-colors cursor-pointer"
              >
                Fechar Visualização
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 9. MODAL: WHATSAPP DISPATCH */}
      {activeActionQuote && (
        <QuoteWhatsAppModal
          quote={activeActionQuote}
          isOpen={isWhatsAppModalOpen}
          onClose={() => setIsWhatsAppModalOpen(false)}
          onMarkAsSent={(q) => handleUpdateStatus(q, 'SENT')}
          onEditQuote={handleOpenEditQuoteModal}
        />
      )}

      {/* 10. MODAL: EMAIL DISPATCH */}
      {activeActionQuote && (
        <QuoteEmailModal
          quote={activeActionQuote}
          isOpen={isEmailModalOpen}
          onClose={() => setIsEmailModalOpen(false)}
          onMarkAsSent={(q) => handleUpdateStatus(q, 'SENT')}
          onEditQuote={handleOpenEditQuoteModal}
        />
      )}

      {/* 11. MODAL: QUICK NEW CLIENT */}
      {isNewClientModalOpen && onAddClient && (
        <QuickNewClientModal
          isOpen={isNewClientModalOpen}
          onClose={() => setIsNewClientModalOpen(false)}
          onSaveClient={onAddClient}
          initialName={formClientName}
          onClientCreated={(createdClient) => {
            setFormClientId(createdClient.id);
            setFormClientName(createdClient.name);
            setFormClientDocument(createdClient.document || '');
            setFormClientPhone(createdClient.phone || '');
            setFormClientEmail(createdClient.email || '');
            setFormClientAddress(createdClient.address || '');
          }}
        />
      )}

      {/* 12. MODAL: QUICK NEW SERVICE (F3) */}
      {isNewServiceModalOpen && onAddService && (
        <QuickNewServiceModal
          isOpen={isNewServiceModalOpen}
          onClose={() => setIsNewServiceModalOpen(false)}
          onSaveService={onAddService}
          existingServices={services}
          onServiceCreated={(createdService) => {
            const desc = createdService.description && createdService.description !== createdService.name
              ? `${createdService.name} - ${createdService.description}`
              : createdService.name;
            const newItem: QuoteItem = {
              id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
              type: 'SERVICO',
              description: desc,
              quantity: 1,
              unit: createdService.unit || 'UN',
              unitPrice: createdService.estimatedCost,
              total: createdService.estimatedCost
            };
            setFormItems(prev => [...prev, newItem]);
            setItemType('SERVICO');
            setItemDesc('');
            setItemPrice(0);
            setItemQty(1);
            setItemUnit('UN');
            showFeedback(`Serviço "${createdService.name}" inserido diretamente na proposta!`, 'success');
          }}
        />
      )}

      {/* 13. MODAL: QUICK NEW EQUIPMENT (F4) */}
      {isNewEquipmentModalOpen && onAddEquipment && (
        <QuickNewEquipmentModal
          isOpen={isNewEquipmentModalOpen}
          onClose={() => setIsNewEquipmentModalOpen(false)}
          clients={clients}
          initialClientId={formClientId}
          onSaveEquipment={onAddEquipment}
          onEquipmentCreated={(createdEquip) => {
            setFormEquipmentId(createdEquip.id);
            setFormEquipmentName(`${createdEquip.name} • ${createdEquip.model}`);
            showFeedback(`Equipamento "${createdEquip.name}" vinculado à proposta!`, 'success');
          }}
        />
      )}

      {/* 14. MODAL: PRICE TABLE SEARCH & INSERT (F7) */}
      {isPriceTableModalOpen && (
        <PriceTableModal
          isOpen={isPriceTableModalOpen}
          onClose={() => setIsPriceTableModalOpen(false)}
          services={services}
          inventory={inventory}
          onInsertItems={handleInsertFromPriceTable}
          onOpenNewService={onAddService ? () => {
            setIsPriceTableModalOpen(false);
            setIsNewServiceModalOpen(true);
          } : undefined}
          title="Tabela de Preços & Catálogo da Oficina"
          subtitle="Pesquise serviços e peças para inserir diretamente no orçamento"
        />
      )}
    </div>
  );
}
