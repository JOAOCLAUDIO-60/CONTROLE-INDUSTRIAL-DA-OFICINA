import React, { useState } from 'react';
import { Client, Equipment, MaintenanceHistoryEntry, ServiceOrder } from '../types';
import { 
  Plus, Search, Edit2, Trash2, Cpu, Tag, Settings, Wrench, Calendar, User, 
  Layers, ChevronRight, X, Eye, FileText, CheckCircle, Info, AlertTriangle,
  List, LayoutGrid
} from 'lucide-react';

interface EquipmentManagerProps {
  equipments: Equipment[];
  clients: Client[];
  history: MaintenanceHistoryEntry[];
  orders: ServiceOrder[];
  onAddEquipment: (equipment: Omit<Equipment, 'id' | 'createdAt'>) => void;
  onEditEquipment: (equipment: Equipment) => void;
  onDeleteEquipment: (id: string) => void;
  onAddHistoryEntry: (entry: Omit<MaintenanceHistoryEntry, 'id' | 'createdAt'>) => void;
  onDeleteHistoryEntry: (id: string) => void;
  onOpenCatalog?: (equipmentId: string) => void;
}

export default function EquipmentManager({
  equipments,
  clients,
  history,
  orders,
  onAddEquipment,
  onEditEquipment,
  onDeleteEquipment,
  onAddHistoryEntry,
  onDeleteHistoryEntry,
  onOpenCatalog,
}: EquipmentManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'LIST' | 'GRID'>('LIST');
  const [isEquipModalOpen, setIsEquipModalOpen] = useState(false);
  const [editingEquipment, setEditingEquipment] = useState<Equipment | null>(null);

  // Sub-tabs for switching between Equipments and General History
  const [subTab, setSubTab] = useState<'EQUIPMENTS' | 'HISTORY_SEARCH'>('EQUIPMENTS');
  const [historySearchQuery, setHistorySearchQuery] = useState('');

  // Equipment Form states
  const [name, setName] = useState('');
  const [model, setModel] = useState('');
  const [type, setType] = useState('');
  const [patrimonyNumber, setPatrimonyNumber] = useState('');
  const [equipError, setEquipError] = useState('');

  // Deletion confirmation states
  const [deleteEquipConfirmation, setDeleteEquipConfirmation] = useState<{ id: string; name: string; hasOrders: boolean } | null>(null);
  const [deleteHistoryConfirmation, setDeleteHistoryConfirmation] = useState<string | null>(null);

  // Maintenance History Modal states
  const [selectedEquipment, setSelectedEquipment] = useState<Equipment | null>(null);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isAddHistoryOpen, setIsAddHistoryOpen] = useState(false);

  // History Entry Form states
  const [historyDate, setHistoryDate] = useState('');
  const [historyType, setHistoryType] = useState('');
  const [historyParts, setHistoryParts] = useState('');
  const [historyTech, setHistoryTech] = useState('');
  const [historyError, setHistoryError] = useState('');

  const filteredEquipments = equipments
    .filter((equip) => {
      const patrimony = equip.patrimonyNumber || '';
      return (
        equip.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        equip.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
        equip.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
        patrimony.toLowerCase().includes(searchQuery.toLowerCase())
      );
    })
    .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR', { sensitivity: 'base' }));

  const filteredHistory = history
    .filter((entry) => {
      const equip = equipments.find((e) => e.id === entry.equipmentId);
      const equipName = equip ? equip.name : '';
      const equipModel = equip ? equip.model : '';
      const equipPatrimony = equip && equip.patrimonyNumber ? equip.patrimonyNumber : '';
      const searchLower = historySearchQuery.toLowerCase();
      
      return (
        entry.serviceType.toLowerCase().includes(searchLower) ||
        entry.partsUsed.toLowerCase().includes(searchLower) ||
        entry.technician.toLowerCase().includes(searchLower) ||
        equipName.toLowerCase().includes(searchLower) ||
        equipModel.toLowerCase().includes(searchLower) ||
        equipPatrimony.toLowerCase().includes(searchLower)
      );
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const openAddEquipModal = () => {
    setEditingEquipment(null);
    setName('');
    setModel('');
    setType('');
    setPatrimonyNumber('');
    setEquipError('');
    setIsEquipModalOpen(true);
  };

  const openEditEquipModal = (equip: Equipment) => {
    setEditingEquipment(equip);
    setName(equip.name);
    setModel(equip.model);
    setType(equip.type);
    setPatrimonyNumber(equip.patrimonyNumber || '');
    setEquipError('');
    setIsEquipModalOpen(true);
  };

  const handleEquipSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !model.trim() || !type.trim()) {
      setEquipError('Todos os campos são obrigatórios.');
      return;
    }

    if (editingEquipment) {
      onEditEquipment({
        ...editingEquipment,
        name,
        model,
        type,
        patrimonyNumber: patrimonyNumber.trim() || undefined,
      });
    } else {
      onAddEquipment({
        name,
        model,
        type,
        patrimonyNumber: patrimonyNumber.trim() || undefined,
      });
    }
    setIsEquipModalOpen(false);
  };

  const handleEquipDelete = (id: string, name: string) => {
    const equipOrders = orders.filter((o) => o.equipmentId === id);
    setDeleteEquipConfirmation({
      id,
      name,
      hasOrders: equipOrders.length > 0
    });
  };

  const openHistoryModal = (equip: Equipment) => {
    setSelectedEquipment(equip);
    setIsHistoryModalOpen(true);
    setIsAddHistoryOpen(false);
    // Reset entry form
    setHistoryDate(new Date().toISOString().split('T')[0]);
    setHistoryType('');
    setHistoryParts('');
    setHistoryTech('');
    setHistoryError('');
  };

  const handleAddHistorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEquipment) return;
    if (!historyDate || !historyType.trim() || !historyTech.trim()) {
      setHistoryError('Data, Tipo de Serviço e Técnico são obrigatórios.');
      return;
    }

    onAddHistoryEntry({
      equipmentId: selectedEquipment.id,
      date: historyDate,
      serviceType: historyType,
      partsUsed: historyParts || 'Nenhuma',
      technician: historyTech,
    });

    // Reset fields & collapse form
    setHistoryType('');
    setHistoryParts('');
    setHistoryTech('');
    setHistoryError('');
    setIsAddHistoryOpen(false);
  };

  return (
    <div className="bg-white rounded-2xl border-2 border-[#b0bec5] shadow-md p-6" id="equipment-manager-container">
      {/* Header Controls */}
      <div className="bg-[#1b365d] text-white p-4 sm:p-5 rounded-xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6 shadow-sm">
        <div>
          <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-300" />
            <span>Cadastro de Equipamentos</span>
          </h2>
          <p className="text-xs text-cyan-100 mt-0.5 font-medium">Controle o catálogo de ativos industriais e seus históricos de manutenção</p>
        </div>
        <button
          id="btn-add-equipment"
          onClick={openAddEquipModal}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs tracking-wider transition-all duration-200 shadow-sm cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>NOVO EQUIPAMENTO</span>
        </button>
      </div>

      {/* Sub tabs: Equipamentos / Histórico Geral */}
      <div className="flex items-center gap-2 border-b-2 border-slate-200 pb-4 mb-6" id="equipment-sub-tabs">
        <button
          type="button"
          onClick={() => setSubTab('EQUIPMENTS')}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 ${
            subTab === 'EQUIPMENTS'
              ? 'bg-[#0052cc] text-white shadow-sm'
              : 'bg-slate-100 border border-slate-300 text-slate-700 hover:text-slate-950 hover:bg-slate-200'
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>Equipamentos</span>
        </button>
        <button
          type="button"
          onClick={() => setSubTab('HISTORY_SEARCH')}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 ${
            subTab === 'HISTORY_SEARCH'
              ? 'bg-[#0052cc] text-white shadow-sm'
              : 'bg-slate-100 border border-slate-300 text-slate-700 hover:text-slate-950 hover:bg-slate-200'
          }`}
        >
          <Wrench className="w-4 h-4" />
          <span>Pesquisar Histórico Geral</span>
        </button>
      </div>

      {subTab === 'EQUIPMENTS' ? (
        <>
          {/* Search Input & View Toggle */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-6" id="search-filter-equipment-row">
            <div className="relative flex-1" id="search-equipment-wrapper">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                id="input-search-equipments"
                type="text"
                placeholder="Buscar equipamento por nome, modelo, tipo ou patrimônio..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] transition-all font-medium"
              />
            </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-1.5 self-end sm:self-auto bg-slate-100 p-1.5 rounded-xl border border-slate-300" id="equipments-view-mode-toggle">
          <button
            type="button"
            id="btn-view-mode-list"
            onClick={() => setViewMode('LIST')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
              viewMode === 'LIST'
                ? 'bg-[#0052cc] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-950'
            }`}
            title="Visualização em Lista"
          >
            <List className="w-3.5 h-3.5" />
            <span>Lista</span>
          </button>
          <button
            type="button"
            id="btn-view-mode-grid"
            onClick={() => setViewMode('GRID')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
              viewMode === 'GRID'
                ? 'bg-[#0052cc] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-950'
            }`}
            title="Visualização em Grade"
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Grade</span>
          </button>
        </div>
      </div>

      {/* Equipments Content */}
      {filteredEquipments.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 px-4 border-2 border-dashed border-slate-300 rounded-2xl bg-slate-50" id="empty-equipments-state">
          <div className="p-3 bg-white border border-slate-200 shadow-2xs rounded-full text-slate-400 mb-3">
            <Cpu className="w-6 h-6" />
          </div>
          <p className="text-xs font-black text-slate-800 uppercase">Nenhum equipamento encontrado</p>
          <p className="text-[11px] text-slate-500 mt-1 font-medium">Experimente buscar outro termo ou cadastre um novo equipamento</p>
        </div>
      ) : viewMode === 'LIST' ? (
        <div className="overflow-x-auto border-2 border-slate-200 rounded-2xl bg-white shadow-xs" id="equipments-list-table-wrapper">
          <table className="w-full text-left border-collapse" id="equipments-list-table">
            <thead>
              <tr className="border-b-2 border-slate-200 bg-[#1b365d] text-white font-black uppercase tracking-wider text-[10px] select-none">
                <th className="py-3.5 px-4 font-black">Nome do Equipamento</th>
                <th className="py-3.5 px-4 font-black">Modelo</th>
                <th className="py-3.5 px-4 font-black">Tipo</th>
                <th className="py-3.5 px-4 font-black text-center">Logs Histórico</th>
                <th className="py-3.5 px-4 font-black text-center">Status OS</th>
                <th className="py-3.5 px-4 font-black text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {filteredEquipments.map((equip) => {
                const equipHistory = history.filter((h) => h.equipmentId === equip.id);
                const activeOSCount = orders.filter(
                  (o) => o.equipmentId === equip.id && (o.status === 'PENDING' || o.status === 'IN_PROGRESS')
                ).length;

                return (
                  <tr
                    id={`table-row-equip-${equip.id}`}
                    key={equip.id}
                    className="hover:bg-blue-50/60 transition-colors group"
                  >
                    <td className="py-3.5 px-4 font-black text-slate-900 group-hover:text-[#0052cc] transition-colors">
                      <div className="flex items-center gap-2.5">
                        <Cpu className="w-4 h-4 text-[#1b365d] group-hover:text-[#0052cc] transition-colors shrink-0" />
                        <div className="flex flex-col">
                          <span>{equip.name}</span>
                          {equip.patrimonyNumber && (
                            <span className="inline-block text-[9px] text-amber-900 font-mono font-bold bg-amber-100 border border-amber-300 px-1.5 py-0.2 rounded mt-0.5 w-fit" title="Número de Patrimônio">
                              Patr: {equip.patrimonyNumber}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-700 font-bold">
                      <div className="flex items-center gap-1.5">
                        <Tag className="w-3 h-3 text-[#0052cc] shrink-0" />
                        <span>{equip.model}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-700 font-bold">
                      <div className="flex items-center gap-1.5">
                        <Layers className="w-3 h-3 text-[#0052cc] shrink-0" />
                        <span>{equip.type}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-slate-100 border border-slate-300 text-[10px] font-mono text-slate-700 font-bold">
                        {equipHistory.length} LOGS
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {activeOSCount > 0 ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-amber-100 border border-amber-300 text-[10px] font-black text-amber-900 animate-pulse">
                          {activeOSCount} ATIVA
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-slate-100 border border-slate-200 text-[10px] font-bold text-slate-500">
                          Nenhuma Ativa
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {onOpenCatalog && (
                          <button
                            type="button"
                            onClick={() => onOpenCatalog(equip.id)}
                            className="p-1.5 bg-blue-50 hover:bg-blue-100 text-[#0052cc] rounded-lg border border-blue-200 transition-all cursor-pointer flex items-center gap-1 text-[10px] font-black uppercase tracking-wider"
                            title="Ver Catálogo de Vista Explodida e Peças"
                          >
                            <Layers className="w-3 h-3 text-[#0052cc]" />
                            <span>Vista Explodida</span>
                          </button>
                        )}
                        <button
                          id={`btn-history-equip-${equip.id}`}
                          onClick={() => openHistoryModal(equip)}
                          className="p-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg border border-indigo-200 transition-all cursor-pointer flex items-center gap-1 text-[10px] font-black uppercase tracking-wider"
                          title="Ver Histórico de Manutenção"
                        >
                          <Wrench className="w-3 h-3 text-indigo-700" />
                          <span>Histórico</span>
                        </button>
                        <button
                          id={`btn-edit-equip-${equip.id}`}
                          onClick={() => openEditEquipModal(equip)}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 rounded-lg border border-slate-300 transition-all cursor-pointer"
                          title="Editar"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          id={`btn-delete-equip-${equip.id}`}
                          onClick={() => handleEquipDelete(equip.id, equip.name)}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg border border-rose-200 transition-all cursor-pointer"
                          title="Excluir"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="equipments-grid">
          {filteredEquipments.map((equip) => {
            const client = clients.find((c) => c.id === equip.clientId);
            const equipHistory = history.filter((h) => h.equipmentId === equip.id);
            const activeOSCount = orders.filter(
              (o) => o.equipmentId === equip.id && (o.status === 'PENDING' || o.status === 'IN_PROGRESS')
            ).length;

            return (
              <div
                id={`equipment-card-${equip.id}`}
                key={equip.id}
                className="group bg-white border-2 border-slate-200 rounded-2xl p-5 hover:border-[#0052cc] hover:shadow-md transition-all duration-200 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-[#0052cc] group-hover:bg-blue-100 transition-colors">
                      <Cpu className="w-5 h-5" />
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        id={`btn-edit-equip-${equip.id}`}
                        onClick={() => openEditEquipModal(equip)}
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 hover:text-slate-900 border border-slate-200 transition-colors cursor-pointer"
                        title="Editar equipamento"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        id={`btn-delete-equip-${equip.id}`}
                        onClick={() => handleEquipDelete(equip.id, equip.name)}
                        className="p-1.5 bg-rose-50 hover:bg-rose-100 rounded-lg text-rose-600 hover:text-rose-800 border border-rose-200 transition-colors cursor-pointer"
                        title="Excluir equipamento"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="mt-4">
                    <h3 className="font-black text-slate-900 group-hover:text-[#0052cc] transition-colors text-sm leading-snug">
                      {equip.name}
                    </h3>
                    {equip.patrimonyNumber && (
                      <span className="inline-flex items-center gap-1 mt-1.5 text-[9px] text-amber-900 font-mono font-black bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded">
                        PATR: {equip.patrimonyNumber}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2.5 mt-4 text-xs text-slate-600 border-t border-slate-200 pt-3.5">
                    <div className="space-y-1 bg-slate-50 p-2 rounded-lg border border-slate-200">
                      <span className="text-[9px] uppercase font-bold text-slate-500 block tracking-wider">Modelo</span>
                      <span className="font-bold text-slate-800 flex items-center gap-1 font-mono text-xs">
                        <Tag className="w-3 h-3 text-[#0052cc]" />
                        {equip.model}
                      </span>
                    </div>
                    <div className="space-y-1 bg-slate-50 p-2 rounded-lg border border-slate-200">
                      <span className="text-[9px] uppercase font-bold text-slate-500 block tracking-wider">Tipo</span>
                      <span className="font-bold text-slate-800 flex items-center gap-1 font-mono text-xs">
                        <Layers className="w-3 h-3 text-[#0052cc]" />
                        {equip.type}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-5 border-t border-slate-200 pt-3.5 flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex gap-1.5">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-100 border border-slate-300 text-[10px] font-mono text-slate-700 font-bold">
                      {equipHistory.length} LOGS
                    </span>
                    {activeOSCount > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-100 border border-amber-300 text-[10px] font-black text-amber-900 animate-pulse">
                        {activeOSCount} ATIVA
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    {onOpenCatalog && (
                      <button
                        type="button"
                        onClick={() => onOpenCatalog(equip.id)}
                        className="flex items-center gap-1 text-[11px] text-[#0052cc] hover:text-blue-800 font-black tracking-wider uppercase py-1 px-2.5 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer border border-blue-200"
                        title="Ver Vista Explodida & Catálogo de Peças"
                      >
                        <Layers className="w-3.5 h-3.5" />
                        <span>Vista Explodida</span>
                      </button>
                    )}
                    <button
                      id={`btn-history-equip-${equip.id}`}
                      onClick={() => openHistoryModal(equip)}
                      className="flex items-center gap-1 text-[11px] text-indigo-700 hover:text-indigo-900 font-black tracking-wider uppercase py-1 px-2.5 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer border border-indigo-200"
                      title="Ver Histórico de Manutenção"
                    >
                      <Wrench className="w-3.5 h-3.5" />
                      <span>Histórico</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
        </>
      ) : (
        <div className="space-y-6" id="general-history-search-view">
          {/* History Search Input */}
          <div className="relative" id="search-history-wrapper">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input
              id="input-search-history"
              type="text"
              placeholder="Buscar por equipamento, patrimônio, modelo, técnico, peças, ou serviço..."
              value={historySearchQuery}
              onChange={(e) => setHistorySearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] transition-all font-medium"
            />
          </div>

          {/* History Items List */}
          {filteredHistory.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 border-2 border-dashed border-slate-300 rounded-2xl bg-slate-50" id="empty-history-search-state">
              <div className="p-3 bg-white border border-slate-200 shadow-2xs rounded-full text-slate-400 mb-3">
                <Wrench className="w-6 h-6" />
              </div>
              <p className="text-xs font-black text-slate-800 uppercase">Nenhum registro de manutenção encontrado</p>
              <p className="text-[11px] text-slate-500 mt-1 font-medium">Experimente refinar o termo de busca ou selecione outro equipamento.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="history-grid-container">
              {filteredHistory.map((entry) => {
                const equip = equipments.find((e) => e.id === entry.equipmentId);
                return (
                  <div
                    key={entry.id}
                    id={`history-search-card-${entry.id}`}
                    className="group bg-white border-2 border-slate-200 rounded-2xl p-5 hover:border-[#0052cc] hover:shadow-md transition-all duration-200 flex flex-col justify-between"
                  >
                    <div>
                      {/* Equip Info & Date */}
                      <div className="flex justify-between items-start gap-2 pb-3 border-b border-slate-200">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-black text-slate-900 text-sm group-hover:text-[#0052cc] transition-colors">
                              {equip ? equip.name : 'Equipamento Removido'}
                            </span>
                            {equip?.patrimonyNumber && (
                              <span className="px-1.5 py-0.5 rounded text-[8px] font-mono font-black bg-amber-100 border border-amber-300 text-amber-900 uppercase">
                                Patr: {equip.patrimonyNumber}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-500 block font-bold">
                            {equip ? `${equip.model} • ${equip.type}` : ''}
                          </span>
                        </div>

                        <span className="inline-flex items-center gap-1 text-[10px] text-slate-600 font-bold bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">
                          <Calendar className="w-3 h-3 text-[#0052cc]" />
                          {new Date(entry.date + 'T12:00:00').toLocaleDateString('pt-BR')}
                        </span>
                      </div>

                      {/* Service / Diagnostic info */}
                      <div className="mt-4">
                        <span className="text-[9px] uppercase font-black text-slate-500 tracking-wider block mb-1">Serviço Realizado</span>
                        <p className="text-xs text-slate-800 font-semibold leading-relaxed">
                          {entry.serviceType}
                        </p>
                      </div>

                      {/* Detail section */}
                      <div className="grid grid-cols-2 gap-3.5 mt-4 text-[11px] bg-slate-50 p-3 rounded-xl border border-slate-200">
                        <div>
                          <span className="text-slate-500 uppercase font-black block text-[8px] tracking-wider mb-0.5">Peças Utilizadas</span>
                          <span className="font-bold text-slate-800 break-words block">{entry.partsUsed}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 uppercase font-black block text-[8px] tracking-wider mb-0.5">Técnico</span>
                          <span className="font-bold text-slate-800 flex items-center gap-1">
                            <User className="w-3.5 h-3.5 text-[#0052cc] shrink-0" />
                            {entry.technician}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200 flex justify-end gap-2.5">
                      {equip && (
                        <button
                          onClick={() => openHistoryModal(equip)}
                          className="flex items-center gap-1.5 text-[10px] font-black text-[#0052cc] hover:text-blue-800 uppercase tracking-wider bg-blue-50 hover:bg-blue-100 border border-blue-200 px-3 py-1.5 rounded-xl transition-all cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Ficha do Ativo</span>
                        </button>
                      )}
                      <button
                        onClick={() => setDeleteHistoryConfirmation(entry.id)}
                        className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl border border-rose-200 transition-all cursor-pointer"
                        title="Excluir Registro"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Equipment Add/Edit Modal */}
      {isEquipModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="equip-form-modal">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs" onClick={() => setIsEquipModalOpen(false)}></div>
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden border-2 border-[#b0bec5] animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-6 py-4 bg-[#1b365d] text-white">
              <h3 className="font-black text-white text-sm uppercase tracking-wider flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-300" />
                <span>{editingEquipment ? 'Editar Equipamento' : 'Cadastrar Equipamento'}</span>
              </h3>
              <button
                id="btn-close-equip-modal"
                onClick={() => setIsEquipModalOpen(false)}
                className="p-1.5 text-cyan-100 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEquipSubmit} className="p-6 space-y-4">
              {equipError && (
                <div className="p-3 bg-rose-50 text-rose-700 rounded-xl text-xs font-bold border border-rose-300" id="equip-form-error">
                  {equipError}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700">
                  Nome do Equipamento
                </label>
                <input
                  id="equip-name-input"
                  type="text"
                  placeholder="Ex: Torno Mecânico CNC"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-medium"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700">
                    Modelo
                  </label>
                  <input
                    id="equip-model-input"
                    type="text"
                    placeholder="Ex: ROMI Centur 30D"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-mono font-medium"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-700">
                    Tipo / Categoria
                  </label>
                  <input
                    id="equip-type-input"
                    type="text"
                    placeholder="Ex: Usinagem"
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-mono font-medium"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <span>Número de Patrimônio</span>
                  <span className="text-[10px] text-slate-500 font-normal capitalize">(Opcional / Se houver)</span>
                </label>
                <input
                  id="equip-patrimony-input"
                  type="text"
                  placeholder="Ex: PAT-2026-99 ou 14859"
                  value={patrimonyNumber}
                  onChange={(e) => setPatrimonyNumber(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-mono font-medium"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <button
                  id="btn-cancel-equip-form"
                  type="button"
                  onClick={() => setIsEquipModalOpen(false)}
                  className="px-4 py-2 text-xs font-black uppercase tracking-wider text-slate-700 hover:text-slate-950 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  id="btn-submit-equip-form"
                  type="submit"
                  className="px-5 py-2 text-xs font-black uppercase tracking-wider text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-xl transition-all shadow-sm cursor-pointer"
                >
                  {editingEquipment ? 'SALVAR ALTERAÇÕES' : 'CADASTRAR'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Equipment Maintenance History Modal (FICHA DO EQUIPAMENTO) */}
      {isHistoryModalOpen && selectedEquipment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="history-detail-modal">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs" onClick={() => setIsHistoryModalOpen(false)}></div>
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden border-2 border-[#b0bec5] animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between px-6 py-5 bg-[#1b365d] text-white">
              <div>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-white/20 text-[10px] font-black text-cyan-100 uppercase tracking-wider mb-2">
                  Ficha do Ativo
                </span>
                <h3 className="font-black text-white text-base uppercase tracking-wider">
                  {selectedEquipment.name}
                </h3>
              </div>
              <button
                id="btn-close-history-modal"
                onClick={() => setIsHistoryModalOpen(false)}
                className="p-1.5 text-cyan-100 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body / Scrollable Area */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              
              {/* Equipment Specifications Box */}
              <div className={`grid ${selectedEquipment.patrimonyNumber ? 'grid-cols-4' : 'grid-cols-3'} gap-4 bg-slate-50 rounded-xl p-4 border border-slate-200 text-xs`}>
                <div>
                  <span className="text-slate-500 uppercase font-bold tracking-wider text-[9px] block mb-0.5">Modelo</span>
                  <span className="font-bold text-slate-900 font-mono">{selectedEquipment.model}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase font-bold tracking-wider text-[9px] block mb-0.5">Tipo</span>
                  <span className="font-bold text-slate-900 font-mono">{selectedEquipment.type}</span>
                </div>
                {selectedEquipment.patrimonyNumber && (
                  <div>
                    <span className="text-amber-800 uppercase font-bold tracking-wider text-[9px] block mb-0.5">Patrimônio</span>
                    <span className="font-black text-amber-900 font-mono bg-amber-100 px-1.5 py-0.5 rounded border border-amber-300">{selectedEquipment.patrimonyNumber}</span>
                  </div>
                )}
                <div>
                  <span className="text-slate-500 uppercase font-bold tracking-wider text-[9px] block mb-0.5">Inclusão</span>
                  <span className="font-bold text-slate-800 font-mono">
                    {new Date(selectedEquipment.createdAt || '').toLocaleDateString('pt-BR')}
                  </span>
                </div>
              </div>

              {/* Maintenance Section Header */}
              <div className="flex items-center justify-between border-b-2 border-slate-200 pb-3">
                <div className="flex items-center gap-2">
                  <Wrench className="w-5 h-5 text-[#0052cc]" />
                  <h4 className="font-black text-slate-900 uppercase tracking-wider text-xs">Histórico de Manutenções</h4>
                </div>
                {!isAddHistoryOpen && (
                  <button
                    id="btn-trigger-add-history"
                    onClick={() => setIsAddHistoryOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0052cc] text-white hover:bg-blue-700 text-xs font-black rounded-xl transition-all cursor-pointer shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>REGISTRAR MANUTENÇÃO</span>
                  </button>
                )}
              </div>

              {/* New Maintenance Entry Inline Form */}
              {isAddHistoryOpen && (
                <div className="bg-slate-50 rounded-xl p-4 border-2 border-slate-200 space-y-3.5 animate-in slide-in-from-top-2 duration-150" id="add-history-form">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <span className="text-xs font-black text-slate-900 uppercase tracking-wider">Novo Registro de Manutenção</span>
                    <button
                      id="btn-close-add-history"
                      type="button"
                      onClick={() => setIsAddHistoryOpen(false)}
                      className="text-slate-500 hover:text-slate-900 text-xs font-black cursor-pointer uppercase tracking-wider"
                    >
                      Cancelar
                    </button>
                  </div>

                  <form onSubmit={handleAddHistorySubmit} className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    <div className="md:col-span-1 space-y-1">
                      <label className="block text-[9px] font-black text-slate-600 uppercase tracking-wider">DATA DO SERVIÇO</label>
                      <input
                        id="history-date-input"
                        type="date"
                        value={historyDate}
                        onChange={(e) => setHistoryDate(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:border-[#0052cc] font-medium"
                        required
                      />
                    </div>
                    <div className="md:col-span-1 space-y-1">
                      <label className="block text-[9px] font-black text-slate-600 uppercase tracking-wider">TÉCNICO RESPONSÁVEL</label>
                      <input
                        id="history-tech-input"
                        type="text"
                        placeholder="Nome do Técnico"
                        value={historyTech}
                        onChange={(e) => setHistoryTech(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-medium"
                        required
                      />
                    </div>
                    <div className="md:col-span-2 space-y-1">
                      <label className="block text-[9px] font-black text-slate-600 uppercase tracking-wider">TIPO DE SERVIÇO REALIZADO</label>
                      <input
                        id="history-type-input"
                        type="text"
                        placeholder="Ex: Troca de filtros, ajuste de gaxetas e alinhamento"
                        value={historyType}
                        onChange={(e) => setHistoryType(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-medium"
                        required
                      />
                    </div>
                    <div className="md:col-span-2 space-y-1">
                      <label className="block text-[9px] font-black text-slate-600 uppercase tracking-wider">PEÇAS UTILIZADAS</label>
                      <input
                        id="history-parts-input"
                        type="text"
                        placeholder="Ex: Válvula 1/2', Óleo Mobil SHC (deixe em branco se não houver)"
                        value={historyParts}
                        onChange={(e) => setHistoryParts(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#0052cc] font-medium"
                      />
                    </div>

                    {historyError && (
                      <p className="md:col-span-2 text-[10px] text-rose-600 font-bold uppercase tracking-wider">{historyError}</p>
                    )}

                    <div className="md:col-span-2 flex justify-end gap-2 pt-2 border-t border-slate-200">
                      <button
                        id="btn-cancel-add-history"
                        type="button"
                        onClick={() => setIsAddHistoryOpen(false)}
                        className="px-3 py-1.5 bg-slate-200 text-slate-700 hover:text-slate-900 font-black text-[10px] uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
                      >
                        Descartar
                      </button>
                      <button
                        id="btn-save-history-entry"
                        type="submit"
                        className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider rounded-lg transition-all shadow-xs cursor-pointer"
                      >
                        Gravar Registro
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Maintenance Timeline / List */}
              <div className="space-y-4">
                {history.filter((h) => h.equipmentId === selectedEquipment.id).length === 0 ? (
                  <div className="text-center py-8 text-slate-500 border-2 border-dashed border-slate-300 rounded-xl bg-slate-50" id="empty-history-state">
                    <Wrench className="w-6 h-6 mx-auto text-slate-400 mb-2" />
                    <p className="text-xs font-black text-slate-700">Nenhum registro de manutenção ativo</p>
                    <p className="text-[10px] text-slate-500 mt-1">Use o formulário acima para registrar a primeira manutenção deste ativo.</p>
                  </div>
                ) : (
                  <div className="relative border-l-2 border-slate-200 pl-4 ml-2.5 space-y-5" id="history-timeline">
                    {history
                      .filter((h) => h.equipmentId === selectedEquipment.id)
                      // Sort by date descending
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((entry) => (
                        <div
                          id={`history-entry-${entry.id}`}
                          key={entry.id}
                          className="relative group/item animate-in fade-in-30"
                        >
                          {/* Dot marker */}
                          <span className="absolute -left-[21px] top-1.5 bg-white border-2 border-[#0052cc] rounded-full w-2.5 h-2.5 ring-4 ring-slate-100"></span>
                          
                          <div className="bg-white border-2 border-slate-200 rounded-xl p-4 hover:border-[#0052cc] transition-all shadow-xs">
                            <div className="flex items-start justify-between gap-2">
                              <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-[#0052cc] font-mono bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                                <Calendar className="w-3.5 h-3.5 text-[#0052cc]" />
                                {new Date(entry.date + 'T12:00:00').toLocaleDateString('pt-BR')}
                              </span>
                              
                              <button
                                id={`btn-delete-history-${entry.id}`}
                                onClick={() => setDeleteHistoryConfirmation(entry.id)}
                                className="text-slate-400 hover:text-rose-600 opacity-0 group-hover/item:opacity-100 transition-opacity p-0.5 rounded cursor-pointer"
                                title="Excluir do histórico"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            <h5 className="text-xs font-black text-slate-900 mt-2 leading-snug">
                              {entry.serviceType}
                            </h5>

                            <div className="grid grid-cols-2 gap-3.5 mt-3 text-[11px] bg-slate-50 p-3 rounded-lg border border-slate-200">
                              <div>
                                <span className="text-slate-500 uppercase font-black block text-[9px] tracking-wider mb-0.5">Peças Utilizadas</span>
                                <span className="font-bold text-slate-800">{entry.partsUsed}</span>
                              </div>
                              <div>
                                <span className="text-slate-500 uppercase font-black block text-[9px] tracking-wider mb-0.5">Responsável</span>
                                <span className="font-bold text-slate-800 flex items-center gap-1.5">
                                  <User className="w-3 h-3 text-[#0052cc] shrink-0" />
                                  {entry.technician}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                id="btn-close-history-modal-footer"
                onClick={() => setIsHistoryModalOpen(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-black text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
              >
                Fechar Ficha
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Delete Equipment Confirmation Modal */}
      {deleteEquipConfirmation && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-150" id="delete-equip-modal">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs" onClick={() => setDeleteEquipConfirmation(null)}></div>
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden border-2 border-rose-300 p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2 bg-rose-50 rounded-xl border border-rose-200">
                <Trash2 className="w-5 h-5" />
              </div>
              <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider">Confirmar Exclusão</h3>
            </div>
            
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              Tem certeza de que deseja excluir o equipamento <strong className="text-slate-900">"{deleteEquipConfirmation.name}"</strong>?
            </p>

            {deleteEquipConfirmation.hasOrders && (
              <div className="p-3 bg-amber-50 text-amber-900 rounded-xl text-xs font-semibold border border-amber-300 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                <span>Atenção: Este equipamento possui ordens de serviço associadas. Excluir o equipamento também poderá impactar essas OSs.</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200">
              <button
                id="btn-cancel-delete-equip"
                onClick={() => setDeleteEquipConfirmation(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider rounded-xl transition-colors cursor-pointer border border-slate-300"
              >
                Cancelar
              </button>
              <button
                id="btn-confirm-delete-equip"
                onClick={() => {
                  onDeleteEquipment(deleteEquipConfirmation.id);
                  setDeleteEquipConfirmation(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-black uppercase tracking-wider rounded-xl transition-colors shadow-sm cursor-pointer"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Maintenance History Entry Confirmation Modal */}
      {deleteHistoryConfirmation && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 animate-in fade-in duration-150" id="delete-history-modal">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs" onClick={() => setDeleteHistoryConfirmation(null)}></div>
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden border-2 border-rose-300 p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2 bg-rose-50 rounded-xl border border-rose-200">
                <Trash2 className="w-5 h-5" />
              </div>
              <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider">Excluir do Histórico</h3>
            </div>
            
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              Deseja realmente excluir este registro de manutenção? Esta ação não pode ser desfeita.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200">
              <button
                id="btn-cancel-delete-history"
                onClick={() => setDeleteHistoryConfirmation(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider rounded-xl transition-colors cursor-pointer border border-slate-300"
              >
                Cancelar
              </button>
              <button
                id="btn-confirm-delete-history"
                onClick={() => {
                  onDeleteHistoryEntry(deleteHistoryConfirmation);
                  setDeleteHistoryConfirmation(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-black uppercase tracking-wider rounded-xl transition-colors shadow-sm cursor-pointer"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
