import React, { useState } from 'react';
import { Client, Equipment, ServiceOrder } from '../types';
import { Plus, Search, Edit2, Trash2, MapPin, Phone, FileText, UserPlus, X, Briefcase, AlertTriangle, Building2, Tag, Users } from 'lucide-react';
import { formatPhoneNumber } from '../utils/phoneFormatter';

interface ClientManagerProps {
  clients: Client[];
  equipments: Equipment[];
  orders?: ServiceOrder[];
  onAddClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  onEditClient: (client: Client) => void;
  onDeleteClient: (id: string) => void;
}

export default function ClientManager({
  clients,
  equipments,
  orders = [],
  onAddClient,
  onEditClient,
  onDeleteClient,
}: ClientManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);

  // Lista padrão e persistida de Ramos / Atividades do Cliente
  const DEFAULT_ACTIVITIES = [
    'PARTICULAR',
    'COMÉRCIO / VAREJO',
    'INDÚSTRIA METALÚRGICA',
    'MINERAÇÃO & CONSTRUÇÃO',
    'TRANSPORTE & LOGÍSTICA',
    'AGROPECUÁRIA & AGRONEGÓCIO',
    'ALIMENTOS & BEBIDAS',
    'PAPEL & PAPELÃO',
    'SERVIÇOS GERAIS',
    'PLÁSTICOS & POLÍMEROS',
    'SISTEMAS HIDRÁULICOS & MANUTENÇÃO',
    'OUTROS'
  ];

  const [activitiesList, setActivitiesList] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('oficina_client_activities');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          if (!parsed.includes('PARTICULAR')) {
            return ['PARTICULAR', ...parsed];
          }
          return parsed;
        }
      }
    } catch (e) {
      console.error('Erro ao ler oficina_client_activities:', e);
    }
    return DEFAULT_ACTIVITIES;
  });

  const [showActivitiesModal, setShowActivitiesModal] = useState(false);
  const [newActivityInput, setNewActivityInput] = useState('');

  const handleAddActivity = (actName: string) => {
    const trimmed = actName.trim().toUpperCase();
    if (!trimmed) return;
    if (activitiesList.some(a => a.toUpperCase() === trimmed)) {
      return;
    }
    const updated = [...activitiesList, trimmed];
    setActivitiesList(updated);
    localStorage.setItem('oficina_client_activities', JSON.stringify(updated));
    setActivity(trimmed);
    setNewActivityInput('');
  };

  const handleDeleteActivity = (actToDelete: string) => {
    if (activitiesList.length <= 1) return;
    const updated = activitiesList.filter(a => a !== actToDelete);
    setActivitiesList(updated);
    localStorage.setItem('oficina_client_activities', JSON.stringify(updated));
    if (activity === actToDelete) {
      setActivity(updated[0] || 'PARTICULAR');
    }
  };

  // Deletion confirmation state
  const [deleteConfirmation, setDeleteConfirmation] = useState<{ id: string; name: string; hasEquipments: boolean } | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [document, setDocument] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [activity, setActivity] = useState<string>('PARTICULAR');
  const [formError, setFormError] = useState('');

  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.document.includes(searchQuery) ||
      client.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (client.activity && client.activity.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const sortedClients = [...filteredClients].sort((a, b) =>
    a.name.localeCompare(b.name, 'pt-BR', { sensitivity: 'base' })
  );

  const openAddModal = () => {
    setEditingClient(null);
    setName('');
    setDocument('');
    setAddress('');
    setPhone('');
    setActivity(activitiesList[0] || 'PARTICULAR');
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (client: Client) => {
    setEditingClient(client);
    setName(client.name);
    setDocument(client.document);
    setAddress(client.address);
    setPhone(formatPhoneNumber(client.phone));
    setActivity(client.activity || activitiesList[0] || 'PARTICULAR');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      setFormError('Nome e Contato Telefônico são obrigatórios.');
      return;
    }

    if (editingClient) {
      onEditClient({
        ...editingClient,
        name,
        document: document.trim(),
        address: address.trim(),
        phone,
        activity,
      });
    } else {
      onAddClient({
        name,
        document: document.trim(),
        address: address.trim(),
        phone,
        activity,
      });
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    const clientOrderEquipIds = orders.filter((o) => o.clientId === id).map((o) => o.equipmentId);
    const clientEquips = equipments.filter((e) => clientOrderEquipIds.includes(e.id));
    setDeleteConfirmation({
      id,
      name,
      hasEquipments: clientEquips.length > 0
    });
  };

  return (
    <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="client-manager-container">
      {/* Header Controls */}
      <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-blue-900">
        <div>
          <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
            <Users className="w-5 h-5 text-cyan-300" />
            Cadastro de Clientes
          </h2>
          <p className="text-xs text-cyan-100 mt-0.5">Gerencie a base de clientes industriais da oficina</p>
        </div>
        <button
          id="btn-add-client"
          onClick={openAddModal}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer shrink-0"
          title="Cadastrar Novo Cliente (Tecla F2)"
        >
          <UserPlus className="w-4 h-4 text-slate-950" />
          <span>NOVO CLIENTE</span>
          <span className="bg-slate-950 text-amber-300 font-mono text-[10px] font-black px-1.5 py-0.5 rounded border border-amber-600 shadow-2xs">
            F2
          </span>
        </button>
      </div>

      <div className="p-4 sm:p-6 bg-[#e9edf2] space-y-4">
        {/* Search Input */}
        <div className="relative" id="search-client-wrapper">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4" />
          <input
            id="input-search-clients"
            type="text"
            placeholder="Buscar cliente por nome, documento ou endereço..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-blue-600 transition-all font-mono shadow-inner"
          />
        </div>

        {/* Clients List (Ordered Alphabetically) */}
        {sortedClients.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 px-4 border border-dashed border-slate-300 rounded-xl bg-white" id="empty-clients-state">
            <div className="p-3 bg-slate-100 rounded-full text-slate-500 mb-3">
              <Search className="w-6 h-6" />
            </div>
            <p className="text-xs font-bold text-slate-700">Nenhum cliente encontrado</p>
            <p className="text-[11px] text-slate-500 mt-1">Tente buscar por outro termo ou cadastre um novo cliente</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3" id="clients-list">
            {sortedClients.map((client) => {
              const clientOrderEquipIds = orders.filter((o) => o.clientId === client.id).map((o) => o.equipmentId);
              const clientEquips = equipments.filter((e) => clientOrderEquipIds.includes(e.id));
              return (
                <div
                  id={`client-card-${client.id}`}
                  key={client.id}
                  className="group bg-white border border-slate-300 rounded-xl p-4 hover:border-blue-600 hover:shadow-md transition-all duration-200 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="flex flex-col md:flex-row md:items-center gap-4 flex-1 min-w-0">
                    {/* Name, Document, and Equipment Counter */}
                    <div className="min-w-0 md:w-2/5">
                      <h3 className="font-black text-slate-900 group-hover:text-blue-700 transition-colors text-sm truncate">
                        {client.name}
                      </h3>
                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                        {client.document ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 border border-slate-300 text-[9px] font-mono font-bold text-slate-700">
                            <FileText className="w-2.5 h-2.5 text-slate-500" />
                            {client.document}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-[9px] font-mono text-slate-400 italic">
                            Sem Documento
                          </span>
                        )}
                        {client.activity && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-300 text-[9px] font-mono font-bold text-emerald-800 uppercase">
                            <Building2 className="w-2.5 h-2.5 text-emerald-600" />
                            {client.activity}
                          </span>
                        )}
                        {clientEquips.length > 0 && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-50 border border-blue-200 text-[9px] font-mono font-bold text-blue-800">
                            <Briefcase className="w-2.5 h-2.5 text-blue-600" />
                            {clientEquips.length} {clientEquips.length === 1 ? 'MÁQUINA' : 'MÁQUINAS'}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Address and Phone Fields */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 md:gap-4 flex-1 text-xs text-slate-600 md:border-l md:border-slate-200 md:pl-4">
                      <div className="flex items-start gap-2 min-w-0">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span className="truncate leading-relaxed" title={client.address || 'Nenhum endereço cadastrado'}>
                          {client.address || 'Nenhum endereço cadastrado'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-mono text-slate-800 font-bold">{client.phone}</span>
                      </div>
                    </div>
                  </div>

                  {/* Edit & Delete Actions */}
                  <div className="flex items-center gap-1 shrink-0 justify-end border-t border-slate-100 md:border-0 pt-3 md:pt-0">
                    <button
                      id={`btn-edit-client-${client.id}`}
                      onClick={() => openEditModal(client)}
                      className="p-1.5 hover:bg-blue-50 rounded-lg text-slate-500 hover:text-blue-700 transition-colors cursor-pointer"
                      title="Editar cliente"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      id={`btn-delete-client-${client.id}`}
                      onClick={() => handleDelete(client.id, client.name)}
                      className="p-1.5 hover:bg-red-50 rounded-lg text-slate-500 hover:text-red-600 transition-colors cursor-pointer"
                      title="Excluir cliente"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal Dialog */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="client-form-modal">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-[#000000]/60 backdrop-blur-xs" onClick={() => setIsModalOpen(false)}></div>
          {/* Container */}
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-300 animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-[#1b365d] text-white flex items-center justify-between px-6 py-4 border-b border-blue-900">
              <h3 className="font-extrabold text-white text-sm uppercase tracking-wider">
                {editingClient ? 'Editar Cliente' : 'Cadastrar Novo Cliente'}
              </h3>
              <button
                id="btn-close-client-modal"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-cyan-200 hover:text-white hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 bg-slate-50">
              {formError && (
                <div className="p-3 bg-red-50 text-red-700 rounded-xl text-xs font-bold border border-red-200" id="client-form-error">
                  {formError}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  Nome do Cliente / Razão Social
                </label>
                <input
                  id="client-name-input"
                  type="text"
                  placeholder="Ex: Metalúrgica Alfa S.A."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold uppercase placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  CPF ou CNPJ <span className="text-[10px] text-slate-500 normal-case font-normal">(Opcional)</span>
                </label>
                <input
                  id="client-document-input"
                  type="text"
                  placeholder="Ex: 12.345.678/0001-99 ou 123.456.789-00"
                  value={document}
                  onChange={(e) => setDocument(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold font-mono placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                    Ramo / Atividade do Cliente
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowActivitiesModal(true)}
                    className="text-[10px] text-blue-700 hover:text-blue-900 underline font-bold cursor-pointer"
                  >
                    Cadastrar / Gerenciar
                  </button>
                </div>
                <div className="flex gap-2">
                  <select
                    id="client-activity-select"
                    value={activity}
                    onChange={(e) => {
                      if (e.target.value === 'ADD_NEW') {
                        setShowActivitiesModal(true);
                      } else {
                        setActivity(e.target.value);
                      }
                    }}
                    className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 font-bold uppercase cursor-pointer shadow-inner"
                  >
                    {activitiesList.map((act) => (
                      <option key={act} value={act} className="bg-white text-slate-900 font-bold">
                        {act}
                      </option>
                    ))}
                    <option value="ADD_NEW" className="bg-white text-blue-700 font-extrabold">
                      + Cadastrar Novo Ramo / Atividade...
                    </option>
                  </select>
                  <button
                    type="button"
                    onClick={() => setShowActivitiesModal(true)}
                    className="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-blue-700 rounded-lg border border-slate-300 text-xs font-bold shrink-0 cursor-pointer"
                    title="Cadastrar ou Excluir Ramos / Atividades"
                  >
                    + / Excluir
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  Contato Telefônico
                </label>
                <input
                  id="client-phone-input"
                  type="text"
                  placeholder="Ex: (21) 98369-9728"
                  value={phone}
                  onChange={(e) => setPhone(formatPhoneNumber(e.target.value))}
                  className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold font-mono placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  Endereço Completo <span className="text-[10px] text-slate-500 normal-case font-normal">(Opcional)</span>
                </label>
                <textarea
                  id="client-address-input"
                  rows={3}
                  placeholder="Ex: Av. Industrial, 1500 - Distrito Industrial, Joinville - SC"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 resize-none leading-relaxed shadow-inner"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <button
                  id="btn-cancel-client-form"
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  id="btn-submit-client-form"
                  type="submit"
                  className="px-5 py-2.5 text-xs font-black uppercase tracking-wider text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-xl transition-all shadow-md cursor-pointer"
                >
                  {editingClient ? 'SALVAR ALTERAÇÕES' : 'CADASTRAR'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-150" id="delete-client-modal">
          <div className="absolute inset-0 bg-[#000000]/60 backdrop-blur-xs" onClick={() => setDeleteConfirmation(null)}></div>
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-red-200 p-6 space-y-4">
            <div className="flex items-center gap-3 text-red-600">
              <div className="p-2 bg-red-50 rounded-xl border border-red-200">
                <Trash2 className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider">Confirmar Exclusão</h3>
            </div>
            
            <p className="text-xs text-slate-600 leading-relaxed">
              Tem certeza de que deseja excluir o cliente <strong className="text-slate-900">"{deleteConfirmation.name}"</strong>?
            </p>

            {deleteConfirmation.hasEquipments && (
              <div className="p-3 bg-red-50 text-red-700 rounded-xl text-xs font-semibold border border-red-200 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                <span>Atenção: Este cliente possui equipamentos vinculados. Excluir o cliente deixará as ordens de serviço e ativos associados órfãos.</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                id="btn-cancel-delete"
                onClick={() => setDeleteConfirmation(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                id="btn-confirm-delete"
                onClick={() => {
                  onDeleteClient(deleteConfirmation.id);
                  setDeleteConfirmation(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors shadow-md cursor-pointer"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: GERENCIAR RAMOS / ATIVIDADES DOS CLIENTES */}
      {showActivitiesModal && (
        <div className="fixed inset-0 z-50 bg-[#000000]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-300 rounded-2xl max-w-md w-full p-6 shadow-2xl text-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-700" />
                <h3 className="font-extrabold text-base text-slate-900">Gerenciar Ramos / Atividades</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowActivitiesModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Cadastre novos ramos ou setores de atividade de clientes para seleção nos cadastros e fichas de entrada, ou remova itens desatualizados.
            </p>

            {/* FORMULARIO: NOVO RAMO / ATIVIDADE */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700 uppercase">Novo Ramo / Atividade</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Ex: FARMACÊUTICA, TÊXTIL..."
                  value={newActivityInput}
                  onChange={(e) => setNewActivityInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddActivity(newActivityInput);
                    }
                  }}
                  className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 uppercase focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 font-bold placeholder-slate-400 shadow-inner"
                />
                <button
                  type="button"
                  onClick={() => handleAddActivity(newActivityInput)}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-lg flex items-center gap-1 cursor-pointer transition-colors shrink-0 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar</span>
                </button>
              </div>
            </div>

            {/* LISTA DE ATIVIDADES */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <label className="block text-xs font-bold text-slate-600 uppercase">
                Atividades Cadastradas ({activitiesList.length})
              </label>
              <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                {activitiesList.map((act) => (
                  <div
                    key={act}
                    className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 hover:border-blue-400"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span className="uppercase">{act}</span>
                      {act === activity && (
                        <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1.5 py-0.5 rounded uppercase font-bold">
                          Selecionado
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteActivity(act)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                      title={`Excluir ${act}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setShowActivitiesModal(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-lg cursor-pointer"
              >
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
