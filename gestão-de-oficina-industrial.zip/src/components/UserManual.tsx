import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Search,
  Printer,
  ChevronDown,
  ChevronUp,
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Users,
  Cpu,
  Package,
  ShieldCheck,
  DollarSign,
  Cloud,
  Share2,
  Award,
  FileSpreadsheet,
  Briefcase,
  ClipboardList,
  UserCheck,
  Sparkles,
  HelpCircle,
  ArrowRight,
  Send,
  Camera,
  CheckSquare,
  LifeBuoy,
  Layers
} from 'lucide-react';

interface UserManualProps {
  onNavigateTab?: (tab: any) => void;
}

interface ManualSection {
  id: string;
  category: 'POP' | 'OS' | 'CADASTRO' | 'QUALIDADE' | 'GESTAO' | 'NUVEM' | 'FAQ';
  title: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
  targetTab?: string;
  badge?: string;
  steps: {
    stepNumber: string;
    title: string;
    description: string;
    details?: string[];
    importantNotice?: string;
  }[];
  tips?: string[];
}

export const UserManual: React.FC<UserManualProps> = ({ onNavigateTab }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    'pop-geral': true,
    'ciclo-os': true,
    'checkin-entrada': true
  });

  const toggleSection = (id: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const expandAll = () => {
    const allExpanded: Record<string, boolean> = {};
    manualSections.forEach(sec => {
      allExpanded[sec.id] = true;
    });
    setExpandedSections(allExpanded);
  };

  const collapseAll = () => {
    setExpandedSections({});
  };

  const handlePrint = () => {
    // Temporarily expand all for complete printout
    expandAll();
    setTimeout(() => {
      window.print();
    }, 200);
  };

  const manualSections: ManualSection[] = [
    {
      id: 'pop-geral',
      category: 'POP',
      title: 'Procedimento Operacional Padrão (POP) - Visão Global',
      subtitle: 'O fluxo padrão de atendimento na oficina: da chegada à entrega final',
      icon: CheckSquare,
      badge: 'Fluxo Principal',
      steps: [
        {
          stepNumber: '1',
          title: 'Recepção e Check-in com Registro Fotográfico',
          description: 'O cliente traz o equipamento defeituoso (bomba, motor, cilindro, válvula). A equipe de recepção realiza o check-in rápido registrando estado visual, sintomas relatados e emite o comprovante com QR Code.',
          details: [
            'Pesquisar cliente por Razão Social, CNPJ ou Nome Fantasia.',
            'Identificar o equipamento ou cadastrar novo com número de patrimônio (Asset Tag).',
            'Tirar ou anexar foto da condição externa de chegada.',
            'Verificar alerta antiduplicidade se o cliente tiver outras máquinas do mesmo modelo.'
          ],
          importantNotice: 'Nunca inicie a desmontagem sem emitir o comprovante de entrada para o portador do equipamento.'
        },
        {
          stepNumber: '2',
          title: 'Desmontagem, Perícia & Orçamento Técnico',
          description: 'O mecânico/técnico desmonta o conjunto, avalia desgaste de peças (hastes, camisas, palhetas, vedação) e cadastra o diagnóstico.',
          details: [
            'Vincular diagnóstico da biblioteca padrão ou digitar laudo personalizado.',
            'Selecionar serviços planejados da Tabela de Preços (brunimento, lapidação, substituição de vedações).',
            'Definir valor orçado e enviar para aprovação do cliente via WhatsApp ou E-mail.'
          ]
        },
        {
          stepNumber: '3',
          title: 'Aprovação & Execução dos Serviços na Bancada',
          description: 'Após a aprovação formal do cliente, a OS avança para "Em Execução". A equipe técnica realiza usinagem, montagem e teste hidrostático.',
          details: [
            'Baixar do estoque as vedações, reparos e fluidos utilizados.',
            'Executar montagem com torques e folgas recomendadas.',
            'Submeter o equipamento a teste de bancada (pressão nominal e verificação de vazamentos).'
          ]
        },
        {
          stepNumber: '4',
          title: 'Finalização, Emissão de Garantia e Entrega',
          description: 'Com o equipamento testado e aprovado, a OS é marcada como "Concluída". É gerado o Recibo & Termo de Garantia de 90 dias e o laudo de bancada.',
          details: [
            'Confirmar status de pagamento (À Vista, A Prazo ou Faturado).',
            'Imprimir ou enviar termo de garantia via WhatsApp/E-mail.',
            'O sistema atualiza automaticamente o histórico indelével do equipamento.'
          ]
        }
      ],
      tips: [
        'Mantenha o cliente sempre informado entre as etapas 2 e 3 para acelerar a aprovação do orçamento.',
        'Ao entregar a máquina, colete a assinatura física ou digital no canhoto de saída.'
      ]
    },
    {
      id: 'checkin-entrada',
      category: 'OS',
      title: 'Módulo de Entrada / Check-In de Equipamentos',
      subtitle: 'Como registrar a chegada de componentes industriais com agilidade',
      icon: FileText,
      targetTab: 'ENTRY_REGISTRY',
      badge: 'Recepção',
      steps: [
        {
          stepNumber: 'A',
          title: 'Localização ou Cadastro do Cliente',
          description: 'Selecione um cliente já cadastrado ou clique no botão rápido para adicionar uma nova empresa industrial com CNPJ, telefone de contato e endereço.',
          details: [
            'O campo de busca permite digitar qualquer parte da Razão Social ou CNPJ.',
            'O contato de WhatsApp cadastrado será usado posteriormente para envio de recibos e orçamentos.'
          ]
        },
        {
          stepNumber: 'B',
          title: 'Seleção do Equipamento e Prevenção Antiduplicidade',
          description: 'Selecione o equipamento pertencente ao cliente.',
          details: [
            'Caso o cliente tenha duas ou mais máquinas do mesmo modelo na oficina, o sistema exibirá uma trava preventiva com aviso sonoro/visual.',
            'Para prosseguir com equipamentos gêmeos, marque a opção "Autorizar duplicidade de modelo" e registre o número de patrimônio distinto.'
          ],
          importantNotice: 'A identificação por Número de Patrimônio evita troca de peças entre equipamentos de clientes diferentes.'
        },
        {
          stepNumber: 'C',
          title: 'Registro Fotográfico e Descrição dos Sintomas',
          description: 'Capture ou anexe uma foto do equipamento ainda na bancada de entrada.',
          details: [
            'Fotografe danos externos prévios, marcas de queima, eixos empenados ou trincas.',
            'Preencha o sintoma relatado pelo operador ou mecânico da fábrica (ex: perda de torque sob carga, superaquecimento, ruído de cavitação).'
          ]
        },
        {
          stepNumber: 'D',
          title: 'Emissão da Ficha de Entrada',
          description: 'Ao confirmar, o sistema gera a numeração sequencial (ex: OS-1002) e disponibiliza a Ficha de Entrada em PDF com QR Code para anexar fisicamente à máquina na oficina.'
        }
      ],
      tips: [
        'Imprima uma via da ficha e prenda ao equipamento em saco plástico protetor para acompanhar o técnico na bancada.'
      ]
    },
    {
      id: 'ciclo-os',
      category: 'OS',
      title: 'O Ciclo de Vida da OS (4 Etapas Integradas)',
      subtitle: 'Acompanhamento progressivo e gestão visual de cada ordem',
      icon: Clock,
      targetTab: 'MOBILE_OS',
      badge: 'Bancada & Gestão',
      steps: [
        {
          stepNumber: 'Etapa 1',
          title: 'Entrada & Ficha Inicial',
          description: 'Contém todos os dados coletados na recepção. Permite revisar dados de cliente, modelo, técnico responsável e prazo estimado.'
        },
        {
          stepNumber: 'Etapa 2',
          title: 'Diagnóstico Técnico & Aprovação de Orçamento',
          description: 'Registro do laudo técnico pós-desmontagem.',
          details: [
            'Inserção da causa raiz da falha (ex: óleo contaminado com água, partículas metálicas).',
            'Definição de peças necessárias e serviços de usinagem.',
            'Marcação de "Aprovado pelo Cliente" ou "Aguardando Aprovação".'
          ]
        },
        {
          stepNumber: 'Etapa 3',
          title: 'Execução dos Reparos & Teste Hidráulico',
          description: 'Trabalho prático na oficina.',
          details: [
            'Preenchimento das peças efetivamente utilizadas.',
            'Registro da pressão de teste alcançada na bancada (BAR / PSI).',
            'Conferência de estanqueidade das gaxetas e vedantes.'
          ]
        },
        {
          stepNumber: 'Etapa 4',
          title: 'Finalização, Saída & Certificado de Garantia',
          description: 'Conclusão definitiva do ciclo.',
          details: [
            'Definição do prazo de garantia (padrão de 90 dias conforme CDC ou prazo acordado).',
            'Registro das condições de entrega e responsável pela retirada.',
            'Emissão do Recibo de Saída com Termo de Garantia formal.'
          ]
        }
      ]
    },
    {
      id: 'envio-whatsapp',
      category: 'OS',
      title: 'Envio por WhatsApp & E-mail com Seleção de Contatos',
      subtitle: 'Como enviar orçamentos, cobranças e garantias diretamente para o cliente',
      icon: Send,
      targetTab: 'OS',
      badge: 'Comunicação',
      steps: [
        {
          stepNumber: '1',
          title: 'Clique no Botão de Compartilhar (WhatsApp ou E-mail)',
          description: 'Em qualquer tela de OS, Recibo ou Orçamento, clique no ícone de WhatsApp ou E-mail.',
          details: [
            'O sistema abrirá a janela suspensa de seleção de destinatário.'
          ]
        },
        {
          stepNumber: '2',
          title: 'Escolha o Contato Principal ou Digite Outro Destinatário',
          description: 'Você pode enviar para o número oficial cadastrado na ficha do cliente ou alternar para "Outro Destinatário".',
          details: [
            'Opção A: Usar o WhatsApp / E-mail cadastrado na ficha do cliente.',
            'Opção B: Digitar avulso o telefone de um encarregado de compras, engenheiro residente ou motorista da transportadora.'
          ],
          importantNotice: 'A mensagem já é gerada automaticamente com saudação formal, número da OS, equipamento e detalhes técnicos.'
        },
        {
          stepNumber: '3',
          title: 'Confirmação e Envio Imediato',
          description: 'Ao clicar em "Abrir WhatsApp", o sistema direciona automaticamente para o aplicativo web ou celular com o texto montado e pronto para envio.'
        }
      ]
    },
    {
      id: 'equipamentos-historico',
      category: 'CADASTRO',
      title: 'Gestão de Equipamentos e Histórico Permanente',
      subtitle: 'Prontuário técnico de bombas, motores, válvulas e cilindros',
      icon: Cpu,
      targetTab: 'EQUIPMENTS',
      badge: 'Ativos',
      steps: [
        {
          stepNumber: '1',
          title: 'Cadastro com Dados Específicos',
          description: 'Cadastre os ativos com Marca, Modelo, Tipo (Bomba de Pistões, Engrenagens, Válvula Direcional, etc.), Pressão Nominal e Patrimônio.',
          details: [
            'Vincule sempre o equipamento à empresa proprietária.',
            'Utilize o número de série da plaqueta do fabricante para rastreabilidade.'
          ]
        },
        {
          stepNumber: '2',
          title: 'Histórico Indelével de Manutenções',
          description: 'Toda vez que uma OS é concluída, o sistema salva automaticamente um registro no prontuário do equipamento.',
          details: [
            'O técnico pode consultar reparos anteriores feitos há meses ou anos.',
            'Permite identificar reincidências de defeito ou falhas operacionais na máquina do cliente.'
          ]
        }
      ]
    },
    {
      id: 'vistas-explodidas-catalogo',
      category: 'CADASTRO',
      title: 'Catálogo de Equipamentos com Vistas Explodidas & Peças',
      subtitle: 'Como cadastrar novos catálogos, editar diagramas, vincular ao estoque e requisitar peças para OS',
      icon: Layers,
      targetTab: 'CATALOGS',
      badge: 'Vista Técnica',
      steps: [
        {
          stepNumber: '1',
          title: 'Como Selecionar e Visualizar no Desenho',
          description: 'Acesse o menu "Vistas Explodidas" no painel lateral ou mobile. No topo, selecione o catálogo ativo no seletor (ex: Kärcher K 3.10, HD 585 ou Cilindro Hidráulico).',
          details: [
            'Use os botões de Zoom (+ / - / Ajustar) para aproximar ou afastar o diagrama.',
            'Passe o mouse ou clique em qualquer pino numérico circular no desenho para destacar a peça correspondente na tabela.',
            'Alternativamente, na tela de Equipamentos, clique no botão "Vista Explodida" de qualquer máquina cadastrada para abri-la diretamente.'
          ]
        },
        {
          stepNumber: '2',
          title: 'Como Pesquisar Componentes no Catálogo',
          description: 'Localize rapidamente qualquer peça digitando no campo de busca do catálogo:',
          details: [
            'Digite o número da posição (ex: 1, 3, 10).',
            'Digite o nome ou parte da descrição (ex: Válvula, Gaxeta, Pistão, Retentor, O-ring).',
            'Digite o código do fabricante (ex: 9.302-012.0) ou código interno de almoxarifado.',
            'A lista de peças e os pinos visuais são filtrados em tempo real.'
          ]
        },
        {
          stepNumber: '3',
          title: 'Como Inserir Novos Catálogos',
          description: 'Clique no botão "+ Novo Catálogo" no canto superior direito da tela:',
          details: [
            'Preencha o Título do Catálogo (ex: Lavadora Kärcher HD 6/15 - Cabeçote de Alta Pressão).',
            'Informe o Modelo do Equipamento e selecione o Equipamento cadastrado correspondente da oficina.',
            'Escolha o Tipo de Desenho: Esquema Técnico Vetorial Integrado ou Imagem/Foto Técnica (upload direto de imagem do catálogo em PNG/JPG).',
            'Defina Categoria e Subconjunto (Cabeçote, Pistões, Bloco de Válvulas, etc.) e clique em "Salvar Catálogo".'
          ],
          importantNotice: 'Você pode adicionar fotos reais ou desenhos de manuais técnicos de qualquer fabricante fazendo upload da imagem!'
        },
        {
          stepNumber: '4',
          title: 'Como Editar Catálogos e Cadastrar Peças',
          description: 'Personalize as informações e componha a lista completa de componentes:',
          details: [
            'Editar Catálogo: Clique no ícone de lápis "Editar" ao lado do seletor de catálogo no topo.',
            'Adicionar Peça: Clique no botão "+ Adicionar Peça" no topo da tabela de itens.',
            'Editar Peça: Clique no ícone de lápis na linha da peça para atualizar descrição, código de fábrica ou quantidade recomendada.',
            'Posicionar Pino no Desenho: Clique no botão com ícone de mira "Posicionar Pino" e clique com o cursor diretamente no local exato do diagrama onde a peça está localizada!'
          ]
        },
        {
          stepNumber: '5',
          title: 'Como Vincular Itens ao Estoque / Almoxarifado',
          description: 'Conecte cada peça da vista explodida ao inventário real da oficina:',
          details: [
            'Na linha da peça, clique no botão "Vincular Estoque" (ícone de link).',
            'O modal exibirá a busca de produtos já cadastrados no estoque, mostrando saldo disponível e preço de venda.',
            'Clique em "Vincular Esta Peça" no item correspondente.',
            'Se a peça ainda não existir no estoque, clique no botão "+ Cadastrar Item no Estoque Agora" dentro do modal para criá-la instantaneamente sem sair da tela!',
            'Para desvincular, basta clicar no ícone de desvínculo (Unlink).'
          ]
        },
        {
          stepNumber: '6',
          title: 'Como Requisitar Peças para uma Ordem de Serviço (OS)',
          description: 'Lance peças da vista explodida diretamente na bancada de trabalho de uma OS:',
          details: [
            'Clique no botão "Requisitar para OS" na peça desejada.',
            'Selecione a Ordem de Serviço aberta e informe a quantidade a ser utilizada.',
            'O sistema inclui a peça na lista de materiais da OS e atualiza os custos do serviço automaticamente.'
          ]
        },
        {
          stepNumber: '7',
          title: 'Como Excluir Catálogos ou Peças',
          description: 'Remoção segura com confirmação prévia:',
          details: [
            'Excluir Catálogo: Clique no botão da lixeira vermelha "Excluir" no cabeçalho do catálogo ativo.',
            'Excluir Peça: Clique no ícone da lixeira na linha da peça que deseja retirar da lista.'
          ]
        }
      ],
      tips: [
        'Ao cadastrar uma lavadora ou bomba nova, tire uma foto do manual ou do catálogo de peças e anexe no novo catálogo.',
        'Vincule as peças com maior giro (gaxetas, válvulas e pistões) ao estoque para acompanhar o saldo durante as manutenções.'
      ]
    },
    {
      id: 'estoque-pecas',
      category: 'GESTAO',
      title: 'Controle de Estoque & Peças de Reposição',
      subtitle: 'Gerenciamento de vedação, kits de reparo e alertas de reposição',
      icon: Package,
      targetTab: 'INVENTORY',
      badge: 'Almoxarifado',
      steps: [
        {
          stepNumber: '1',
          title: 'Cadastro de Peças e Vedações',
          description: 'Adicione anéis O-Ring, gaxetas de poliuretano, kits de vedação viton, filtros de retorno e eixos.',
          details: [
            'Preencha código da peça, fornecedor, preço de custo e preço de venda.',
            'Defina a quantidade de Estoque Mínimo para cada item.'
          ]
        },
        {
          stepNumber: '2',
          title: 'Alertas Visuais de Estoque Baixo',
          description: 'Quando a quantidade em estoque atinge ou fica abaixo do mínimo configurado:',
          details: [
            'O menu lateral exibe um aviso em destaque vermelho com a contagem de itens críticos.',
            'O painel permite filtrar instantaneamente todos os itens em falta para gerar pedido de compras.'
          ]
        }
      ]
    },
    {
      id: 'laudo-tecnico',
      category: 'QUALIDADE',
      title: 'Emissão de Laudos Técnicos & Certificados de Bancada',
      subtitle: 'Comprovação formal de conformidade para clientes industriais exigentes',
      icon: ShieldCheck,
      targetTab: 'TECHNICAL_REPORT',
      badge: 'Certificação',
      steps: [
        {
          stepNumber: '1',
          title: 'Seleção da Ordem de Serviço Testada',
          description: 'Selecione uma OS concluída ou em fase final de teste.',
          details: [
            'O sistema preenche automaticamente os dados do cliente, modelo e técnico responsável.'
          ]
        },
        {
          stepNumber: '2',
          title: 'Inserção de Parâmetros de Teste',
          description: 'Informe os resultados obtidos na bancada de testes hidráulicos:',
          details: [
            'Pressão Máxima de Teste (bar / psi).',
            'Vazão aferida em bancada (L/min).',
            'Resultado do ensaio de estanqueidade interna e externa.',
            'Temperatura do fluido durante o ensaio.'
          ]
        },
        {
          stepNumber: '3',
          title: 'Fotos Antes/Depois e Assinatura Técnica',
          description: 'Gere o certificado formal com visual profissional para envio à engenharia do cliente ou auditorias de qualidade ISO.'
        }
      ]
    },
    {
      id: 'garantia-prazos',
      category: 'QUALIDADE',
      title: 'Controle de Garantias & Retornos Técnicos',
      subtitle: 'Monitoramento de vigência legal e histórico de garantia',
      icon: Award,
      targetTab: 'WARRANTY_CONTROL',
      badge: 'Garantia',
      steps: [
        {
          stepNumber: '1',
          title: 'Contagem Regressiva de Vigência',
          description: 'O módulo monitora automaticamente todas as OS concluídas.',
          details: [
            'Exibe os dias restantes de garantia para cada equipamento entregue.',
            'Classifica o status em "Dentro da Garantia", "Próximo ao Vencimento" ou "Expirada".'
          ]
        },
        {
          stepNumber: '2',
          title: 'Atendimento de Retorno em Garantia',
          description: 'Caso o cliente relate falha no prazo:',
          details: [
            'Abra nova OS vinculada à garantia anterior.',
            'O sistema sinaliza que o serviço está sob cobertura, facilitando o atendimento prioritário.'
          ]
        }
      ]
    },
    {
      id: 'financeiro-gestao',
      category: 'GESTAO',
      title: 'Módulo Financeiro & Fluxo de Caixa',
      subtitle: 'Contas a pagar, faturamento de OS e conciliação',
      icon: DollarSign,
      targetTab: 'FINANCE',
      badge: 'Finanças',
      steps: [
        {
          stepNumber: '1',
          title: 'Recebimentos Vinculados às Ordens de Serviço',
          description: 'Ao concluir uma OS com valor financeiro, o lançamento a receber pode ser confirmado e baixado.',
          details: [
            'Controle de formas de pagamento: PIX, Boleto Bancário, Transferência ou Faturado 28 DDL.'
          ]
        },
        {
          stepNumber: '2',
          title: 'Contas a Pagar e Despesas da Oficina',
          description: 'Lance despesas com fornecedores de vedação, óleo hidráulico, ferramentas e custos fixos.',
          details: [
            'O painel calcula automaticamente o saldo real, receitas do mês e lucratividade operacional.'
          ]
        }
      ]
    },
    {
      id: 'nuvem-sincronismo',
      category: 'NUVEM',
      title: 'Sincronismo em Nuvem, Rede e Multi-Dispositivos',
      subtitle: 'Como utilizar o sistema simultaneamente na recepção, bancada e celular',
      icon: Cloud,
      badge: 'Tecnologia 4.0',
      steps: [
        {
          stepNumber: '1',
          title: 'Banco de Dados em Tempo Real',
          description: 'O sistema utiliza um banco de dados integrado que sincroniza instantaneamente todas as alterações.',
          details: [
            'Quando um técnico altera o status de uma OS na bancada, a recepção visualiza a mudança em segundos.',
            'O indicador "SINC NUVEM" no rodapé sinaliza o status da conexão em verde (Conectada).'
          ]
        },
        {
          stepNumber: '2',
          title: 'Acesso via Celular ou Tablet na Oficina',
          description: 'No menu superior ou lateral, clique em "Compartilhar Links" e envie o link para o celular dos técnicos.',
          details: [
            'Pelo celular, o mecânico pode consultar a lista de OS, ver fotos do equipamento e atualizar status diretamente da bancada.'
          ]
        },
        {
          stepNumber: '3',
          title: 'Backup e Exportação Google Sheets',
          description: 'Na aba "Google Sheets", você pode conectar uma planilha do Google Drive para exportar registros para relatórios externos ou contabilidade.'
        }
      ]
    },
    {
      id: 'perguntas-frequentes',
      category: 'FAQ',
      title: 'Perguntas Frequentes & Dúvidas Rápidas (FAQ)',
      subtitle: 'Soluções rápidas para as principais dúvidas do dia a dia',
      icon: HelpCircle,
      badge: 'Ajuda',
      steps: [
        {
          stepNumber: 'Q1',
          title: 'Como alterar o status de uma OS para "Concluída"?',
          description: 'Você pode ir na aba "Ciclo da OS" e avançar para a Etapa 4 (Finalizar), ou na aba "Ordens (OS)" arrastar o card para a coluna "Concluída" ou clicar no botão "Concluir" do registro. O sistema solicitará os dados de entrega e dias de garantia.'
        },
        {
          stepNumber: 'Q2',
          title: 'O que fazer quando o cliente traz dois cilindros idênticos?',
          description: 'Na tela de Check-in, ao selecionar o mesmo cliente e modelo, o sistema exibirá um alerta antiduplicidade. Basta marcar a caixa "Autorizar duplicidade de modelo" e preencher números de patrimônio ou observações distintas (ex: "Cilindro Esquerdo" e "Cilindro Direito").'
        },
        {
          stepNumber: 'Q3',
          title: 'Como imprimir apenas a Ficha de Entrada ou o Termo de Garantia?',
          description: 'Abra a OS desejada no menu "Ordens (OS)" ou "Ciclo da OS" e clique no botão com ícone de impressora. O sistema formata a página automaticamente eliminando barras de navegação para economizar papel e tinta.'
        },
        {
          stepNumber: 'Q4',
          title: 'Como cadastrar um mecânico ou técnico na equipe?',
          description: 'Acesse o menu "Técnicos", clique em "+ Novo Técnico", preencha nome, especialidade (ex: Hidráulica Móbil, Usinagem, Válvulas) e contato. Ele ficará disponível para alocação imediata em novas ordens.'
        },
        {
          stepNumber: 'Q5',
          title: 'Como enviar cobrança ou orçamento com chave PIX inclusa?',
          description: 'Ao compartilhar a OS por WhatsApp ou E-mail, certifique-se de configurar a chave PIX nas opções do sistema. A chave e as instruções de pagamento serão incluídas automaticamente no texto da mensagem.'
        }
      ]
    }
  ];

  const filteredSections = useMemo(() => {
    return manualSections.filter(section => {
      const matchesCategory = selectedCategory === 'ALL' || section.category === selectedCategory;
      const searchLower = searchTerm.toLowerCase().trim();

      if (!searchLower) return matchesCategory;

      const titleMatch = section.title.toLowerCase().includes(searchLower);
      const subtitleMatch = section.subtitle.toLowerCase().includes(searchLower);
      const stepsMatch = section.steps.some(st => 
        st.title.toLowerCase().includes(searchLower) ||
        st.description.toLowerCase().includes(searchLower) ||
        (st.details && st.details.some(d => d.toLowerCase().includes(searchLower)))
      );

      return matchesCategory && (titleMatch || subtitleMatch || stepsMatch);
    });
  }, [searchTerm, selectedCategory]);

  return (
    <div className="space-y-4 animate-fade-in" id="user-manual-container">
      {/* Top Banner & Title */}
      <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm print:border-none print:shadow-none">
        <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-blue-900 print:bg-white print:text-black print:border-none">
          <div className="flex items-center gap-3">
            <span className="p-2 bg-white/10 rounded-lg border border-white/20 text-cyan-300 shadow-sm print:hidden">
              <BookOpen className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2 flex-wrap mb-0.5">
                <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest bg-cyan-400/20 text-cyan-200 border border-cyan-400/30 print:hidden font-mono">
                  DOCUMENTAÇÃO OPERACIONAL 4.0
                </span>
                <span className="text-[10px] text-cyan-200 font-mono font-bold print:hidden">
                  JC&F SISTEMAS • POP & GUIA DO USUÁRIO
                </span>
              </div>
              <h1 className="text-sm sm:text-base font-black uppercase tracking-wider text-white print:text-black">
                Manual de Operação do Sistema
              </h1>
              <p className="text-xs text-cyan-100 max-w-2xl mt-0.5 leading-relaxed print:text-slate-700">
                Guia completo de procedimentos operacionais padrão (POP), rotinas de bancada, ciclo de vida de ordens de serviço e normas de qualidade para manutenção hidráulica e pneumática.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 shrink-0 print:hidden">
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg shadow-md transition-all cursor-pointer"
              title="Imprimir ou Salvar PDF deste manual"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Imprimir / PDF</span>
            </button>
            <button
              type="button"
              onClick={expandAll}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 text-xs font-bold rounded-lg transition-colors cursor-pointer"
              title="Expandir todas as seções"
            >
              Expandir Tudo
            </button>
            <button
              type="button"
              onClick={collapseAll}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 text-xs font-bold rounded-lg transition-colors cursor-pointer"
              title="Recolher todas as seções"
            >
              Recolher
            </button>
          </div>
        </div>

        {/* Quick search and category filter bar */}
        <div className="p-4 bg-[#f4f7fa] border-t border-slate-200 flex flex-col md:flex-row items-center gap-3 print:hidden">
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar no manual (ex: check-in, garantia, whatsapp, teste, estoque)..."
              className="w-full pl-10 pr-14 py-2 bg-white border border-slate-300 focus:border-[#1b365d] rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden font-medium shadow-xs"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-slate-800 font-bold cursor-pointer"
              >
                Limpar
              </button>
            )}
          </div>

          {/* Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full pb-1 scrollbar-none text-xs">
            {[
              { id: 'ALL', label: 'Todos os Módulos' },
              { id: 'POP', label: 'Fluxo Geral (POP)' },
              { id: 'OS', label: 'Ordens & Ciclo' },
              { id: 'QUALIDADE', label: 'Laudos & Garantia' },
              { id: 'CADASTRO', label: 'Cadastros' },
              { id: 'GESTAO', label: 'Estoque & Finanças' },
              { id: 'NUVEM', label: 'Sincronismo' },
              { id: 'FAQ', label: 'Dúvidas (FAQ)' }
            ].map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition-all cursor-pointer text-xs ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-300'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Manual Content Sections */}
      <div className="space-y-4 print:space-y-3">
        {filteredSections.length === 0 ? (
          <div className="bg-white rounded-xl border-2 border-[#b0bec5] p-10 text-center text-slate-600 space-y-3 shadow-sm">
            <AlertTriangle className="w-10 h-10 mx-auto text-amber-500" />
            <h3 className="text-base font-black text-slate-900 uppercase">Nenhum tópico encontrado</h3>
            <p className="text-xs text-slate-600 max-w-md mx-auto">
              Não localizamos nenhuma seção com o termo "{searchTerm}". Tente buscar por palavras-chave mais comuns como "OS", "cliente", "peça" ou "recebimento".
            </p>
            <button
              type="button"
              onClick={() => { setSearchTerm(''); setSelectedCategory('ALL'); }}
              className="px-4 py-2 bg-[#1b365d] hover:bg-blue-900 text-white font-black text-xs uppercase tracking-wider rounded-lg transition-all cursor-pointer shadow-sm"
            >
              Exibir Manual Completo
            </button>
          </div>
        ) : (
          filteredSections.map(section => {
            const isExpanded = !!expandedSections[section.id];
            const IconComp = section.icon;

            return (
              <div
                key={section.id}
                id={`manual-sec-${section.id}`}
                className="bg-white rounded-xl border-2 border-[#b0bec5] shadow-xs overflow-hidden transition-all duration-200 print:border-gray-300 print:shadow-none print:break-inside-avoid"
              >
                {/* Section Header */}
                <div
                  onClick={() => toggleSection(section.id)}
                  className="p-4 flex items-start justify-between gap-4 cursor-pointer hover:bg-slate-50 transition-colors select-none print:p-2 print:border-b print:border-gray-200"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg text-[#1b365d] shrink-0 mt-0.5 print:border-gray-400 print:text-black print:bg-gray-100">
                      <IconComp className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-blue-50 text-[#1b365d] border border-blue-200 print:text-gray-700 print:border-gray-300 font-mono">
                          {section.badge || section.category}
                        </span>
                        <h2 className="text-sm md:text-base font-black text-slate-900 tracking-wide print:text-black">
                          {section.title}
                        </h2>
                      </div>
                      <p className="text-xs text-slate-600 mt-1 leading-normal print:text-gray-600 font-medium">
                        {section.subtitle}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 print:hidden">
                    {section.targetTab && onNavigateTab && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onNavigateTab(section.targetTab);
                        }}
                        className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-[#1b365d] rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
                      >
                        <span>Ir para Módulo</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                    <button
                      type="button"
                      className="p-1 text-slate-500 hover:text-slate-800 transition-colors"
                      aria-label="Alternar exibição"
                    >
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Section Content */}
                {(isExpanded || (typeof window !== 'undefined' && window.matchMedia?.('print').matches)) && (
                  <div className="px-4 pb-5 pt-3 border-t border-slate-200 bg-[#f8fafc] space-y-3 print:px-2 print:pb-2 print:border-gray-200 print:bg-white">
                    <div className="grid grid-cols-1 gap-3">
                      {section.steps.map((step, idx) => (
                        <div
                          key={idx}
                          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-2 print:bg-gray-50 print:border-gray-300 print:p-2.5"
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="w-6 h-6 rounded-full bg-[#1b365d] text-white font-mono text-[11px] font-black flex items-center justify-center shrink-0 print:bg-gray-200 print:text-black shadow-xs">
                              {step.stepNumber}
                            </span>
                            <h3 className="text-xs md:text-sm font-black text-slate-900 print:text-black">
                              {step.title}
                            </h3>
                          </div>

                          <p className="text-xs text-slate-700 leading-relaxed pl-8 print:text-gray-800 font-medium">
                            {step.description}
                          </p>

                          {step.details && step.details.length > 0 && (
                            <ul className="pl-12 space-y-1.5 list-disc text-xs text-slate-600 print:text-gray-700">
                              {step.details.map((detail, dIdx) => (
                                <li key={dIdx} className="leading-snug">
                                  {detail}
                                </li>
                              ))}
                            </ul>
                          )}

                          {step.importantNotice && (
                            <div className="ml-8 mt-2 p-2.5 rounded-lg bg-amber-50 border border-amber-300 flex items-start gap-2 text-xs text-amber-950 print:bg-amber-50 print:text-amber-900">
                              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                              <div className="leading-normal">
                                <strong className="font-black text-amber-900 uppercase tracking-wider text-[10px] block">Atenção Operacional:</strong>
                                {step.importantNotice}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {section.tips && section.tips.length > 0 && (
                      <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl space-y-1 text-xs text-blue-950 print:bg-blue-50 print:text-blue-950 print:border-blue-200">
                        <span className="font-black text-[10px] uppercase tracking-wider text-[#1b365d] flex items-center gap-1.5 print:text-blue-900">
                          <Sparkles className="w-3.5 h-3.5 text-blue-600" /> Boas Práticas da Oficina:
                        </span>
                        <ul className="list-disc pl-5 space-y-1 text-slate-700 print:text-gray-800 text-[11px]">
                          {section.tips.map((tip, tIdx) => (
                            <li key={tIdx}>{tip}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {section.targetTab && onNavigateTab && (
                      <div className="pt-2 flex justify-end print:hidden">
                        <button
                          type="button"
                          onClick={() => onNavigateTab(section.targetTab)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1b365d] hover:bg-blue-900 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer shadow-xs"
                        >
                          <span>Abrir Módulo correspondente</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Workshop Emergency & Support Contacts Banner */}
      <div className="bg-white border-2 border-[#b0bec5] rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-700 shadow-sm print:hidden">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-[#1b365d] shrink-0">
            <LifeBuoy className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-black text-slate-900 text-sm uppercase tracking-wider">Dúvidas Técnicas ou Solicitação de Customizações?</h4>
            <p className="text-slate-600 text-xs mt-0.5 font-medium">
              Este manual reflete a versão operacional do sistema JC&F Sistemas Hidráulicos.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg font-bold text-xs transition-colors shrink-0 cursor-pointer"
        >
          Voltar ao Topo
        </button>
      </div>
    </div>
  );
};
