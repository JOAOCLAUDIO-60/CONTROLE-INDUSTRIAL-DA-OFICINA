import React, { useState, useEffect, useRef } from 'react';
import { Client, Equipment, ServiceOrder, OSStatus, MaintenanceHistoryEntry, FinancialTransaction, Technician, InventoryItem, TechnicalDiagnostic, PlannedService } from '../types';
import { formatPhoneNumber } from '../utils/phoneFormatter';
import { 
  FileSpreadsheet, Plus, RefreshCw, CheckCircle2, AlertTriangle, User, DollarSign, Calendar, ChevronRight, 
  Camera, Upload, Shield, ShieldCheck, Send, Mail, MessageSquare, Clock, ArrowLeft, Wrench, Check, CheckCircle, 
  TrendingUp, UserPlus, Smartphone, Package, History, ClipboardCheck, X, Search, FileText, Info, Trash2,
  ClipboardList, Briefcase, Tag, Layers
} from 'lucide-react';
import { generatePDF, PDFDocType } from '../utils/pdfGenerator';
import { ShareContactModal, ShareContactModalProps } from './ShareContactModal';
 
interface MaintenanceLifecycleProps {
  orders: ServiceOrder[];
  clients: Client[];
  equipments: Equipment[];
  history: MaintenanceHistoryEntry[];
  technicians: Technician[];
  diagnostics?: TechnicalDiagnostic[];
  services?: PlannedService[];
  onAddOrder: (order: Omit<ServiceOrder, 'id' | 'osNumber' | 'createdAt'>) => ServiceOrder;
  onEditOrder: (order: ServiceOrder) => void;
  onAddClient: (client: Omit<Client, 'id' | 'createdAt'>) => Client;
  onAddEquipment: (equipment: Omit<Equipment, 'id' | 'createdAt'>) => Equipment;
  onAutoAddHistoryFromOS: (order: ServiceOrder) => void;
  onAddTransaction?: (transactionData: Omit<FinancialTransaction, 'id' | 'createdAt'>) => void;
  onDeleteOrder?: (id: string) => void;
  onEditEquipment?: (equipment: Equipment) => void;
  inventory?: InventoryItem[];
  onEditInventoryItem?: (item: InventoryItem) => void;
  receivers?: string[];
  onSaveReceivers?: (receivers: string[]) => void;
}

const PRESET_PHOTOS = [
  { id: 'cylinder', name: 'Cilindro Hidráulico', url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=400&q=80' },
  { id: 'pump', name: 'Bomba de Pistão', url: 'https://images.unsplash.com/photo-1581092162384-8987c17d4e26?auto=format&fit=crop&w=400&q=80' },
  { id: 'valve', name: 'Válvula Direcional', url: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=400&q=80' },
  { id: 'pneumatic', name: 'Atuador Pneumático', url: 'https://images.unsplash.com/photo-1537462715879-360eeb61a0bc?auto=format&fit=crop&w=400&q=80' },
];

export default function MaintenanceLifecycle({
  orders,
  clients,
  equipments,
  history,
  technicians,
  diagnostics = [],
  services = [],
  onAddOrder,
  onEditOrder,
  onAddClient,
  onAddEquipment,
  onAutoAddHistoryFromOS,
  onAddTransaction,
  onDeleteOrder,
  onEditEquipment,
  inventory = [],
  onEditInventoryItem,
  receivers,
  onSaveReceivers,
}: MaintenanceLifecycleProps) {
  
  // Selected OS to track
  const [selectedOrderId, setSelectedOrderId] = useState<string>('');
  const [activeStepTab, setActiveStepTab] = useState<1 | 2 | 3 | 4>(1);
  const [osSearchQuery, setOsSearchQuery] = useState('');
  const [isCreatingNewOS, setIsCreatingNewOS] = useState(false);

  // STEP 1 STATE: Check-in / Entrada
  const [checkinClientMode, setCheckinClientMode] = useState<'SELECT' | 'CREATE'>('SELECT');
  const [selectedClientId, setSelectedClientId] = useState('');
  const [clientSearch, setClientSearch] = useState('');
  const [newClientName, setNewClientName] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');
  const [newClientDoc, setNewClientDoc] = useState('');
  const [newClientAddress, setNewClientAddress] = useState('');

  const [checkinEquipMode, setCheckinEquipMode] = useState<'SELECT' | 'CREATE'>('SELECT');
  const [selectedEquipId, setSelectedEquipId] = useState('');
  const [equipSearch, setEquipSearch] = useState('');
  const [newEquipName, setNewEquipName] = useState('');
  const [newEquipModel, setNewEquipModel] = useState('');
  const [newEquipType, setNewEquipType] = useState('Hidráulico');

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('MEDIUM');
  const [technician, setTechnician] = useState(() => technicians[0]?.name || 'João CLAUDIO');
  
  // Gerenciamento de Recebedores / Atendentes com localStorage e Servidor Central
  const DEFAULT_RECEIVERS = ['Atendimento Balcão', 'JOÃO CLAUDIO'];
  const PURGE_MOCK_RECEIVERS = ['Carlos Silva', 'João Carlos', 'Maria Oliveira', 'Roberto Souza'];

  const cleanReceivers = (list: any[]): string[] => {
    if (!Array.isArray(list)) return DEFAULT_RECEIVERS;
    const cleaned = list
      .filter((r) => typeof r === 'string' && r.trim().length > 0)
      .map((r) => r.trim())
      .filter((r) => !PURGE_MOCK_RECEIVERS.includes(r));
    return cleaned.length > 0 ? Array.from(new Set(cleaned)) : DEFAULT_RECEIVERS;
  };

  const [receiversList, setReceiversList] = useState<string[]>(() => {
    if (receivers && receivers.length > 0) return cleanReceivers(receivers);
    try {
      const saved = localStorage.getItem('oficina_receivers');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return cleanReceivers(parsed);
      }
    } catch (e) {
      console.error('Erro ao ler oficina_receivers:', e);
    }
    return DEFAULT_RECEIVERS;
  });

  const activeReceivers = cleanReceivers(receivers && receivers.length > 0 ? receivers : receiversList);

  useEffect(() => {
    if (receivers && receivers.length > 0) {
      const cleaned = cleanReceivers(receivers);
      setReceiversList(cleaned);
      if (!receiverName || !cleaned.includes(receiverName)) {
        setReceiverName(cleaned[0] || 'Atendimento Balcão');
      }
    }
  }, [receivers]);

  const [receiverName, setReceiverName] = useState(() => activeReceivers[0] || 'Atendimento Balcão');
  const [showReceiversModal, setShowReceiversModal] = useState(false);
  const [newReceiverInput, setNewReceiverInput] = useState('');

  const handleAddReceiver = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const currentList = activeReceivers;
    if (currentList.some(r => r.toLowerCase() === trimmed.toLowerCase())) return;
    const updated = [...currentList, trimmed];
    setReceiversList(updated);
    localStorage.setItem('oficina_receivers', JSON.stringify(updated));
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    setReceiverName(trimmed);
    setNewReceiverInput('');
  };

  const handleDeleteReceiver = (nameToDelete: string) => {
    const currentList = activeReceivers;
    if (currentList.length <= 1) return;
    const updated = currentList.filter(r => r !== nameToDelete);
    setReceiversList(updated);
    localStorage.setItem('oficina_receivers', JSON.stringify(updated));
    if (onSaveReceivers) {
      onSaveReceivers(updated);
    }
    if (receiverName === nameToDelete) {
      setReceiverName(updated[0] || '');
    }
  };
  const [estimatedCost, setEstimatedCost] = useState<number>(0);
  const [photo, setPhoto] = useState<string>('');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [orderType, setOrderType] = useState<'SERVICE' | 'WARRANTY'>('SERVICE');

  // STEP 2 STATE: Diagnóstico & Orçamento
  const [diagnostic, setDiagnostic] = useState('');
  const [plannedServices, setPlannedServices] = useState('');
  const [step2EstimatedCost, setStep2EstimatedCost] = useState<number>(0);
  const [budgetStatus, setBudgetStatus] = useState<'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED'>('PENDING_APPROVAL');
  const [budgetDate, setBudgetDate] = useState(new Date().toISOString().split('T')[0]);

  // STEP 3 STATE: Execução Real
  const [actualServicesPerformed, setActualServicesPerformed] = useState('');
  const [materialsUsed, setMaterialsUsed] = useState('');
  const [actualCost, setActualCost] = useState<number>(0);
  const [osStatus, setOsStatus] = useState<OSStatus>('IN_PROGRESS');
  const [executionDate, setExecutionDate] = useState(new Date().toISOString().split('T')[0]);
  const [osMaterialsList, setOsMaterialsList] = useState<{ itemId: string; name: string; code: string; quantity: number; salePrice: number }[]>([]);
  const [materialSearchQuery, setMaterialSearchQuery] = useState('');
  const [selectedMaterialId, setSelectedMaterialId] = useState('');
  const [selectedMaterialQty, setSelectedMaterialQty] = useState<number>(1);
  const [isBrowsingInventory, setIsBrowsingInventory] = useState(false);

  // Price Table Attachment State
  const [isPriceTableModalOpen, setIsPriceTableModalOpen] = useState(false);
  const [priceTableTarget, setPriceTableTarget] = useState<'STEP2' | 'STEP3'>('STEP2');
  const [priceTableSearch, setPriceTableSearch] = useState('');
  const [selectedPriceCategory, setSelectedPriceCategory] = useState<string>('ALL');
  const [selectedPriceTableIds, setSelectedPriceTableIds] = useState<string[]>([]);

  const handleAttachServiceFromPriceTable = (srv: PlannedService, forcedTarget?: 'STEP2' | 'STEP3') => {
    // Prioritize forcedTarget, then current activeStepTab (tab 3 is execution), then priceTableTarget
    const target = forcedTarget || (activeStepTab === 3 ? 'STEP3' : (activeStepTab === 2 ? 'STEP2' : priceTableTarget));

    const descText = srv.description && srv.description.trim() ? `\n  Descritivo Técnico: ${srv.description.trim()}` : '';
    const formattedLine = `• [${srv.code}] ${srv.name} (R$ ${srv.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })})${descText}`;

    if (target === 'STEP2') {
      if (!plannedServices || plannedServices.trim() === '') {
        setPlannedServices(formattedLine);
      } else {
        setPlannedServices(prev => `${prev}\n\n${formattedLine}`);
      }
      setStep2EstimatedCost(prev => (prev || 0) + srv.estimatedCost);
      showFeedback(`✅ [${srv.code}] ${srv.name} e descritivo adicionados ao Orçamento (+ R$ ${srv.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })})!`, 'success', 4000);
    } else {
      if (!actualServicesPerformed || actualServicesPerformed.trim() === '') {
        setActualServicesPerformed(formattedLine);
      } else {
        setActualServicesPerformed(prev => `${prev}\n\n${formattedLine}`);
      }
      setActualCost(prev => (prev || 0) + srv.estimatedCost);
      showFeedback(`✅ [${srv.code}] ${srv.name} e descritivo transferidos para a Execução (+ R$ ${srv.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })})!`, 'success', 4000);
    }
  };

  const handleAttachBatchServicesFromPriceTable = (forcedTarget?: 'STEP2' | 'STEP3') => {
    const target = forcedTarget || (activeStepTab === 3 ? 'STEP3' : (activeStepTab === 2 ? 'STEP2' : priceTableTarget));
    if (selectedPriceTableIds.length === 0) return;

    const itemsToAttach = services.filter(s => selectedPriceTableIds.includes(s.id));
    if (itemsToAttach.length === 0) return;

    const formattedLines = itemsToAttach.map(srv => {
      const descText = srv.description && srv.description.trim() ? `\n  Descritivo Técnico: ${srv.description.trim()}` : '';
      return `• [${srv.code}] ${srv.name} (R$ ${srv.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })})${descText}`;
    }).join('\n\n');

    const totalAdded = itemsToAttach.reduce((acc, s) => acc + s.estimatedCost, 0);

    if (target === 'STEP2') {
      if (!plannedServices || plannedServices.trim() === '') {
        setPlannedServices(formattedLines);
      } else {
        setPlannedServices(prev => `${prev}\n\n${formattedLines}`);
      }
      setStep2EstimatedCost(prev => (prev || 0) + totalAdded);
      showFeedback(`✅ ${itemsToAttach.length} serviços e descritivos transferidos para o Orçamento (+ R$ ${totalAdded.toLocaleString('pt-BR', { minimumFractionDigits: 2 })})!`, 'success', 5000);
    } else {
      if (!actualServicesPerformed || actualServicesPerformed.trim() === '') {
        setActualServicesPerformed(formattedLines);
      } else {
        setActualServicesPerformed(prev => `${prev}\n\n${formattedLines}`);
      }
      setActualCost(prev => (prev || 0) + totalAdded);
      showFeedback(`✅ ${itemsToAttach.length} serviços e descritivos transferidos para o Laudo de Execução (+ R$ ${totalAdded.toLocaleString('pt-BR', { minimumFractionDigits: 2 })})!`, 'success', 5000);
    }

    setSelectedPriceTableIds([]);
    setIsPriceTableModalOpen(false);
  };

  // STEP 4 STATE: Finalização & Entrega
  const [isDelivered, setIsDelivered] = useState(false);
  const [deliveryDate, setDeliveryDate] = useState('');
  const [warrantyDays, setWarrantyDays] = useState<number>(90);
  const [warrantyNotes, setWarrantyNotes] = useState('');
  const [deliveryPhoto, setDeliveryPhoto] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('PIX');
  const [paymentStatus, setPaymentStatus] = useState<'PENDING' | 'PAID'>('PENDING');

  const deliveryFileInputRef = useRef<HTMLInputElement>(null);

  // Share & Copy feedback states
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [copyFeedback, setCopyFeedback] = useState(false);
  const [osToDelete, setOsToDelete] = useState<{ id: string; osNumber: string } | null>(null);
  const [stageCompletionModal, setStageCompletionModal] = useState<{
    isOpen: boolean;
    stepNumber: 1 | 2 | 3 | 4;
    stepName: string;
    badge: string;
    title: string;
    description: string;
    osNumber: string;
    clientName: string;
    equipmentName: string;
    details?: { label: string; value: string }[];
    primaryActionLabel: string;
    onPrimaryAction: () => void;
    secondaryActionLabel?: string;
    onSecondaryAction?: () => void;
  } | null>(null);
  const [shareModalConfig, setShareModalConfig] = useState<{
    isOpen: boolean;
    title: string;
    subtitle?: string;
    docType: 'ORCAMENTO' | 'RECIBO_GARANTIA' | 'FICHA_ENTRADA' | 'GERAL';
    clientName: string;
    clientPhone: string;
    clientEmail?: string;
    defaultChannel: 'WHATSAPP' | 'EMAIL';
    defaultMessage: string;
    subject: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const lastLoadedOrderIdRef = useRef<string | null>(null);

  // Sync state whenever selected Order changes
  const activeOrder = orders.find(o => o.id === selectedOrderId);

  useEffect(() => {
    if (activeOrder) {
      if (selectedOrderId !== lastLoadedOrderIdRef.current) {
        // Load current values of selected order
        setTitle(activeOrder.title || '');
        setDescription(activeOrder.description || '');
        setPriority(activeOrder.priority || 'MEDIUM');
        setTechnician(activeOrder.technician || (technicians[0]?.name || 'João CLAUDIO'));
        setReceiverName(activeOrder.receiverName || activeOrder.technician || (activeReceivers[0] || 'Atendimento Balcão'));
        setEstimatedCost(activeOrder.estimatedCost || 0);
        setPhoto(activeOrder.equipmentPhoto || '');
        setSelectedClientId(activeOrder.clientId || '');
        setSelectedEquipId(activeOrder.equipmentId || '');
        setStartDate(activeOrder.startDate || new Date().toISOString().split('T')[0]);
        setOrderType(activeOrder.orderType || 'SERVICE');

        // Step 2
        setDiagnostic(activeOrder.diagnostic || '');
        setPlannedServices(activeOrder.plannedServices || '');
        setStep2EstimatedCost(activeOrder.estimatedCost || 0);
        setBudgetStatus(activeOrder.budgetStatus || 'PENDING_APPROVAL');
        setBudgetDate(activeOrder.budgetDate || activeOrder.startDate || new Date().toISOString().split('T')[0]);

        // Step 3
        setActualServicesPerformed(activeOrder.actualServicesPerformed || '');
        setMaterialsUsed(activeOrder.materialsUsed || '');
        setActualCost(activeOrder.actualCost || activeOrder.estimatedCost || 0);
        setOsStatus(activeOrder.status || 'PENDING');
        setExecutionDate(activeOrder.executionDate || activeOrder.endDate || new Date().toISOString().split('T')[0]);
        setOsMaterialsList(activeOrder.materialsUsedList || []);

        // Step 4
        setIsDelivered(!!activeOrder.isDelivered);
        setDeliveryDate(activeOrder.deliveryDate || activeOrder.endDate || new Date().toISOString().split('T')[0]);
        setWarrantyDays(activeOrder.warrantyDays !== undefined ? activeOrder.warrantyDays : 90);
        setWarrantyNotes(activeOrder.warrantyNotes || '');
        setDeliveryPhoto(activeOrder.deliveryPhoto || '');
        setPaymentMethod(activeOrder.paymentMethod || 'PIX');
        setPaymentStatus(activeOrder.paymentStatus || 'PENDING');

        setIsCreatingNewOS(false);
        lastLoadedOrderIdRef.current = selectedOrderId;

        // Auto-select correct step tab according to OS status
        let targetStep: 1 | 2 | 3 | 4 = 1;
        if (activeOrder.status === 'COMPLETED' || activeOrder.isDelivered) {
          targetStep = 4;
        } else if (activeOrder.status === 'IN_PROGRESS' || activeOrder.actualServicesPerformed || activeOrder.budgetStatus === 'APPROVED') {
          targetStep = 3;
        } else if (activeOrder.diagnostic || activeOrder.plannedServices || activeOrder.budgetStatus === 'PENDING_APPROVAL') {
          targetStep = 2;
        } else {
          targetStep = 1;
        }
        setActiveStepTab(targetStep);
      }
    } else {
      if (!selectedOrderId && lastLoadedOrderIdRef.current !== '') {
        // Reset form fields
        setTitle('');
        setDescription('');
        setPriority('MEDIUM');
        setTechnician(technicians[0]?.name || 'João CLAUDIO');
        setReceiverName(activeReceivers[0] || 'Atendimento Balcão');
        setEstimatedCost(0);
        setPhoto('');
        setStartDate(new Date().toISOString().split('T')[0]);
        setOrderType('SERVICE');
        setSelectedClientId(clients[0]?.id || '');
        setSelectedEquipId('');
        
        setDiagnostic('');
        setPlannedServices('');
        setStep2EstimatedCost(0);
        setBudgetStatus('PENDING_APPROVAL');
        setBudgetDate(new Date().toISOString().split('T')[0]);

        setActualServicesPerformed('');
        setMaterialsUsed('');
        setActualCost(0);
        setOsStatus('PENDING');
        setExecutionDate(new Date().toISOString().split('T')[0]);
        setOsMaterialsList([]);

        setIsDelivered(false);
        setDeliveryDate(new Date().toISOString().split('T')[0]);
        setWarrantyDays(90);
        setWarrantyNotes('');
        setDeliveryPhoto('');
        setPaymentMethod('PIX');
        setPaymentStatus('PENDING');

        lastLoadedOrderIdRef.current = '';
      }
    }
  }, [selectedOrderId, activeOrder, clients]);

  // Set default client if none is selected
  useEffect(() => {
    if (clients.length > 0 && !selectedClientId) {
      setSelectedClientId(clients[0].id);
    }
  }, [clients, selectedClientId]);

  // Show status feedback helper
  const showFeedback = (message: string, type: 'success' | 'error' | 'info' = 'success', duration = 4000) => {
    setFeedback({ message, type });
    setTimeout(() => setFeedback(null), duration);
  };

  // Filter lists
  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
    c.phone.includes(clientSearch) ||
    c.document.includes(clientSearch)
  ).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));

  const filteredEquipments = equipments.filter(e => {
    return e.name.toLowerCase().includes(equipSearch.toLowerCase()) || 
           e.model.toLowerCase().includes(equipSearch.toLowerCase()) ||
           (e.patrimonyNumber && e.patrimonyNumber.toLowerCase().includes(equipSearch.toLowerCase()));
  }).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));

  // Handler: Select photo upload
  const handlePhotoClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        showFeedback('A imagem deve ter menos de 3MB.', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
        showFeedback('Foto anexada com sucesso!', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Sign out / reset selected OS
  const handleResetActiveOS = () => {
    setSelectedOrderId('');
    setIsCreatingNewOS(false);
    setActiveStepTab(1);
  };

  // HANDLER STEP 1: Save Check-in (Add Order)
  const handleCreateOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let targetClientId = selectedClientId;
    let targetEquipId = selectedEquipId;

    // 1. Create client if in create mode
    if (checkinClientMode === 'CREATE') {
      if (!newClientName.trim() || !newClientPhone.trim()) {
        showFeedback('Preencha o nome e telefone do novo cliente.', 'error');
        return;
      }
      const addedClient = onAddClient({
        name: newClientName,
        document: newClientDoc,
        phone: newClientPhone,
        address: newClientAddress,
      });
      targetClientId = addedClient.id;
      // Reset new client form
      setNewClientName('');
      setNewClientPhone('');
      setNewClientDoc('');
      setNewClientAddress('');
      setCheckinClientMode('SELECT');
      setSelectedClientId(addedClient.id);
    }

    // 2. Create equipment if in create mode
    if (checkinEquipMode === 'CREATE') {
      if (!newEquipName.trim()) {
        showFeedback('Preencha o nome do novo equipamento.', 'error');
        return;
      }
      const addedEquip = onAddEquipment({
        name: newEquipName,
        model: newEquipModel || 'S/N',
        type: newEquipType,
        clientId: targetClientId,
      });
      targetEquipId = addedEquip.id;
      // Reset new equipment form
      setNewEquipName('');
      setNewEquipModel('');
      setNewEquipType('Hidráulico');
      setCheckinEquipMode('SELECT');
      setSelectedEquipId(addedEquip.id);
    } else {
      // If selecting an existing equipment that doesn't have an owner yet, link it to the selected client
      const existingEquip = equipments.find(e => e.id === targetEquipId);
      if (existingEquip && !existingEquip.clientId && onEditEquipment) {
        onEditEquipment({
          ...existingEquip,
          clientId: targetClientId,
        });
      }
    }

    if (!targetClientId) {
      showFeedback('Por favor, selecione ou cadastre um cliente.', 'error');
      return;
    }
    if (!targetEquipId) {
      showFeedback('Por favor, selecione ou cadastre um equipamento.', 'error');
      return;
    }
    if (!title.trim() || !description.trim()) {
      showFeedback('Por favor, digite o título e o problema do equipamento.', 'error');
      return;
    }

    // If editing existing OS in Step 1
    if (activeOrder && !isCreatingNewOS) {
      const updatedOrder: ServiceOrder = {
        ...activeOrder,
        clientId: targetClientId,
        equipmentId: targetEquipId,
        title: title.trim(),
        description: description.trim(),
        priority,
        technician,
        receiverName: receiverName.trim() || technician,
        estimatedCost: Number(estimatedCost),
        startDate: startDate,
        equipmentPhoto: photo,
        orderType: orderType,
        updatedAt: new Date().toISOString(),
      };
      onEditOrder(updatedOrder);

      const targetClient = clients.find(c => c.id === targetClientId);
      const targetEquip = equipments.find(e => e.id === targetEquipId);

      setStageCompletionModal({
        isOpen: true,
        stepNumber: 1,
        stepName: 'Etapa 1: Entrada / Check-in',
        badge: 'ETAPA CONCLUÍDA',
        title: 'Etapa de Entrada Concluída com Sucesso!',
        description: `Os dados de entrada da OS ${updatedOrder.osNumber} foram atualizados e concluídos. O equipamento está pronto para a avaliação e diagnóstico técnico.`,
        osNumber: updatedOrder.osNumber,
        clientName: targetClient?.name || 'Cliente',
        equipmentName: targetEquip ? `${targetEquip.name} (${targetEquip.model})` : 'Equipamento',
        details: [
          { label: 'Data de Entrada', value: updatedOrder.startDate || 'Hoje' },
          { label: 'Prioridade', value: updatedOrder.priority === 'HIGH' ? 'ALTA' : updatedOrder.priority === 'MEDIUM' ? 'MÉDIA' : 'BAIXA' },
          { label: 'Técnico Responsável', value: updatedOrder.technician },
        ],
        primaryActionLabel: 'Avançar para Etapa 2 (Diagnóstico) ➔',
        onPrimaryAction: () => {
          setActiveStepTab(2);
          setStageCompletionModal(null);
        }
      });

      showFeedback(`✅ Etapa 1 (Entrada) concluída com sucesso! OS ${updatedOrder.osNumber} pronta para Diagnóstico.`, 'success', 6000);
      setActiveStepTab(2);
      return;
    }

    // Antiduplicity device check for same client + same equipment
    const existingDuplicates = orders.filter(o => 
      o.clientId === targetClientId && 
      (o.equipmentId === targetEquipId || 
       equipments.find(e => e.id === o.equipmentId)?.name.toLowerCase() === equipments.find(e => e.id === targetEquipId)?.name.toLowerCase()) &&
      o.status !== 'CANCELLED' &&
      !o.isDelivered
    );
    const isDuplicate = existingDuplicates.length > 0;

    // Create Service Order
    const created = onAddOrder({
      clientId: targetClientId,
      equipmentId: targetEquipId,
      title: isDuplicate ? `${title.trim()} (2º Equipamento)` : title.trim(),
      description: isDuplicate 
        ? `${description.trim()}\n\n[DISPOSITIVO ANTIDUPLICIDADE: OS Autorizada pelo Usuário - Cliente trouxe 2º equipamento idêntico]`
        : description.trim(),
      status: 'PENDING',
      priority,
      technician,
      receiverName: receiverName.trim() || technician,
      estimatedCost: Number(estimatedCost),
      startDate: startDate,
      equipmentPhoto: photo,
      budgetStatus: 'PENDING_APPROVAL',
      orderType: orderType,
      isDuplicateAuthorized: isDuplicate,
      duplicateNote: isDuplicate ? 'Autorizado pelo usuário: 2º equipamento idêntico do cliente' : undefined
    });

    setSelectedOrderId(created.id);
    setIsCreatingNewOS(false);

    const targetClient = clients.find(c => c.id === targetClientId);
    const targetEquip = equipments.find(e => e.id === targetEquipId);

    setStageCompletionModal({
      isOpen: true,
      stepNumber: 1,
      stepName: 'Etapa 1: Entrada / Check-in',
      badge: 'NOVA OS GERADA COM SUCESSO',
      title: 'Etapa de Entrada Concluída com Sucesso!',
      description: `O equipamento foi recebido, registrado no sistema da JC&F e a OS ${created.osNumber} foi gerada com sucesso! O próximo passo é realizar o diagnóstico e orçamento.`,
      osNumber: created.osNumber,
      clientName: targetClient?.name || newClientName || 'Cliente',
      equipmentName: targetEquip ? `${targetEquip.name} (${targetEquip.model})` : (newEquipName || 'Equipamento'),
      details: [
        { label: 'Número da OS', value: created.osNumber },
        { label: 'Data de Entrada', value: created.startDate || 'Hoje' },
        { label: 'Técnico Responsável', value: created.technician },
        { label: 'Recebedor', value: created.receiverName || created.technician },
      ],
      primaryActionLabel: 'Avançar para Etapa 2 (Diagnóstico) ➔',
      onPrimaryAction: () => {
        setActiveStepTab(2);
        setStageCompletionModal(null);
      }
    });

    showFeedback(`✅ Etapa 1 (Entrada) concluída com sucesso! OS ${created.osNumber} gerada e encaminhada para Diagnóstico.`, 'success', 8000);
    setActiveStepTab(2); // Auto advance to Diagnostic
  };

  // Handler to update date for any lifecycle step dynamically
  const handleUpdateStepDate = (
    field: 'startDate' | 'budgetDate' | 'executionDate' | 'deliveryDate',
    newDate: string
  ) => {
    if (field === 'startDate') setStartDate(newDate);
    if (field === 'budgetDate') setBudgetDate(newDate);
    if (field === 'executionDate') setExecutionDate(newDate);
    if (field === 'deliveryDate') setDeliveryDate(newDate);

    if (activeOrder) {
      const updatedOrder: ServiceOrder = {
        ...activeOrder,
        [field]: newDate,
        ...(field === 'startDate' ? { startDate: newDate } : {}),
        ...(field === 'budgetDate' ? { budgetDate: newDate } : {}),
        ...(field === 'executionDate' ? { executionDate: newDate, endDate: newDate } : {}),
        ...(field === 'deliveryDate' ? { deliveryDate: newDate } : {}),
      };
      onEditOrder(updatedOrder);
      showFeedback('Data da etapa redefinida e salva com sucesso!', 'success');
    }
  };

  // HANDLER STEP 2: Save Diagnostic & Budget
  const handleSaveBudget = () => {
    if (!activeOrder) return;

    const isApproved = budgetStatus === 'APPROVED';
    const isRejected = budgetStatus === 'REJECTED';

    const updatedOrder: ServiceOrder = {
      ...activeOrder,
      diagnostic: diagnostic.trim() || undefined,
      plannedServices: plannedServices.trim() || undefined,
      estimatedCost: Number(step2EstimatedCost),
      budgetStatus: budgetStatus,
      budgetDate: budgetDate || new Date().toISOString().split('T')[0],
      // If approved, auto advance status to IN_PROGRESS if previously PENDING
      status: (isApproved && activeOrder.status === 'PENDING') ? 'IN_PROGRESS' : activeOrder.status,
      updatedAt: new Date().toISOString(),
    };

    onEditOrder(updatedOrder);

    if (isApproved) {
      setStageCompletionModal({
        isOpen: true,
        stepNumber: 2,
        stepName: 'Etapa 2: Diagnóstico & Orçamento',
        badge: 'ETAPA CONCLUÍDA & AUTORIZADA',
        title: 'Etapa de Diagnóstico Concluída com Sucesso!',
        description: `O laudo de inspeção técnica e a proposta de orçamento da OS ${updatedOrder.osNumber} foram gravados e marcados como APROVADOS pelo cliente. O serviço foi autorizado e liberado para a Etapa 3 (Execução na Bancada).`,
        osNumber: updatedOrder.osNumber,
        clientName: activeClient?.name || 'Cliente',
        equipmentName: activeEquip ? `${activeEquip.name} (${activeEquip.model})` : 'Equipamento',
        details: [
          { label: 'Situação do Orçamento', value: 'AUTORIZADO PELO CLIENTE' },
          { label: 'Valor do Orçamento', value: `R$ ${Number(step2EstimatedCost).toFixed(2)}` },
          { label: 'Data do Diagnóstico', value: updatedOrder.budgetDate || 'Hoje' },
          { label: 'Próxima Ação', value: 'Etapa 3: Execução da Manutenção' },
        ],
        primaryActionLabel: 'Avançar para Etapa 3 (Execução) ➔',
        onPrimaryAction: () => {
          setActiveStepTab(3);
          setStageCompletionModal(null);
        }
      });
      showFeedback(`✅ Etapa 2 (Diagnóstico) concluída com sucesso! Orçamento aprovado e encaminhado para Execução.`, 'success', 7000);
    } else if (isRejected) {
      setStageCompletionModal({
        isOpen: true,
        stepNumber: 2,
        stepName: 'Etapa 2: Diagnóstico & Orçamento',
        badge: 'ORÇAMENTO RECUSADO',
        title: 'Etapa de Diagnóstico Concluída (Orçamento Recusado)',
        description: `O diagnóstico técnico da OS ${updatedOrder.osNumber} foi registrado, e o orçamento foi marcado como RECUSADO pelo cliente. Você pode enviar uma contraproposta ou excluir/arquivar a OS.`,
        osNumber: updatedOrder.osNumber,
        clientName: activeClient?.name || 'Cliente',
        equipmentName: activeEquip ? `${activeEquip.name} (${activeEquip.model})` : 'Equipamento',
        details: [
          { label: 'Situação', value: 'RECUSADO PELO CLIENTE' },
          { label: 'Valor Estimado', value: `R$ ${Number(step2EstimatedCost).toFixed(2)}` },
          { label: 'Data do Registro', value: updatedOrder.budgetDate || 'Hoje' },
        ],
        primaryActionLabel: 'OK, Entendido',
        onPrimaryAction: () => setStageCompletionModal(null)
      });
      showFeedback(`Etapa 2 (Diagnóstico): Orçamento registrado como Recusado.`, 'info', 5000);
    } else {
      setStageCompletionModal({
        isOpen: true,
        stepNumber: 2,
        stepName: 'Etapa 2: Diagnóstico & Orçamento',
        badge: 'DIAGNÓSTICO GRAVADO',
        title: 'Etapa de Diagnóstico Registrada com Sucesso!',
        description: `O laudo técnico e os valores da OS ${updatedOrder.osNumber} foram salvos no sistema. O status está como 'Aguardando Aprovação' do cliente. Envie o PDF ou compartilhe via WhatsApp/E-mail.`,
        osNumber: updatedOrder.osNumber,
        clientName: activeClient?.name || 'Cliente',
        equipmentName: activeEquip ? `${activeEquip.name} (${activeEquip.model})` : 'Equipamento',
        details: [
          { label: 'Situação', value: 'AGUARDANDO APROVAÇÃO' },
          { label: 'Valor Proposto', value: `R$ ${Number(step2EstimatedCost).toFixed(2)}` },
          { label: 'Data do Laudo', value: updatedOrder.budgetDate || 'Hoje' },
        ],
        primaryActionLabel: 'OK, Entendido',
        onPrimaryAction: () => setStageCompletionModal(null)
      });
      showFeedback(`✅ Etapa 2 (Diagnóstico) registrada com sucesso! Aguardando autorização do cliente.`, 'success', 6000);
    }
  };

  // Helper to generate text string of materials and update actualCost dynamically
  const updateMaterialsStringAndCost = (newList: typeof osMaterialsList) => {
    const text = newList.map(item => `- ${item.quantity}x ${item.name} (${item.code})`).join('\n');
    setMaterialsUsed(text);
  };

  const handleAddMaterialToOS = (itemId: string, qty: number) => {
    if (!onEditInventoryItem) {
      showFeedback('Controle de estoque indisponível.', 'error');
      return;
    }
    const item = inventory.find(i => i.id === itemId);
    if (!item) {
      showFeedback('Item não encontrado no estoque.', 'error');
      return;
    }

    if (item.quantity < qty) {
      showFeedback(`Estoque insuficiente! Disponível: ${item.quantity} ${item.unit}.`, 'error');
      return;
    }

    // Deduct from stock
    const updatedStockItem = { ...item, quantity: item.quantity - qty };
    onEditInventoryItem(updatedStockItem);

    // Add to current OS list
    let updatedList = [...osMaterialsList];
    const existingIndex = updatedList.findIndex(m => m.itemId === itemId);
    if (existingIndex > -1) {
      updatedList[existingIndex] = {
        ...updatedList[existingIndex],
        quantity: updatedList[existingIndex].quantity + qty,
      };
    } else {
      updatedList.push({
        itemId: item.id,
        name: item.name,
        code: item.code,
        quantity: qty,
        salePrice: item.salePrice,
      });
    }

    setOsMaterialsList(updatedList);
    updateMaterialsStringAndCost(updatedList);
    setActualCost(prev => (prev || 0) + (qty * item.salePrice));
    
    // Reset quantity selection inputs
    setSelectedMaterialQty(1);
    setSelectedMaterialId('');
    setMaterialSearchQuery('');
    showFeedback(`${qty}x ${item.name} adicionado(s) à manutenção!`, 'success');
  };

  const handleReturnMaterialFromOS = (itemId: string, qtyToReturn: number) => {
    if (!onEditInventoryItem) {
      showFeedback('Controle de estoque indisponível.', 'error');
      return;
    }

    const addedItem = osMaterialsList.find(m => m.itemId === itemId);
    if (!addedItem) return;

    const actualQtyToReturn = Math.min(qtyToReturn, addedItem.quantity);
    if (actualQtyToReturn <= 0) return;

    const stockItem = inventory.find(i => i.id === itemId);
    if (stockItem) {
      // Add back to stock
      const updatedStockItem = { ...stockItem, quantity: stockItem.quantity + actualQtyToReturn };
      onEditInventoryItem(updatedStockItem);
    }

    // Remove or reduce in OS list
    let updatedList = [...osMaterialsList];
    const existingIndex = updatedList.findIndex(m => m.itemId === itemId);
    if (existingIndex > -1) {
      if (updatedList[existingIndex].quantity <= actualQtyToReturn) {
        updatedList.splice(existingIndex, 1);
      } else {
        updatedList[existingIndex] = {
          ...updatedList[existingIndex],
          quantity: updatedList[existingIndex].quantity - actualQtyToReturn,
        };
      }
    }

    setOsMaterialsList(updatedList);
    updateMaterialsStringAndCost(updatedList);
    setActualCost(prev => Math.max(0, (prev || 0) - (actualQtyToReturn * addedItem.salePrice)));
    showFeedback(`${actualQtyToReturn}x ${addedItem.name} retornado(s) ao estoque!`, 'info');
  };

  // HANDLER STEP 3: Save Execution
  const handleSaveExecution = (forceComplete: boolean = false) => {
    if (!activeOrder) return;

    const isNowCompleted = forceComplete || osStatus === 'COMPLETED';
    const targetStatus = isNowCompleted ? 'COMPLETED' : osStatus;
    if (forceComplete) {
      setOsStatus('COMPLETED');
    }

    const updatedOrder: ServiceOrder = {
      ...activeOrder,
      actualServicesPerformed: actualServicesPerformed.trim() || undefined,
      materialsUsed: materialsUsed.trim() || undefined,
      materialsUsedList: osMaterialsList,
      actualCost: Number(actualCost),
      executionDate: executionDate || new Date().toISOString().split('T')[0],
      status: targetStatus,
      isDelivered: isNowCompleted ? true : activeOrder.isDelivered,
      deliveryDate: isNowCompleted ? (activeOrder.deliveryDate || executionDate || new Date().toISOString().split('T')[0]) : activeOrder.deliveryDate,
      endDate: isNowCompleted ? (executionDate || activeOrder.endDate || new Date().toISOString().split('T')[0]) : activeOrder.endDate,
      updatedAt: new Date().toISOString(),
    };

    onEditOrder(updatedOrder);

    // Register history automatically if completed
    if (isNowCompleted) {
      onAutoAddHistoryFromOS(updatedOrder);
      
      // Auto add Transaction to Finance if requested
      if (onAddTransaction && actualCost > 0) {
        onAddTransaction({
          type: 'RECEIVABLE',
          description: `Faturamento - ${updatedOrder.osNumber} (${updatedOrder.title})`,
          amount: Number(actualCost),
          dueDate: new Date().toISOString().split('T')[0],
          paymentDate: new Date().toISOString().split('T')[0],
          category: 'Serviço Efetuado',
          status: 'PAID',
          notes: `Gerado automaticamente via ciclo de execução da OS ${updatedOrder.osNumber}.`,
          serviceOrderId: updatedOrder.id,
        });
      }

      setStageCompletionModal({
        isOpen: true,
        stepNumber: 3,
        stepName: 'Etapa 3: Execução da Manutenção',
        badge: 'ETAPA CONCLUÍDA COM SUCESSO',
        title: 'Etapa de Execução Concluída com Sucesso!',
        description: `Os serviços técnicos e as peças/materiais da OS ${updatedOrder.osNumber} foram registrados e concluídos na bancada. O equipamento está pronto para a Etapa 4 (Entrega ao Cliente).`,
        osNumber: updatedOrder.osNumber,
        clientName: activeClient?.name || 'Cliente',
        equipmentName: activeEquip ? `${activeEquip.name} (${activeEquip.model})` : 'Equipamento',
        details: [
          { label: 'Situação da OS', value: 'SERVIÇO CONCLUÍDO NA BANCADA' },
          { label: 'Custo Final Apurado', value: `R$ ${Number(actualCost).toFixed(2)}` },
          { label: 'Data de Conclusão', value: updatedOrder.executionDate || 'Hoje' },
          { label: 'Próxima Ação', value: 'Etapa 4: Entrega & Garantia' },
        ],
        primaryActionLabel: 'Avançar para Etapa 4 (Entrega) ➔',
        onPrimaryAction: () => {
          setActiveStepTab(4);
          setStageCompletionModal(null);
        }
      });

      showFeedback(`✅ Etapa 3 (Execução) concluída com sucesso! Equipamento pronto para Entrega.`, 'success', 7000);
    } else {
      showFeedback('✅ Progresso da Etapa de Execução salvo com sucesso! OS em andamento na oficina.', 'info', 5000);
    }
  };

  // HANDLER STEP 4: Save Delivery & Warranty
  const handleSaveFinalization = () => {
    if (!activeOrder) return;

    const todayStr = new Date().toISOString().split('T')[0];
    const finalDeliveryDate = deliveryDate || todayStr;

    // When clicking "Salvar Saída e Fechar OS", mark as delivered and completed
    setIsDelivered(true);
    setDeliveryDate(finalDeliveryDate);
    setOsStatus('COMPLETED');

    const updatedOrder: ServiceOrder = {
      ...activeOrder,
      isDelivered: true,
      deliveryDate: finalDeliveryDate,
      warrantyDays: Number(warrantyDays),
      warrantyNotes: warrantyNotes.trim() || undefined,
      deliveryPhoto: deliveryPhoto || undefined,
      paymentMethod: paymentMethod,
      paymentStatus: paymentStatus,
      status: 'COMPLETED',
      endDate: activeOrder.endDate || finalDeliveryDate,
      updatedAt: new Date().toISOString(),
    };

    onEditOrder(updatedOrder);

    // Create automatic financial transaction on transition to PAID
    if (onAddTransaction && activeOrder.paymentStatus !== 'PAID' && paymentStatus === 'PAID') {
      onAddTransaction({
        type: 'RECEIVABLE',
        description: `Recebimento OS-${activeOrder.osNumber.split('-')[1]} - ${activeClient?.name || 'Cliente'}`,
        amount: activeOrder.actualCost || activeOrder.estimatedCost || 0,
        dueDate: finalDeliveryDate,
        paymentDate: finalDeliveryDate,
        category: 'Mão de Obra / Peças',
        status: 'PAID',
        notes: `Equipamento: ${activeEquip?.name || 'Não Identificado'}. Pagamento via ${paymentMethod}.`,
        serviceOrderId: activeOrder.id
      });
    }

    // Auto-update history of client and equipment
    onAutoAddHistoryFromOS(updatedOrder);

    setStageCompletionModal({
      isOpen: true,
      stepNumber: 4,
      stepName: 'Etapa 4: Entrega & Fechamento',
      badge: 'CICLO 100% CONCLUÍDO',
      title: 'Etapa de Entrega Concluída com Sucesso!',
      description: `A entrega do equipamento da OS ${updatedOrder.osNumber} foi concluída com sucesso! A saída foi confirmada, o termo de garantia (${warrantyDays} dias) foi ativado e a Ordem de Serviço foi oficialmente encerrada e arquivada.`,
      osNumber: updatedOrder.osNumber,
      clientName: activeClient?.name || 'Cliente',
      equipmentName: activeEquip ? `${activeEquip.name} (${activeEquip.model})` : 'Equipamento',
      details: [
        { label: 'Situação Final', value: 'CONCLUÍDA & ENTREGUE AO CLIENTE' },
        { label: 'Garantia Ativada', value: `${warrantyDays} Dias` },
        { label: 'Data da Saída/Entrega', value: finalDeliveryDate },
        { label: 'Forma de Pagamento', value: `${paymentMethod} (${paymentStatus === 'PAID' ? 'PAGO' : 'PENDENTE'})` },
      ],
      primaryActionLabel: 'Visualizar Resumo da OS ➔',
      onPrimaryAction: () => setStageCompletionModal(null)
    });

    showFeedback(`✅ Etapa 4 (Entrega) concluída com sucesso! Ordem de Serviço finalizada e fechada!`, 'success', 8000);
  };

  // HANDLER: Direct completion of an OS from table or active panel
  const handleDirectComplete = (orderToComplete: ServiceOrder) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const updatedOrder: ServiceOrder = {
      ...orderToComplete,
      status: 'COMPLETED',
      isDelivered: true,
      deliveryDate: orderToComplete.deliveryDate || todayStr,
      endDate: orderToComplete.endDate || todayStr,
      updatedAt: new Date().toISOString(),
    };

    onEditOrder(updatedOrder);
    onAutoAddHistoryFromOS(updatedOrder);

    if (selectedOrderId === orderToComplete.id) {
      setOsStatus('COMPLETED');
      setIsDelivered(true);
      setDeliveryDate(updatedOrder.deliveryDate || todayStr);
    }

    const targetClient = clients.find(c => c.id === orderToComplete.clientId);
    const targetEquip = equipments.find(e => e.id === orderToComplete.equipmentId);

    setStageCompletionModal({
      isOpen: true,
      stepNumber: 4,
      stepName: 'Etapa 4: Entrega & Fechamento',
      badge: 'CICLO CONCLUÍDO',
      title: 'Etapa de Entrega Concluída com Sucesso!',
      description: `A Ordem de Serviço ${orderToComplete.osNumber} foi marcada como finalizada e o equipamento foi registrado como entregue ao cliente com sucesso!`,
      osNumber: orderToComplete.osNumber,
      clientName: targetClient?.name || 'Cliente',
      equipmentName: targetEquip ? `${targetEquip.name} (${targetEquip.model})` : 'Equipamento',
      details: [
        { label: 'Situação Final', value: 'CONCLUÍDA & ENTREGUE' },
        { label: 'Data da Finalização', value: todayStr },
      ],
      primaryActionLabel: 'OK, Entendido',
      onPrimaryAction: () => setStageCompletionModal(null)
    });

    showFeedback(`✅ Etapa de Entrega e Fechamento da OS ${orderToComplete.osNumber} concluída com sucesso!`, 'success', 8000);
  };

  // Handler: Select delivery photo upload
  const handleDeliveryPhotoClick = () => {
    deliveryFileInputRef.current?.click();
  };

  const handleDeliveryFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        showFeedback('A imagem deve ter menos de 3MB.', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setDeliveryPhoto(reader.result as string);
        showFeedback('Foto pós-manutenção anexada com sucesso!', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleShareCheckOut = (type: 'WHATSAPP' | 'EMAIL') => {
    if (!activeClient || !activeEquip || !activeOrder) return;
    
    const osNum = activeOrder.osNumber;
    const clientName = activeClient.name;
    const equipName = `${activeEquip.name} (Série: ${activeEquip.model})`;
    const servs = activeOrder.actualServicesPerformed || 'Serviços de manutenção realizados';
    const total = activeOrder.actualCost || activeOrder.estimatedCost || 0;
    const payStatus = paymentStatus === 'PAID' ? 'Pago ✅' : 'Pendente ⏳';
    const payMethod = paymentMethod;
    const wDays = warrantyDays;
    const wExpiry = wDays > 0 && deliveryDate
      ? new Date(new Date(deliveryDate).getTime() + wDays * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR')
      : 'N/A';

    const message = `🛠️ *Relatório Técnico & Saída de Equipamento - JC&F Manutenção* 🛠️\n\nOlá, *${clientName}*!\nSeu equipamento foi finalizado e está pronto para retirada:\n\n📌 *OS:* ${osNum}\n⚙️ *Equipamento:* ${equipName}\n🔧 *Serviços Executados:* "${servs}"\n\n💰 *Valor Total:* R$ ${total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}\n💳 *Status do Pagamento:* ${payStatus} (${payMethod})\n🛡️ *Período de Garantia:* ${wDays > 0 ? `${wDays} dias (Até ${wExpiry})` : 'Sem garantia'}\n\nObrigado pela preferência! Se precisar, conte com nossa equipe!`;

    setShareModalConfig({
      isOpen: true,
      title: 'Compartilhar Recibo & Garantia',
      subtitle: `OS ${osNum} • ${equipName}`,
      docType: 'RECIBO_GARANTIA',
      clientName: activeClient.name,
      clientPhone: activeClient.phone,
      clientEmail: activeClient.email || '',
      defaultChannel: type,
      defaultMessage: message,
      subject: `Relatório Técnico e Saída - OS ${osNum} - JC&F`,
    });
  };

  const handleDeleteRejectedOS = () => {
    if (!activeOrder) return;
    setOsToDelete({ id: activeOrder.id, osNumber: activeOrder.osNumber });
  };

  // WhatsApp / Email Sharing Generation Helpers
  const activeClient = clients.find(c => c.id === (activeOrder?.clientId || selectedClientId));
  const activeEquip = equipments.find(e => e.id === (activeOrder?.equipmentId || selectedEquipId));

  const handleShareCheckIn = (type: 'WHATSAPP' | 'EMAIL') => {
    if (!activeClient || !activeEquip) return;
    
    const osNum = activeOrder?.osNumber || 'NOVA';
    const clientName = activeClient.name;
    const equipName = `${activeEquip.name} (Série: ${activeEquip.model})`;
    const prob = activeOrder?.description || description;
    const est = activeOrder?.estimatedCost || estimatedCost;

    const message = `🛠️ *Ficha de Entrada - JC&F Manutenção* 🛠️\n\nOlá, *${clientName}*!\nConfirmamos a entrada do seu equipamento em nossa oficina técnica:\n\n📌 *OS:* ${osNum}\n⚙️ *Equipamento:* ${equipName}\n⚠️ *Problema Informado:* "${prob}"\n💰 *Estimativa Inicial:* ${est > 0 ? `R$ ${est.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : 'A definir após análise'}\n\nEstamos iniciando a desmontagem e análise do circuito. Em breve enviaremos o laudo técnico com o orçamento detalhado para sua aprovação. Obrigado pela confiança!`;

    setShareModalConfig({
      isOpen: true,
      title: 'Compartilhar Ficha de Entrada',
      subtitle: `OS ${osNum} • ${equipName}`,
      docType: 'FICHA_ENTRADA',
      clientName: activeClient.name,
      clientPhone: activeClient.phone,
      clientEmail: activeClient.email || '',
      defaultChannel: type,
      defaultMessage: message,
      subject: `Ficha de Entrada de Equipamento - OS ${osNum} - JC&F`,
    });
  };

  const handleShareBudget = (type: 'WHATSAPP' | 'EMAIL') => {
    if (!activeOrder || !activeClient || !activeEquip) return;

    const clientName = activeClient.name;
    const equipName = `${activeEquip.name} (Série: ${activeEquip.model})`;
    const osNum = activeOrder.osNumber;
    const diagText = diagnostic || 'Sob análise técnica detalhada';
    const servs = plannedServices || 'Brunimento, troca de vedações e testes em bancada.';
    const cost = step2EstimatedCost;

    const message = `📋 *Orçamento Técnico - JC&F Manutenção* 📋\n\nPrezado(a) *${clientName}*,\nConcluímos o diagnóstico técnico para a *OS ${osNum}*:\n\n⚙️ *Equipamento:* ${equipName}\n🔍 *Laudo Técnico:* ${diagText}\n🛠️ *Serviço/Peças propostas:* ${servs}\n\n💰 *Valor Total do Orçamento:* R$ ${cost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}\n\n⚠️ *CONDIÇÕES GERAIS DE SERVIÇO*\n\n1. O orçamento será executado somente após a autorização do cliente.\n\n2. Os equipamentos serão entregues mediante a quitação integral dos serviços, peças e demais despesas relacionadas.\n\n3. A garantia cobre exclusivamente os serviços executados e as peças fornecidas pela JC&F Manutenção, não abrangendo mau uso, quedas, sobrecargas, instalações inadequadas ou intervenções de terceiros.\n\n4. Após a comunicação da conclusão do serviço, o cliente deverá retirar o equipamento em até 90 (noventa) dias.\n\n5. Equipamentos não retirados dentro do prazo de 90 (noventa) dias estarão sujeitos à cobrança de taxa de armazenagem no valor de R$ 0,50 (cinquenta centavos) por dia, por equipamento.\n\n6. Os valores de armazenagem deverão ser pagos juntamente com os demais débitos existentes antes da retirada do equipamento.\n\n7. Ao autorizar o serviço, o cliente declara estar ciente e de acordo com as condições acima.\n\n*Por favor, responda a esta mensagem confirmando se autoriza a execução da manutenção.* Se preferir, entre em contato.`;

    setShareModalConfig({
      isOpen: true,
      title: 'Compartilhar Diagnóstico & Orçamento',
      subtitle: `OS ${osNum} • ${equipName}`,
      docType: 'ORCAMENTO',
      clientName: activeClient.name,
      clientPhone: activeClient.phone,
      clientEmail: activeClient.email || '',
      defaultChannel: type,
      defaultMessage: message,
      subject: `Orçamento para Manutenção - OS ${osNum} - JC&F`,
    });
  };

  const handleDownloadPDF = (type: PDFDocType) => {
    // If we're creating a new OS, let's alert that we need an active OS first
    if (!activeOrder) {
      showFeedback('Erro: Por favor, salve a Ordem de Serviço antes de gerar o PDF.', 'error');
      return;
    }
    if (!activeClient || !activeEquip) {
      showFeedback('Erro: Dados do cliente ou do equipamento estão incompletos.', 'error');
      return;
    }
    try {
      // Merge current form input states so that the downloaded PDF is real-time accurate
      const tempOrderForPDF: ServiceOrder = {
        ...activeOrder,
        diagnostic: diagnostic.trim() || activeOrder.diagnostic,
        plannedServices: plannedServices.trim() || activeOrder.plannedServices,
        estimatedCost: step2EstimatedCost || activeOrder.estimatedCost,
        actualServicesPerformed: actualServicesPerformed.trim() || activeOrder.actualServicesPerformed,
        materialsUsed: materialsUsed.trim() || activeOrder.materialsUsed,
        actualCost: actualCost || activeOrder.actualCost || activeOrder.estimatedCost,
        warrantyDays: warrantyDays !== undefined ? warrantyDays : activeOrder.warrantyDays,
        warrantyNotes: warrantyNotes.trim() || activeOrder.warrantyNotes,
        isDelivered: isDelivered,
        deliveryDate: deliveryDate || activeOrder.deliveryDate,
      };

      generatePDF({
        docType: type,
        order: tempOrderForPDF,
        client: activeClient,
        equipment: activeEquip
      });
      showFeedback('Documento PDF gerado e baixado com sucesso!', 'success');
    } catch (err) {
      console.error('PDF Generation Error:', err);
      showFeedback('Erro ao gerar o arquivo PDF.', 'error');
    }
  };

  // Get current history logs of selected equipment for Step 4 list
  const equipmentLogs = activeEquip 
    ? history.filter(h => h.equipmentId === activeEquip.id).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];

  const otherOrdersForEquip = activeEquip 
    ? orders.filter(o => o.equipmentId === activeEquip.id && o.id !== selectedOrderId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    : [];

  // Filter Active OS selection list
  const activeOSList = orders.filter(o => 
    (o.osNumber || '').toLowerCase().includes(osSearchQuery.toLowerCase()) ||
    (o.title || '').toLowerCase().includes(osSearchQuery.toLowerCase()) ||
    (clients.find(c => c.id === o.clientId)?.name || '').toLowerCase().includes(osSearchQuery.toLowerCase()) ||
    (equipments.find(e => e.id === o.equipmentId)?.name || '').toLowerCase().includes(osSearchQuery.toLowerCase())
  ).sort((a, b) => {
    const dateA = a.startDate || a.createdAt || '';
    const dateB = b.startDate || b.createdAt || '';
    if (dateB !== dateA) {
      return dateB.localeCompare(dateA);
    }
    return (b.osNumber || '').localeCompare(a.osNumber || '');
  });

  return (
    <div className="space-y-6" id="maintenance-lifecycle-root">
      
      {/* Upper Selector Panel */}
      <div className="bg-white rounded-2xl border-2 border-[#b0bec5] p-5 space-y-4 shadow-sm" id="os-lifecycle-selector-panel">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-sm font-black text-[#1b365d] uppercase tracking-widest flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#0052cc]" />
              Etapas do Ciclo de Vida da OS
            </h2>
            <p className="text-xs text-slate-600 font-medium">
              Gerencie a ordem de serviço dividida em 4 etapas obrigatórias: Entrada, Diagnóstico, Execução e Entrega.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {!selectedOrderId && !isCreatingNewOS ? (
              <button
                type="button"
                onClick={() => {
                  setIsCreatingNewOS(true);
                  setActiveStepTab(1);
                }}
                className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                id="btn-trigger-new-checkin"
              >
                <Plus className="w-4 h-4 text-slate-950 stroke-[3]" />
                <span>Nova Entrada (Check-In Rápido)</span>
              </button>
            ) : (
              <div className="flex items-center gap-2">
                {activeOrder && (
                  <button
                    type="button"
                    id="btn-delete-active-os-header"
                    onClick={() => setOsToDelete({ id: activeOrder.id, osNumber: activeOrder.osNumber })}
                    className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-300 text-rose-800 font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                    title="Excluir esta Ordem de Serviço"
                  >
                    <Trash2 className="w-4 h-4 text-rose-600" />
                    <span>Excluir OS</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleResetActiveOS}
                  className="px-3.5 py-2 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-[#003b7a] font-black text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer shadow-xs"
                  id="btn-return-os-list"
                >
                  Selecionar Outra OS
                </button>
              </div>
            )}
          </div>
        </div>

        {/* OS SEARCH & SELECTOR - ONLY IF NO ACTIVE SELECTION */}
        {!selectedOrderId && !isCreatingNewOS && (
          <div className="space-y-3 pt-2">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar por número de OS, Cliente ou Equipamento..."
                value={osSearchQuery}
                onChange={(e) => setOsSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border-2 border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-[#1b365d] font-bold"
              />
            </div>

            <div className="overflow-x-auto rounded-xl border-2 border-[#b0bec5] bg-white shadow-xs" id="lifecycle-os-list-container">
              <table className="w-full text-left border-collapse" id="lifecycle-os-table">
                <thead>
                  <tr className="bg-[#1b365d] text-[10px] font-black uppercase tracking-wider text-white">
                    <th className="py-3 px-4 font-mono">Nº OS</th>
                    <th className="py-3 px-4">Cliente</th>
                    <th className="py-3 px-4">Equipamento</th>
                    <th className="py-3 px-4 hidden sm:table-cell">Etapa Atual</th>
                    <th className="py-3 px-4 hidden md:table-cell">Progresso do Ciclo</th>
                    <th className="py-3 px-4 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {activeOSList.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-slate-500 text-xs font-bold">
                        Nenhuma ordem de serviço ativa encontrada. Crie uma nova entrada para começar.
                      </td>
                    </tr>
                  ) : (
                    activeOSList.map((os) => {
                      const client = clients.find(c => c.id === os.clientId);
                      const equip = equipments.find(e => e.id === os.equipmentId);
                      
                      // Progress indicator based on OS steps
                      let completedSteps: 1 | 2 | 3 | 4 = 1;
                      if (os.status === 'COMPLETED' || os.isDelivered) {
                        completedSteps = 4;
                      } else if (os.status === 'IN_PROGRESS' || os.actualServicesPerformed || os.budgetStatus === 'APPROVED') {
                        completedSteps = 3;
                      } else if (os.diagnostic || os.plannedServices || os.budgetStatus === 'PENDING_APPROVAL') {
                        completedSteps = 2;
                      } else {
                        completedSteps = 1;
                      }

                      // Define stage labels & colors
                      const currentStageLabel = 
                        completedSteps === 4 ? 'Finalizada / Concluída' :
                        completedSteps === 3 ? 'Em Execução' :
                        completedSteps === 2 ? 'Diagnóstico & Orçamento' : 'Entrada (Check-in)';

                      const currentStageColor = 
                        completedSteps === 4 ? 'text-emerald-800 bg-emerald-100 border-emerald-300' :
                        completedSteps === 3 ? 'text-purple-800 bg-purple-100 border-purple-300' :
                        completedSteps === 2 ? 'text-amber-900 bg-amber-100 border-amber-300' : 
                        'text-blue-800 bg-blue-100 border-blue-300';

                      return (
                        <tr 
                          key={os.id}
                          onClick={() => {
                            setSelectedOrderId(os.id);
                            setActiveStepTab(completedSteps);
                          }}
                          className="group hover:bg-blue-50/60 transition-colors cursor-pointer"
                        >
                          {/* OS Number */}
                          <td className="py-3.5 px-4 font-mono">
                            <span className="text-[#0052cc] font-black text-xs tracking-wider group-hover:underline">
                              {os.osNumber}
                            </span>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-md uppercase tracking-wider ${
                                os.orderType === 'WARRANTY' 
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300' 
                                  : 'bg-blue-100 text-[#003b7a] border border-blue-300'
                              }`}>
                                {os.orderType === 'WARRANTY' ? 'Garantia' : 'Serviço'}
                              </span>
                              <span className="text-[9px] text-slate-600 font-medium">
                                • {os.startDate ? new Date(os.startDate).toLocaleDateString('pt-BR') : 'Sem data'}
                              </span>
                            </div>
                          </td>

                          {/* Client */}
                          <td className="py-3.5 px-4">
                            <div className="text-xs font-black text-slate-900 truncate max-w-[140px]">
                              {client?.name || 'Cliente desconhecido'}
                            </div>
                            <span className="text-[9px] text-slate-600 font-bold block">
                              {client?.phone || 'Sem telefone'}
                            </span>
                          </td>

                          {/* Equipment */}
                          <td className="py-3.5 px-4">
                            <div className="text-xs font-bold text-slate-800 truncate max-w-[160px]">
                              {equip?.name || 'Sem equipamento'}
                            </div>
                            <span className="text-[9px] text-slate-600 font-medium block truncate max-w-[160px]">
                              Mod: {equip?.model || '-'}
                            </span>
                          </td>

                          {/* Status / Active stage */}
                          <td className="py-3.5 px-4 hidden sm:table-cell">
                            <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md border ${currentStageColor}`}>
                              {currentStageLabel}
                            </span>
                          </td>

                          {/* Horizontal step indicators inside the list */}
                          <td className="py-3.5 px-4 hidden md:table-cell">
                            <div className="flex items-center gap-1.5 text-[8px] font-black font-mono">
                              <span className={`px-1.5 py-0.5 rounded-sm border ${completedSteps >= 1 ? 'text-[#003b7a] bg-blue-100 border-blue-300' : 'text-slate-500 bg-slate-100 border-slate-200'}`}>
                                01. Entrada
                              </span>
                              <ChevronRight className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                              <span className={`px-1.5 py-0.5 rounded-sm border ${completedSteps >= 2 ? 'text-amber-900 bg-amber-100 border-amber-300' : 'text-slate-500 bg-slate-100 border-slate-200'}`}>
                                02. Diagnóstico
                              </span>
                              <ChevronRight className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                              <span className={`px-1.5 py-0.5 rounded-sm border ${completedSteps >= 3 ? 'text-purple-900 bg-purple-100 border-purple-300' : 'text-slate-500 bg-slate-100 border-slate-200'}`}>
                                03. Execução
                              </span>
                              <ChevronRight className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                              <span className={`px-1.5 py-0.5 rounded-sm border ${completedSteps >= 4 ? 'text-emerald-900 bg-emerald-100 border-emerald-300' : 'text-slate-500 bg-slate-100 border-slate-200'}`}>
                                04. Entrega
                              </span>
                            </div>
                          </td>

                          {/* Selection and delete action */}
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                              {os.status !== 'COMPLETED' && !os.isDelivered ? (
                                <button
                                  type="button"
                                  id={`lifecycle-btn-complete-os-${os.id}`}
                                  onClick={() => handleDirectComplete(os)}
                                  className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[9px] uppercase tracking-wider rounded-md flex items-center gap-1 cursor-pointer transition-colors shadow-xs"
                                  title="Finalizar e Concluir esta OS agora"
                                >
                                  <CheckCircle2 className="w-3 h-3" />
                                  <span>Finalizar</span>
                                </button>
                              ) : (
                                <span className="px-2 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-900 font-black text-[8px] uppercase tracking-wider rounded-md flex items-center gap-1">
                                  <Check className="w-2.5 h-2.5" />
                                  <span>Concluída</span>
                                </span>
                              )}
                              <button
                                type="button"
                                id={`lifecycle-btn-delete-os-${os.id}`}
                                onClick={() => setOsToDelete({ id: os.id, osNumber: os.osNumber })}
                                className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-900 border border-rose-200 rounded-lg text-[10px] font-black flex items-center gap-1 cursor-pointer transition-colors shadow-xs"
                                title="Excluir Ordem de Serviço"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                <span>Excluir</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedOrderId(os.id);
                                  setActiveStepTab(completedSteps);
                                }}
                                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white font-black text-[9px] uppercase tracking-wider rounded-md transition-colors cursor-pointer shadow-xs"
                              >
                                Acessar
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Floating Notification Toast */}
      {feedback && (
        <div 
          className={`fixed top-5 left-1/2 -translate-x-1/2 z-[100] max-w-lg w-[92vw] sm:w-auto p-4 rounded-2xl border-2 shadow-2xl flex items-center gap-3 transition-all animate-in fade-in slide-in-from-top-4 duration-200 ${
            feedback.type === 'success' 
              ? 'bg-[#064e3b] text-emerald-50 border-emerald-400 shadow-emerald-950/40' 
              : feedback.type === 'error' 
              ? 'bg-[#881337] text-rose-50 border-rose-400 shadow-rose-950/40' 
              : 'bg-[#1e3a8a] text-blue-50 border-blue-400 shadow-blue-950/40'
          }`} 
          id="lifecycle-floating-feedback"
          role="alert"
        >
          {feedback.type === 'success' ? (
            <div className="w-8 h-8 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5 text-emerald-200" />
            </div>
          ) : feedback.type === 'error' ? (
            <div className="w-8 h-8 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 text-rose-200" />
            </div>
          ) : (
            <div className="w-8 h-8 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center shrink-0">
              <Info className="w-5 h-5 text-blue-200" />
            </div>
          )}
          <div className="flex-1 pr-2">
            <div className="text-xs font-black tracking-tight leading-snug">{feedback.message}</div>
          </div>
          <button 
            type="button" 
            onClick={() => setFeedback(null)} 
            className="p-1 hover:bg-white/20 rounded-lg text-white/80 hover:text-white cursor-pointer transition-colors"
            title="Fechar aviso"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {feedback && (
        <div className={`p-4 rounded-xl border-2 flex items-start gap-3 transition-all max-w-2xl mx-auto shadow-xs ${
          feedback.type === 'success' 
            ? 'bg-emerald-50 border-emerald-300 text-emerald-900' 
            : feedback.type === 'error' 
            ? 'bg-rose-50 border-rose-300 text-rose-900' 
            : 'bg-blue-50 border-blue-300 text-blue-900'
        }`} id="lifecycle-feedback">
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 mt-0.5 shrink-0 text-emerald-600" />
          ) : (
            <AlertTriangle className="w-5 h-5 mt-0.5 shrink-0" />
          )}
          <div className="text-xs font-black font-sans tracking-tight">{feedback.message}</div>
        </div>
      )}

      {/* RENDER ACTIVE CYCLE VIEW */}
      {(selectedOrderId || isCreatingNewOS) && (
        <div className="space-y-6" id="active-lifecycle-workflow">
          
          {/* Top Date Control Panel for Viewing and Redefining Execution Dates across all 4 stages */}
          {activeOrder && !isCreatingNewOS && (
            <div className="bg-white rounded-2xl border-2 border-[#b0bec5] p-4 space-y-3 shadow-xs" id="lifecycle-dates-panel">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 pb-2.5 gap-2">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#0052cc]" />
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                    Datas do Ciclo da OS (Visualização e Redefinição de Execução)
                  </h3>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] text-slate-800 font-mono font-black bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                    OS: <strong className="text-[#0052cc]">{activeOrder.osNumber}</strong>
                  </span>
                  <span className="text-[10px] text-slate-700 font-mono">
                    Cliente: <span className="text-slate-950 font-black">{activeClient?.name}</span>
                  </span>
                  {activeOrder.status === 'COMPLETED' || activeOrder.isDelivered ? (
                    <span className="px-2.5 py-1 bg-emerald-100 border border-emerald-300 text-emerald-900 font-black text-[10px] uppercase rounded-lg flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                      <span>OS Finalizada & Concluída</span>
                    </span>
                  ) : (
                    <button
                      type="button"
                      id="btn-quick-complete-active-os"
                      onClick={() => handleDirectComplete(activeOrder)}
                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[10px] uppercase rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
                      title="Marcar esta OS como Finalizada e Concluída"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Finalizar OS Agora</span>
                    </button>
                  )}
                  <button
                    type="button"
                    id="btn-delete-active-os-dates-panel"
                    onClick={() => setOsToDelete({ id: activeOrder.id, osNumber: activeOrder.osNumber })}
                    className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-800 hover:text-rose-950 font-black text-[10px] uppercase rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
                    title="Excluir esta Ordem de Serviço"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                    <span>Excluir OS</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {/* Date 1: Entrada */}
                <div className="bg-blue-50/60 p-3 rounded-xl border-2 border-blue-200 space-y-1.5 shadow-xs">
                  <label className="block text-[9.5px] font-black uppercase text-slate-800 tracking-wider flex items-center justify-between">
                    <span>1. Entrada (Check-in)</span>
                    <span className="text-[#0052cc] font-mono text-[8.5px] font-black">Etapa 1</span>
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => handleUpdateStepDate('startDate', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono font-bold focus:border-[#0052cc] focus:outline-none transition-colors"
                  />
                  <span className="block text-[8.5px] text-slate-600 font-bold">Data de Registro/Entrada</span>
                </div>

                {/* Date 2: Diagnóstico */}
                <div className="bg-amber-50/60 p-3 rounded-xl border-2 border-amber-200 space-y-1.5 shadow-xs">
                  <label className="block text-[9.5px] font-black uppercase text-slate-800 tracking-wider flex items-center justify-between">
                    <span>2. Diagnóstico</span>
                    <span className="text-amber-800 font-mono text-[8.5px] font-black">Etapa 2</span>
                  </label>
                  <input
                    type="date"
                    value={budgetDate}
                    onChange={(e) => handleUpdateStepDate('budgetDate', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono font-bold focus:border-amber-500 focus:outline-none transition-colors"
                  />
                  <span className="block text-[8.5px] text-slate-600 font-bold">Data do Laudo/Orçamento</span>
                </div>

                {/* Date 3: Execução */}
                <div className="bg-purple-50/60 p-3 rounded-xl border-2 border-purple-200 space-y-1.5 shadow-xs">
                  <label className="block text-[9.5px] font-black uppercase text-slate-800 tracking-wider flex items-center justify-between">
                    <span>3. Execução</span>
                    <span className="text-purple-800 font-mono text-[8.5px] font-black">Etapa 3</span>
                  </label>
                  <input
                    type="date"
                    value={executionDate}
                    onChange={(e) => handleUpdateStepDate('executionDate', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono font-bold focus:border-purple-500 focus:outline-none transition-colors"
                  />
                  <span className="block text-[8.5px] text-slate-600 font-bold">Data de Execução do Serviço</span>
                </div>

                {/* Date 4: Entrega */}
                <div className="bg-emerald-50/60 p-3 rounded-xl border-2 border-emerald-200 space-y-1.5 shadow-xs">
                  <label className="block text-[9.5px] font-black uppercase text-slate-800 tracking-wider flex items-center justify-between">
                    <span>4. Finalização</span>
                    <span className="text-emerald-800 font-mono text-[8.5px] font-black">Etapa 4</span>
                  </label>
                  <input
                    type="date"
                    value={deliveryDate}
                    onChange={(e) => handleUpdateStepDate('deliveryDate', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono font-bold focus:border-emerald-500 focus:outline-none transition-colors"
                  />
                  <span className="block text-[8.5px] text-slate-600 font-bold">Data de Entrega/Saída</span>
                </div>
              </div>
            </div>
          )}

          {/* Main Visual Stepper Navigation Bar */}
          <div className="grid grid-cols-4 gap-2 bg-white p-2.5 rounded-2xl border-2 border-[#b0bec5] shadow-xs" id="visual-stepper-nav">
            <button
              type="button"
              disabled={isCreatingNewOS && activeStepTab < 1}
              onClick={() => setActiveStepTab(1)}
              className={`py-3 px-1 rounded-xl text-center cursor-pointer transition-all ${
                activeStepTab === 1 
                  ? 'bg-blue-50 border-2 border-[#0052cc] text-[#003b7a] font-black shadow-xs' 
                  : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
              }`}
            >
              <span className="block text-base font-black font-mono text-[#0052cc]">01</span>
              <span className="block text-[9px] font-black uppercase tracking-wider text-slate-900">01. Entrada (Check-in)</span>
            </button>

            <button
              type="button"
              disabled={isCreatingNewOS || !selectedOrderId}
              onClick={() => setActiveStepTab(2)}
              className={`py-3 px-1 rounded-xl text-center transition-all ${
                isCreatingNewOS || !selectedOrderId ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'
              } ${
                activeStepTab === 2 
                  ? 'bg-amber-50 border-2 border-amber-500 text-amber-950 font-black shadow-xs' 
                  : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
              }`}
            >
              <span className="block text-base font-black font-mono text-amber-600">02</span>
              <span className="block text-[9px] font-black uppercase tracking-wider text-slate-900">02. Diagnóstico</span>
            </button>

            <button
              type="button"
              disabled={isCreatingNewOS || !selectedOrderId}
              onClick={() => setActiveStepTab(3)}
              className={`py-3 px-1 rounded-xl text-center transition-all ${
                isCreatingNewOS || !selectedOrderId ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'
              } ${
                activeStepTab === 3 
                  ? 'bg-purple-50 border-2 border-purple-500 text-purple-950 font-black shadow-xs' 
                  : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
              }`}
            >
              <span className="block text-base font-black font-mono text-purple-600">03</span>
              <span className="block text-[9px] font-black uppercase tracking-wider text-slate-900">03. Execução</span>
            </button>

            <button
              type="button"
              disabled={isCreatingNewOS || !selectedOrderId}
              onClick={() => setActiveStepTab(4)}
              className={`py-3 px-1 rounded-xl text-center transition-all ${
                isCreatingNewOS || !selectedOrderId ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'
              } ${
                activeStepTab === 4 
                  ? 'bg-emerald-50 border-2 border-emerald-500 text-emerald-950 font-black shadow-xs' 
                  : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
              }`}
            >
              <span className="block text-base font-black font-mono text-emerald-600">04</span>
              <span className="block text-[9px] font-black uppercase tracking-wider text-slate-900">04. Entrega</span>
            </button>
          </div>

          {/* ACTIVE STEP CONTENT */}
          <div className="bg-white rounded-3xl border-2 border-[#b0bec5] p-6 shadow-sm" id="lifecycle-step-body">
            
            {/* STAGE 1: CHECK-IN RAPIDO */}
            {activeStepTab === 1 && (
              <div className="space-y-6" id="stage-1-pane">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="space-y-0.5">
                    <span className="block text-[10px] uppercase tracking-widest font-black text-[#0052cc] font-mono">Etapa 01 de 04</span>
                    <h3 className="text-base font-black text-slate-900 uppercase tracking-wider">Check-in Rápido / Entrada de Equipamento</h3>
                  </div>
                  {activeOrder && (
                    <div className="flex gap-2">
                      <span className={`text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-lg border ${
                        activeOrder.orderType === 'WARRANTY' 
                          ? 'text-amber-900 bg-amber-100 border-amber-300' 
                          : 'text-[#003b7a] bg-blue-100 border-blue-300'
                      }`}>
                        {activeOrder.orderType === 'WARRANTY' ? 'Garantia' : 'Serviço'}
                      </span>
                      <span className="text-xs font-mono font-black text-[#0052cc] bg-blue-50 px-3 py-1 rounded-lg border border-blue-200">{activeOrder.osNumber}</span>
                    </div>
                  )}
                </div>

                {/* If selected order exists, we display summary / view mode first with print slips */}
                {activeOrder && !isCreatingNewOS ? (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Left & Middle Column: Summary Data */}
                    <div className="lg:col-span-2 space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border-2 border-slate-200">
                        <div className="space-y-1">
                          <span className="text-[9px] uppercase tracking-wider font-black text-slate-600">Cliente Proprietário</span>
                          <p className="text-xs font-black text-slate-950">{activeClient?.name}</p>
                          <p className="text-[11px] font-mono font-bold text-slate-700">{activeClient?.phone}</p>
                          <p className="text-[11px] text-slate-600 font-medium">{activeClient?.address}</p>
                        </div>

                        <div className="space-y-1">
                          <span className="text-[9px] uppercase tracking-wider font-black text-slate-600">Equipamento</span>
                          <p className="text-xs font-black text-slate-950">{activeEquip?.name}</p>
                          <p className="text-[11px] font-mono font-bold text-slate-700">Modelo/Série: {activeEquip?.model || 'Não Informado'}</p>
                          <p className="text-[11px] font-black text-[#0052cc]">Tipo: {activeEquip?.type || 'Hidráulico'}</p>
                        </div>
                      </div>

                      <div className="space-y-1 bg-slate-50 p-4 rounded-2xl border-2 border-slate-200">
                        <span className="text-[9px] uppercase tracking-wider font-black text-slate-600 block">Problema Informado / Reclamação do Cliente</span>
                        <p className="text-xs font-sans text-slate-800 whitespace-pre-line leading-relaxed italic bg-white p-3 rounded-xl border border-slate-300 font-medium">
                          "{activeOrder.description}"
                        </p>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 text-center">
                          <span className="text-[9px] uppercase tracking-wider font-black text-slate-600 block">Tipo de Ordem</span>
                          <span className={`text-xs font-black block mt-1 uppercase ${
                            activeOrder.orderType === 'WARRANTY' ? 'text-amber-800' : 'text-[#0052cc]'
                          }`}>
                            {activeOrder.orderType === 'WARRANTY' ? 'Garantia' : 'Serviço'}
                          </span>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 text-center">
                          <span className="text-[9px] uppercase tracking-wider font-black text-slate-600 block">Recebedor do Equipamento</span>
                          <span className="text-xs font-black text-slate-900 block mt-1">{activeOrder.receiverName || activeOrder.technician}</span>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 text-center">
                          <span className="text-[9px] uppercase tracking-wider font-black text-slate-600 block">Valor Estimado</span>
                          <span className="text-xs font-black text-emerald-700 block mt-1">
                            {activeOrder.estimatedCost > 0 
                              ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(activeOrder.estimatedCost)
                              : 'Sob Orçamento'
                            }
                          </span>
                        </div>
                      </div>

                      {/* Slip Actions */}
                      <div className="bg-blue-50/70 p-5 rounded-2xl border-2 border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1">
                          <span className="text-xs font-black text-[#1b365d] uppercase tracking-wider block">Ficha de Entrada Gerada</span>
                          <p className="text-[10px] text-slate-600 font-medium">Gere e compartilhe a ficha de entrada com cabeçalho oficial em PDF ou envie pelos canais.</p>
                        </div>
                        <div className="flex gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleDownloadPDF('FICHA_ENTRADA')}
                            className="px-3.5 py-2 bg-white border-2 border-slate-300 hover:border-slate-400 text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <FileText className="w-4 h-4 text-[#0052cc]" />
                            <span>Baixar PDF</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleShareCheckIn('WHATSAPP')}
                            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <MessageSquare className="w-4 h-4" />
                            <span>WhatsApp</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleShareCheckIn('EMAIL')}
                            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <Mail className="w-4 h-4" />
                            <span>E-mail</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Right Column: Photo */}
                    <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 flex flex-col justify-between">
                      <span className="text-[9px] uppercase tracking-wider font-black text-slate-700 block text-center">Foto do Equipamento na Entrada</span>
                      
                      <div className="flex-1 flex items-center justify-center bg-white rounded-xl overflow-hidden border-2 border-slate-200 aspect-square max-h-[300px] my-3">
                        {activeOrder.equipmentPhoto ? (
                          <img src={activeOrder.equipmentPhoto} alt="Equipamento" className="w-full h-full object-cover" />
                        ) : (
                          <div className="text-center text-slate-500 p-6">
                            <Camera className="w-10 h-10 mx-auto mb-2 opacity-60 text-slate-400" />
                            <span className="text-xs font-bold block">Nenhuma foto enviada no check-in</span>
                          </div>
                        )}
                      </div>

                      <div className="text-center">
                        <span className="text-[10px] text-slate-600 block font-bold">Sincronizado via LocalStorage</span>
                      </div>
                    </div>

                  </div>
                ) : (
                  /* Form to Create New Check-in Order */
                  <form onSubmit={handleCreateOrderSubmit} className="space-y-6" id="new-checkin-creation-form">
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      
                      {/* Left: Client and Equipment Selector */}
                      <div className="space-y-5">
                        
                        {/* 1. Client Select or Register */}
                        <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-4">
                          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                            <span className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                              <User className="w-4 h-4 text-[#0052cc]" />
                              Cliente do Equipamento
                            </span>
                            <div className="flex bg-slate-200 p-0.5 rounded-lg border border-slate-300">
                              <button
                                type="button"
                                onClick={() => setCheckinClientMode('SELECT')}
                                className={`px-2.5 py-1 rounded-md text-[9px] font-black uppercase transition-all cursor-pointer ${
                                  checkinClientMode === 'SELECT' ? 'bg-[#1b365d] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                                }`}
                              >
                                Selecionar
                              </button>
                              <button
                                type="button"
                                onClick={() => setCheckinClientMode('CREATE')}
                                className={`px-2.5 py-1 rounded-md text-[9px] font-black uppercase transition-all cursor-pointer ${
                                  checkinClientMode === 'CREATE' ? 'bg-[#1b365d] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                                }`}
                              >
                                + Cadastrar
                              </button>
                            </div>
                          </div>

                          {checkinClientMode === 'SELECT' ? (
                            <div className="space-y-2">
                              <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                                <input
                                  type="text"
                                  placeholder="Filtrar clientes..."
                                  value={clientSearch}
                                  onChange={(e) => setClientSearch(e.target.value)}
                                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold"
                                />
                              </div>
                              <select
                                value={selectedClientId}
                                onChange={(e) => setSelectedClientId(e.target.value)}
                                className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold focus:border-[#0052cc] shadow-xs"
                                id="stage-1-select-client"
                              >
                                <option value="" className="bg-white text-black font-bold">Escolha o cliente...</option>
                                {filteredClients.map(c => (
                                  <option key={c.id} value={c.id} className="bg-white text-black font-bold">{c.name} - {c.phone}</option>
                                ))}
                              </select>
                            </div>
                          ) : (
                            <div className="grid grid-cols-2 gap-3 pt-1">
                              <div className="col-span-2 space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Nome Completo *</span>
                                <input
                                  type="text"
                                  placeholder="Ex: João da Silva"
                                  value={newClientName}
                                  onChange={(e) => setNewClientName(e.target.value)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold"
                                />
                              </div>
                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Telefone *</span>
                                <input
                                  type="text"
                                  placeholder="Ex: (21) 98369-9728"
                                  value={newClientPhone}
                                  onChange={(e) => setNewClientPhone(formatPhoneNumber(e.target.value))}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono font-bold"
                                />
                              </div>
                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">CPF / CNPJ</span>
                                <input
                                  type="text"
                                  placeholder="Ex: 000.000.000-00"
                                  value={newClientDoc}
                                  onChange={(e) => setNewClientDoc(e.target.value)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold"
                                />
                              </div>
                              <div className="col-span-2 space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Endereço Residencial/Comercial</span>
                                <input
                                  type="text"
                                  placeholder="Ex: Av das Nações, 1500"
                                  value={newClientAddress}
                                  onChange={(e) => setNewClientAddress(e.target.value)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold"
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        {/* 2. Equipment Select or Register */}
                        <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-4">
                          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                            <span className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                              <Package className="w-4 h-4 text-[#0052cc]" />
                              Equipamento Recebido
                            </span>
                            <div className="flex bg-slate-200 p-0.5 rounded-lg border border-slate-300">
                              <button
                                type="button"
                                onClick={() => setCheckinEquipMode('SELECT')}
                                className={`px-2.5 py-1 rounded-md text-[9px] font-black uppercase transition-all cursor-pointer ${
                                  checkinEquipMode === 'SELECT' ? 'bg-[#1b365d] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                                }`}
                              >
                                Selecionar
                              </button>
                              <button
                                type="button"
                                onClick={() => setCheckinEquipMode('CREATE')}
                                className={`px-2.5 py-1 rounded-md text-[9px] font-black uppercase transition-all cursor-pointer ${
                                  checkinEquipMode === 'CREATE' ? 'bg-[#1b365d] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                                }`}
                              >
                                + Cadastrar
                              </button>
                            </div>
                          </div>

                          {checkinEquipMode === 'SELECT' ? (
                            <div className="space-y-2">
                              <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                                <input
                                  type="text"
                                  placeholder="Filtrar equipamentos..."
                                  value={equipSearch}
                                  onChange={(e) => setEquipSearch(e.target.value)}
                                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold"
                                />
                              </div>
                              <select
                                value={selectedEquipId}
                                onChange={(e) => setSelectedEquipId(e.target.value)}
                                className="w-full px-3 py-2 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold focus:border-[#0052cc] shadow-xs"
                                id="stage-1-select-equip"
                              >
                                <option value="" className="bg-white text-black font-bold">Escolha o equipamento...</option>
                                {filteredEquipments.map(e => (
                                  <option key={e.id} value={e.id} className="bg-white text-black font-bold">{e.name} (Série: {e.model})</option>
                                ))}
                              </select>
                            </div>
                          ) : (
                            <div className="grid grid-cols-2 gap-3 pt-1">
                              <div className="col-span-2 space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Nome do Equipamento *</span>
                                <input
                                  type="text"
                                  placeholder='Ex: Cilindro Hidráulico Parker 2"'
                                  value={newEquipName}
                                  onChange={(e) => setNewEquipName(e.target.value)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold"
                                />
                              </div>
                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Modelo ou Nº Série</span>
                                <input
                                  type="text"
                                  placeholder="Ex: PK-827361"
                                  value={newEquipModel}
                                  onChange={(e) => setNewEquipModel(e.target.value)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold"
                                />
                              </div>
                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Tipo</span>
                                <select
                                  value={newEquipType}
                                  onChange={(e) => setNewEquipType(e.target.value)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-black font-bold shadow-xs"
                                >
                                  <option value="Hidráulico" className="bg-white text-black font-bold">Hidráulico</option>
                                  <option value="Pneumático" className="bg-white text-black font-bold">Pneumático</option>
                                  <option value="Geral" className="bg-white text-black font-bold">Geral / Misto</option>
                                </select>
                              </div>
                            </div>
                          )}
                        </div>

                      </div>

                      {/* Right: Technical Details & Photo */}
                      <div className="space-y-5">
                        
                        {/* Details */}
                        <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-4">
                          <span className="text-xs font-black text-slate-900 uppercase tracking-wider block border-b border-slate-200 pb-2">
                            Detalhes Técnicos da Entrada
                          </span>

                          <div className="space-y-3">
                            <div className="space-y-1.5">
                              <label className="block text-[9px] font-black text-slate-700 uppercase">Título Resumido do Serviço *</label>
                              <input
                                type="text"
                                required
                                placeholder="Ex: Brunimento de Cilindro / Substituição de Válvula"
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-bold"
                              />
                            </div>

                            <div className="space-y-1.5">
                              <label className="block text-[9px] font-bold text-slate-700 uppercase">Sintomas / Problema Reclamado pelo Cliente *</label>
                              <textarea
                                required
                                rows={3}
                                placeholder="Descreva exatamente o que o cliente reclamou ou observou sobre o mau funcionamento..."
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                className="w-full px-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold leading-relaxed font-mono focus:border-blue-600 focus:bg-white placeholder:text-slate-500 placeholder:font-normal"
                              />
                            </div>

                            <div className="grid grid-cols-3 gap-3">
                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Data de Entrada *</span>
                                <input
                                  type="date"
                                  required
                                  value={startDate}
                                  onChange={(e) => setStartDate(e.target.value)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono font-bold"
                                />
                              </div>

                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Tipo de Ordem *</span>
                                <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-200 rounded-lg border border-slate-300 h-[34px] items-center">
                                  <button
                                    type="button"
                                    onClick={() => setOrderType('SERVICE')}
                                    className={`h-full rounded-md text-[9px] font-black uppercase transition-all cursor-pointer ${
                                      orderType === 'SERVICE' ? 'bg-[#0052cc] text-white' : 'text-slate-600 hover:text-slate-900'
                                    }`}
                                  >
                                    Serviço
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setOrderType('WARRANTY');
                                      setEstimatedCost(0);
                                    }}
                                    className={`h-full rounded-md text-[9px] font-black uppercase transition-all cursor-pointer ${
                                      orderType === 'WARRANTY' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-600 hover:text-slate-900'
                                    }`}
                                  >
                                    Garantia
                                  </button>
                                </div>
                              </div>

                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Prioridade</span>
                                <select
                                  value={priority}
                                  onChange={(e) => setPriority(e.target.value as any)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-black font-bold h-[34px] shadow-xs"
                                >
                                  <option value="LOW" className="bg-white text-black font-bold">Baixa</option>
                                  <option value="MEDIUM" className="bg-white text-black font-bold">Média</option>
                                  <option value="HIGH" className="bg-white text-black font-bold">Crítica</option>
                                </select>
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-3 pt-1">
                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Técnico Entrada</span>
                                <select
                                  value={technician}
                                  onChange={(e) => setTechnician(e.target.value)}
                                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-black font-bold shadow-xs"
                                >
                                  {technicians.filter(t => t.status === 'ACTIVE').map(t => (
                                    <option key={t.id} value={t.name} className="bg-white text-black font-bold">{t.name} - {t.specialty}</option>
                                  ))}
                                  {technician && !technicians.some(t => t.name === technician && t.status === 'ACTIVE') && (
                                    <option value={technician} className="bg-white text-black font-bold">{technician} (Atual)</option>
                                  )}
                                  {technicians.length === 0 && (
                                    <>
                                      <option value="João CLAUDIO" className="bg-white text-black font-bold">João CLAUDIO</option>
                                      <option value="Felipe" className="bg-white text-black font-bold">Felipe</option>
                                      <option value="Suporte Técnico" className="bg-white text-black font-bold">Suporte Técnico</option>
                                    </>
                                  )}
                                </select>
                              </div>

                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-[9px] font-black text-slate-700 uppercase block">Pessoa Recebedora *</span>
                                  <button
                                    type="button"
                                    onClick={() => setShowReceiversModal(true)}
                                    className="text-[9px] text-[#0052cc] hover:underline font-bold cursor-pointer"
                                  >
                                    Gerenciar
                                  </button>
                                </div>
                                <select
                                  value={receiverName}
                                  onChange={(e) => {
                                    if (e.target.value === 'ADD_NEW') {
                                      setShowReceiversModal(true);
                                    } else {
                                      setReceiverName(e.target.value);
                                    }
                                  }}
                                  className="w-full px-2.5 py-2 bg-white border border-slate-300 rounded-lg text-xs text-black font-bold cursor-pointer shadow-xs"
                                >
                                  {activeReceivers.map((r) => (
                                    <option key={r} value={r} className="bg-white text-black font-bold">
                                      {r}
                                    </option>
                                  ))}
                                  <option value="ADD_NEW" className="bg-white text-blue-700 font-extrabold">
                                    + Cadastrar / Gerenciar Recebedores...
                                  </option>
                                </select>
                              </div>

                              <div className="space-y-1">
                                <span className="text-[9px] font-black text-slate-700 uppercase block">Estimativa de Orçamento (R$)</span>
                                <div className="relative">
                                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-xs">R$</span>
                                  <input
                                    type="number"
                                    step="0.01;any"
                                    min="0"
                                    placeholder="0,00 para definir depois"
                                    value={estimatedCost || ''}
                                    onChange={(e) => setEstimatedCost(parseFloat(e.target.value) || 0)}
                                    className="w-full pl-8 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono font-bold"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Photo Attachment Container */}
                        <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-3">
                          <span className="text-xs font-black text-slate-900 uppercase tracking-wider block border-b border-slate-200 pb-2">
                            Anexar Foto de Entrada (Laudo Visual)
                          </span>

                          <div className="flex gap-4">
                            {/* Upload Area */}
                            <div 
                              onClick={handlePhotoClick}
                              className="w-24 h-24 bg-white border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-[#0052cc] hover:bg-blue-50/40 transition-colors shrink-0"
                            >
                              {photo ? (
                                <img src={photo} alt="Upload" className="w-full h-full object-cover rounded-xl" />
                              ) : (
                                <div className="text-center p-2 text-slate-500">
                                  <Camera className="w-5 h-5 mx-auto mb-1 opacity-70 text-slate-400" />
                                  <span className="text-[8px] block font-bold font-sans uppercase">Enviar</span>
                                </div>
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                ref={fileInputRef}
                                onChange={handleFileChange}
                                className="hidden"
                              />
                            </div>

                            {/* Preset Options */}
                            <div className="flex-1 space-y-2">
                              <span className="text-[9px] font-black text-slate-700 uppercase tracking-wider block">Fotos Rápidas Ilustrativas</span>
                              <div className="grid grid-cols-2 gap-2">
                                {PRESET_PHOTOS.map(p => (
                                  <button
                                    type="button"
                                    key={p.id}
                                    onClick={() => {
                                      setPhoto(p.url);
                                      showFeedback('Foto rápida selecionada!', 'success');
                                    }}
                                    className={`p-1.5 bg-white rounded-lg border text-left flex items-center gap-1.5 cursor-pointer transition-all ${
                                      photo === p.url ? 'border-[#0052cc] bg-blue-50 ring-2 ring-[#0052cc]/30' : 'border-slate-300 hover:border-slate-400'
                                    }`}
                                  >
                                    <img src={p.url} alt={p.name} className="w-6 h-6 object-cover rounded-md" />
                                    <span className="text-[8px] text-slate-700 truncate block font-bold">{p.name}</span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                      </div>

                    </div>

                    {/* Submit Button */}
                    <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                      <button
                        type="button"
                        onClick={handleResetActiveOS}
                        className="px-4 py-2 text-slate-600 hover:text-slate-900 text-xs font-bold uppercase transition-colors"
                      >
                        Cancelar
                      </button>
                      <button
                        type="submit"
                        className="px-8 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-widest rounded-xl shadow-md transition-all cursor-pointer"
                        id="btn-lifecycle-submit-step-1"
                      >
                        Concluir Entrada & Avançar
                      </button>
                    </div>

                  </form>
                )}
              </div>
            )}

            {/* STAGE 2: DIAGNOSTICO E ORÇAMENTO */}
            {activeStepTab === 2 && activeOrder && (
              <div className="space-y-6" id="stage-2-pane">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div className="space-y-0.5">
                    <span className="block text-[10px] uppercase tracking-widest font-black text-amber-600 font-mono">Etapa 02 de 04</span>
                    <h3 className="text-base font-black text-slate-900 uppercase tracking-wider">Diagnóstico Técnico & Orçamento de Peças/Mão de Obra</h3>
                  </div>
                  <div className="flex gap-2">
                    <span className={`text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-lg border ${
                      activeOrder.orderType === 'WARRANTY' 
                        ? 'text-amber-900 bg-amber-100 border-amber-300' 
                        : 'text-[#003b7a] bg-blue-100 border-blue-300'
                    }`}>
                      {activeOrder.orderType === 'WARRANTY' ? 'Garantia' : 'Serviço'}
                    </span>
                    <span className="text-xs font-mono font-black text-amber-800 bg-amber-50 px-3 py-1 rounded-lg border border-amber-200">{activeOrder.osNumber}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  
                  {/* Left Column: Form inputs */}
                  <div className="lg:col-span-2 space-y-4">
                    
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-black text-slate-800 uppercase tracking-wider">Laudo Técnico de Inspeção (Diagnóstico) *</label>
                      <textarea
                        required
                        rows={4}
                        placeholder="Ex: Identificado desgaste severo nas gaxetas de vedação traseira, ranhuras no curso do cilindro requerendo brunimento leve, contaminação do fluido hidráulico por partículas ferrosas."
                        value={diagnostic}
                        onChange={(e) => setDiagnostic(e.target.value)}
                        className="w-full px-3.5 py-3 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold leading-relaxed font-mono focus:border-blue-600 focus:bg-white placeholder:text-slate-500 placeholder:font-normal"
                      />

                      {diagnostics && diagnostics.length > 0 && (
                        <div className="mt-2 p-3 bg-slate-50 border-2 border-slate-200 rounded-xl">
                          <span className="block text-[9px] font-black text-slate-700 uppercase tracking-wider mb-2">
                            Preencher Laudo com Diagnóstico Cadastrado:
                          </span>
                          <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                            {diagnostics.map((diag) => (
                              <button
                                key={diag.id}
                                type="button"
                                onClick={() => {
                                  if (!diagnostic || diagnostic.trim() === '') {
                                    setDiagnostic(diag.description);
                                  } else {
                                    setDiagnostic(prev => `${prev}\n\n${diag.description}`);
                                  }
                                }}
                                className="px-2.5 py-1 bg-white hover:bg-blue-50 hover:text-[#0052cc] border border-slate-300 hover:border-[#0052cc] text-[10px] text-slate-700 rounded-lg font-bold transition-all text-left flex items-center gap-1.5 cursor-pointer shadow-xs"
                              >
                                <ClipboardList className="w-3 h-3 text-[#0052cc] shrink-0" />
                                <span className="truncate max-w-[150px]">{diag.title}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <label className="block text-[10px] font-black text-slate-800 uppercase tracking-wider">Serviços e Peças Planejados para a Manutenção *</label>
                        <button
                          type="button"
                          onClick={() => {
                            setPriceTableTarget('STEP2');
                            setIsPriceTableModalOpen(true);
                          }}
                          className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto shadow-xs"
                        >
                          <Briefcase className="w-3.5 h-3.5" />
                          <span>Anexar da Tabela de Preços</span>
                        </button>
                      </div>

                      {/* Novo Modelo de Atalhos da Tabela de Preços Predefinidos (Diagnóstico/Orçamento) */}
                      {services && services.length > 0 && (
                        <div className="bg-emerald-50/60 p-4 rounded-2xl border-2 border-emerald-200 space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <span className="p-1 bg-emerald-600 text-white rounded-md">
                                <Briefcase className="w-3.5 h-3.5" />
                              </span>
                              <span className="text-[11px] font-black text-emerald-950 uppercase tracking-wider block">
                                Atalhos Rápidos da Tabela de Preços Predefinidos
                              </span>
                            </div>
                            <span className="text-[10px] font-bold text-emerald-800">
                              Transfere descritivo técnico e valor estimado para o orçamento
                            </span>
                          </div>

                          {/* Seletor direto interativo (dropdown) */}
                          <div className="relative">
                            <select
                              defaultValue=""
                              onChange={(e) => {
                                const srv = services.find(s => s.id === e.target.value);
                                if (srv) {
                                  handleAttachServiceFromPriceTable(srv, 'STEP2');
                                  e.target.value = '';
                                }
                              }}
                              className="w-full px-3.5 py-2.5 bg-white border-2 border-emerald-400 rounded-xl text-xs text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500 shadow-xs cursor-pointer"
                            >
                              <option value="">⚡ Selecionar serviço da tabela para transferir ao orçamento imediatamente...</option>
                              {services.map(srv => (
                                <option key={srv.id} value={srv.id}>
                                  [{srv.code}] {srv.name} — R$ {srv.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} {srv.category ? `(${srv.category})` : ''}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* Cards de atalho rápido em grade */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                            {services.slice(0, 6).map((srv) => (
                              <button
                                key={srv.id}
                                type="button"
                                onClick={() => handleAttachServiceFromPriceTable(srv, 'STEP2')}
                                className="p-2.5 bg-white hover:bg-emerald-50 text-slate-800 hover:text-emerald-950 border-2 border-emerald-200 hover:border-emerald-500 rounded-xl text-left transition-all flex flex-col justify-between gap-1.5 cursor-pointer shadow-xs group"
                                title={`Transferir ${srv.name} (R$ ${srv.estimatedCost}) para o orçamento`}
                              >
                                <div className="flex items-center justify-between gap-1 w-full">
                                  <span className="font-mono text-[10px] font-black text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded border border-emerald-300 uppercase">
                                    {srv.code}
                                  </span>
                                  <span className="text-[11px] font-black text-emerald-700 font-mono">
                                    R$ {srv.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                  </span>
                                </div>
                                <span className="text-xs font-bold text-slate-900 line-clamp-1 group-hover:text-emerald-900">
                                  {srv.name}
                                </span>
                                {srv.description && (
                                  <span className="text-[10px] text-slate-500 line-clamp-1 italic">
                                    {srv.description}
                                  </span>
                                )}
                                <div className="pt-1 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-emerald-700 group-hover:text-emerald-800">
                                  <span>+ Transferir Descritivo</span>
                                  <Plus className="w-3 h-3" />
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      <textarea
                        required
                        rows={4}
                        placeholder='Descreva as peças que serão trocadas e as horas de serviço estimadas. Ex:\n- 1x Jogo de Reparos Parker 2" (R$ 450,00)\n- Brunimento interno e polimento de haste (R$ 350,00)\n- 3 horas de mão de obra técnica de montagem/testes.'
                        value={plannedServices}
                        onChange={(e) => setPlannedServices(e.target.value)}
                        className="w-full px-3.5 py-3 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold leading-relaxed font-mono focus:border-blue-600 focus:bg-white placeholder:text-slate-500 placeholder:font-normal"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-black text-slate-800 uppercase tracking-wider">Data do Diagnóstico / Orçamento *</label>
                        <input
                          type="date"
                          required
                          value={budgetDate}
                          onChange={(e) => setBudgetDate(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-mono font-bold focus:border-amber-500 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-black text-slate-800 uppercase tracking-wider">Valor Aproximado do Orçamento (R$)</label>
                        <div className="relative">
                          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-xs">R$</span>
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            placeholder="0,00"
                            value={step2EstimatedCost || ''}
                            onChange={(e) => setStep2EstimatedCost(parseFloat(e.target.value) || 0)}
                            className="w-full pl-9 pr-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-mono font-bold"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-black text-slate-800 uppercase tracking-wider">Aprovação do Cliente</label>
                        <div className="grid grid-cols-3 gap-2" id="budget-status-picker">
                          <button
                            type="button"
                            onClick={() => setBudgetStatus('PENDING_APPROVAL')}
                            className={`py-2 px-2.5 rounded-lg text-[9px] font-black uppercase transition-all border-2 cursor-pointer text-center ${
                              budgetStatus === 'PENDING_APPROVAL' 
                                ? 'bg-amber-100 border-amber-400 text-amber-900 shadow-xs' 
                                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            Pendente
                          </button>
                          <button
                            type="button"
                            onClick={() => setBudgetStatus('APPROVED')}
                            className={`py-2 px-2.5 rounded-lg text-[9px] font-black uppercase transition-all border-2 cursor-pointer text-center ${
                              budgetStatus === 'APPROVED' 
                                ? 'bg-emerald-100 border-emerald-400 text-emerald-900 shadow-xs' 
                                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            Autorizado
                          </button>
                          <button
                            type="button"
                            onClick={() => setBudgetStatus('REJECTED')}
                            className={`py-2 px-2.5 rounded-lg text-[9px] font-black uppercase transition-all border-2 cursor-pointer text-center ${
                              budgetStatus === 'REJECTED' 
                                ? 'bg-rose-100 border-rose-400 text-rose-900 shadow-xs' 
                                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            Recusado
                          </button>
                        </div>
                      </div>

                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
                      {budgetStatus === 'REJECTED' && (
                        <button
                          type="button"
                          onClick={handleDeleteRejectedOS}
                          className="px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                          id="btn-delete-rejected-os"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Excluir OS Recusada</span>
                        </button>
                      )}
                      
                      <div className="ml-auto flex items-center gap-2">
                        {budgetStatus === 'APPROVED' ? (
                          <button
                            type="button"
                            onClick={handleSaveBudget}
                            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer shadow-md flex items-center gap-1.5"
                            id="btn-save-budget-diagnostics"
                          >
                            <CheckCircle2 className="w-4 h-4 text-white" />
                            <span>Concluir Diagnóstico & Avançar p/ Execução</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={handleSaveBudget}
                            className="px-6 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer shadow-sm flex items-center gap-1.5"
                            id="btn-save-budget-diagnostics"
                          >
                            <CheckCircle2 className="w-4 h-4 text-white" />
                            <span>Gravar Diagnóstico & Orçamento</span>
                          </button>
                        )}
                      </div>
                    </div>

                  </div>

                  {/* Right Column: Share budget & Check-in reference */}
                  <div className="space-y-4">
                    
                    {/* Share Box */}
                    <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-4">
                      <div className="space-y-1">
                        <span className="block text-xs font-black text-[#1b365d] uppercase tracking-wider">Enviar Orçamento p/ Cliente</span>
                        <p className="text-[10px] text-slate-600 font-medium">Gere o documento oficial em PDF ou envie pelos canais integrados.</p>
                      </div>

                      <div className="space-y-2">
                        <button
                          type="button"
                          onClick={() => handleDownloadPDF('ORCAMENTO')}
                          className="w-full py-2.5 px-3 bg-white hover:bg-slate-100 border-2 border-slate-300 text-slate-900 rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <FileText className="w-3.5 h-3.5 text-amber-600" />
                          <span>Baixar Orçamento (PDF)</span>
                        </button>

                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => handleShareBudget('WHATSAPP')}
                            className="py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>WhatsApp</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleShareBudget('EMAIL')}
                            className="py-2 px-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <Mail className="w-3.5 h-3.5" />
                            <span>E-mail</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Original Check-in Summary Reference Card */}
                    <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-3">
                      <span className="block text-[9px] font-black text-slate-700 uppercase tracking-widest border-b border-slate-200 pb-1">
                        Problema Original Declarado
                      </span>
                      <p className="text-[11px] leading-relaxed font-sans text-slate-800 italic bg-white p-2.5 rounded-lg border border-slate-200">
                        "{activeOrder.description}"
                      </p>
                      {activeOrder.equipmentPhoto && (
                        <div className="rounded-lg overflow-hidden border border-slate-300 h-24 aspect-video mx-auto">
                          <img src={activeOrder.equipmentPhoto} alt="Equipamento" className="w-full h-full object-cover" />
                        </div>
                      )}
                    </div>

                  </div>

                </div>

              </div>
            )}

            {/* STAGE 3: EXECUÇÃO */}
            {activeStepTab === 3 && activeOrder && (
              <div className="space-y-6" id="stage-3-pane">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div className="space-y-0.5">
                    <span className="block text-[10px] uppercase tracking-widest font-black text-purple-700 font-mono">Etapa 03 de 04</span>
                    <h3 className="text-base font-black text-slate-900 uppercase tracking-wider">Execução do Serviço (Acompanhamento Técnico)</h3>
                  </div>
                  <div className="flex gap-2">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-lg border ${
                      activeOrder.orderType === 'WARRANTY' 
                        ? 'text-amber-900 bg-amber-100 border-amber-300' 
                        : 'text-[#003b7a] bg-blue-100 border-blue-300'
                    }`}>
                      {activeOrder.orderType === 'WARRANTY' ? 'Garantia' : 'Serviço'}
                    </span>
                    <span className="text-xs font-mono font-bold text-purple-700 bg-purple-50 px-3 py-1 rounded-lg border border-purple-200">{activeOrder.osNumber}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  
                  {/* Form fields */}
                  <div className="lg:col-span-2 space-y-4">
                    
                    <div className="space-y-1.5">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">O que foi exatamente efetuado? (Laudo de Execução) *</label>
                        <button
                          type="button"
                          onClick={() => {
                            setPriceTableTarget('STEP3');
                            setIsPriceTableModalOpen(true);
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto shadow-xs"
                        >
                          <Briefcase className="w-3.5 h-3.5" />
                          <span>Anexar da Tabela de Preços (Catálogo)</span>
                        </button>
                      </div>

                      {/* Novo Modelo de Atalhos da Tabela de Preços Predefinidos */}
                      {services && services.length > 0 && (
                        <div className="bg-emerald-50/60 p-4 rounded-2xl border-2 border-emerald-200 space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <span className="p-1 bg-emerald-600 text-white rounded-md">
                                <Briefcase className="w-3.5 h-3.5" />
                              </span>
                              <span className="text-[11px] font-black text-emerald-950 uppercase tracking-wider block">
                                Atalhos Rápidos da Tabela de Preços Predefinidos
                              </span>
                            </div>
                            <span className="text-[10px] font-bold text-emerald-800">
                              Clique no atalho ou selecione para transferir o descritivo e valor
                            </span>
                          </div>

                          {/* Seletor direto interativo (dropdown) */}
                          <div className="relative">
                            <select
                              defaultValue=""
                              onChange={(e) => {
                                const srv = services.find(s => s.id === e.target.value);
                                if (srv) {
                                  handleAttachServiceFromPriceTable(srv, 'STEP3');
                                  e.target.value = '';
                                }
                              }}
                              className="w-full px-3.5 py-2.5 bg-white border-2 border-emerald-400 rounded-xl text-xs text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500 shadow-xs cursor-pointer"
                            >
                              <option value="">⚡ Selecionar serviço da tabela para transferir descritivo e valor imediatamente...</option>
                              {services.map(srv => (
                                <option key={srv.id} value={srv.id}>
                                  [{srv.code}] {srv.name} — R$ {srv.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} {srv.category ? `(${srv.category})` : ''}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* Cards de atalho rápido em grade */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                            {services.slice(0, 6).map((srv) => (
                              <button
                                key={srv.id}
                                type="button"
                                onClick={() => handleAttachServiceFromPriceTable(srv, 'STEP3')}
                                className="p-2.5 bg-white hover:bg-emerald-50 text-slate-800 hover:text-emerald-950 border-2 border-emerald-200 hover:border-emerald-500 rounded-xl text-left transition-all flex flex-col justify-between gap-1.5 cursor-pointer shadow-xs group"
                                title={`Transferir ${srv.name} (R$ ${srv.estimatedCost}) para a execução`}
                              >
                                <div className="flex items-center justify-between gap-1 w-full">
                                  <span className="font-mono text-[10px] font-black text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded border border-emerald-300 uppercase">
                                    {srv.code}
                                  </span>
                                  <span className="text-[11px] font-black text-emerald-700 font-mono">
                                    R$ {srv.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                  </span>
                                </div>
                                <span className="text-xs font-bold text-slate-900 line-clamp-1 group-hover:text-emerald-900">
                                  {srv.name}
                                </span>
                                {srv.description && (
                                  <span className="text-[10px] text-slate-500 line-clamp-1 italic">
                                    {srv.description}
                                  </span>
                                )}
                                <div className="pt-1 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-emerald-700 group-hover:text-emerald-800">
                                  <span>+ Transferir Descritivo</span>
                                  <Plus className="w-3 h-3" />
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      <textarea
                        required
                        rows={4}
                        placeholder="Ex: Realizada a desmontagem completa do cilindro hidráulico, polimento leve na haste de curso para remoção de micropontos de ferrugem, brunimento na camisa, substituição completa do kit de gaxetas e anéis por novos de nitrílica 90 Shore A. Testado em bancada estática de pressão a 150 Bar."
                        value={actualServicesPerformed}
                        onChange={(e) => setActualServicesPerformed(e.target.value)}
                        className="w-full px-3.5 py-3 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold leading-relaxed font-mono focus:border-blue-600 focus:bg-white placeholder:text-slate-500 placeholder:font-normal shadow-sm"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Material Gasto / Peças Utilizadas *</label>
                      <textarea
                        required
                        rows={3}
                        placeholder='Ex:\n- 1x Kit de Vedação Cilindro Parker 2"\n- 3 Litros de Óleo de Teste ISO VG 68\n- Cola trava rosca média anaeróbica.'
                        value={materialsUsed}
                        onChange={(e) => setMaterialsUsed(e.target.value)}
                        className="w-full px-3.5 py-3 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold leading-relaxed font-mono focus:border-blue-600 focus:bg-white placeholder:text-slate-500 placeholder:font-normal shadow-sm"
                      />
                    </div>

                    {/* INTEGRATED MATERIAL INVENTORY CONTROLLER */}
                    <div className="bg-slate-50 p-5 rounded-2xl border-2 border-slate-300 space-y-4">
                      <div className="flex items-center gap-2 border-b-2 border-slate-200 pb-3">
                        <Package className="w-5 h-5 text-amber-600" />
                        <div>
                          <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">Controle de Materiais e Peças de Estoque</h4>
                          <p className="text-[10px] text-slate-600">Busque, insira e gerencie devoluções de peças diretamente na manutenção</p>
                        </div>
                      </div>

                      {/* Search and Select Row */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1.5 relative">
                          <div className="flex items-center justify-between">
                            <label className="block text-[10px] font-black text-slate-700 uppercase tracking-wider">Pesquisar Material no Estoque</label>
                            <button
                              type="button"
                              onClick={() => setIsBrowsingInventory(true)}
                              className="text-[9px] text-amber-700 hover:text-amber-800 transition-colors font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                              id="btn-browse-complete-stock"
                            >
                              <Search className="w-3 h-3" />
                              <span>Ver estoque completo</span>
                            </button>
                          </div>
                          <div className="relative">
                            <input
                              type="text"
                              placeholder="Busque por nome ou código..."
                              value={materialSearchQuery}
                              onChange={(e) => setMaterialSearchQuery(e.target.value)}
                              className="w-full pl-9 pr-3 py-2 bg-white border-2 border-slate-300 rounded-lg text-xs text-slate-900 placeholder:text-slate-500 focus:outline-none focus:border-amber-500 font-bold"
                            />
                            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                          </div>

                          {/* Matching stock items list */}
                          {materialSearchQuery.trim().length > 0 && (
                            <div className="absolute z-50 w-full bg-white border-2 border-slate-300 rounded-lg max-h-56 overflow-y-auto shadow-xl divide-y divide-slate-200 mt-1">
                              {inventory
                                .filter(item => 
                                  item.name.toLowerCase().includes(materialSearchQuery.toLowerCase()) ||
                                  item.code.toLowerCase().includes(materialSearchQuery.toLowerCase())
                                )
                                .slice(0, 5)
                                .map(item => (
                                  <button
                                    key={item.id}
                                    type="button"
                                    onClick={() => {
                                      setSelectedMaterialId(item.id);
                                      setMaterialSearchQuery('');
                                    }}
                                    className="w-full text-left px-3 py-2 hover:bg-amber-50/60 transition-colors flex items-center justify-between text-xs cursor-pointer"
                                  >
                                    <div>
                                      <span className="font-mono text-[10px] text-amber-700 font-bold block">{item.code}</span>
                                      <span className="font-bold text-slate-900">{item.name}</span>
                                    </div>
                                    <div className="text-right">
                                      <span className="text-[10px] text-slate-600 block">Estoque: <strong className={item.quantity <= item.minimumStock ? 'text-red-600 font-bold' : 'text-slate-800 font-semibold'}>{item.quantity} {item.unit}</strong></span>
                                      <span className="text-[10px] text-emerald-700 font-bold">R$ {item.salePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                                    </div>
                                  </button>
                                ))}
                              {inventory.filter(item => 
                                item.name.toLowerCase().includes(materialSearchQuery.toLowerCase()) ||
                                item.code.toLowerCase().includes(materialSearchQuery.toLowerCase())
                              ).length === 0 && (
                                <p className="p-3 text-[11px] text-slate-500 text-center font-medium">Nenhum item correspondente encontrado</p>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Selected product and Quantity controls */}
                        {selectedMaterialId && (
                          <div className="space-y-2 bg-white p-3 rounded-xl border-2 border-slate-300">
                            {(() => {
                              const item = inventory.find(i => i.id === selectedMaterialId);
                              if (!item) return null;
                              return (
                                <div className="space-y-3">
                                  <div className="flex items-center justify-between">
                                    <div>
                                      <span className="text-[9px] font-mono text-amber-700 font-bold">{item.code}</span>
                                      <h5 className="font-bold text-slate-900 text-xs leading-none mt-0.5">{item.name}</h5>
                                    </div>
                                    <button 
                                      type="button" 
                                      onClick={() => setSelectedMaterialId('')}
                                      className="text-slate-400 hover:text-slate-700 cursor-pointer"
                                    >
                                      <X className="w-4 h-4" />
                                    </button>
                                  </div>

                                  <div className="grid grid-cols-2 gap-3 items-end">
                                    <div className="space-y-1">
                                      <span className="text-[9px] text-slate-600 uppercase font-black tracking-wider">Quant. a Inserir</span>
                                      <div className="flex items-center gap-1">
                                        <input
                                          type="number"
                                          min={1}
                                          max={item.quantity}
                                          value={selectedMaterialQty}
                                          onChange={(e) => setSelectedMaterialQty(Math.max(1, Math.min(item.quantity, Number(e.target.value))))}
                                          className="w-full px-2 py-1.5 bg-white border-2 border-slate-300 rounded-lg text-xs text-slate-900 font-mono text-center font-bold"
                                        />
                                        <span className="text-[10px] text-slate-600 font-medium shrink-0">/ {item.quantity} {item.unit}</span>
                                      </div>
                                    </div>

                                    <button
                                      type="button"
                                      onClick={() => handleAddMaterialToOS(selectedMaterialId, selectedMaterialQty)}
                                      className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                                    >
                                      <Plus className="w-3.5 h-3.5" />
                                      <span>Inserir</span>
                                    </button>
                                  </div>
                                </div>
                              );
                            })()}
                          </div>
                        )}
                      </div>

                      {/* Current materials attached list */}
                      <div className="space-y-2.5">
                        <span className="block text-[9px] font-black text-slate-700 uppercase tracking-wider font-mono">Materiais Inseridos nesta Manutenção</span>
                        
                        {osMaterialsList.length === 0 ? (
                          <div className="text-center py-6 text-slate-500 border-2 border-dashed border-slate-300 rounded-xl bg-white">
                            <p className="text-[10px] font-bold text-slate-600">Nenhum material inserido do estoque ainda</p>
                            <p className="text-[9px] text-slate-500 mt-1">Utilize o campo acima para buscar e inserir retentores, gaxetas, óleos etc.</p>
                          </div>
                        ) : (
                          <div className="border-2 border-slate-200 bg-white rounded-xl overflow-hidden shadow-xs">
                            <table className="w-full text-left text-[11px] divide-y divide-slate-200">
                              <thead className="bg-slate-100 text-slate-700 text-[9px] font-black uppercase tracking-wider">
                                <tr>
                                  <th className="px-3 py-2">Código/Nome</th>
                                  <th className="px-3 py-2 text-center">Quant.</th>
                                  <th className="px-3 py-2 text-right">Unitário</th>
                                  <th className="px-3 py-2 text-right">Subtotal</th>
                                  <th className="px-3 py-2 text-center">Ações / Devolução</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-200 font-medium">
                                {osMaterialsList.map(item => (
                                  <tr key={item.itemId} className="hover:bg-slate-50 text-slate-800">
                                    <td className="px-3 py-2.5">
                                      <span className="font-mono text-[9px] text-amber-700 font-bold block leading-none">{item.code}</span>
                                      <span className="text-slate-900 font-bold block mt-0.5">{item.name}</span>
                                    </td>
                                    <td className="px-3 py-2.5 text-center font-bold text-slate-900 font-mono">
                                      {item.quantity}
                                    </td>
                                    <td className="px-3 py-2.5 text-right font-mono text-slate-700">
                                      R$ {item.salePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                    </td>
                                    <td className="px-3 py-2.5 text-right font-black font-mono text-emerald-700">
                                      R$ {(item.quantity * item.salePrice).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                    </td>
                                    <td className="px-3 py-2.5 text-center">
                                      <div className="flex items-center justify-center gap-2">
                                        <button
                                          type="button"
                                          title="Devolver 1 unidade ao estoque"
                                          onClick={() => handleReturnMaterialFromOS(item.itemId, 1)}
                                          className="px-2 py-1 bg-amber-100 text-amber-900 border border-amber-300 rounded-md hover:bg-amber-200 transition-colors cursor-pointer text-[10px] font-bold uppercase"
                                        >
                                          Devolver 1
                                        </button>
                                        <button
                                          type="button"
                                          title="Excluir item e devolver toda quantidade ao estoque"
                                          onClick={() => handleReturnMaterialFromOS(item.itemId, item.quantity)}
                                          className="p-1 bg-rose-100 text-rose-800 border border-rose-300 rounded-md hover:bg-rose-200 transition-colors cursor-pointer"
                                        >
                                          <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                              <tfoot className="bg-slate-50 font-bold border-t-2 border-slate-200">
                                <tr>
                                  <td colSpan={3} className="px-3 py-2 text-right uppercase tracking-wider text-[9px] text-slate-600 font-black">Custo Total das Peças:</td>
                                  <td className="px-3 py-2 text-right font-mono text-xs font-black text-emerald-700">
                                    R$ {osMaterialsList.reduce((sum, item) => sum + (item.quantity * item.salePrice), 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                  </td>
                                  <td></td>
                                </tr>
                              </tfoot>
                            </table>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Data de Execução do Serviço *</label>
                        <input
                          type="date"
                          required
                          value={executionDate}
                          onChange={(e) => setExecutionDate(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-mono font-bold focus:border-emerald-600 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Valor Real / Final da Manutenção (R$)</label>
                        <div className="relative">
                          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-xs">R$</span>
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            placeholder="Deixe em branco p/ usar o estimado"
                            value={actualCost || ''}
                            onChange={(e) => setActualCost(parseFloat(e.target.value) || 0)}
                            className="w-full pl-9 pr-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-mono font-bold"
                          />
                        </div>
                        <p className="text-[8.5px] text-slate-600 font-mono">Estimado: R$ {activeOrder.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Status da Execução / Situação da OS</label>
                        <select
                          value={osStatus}
                          onChange={(e) => setOsStatus(e.target.value as any)}
                          className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold focus:outline-hidden focus:ring-2 focus:ring-emerald-600 shadow-xs cursor-pointer"
                        >
                          <option value="PENDING" className="bg-white text-black font-bold">⏳ Aguardando Início / Orçamento</option>
                          <option value="IN_PROGRESS" className="bg-white text-black font-bold">🛠️ Em Execução / Oficina</option>
                          <option value="COMPLETED" className="bg-white text-black font-bold">✅ Serviço Concluído (Pronto p/ Entrega)</option>
                          <option value="CANCELLED" className="bg-white text-black font-bold">❌ Cancelado / Recusado</option>
                        </select>
                      </div>

                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
                      <button
                        type="button"
                        onClick={() => handleSaveExecution(false)}
                        className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border-2 border-slate-300 font-black text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                        id="btn-save-execution-progress"
                        title="Salvar alterações sem concluir a etapa"
                      >
                        Salvar Progresso (Em Execução)
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSaveExecution(true)}
                        className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer shadow-md flex items-center gap-1.5"
                        id="btn-save-execution-complete"
                        title="Concluir a execução do serviço e avançar para a entrega"
                      >
                        <CheckCircle2 className="w-4 h-4 text-white" />
                        <span>Concluir Execução & Avançar p/ Entrega</span>
                      </button>
                    </div>

                  </div>

                  {/* Right Column: Information card */}
                  <div className="space-y-4">
                    
                    <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-3">
                      <span className="block text-[9px] font-black text-slate-700 uppercase tracking-wider">Integração Financeira Direta</span>
                      <p className="text-[10px] text-slate-600 leading-relaxed">
                        Ao selecionar a situação <strong>"Serviço Concluído"</strong> e clicar em salvar, o sistema fará o lançamento automático de receita correspondente ao valor real da manutenção na aba <strong>Financeiro</strong>.
                      </p>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-2">
                      <span className="block text-[8px] font-black text-slate-600 uppercase tracking-widest">Peças e Serviços Planejados</span>
                      <p className="text-[10px] font-mono text-slate-700 italic">
                        "{activeOrder.plannedServices || 'Não cadastrados'}"
                      </p>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-3">
                      <span className="block text-[9px] font-black text-slate-900 uppercase tracking-wider">Documento Técnico / PDF</span>
                      <p className="text-[10px] text-slate-600">Exporte o Laudo Técnico de Execução oficial para entregar ao cliente.</p>
                      <button
                        type="button"
                        onClick={() => handleDownloadPDF('LAUDO_TECNICO')}
                        className="w-full py-2.5 px-3 bg-white hover:bg-slate-100 border-2 border-slate-300 text-slate-900 rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <FileText className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Baixar Laudo Técnico (PDF)</span>
                      </button>
                    </div>

                  </div>

                </div>

              </div>
            )}

            {/* STAGE 4: FINALIZAÇÃO (ENTREGA & GARANTIA) */}
            {activeStepTab === 4 && activeOrder && (
              <div className="space-y-6" id="stage-4-pane">
                
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 pb-4 gap-3">
                  <div className="space-y-1">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[9px] uppercase tracking-wider font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300 font-mono">
                      <ClipboardCheck className="w-3 h-3" />
                      Etapa 04 de 04
                    </span>
                    <h3 className="text-lg font-black text-slate-900 uppercase tracking-wider">Saída de Equipamento & Controle de Entrega</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-lg border ${
                      activeOrder.orderType === 'WARRANTY' 
                        ? 'text-amber-900 bg-amber-100 border-amber-300' 
                        : 'text-[#003b7a] bg-blue-100 border-blue-300'
                    }`}>
                      {activeOrder.orderType === 'WARRANTY' ? 'Garantia' : 'Serviço'}
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-200">{activeOrder.osNumber}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  
                  {/* Left Column: Delivery, Checkout Photo, and Payment */}
                  <div className="lg:col-span-2 space-y-6">
                    
                    {/* Part A: Control of Delivery & Date */}
                    <div className="bg-slate-50 p-5 rounded-2xl border-2 border-slate-200 space-y-4">
                      <span className="text-[11px] font-black text-slate-900 uppercase tracking-wider block border-b-2 border-slate-200 pb-2 flex items-center gap-1.5">
                        <Smartphone className="w-4 h-4 text-emerald-600" />
                        1. Status da Retirada / Entrega
                      </span>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">O Equipamento foi Retirado? *</label>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setIsDelivered(true);
                                if (!deliveryDate) {
                                  setDeliveryDate(new Date().toISOString().split('T')[0]);
                                }
                              }}
                              className={`flex-1 py-3 px-3 rounded-xl text-xs font-black uppercase transition-all border-2 cursor-pointer text-center flex items-center justify-center gap-1.5 shadow-xs ${
                                isDelivered 
                                  ? 'bg-emerald-600 border-emerald-600 text-white shadow-md' 
                                  : 'bg-white border-slate-300 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                              }`}
                            >
                              <Check className="w-4 h-4 stroke-[3]" />
                              <span>Sim, Retirado</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setIsDelivered(false)}
                              className={`flex-1 py-3 px-3 rounded-xl text-xs font-black uppercase transition-all border-2 cursor-pointer text-center flex items-center justify-center gap-1.5 shadow-xs ${
                                !isDelivered 
                                  ? 'bg-amber-500 border-amber-500 text-slate-950 shadow-md' 
                                  : 'bg-white border-slate-300 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                              }`}
                            >
                              <Clock className="w-4 h-4" />
                              <span>Ainda na Oficina</span>
                            </button>
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Data do Registro de Saída / Entrega *</label>
                          <input
                            type="date"
                            value={deliveryDate}
                            onChange={(e) => setDeliveryDate(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-mono font-bold focus:border-emerald-600 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Part B: Capture of Equipment Photo AFTER Maintenance */}
                    <div className="bg-slate-50 p-5 rounded-2xl border-2 border-slate-200 space-y-4">
                      <span className="text-[11px] font-black text-slate-900 uppercase tracking-wider block border-b-2 border-slate-200 pb-2 flex items-center gap-1.5">
                        <Camera className="w-4 h-4 text-emerald-600" />
                        2. Foto do Equipamento Concluído (Pós-Manutenção)
                      </span>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Photo capture frame */}
                        <div className="space-y-2">
                          <div 
                            onClick={handleDeliveryPhotoClick}
                            className="relative h-40 bg-white hover:bg-emerald-50/40 border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl flex flex-col items-center justify-center gap-2 cursor-pointer transition-all overflow-hidden group shadow-xs"
                          >
                            {deliveryPhoto ? (
                              <>
                                <img src={deliveryPhoto} alt="Entrega" className="w-full h-full object-cover rounded-2xl" />
                                <div className="absolute inset-0 bg-slate-950/70 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center gap-1 transition-opacity text-slate-200">
                                  <Camera className="w-5 h-5 text-emerald-400" />
                                  <span className="text-[9px] font-black uppercase tracking-wider">Alterar Foto de Saída</span>
                                </div>
                              </>
                            ) : (
                              <>
                                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-700 group-hover:text-emerald-800 transition-colors">
                                  <Camera className="w-5 h-5" />
                                </div>
                                <div className="text-center space-y-0.5">
                                  <span className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Tirar Foto / Anexar Imagem</span>
                                  <span className="block text-[8px] text-slate-500 font-mono">Suporta câmera e arquivos de imagem</span>
                                </div>
                              </>
                            )}
                          </div>
                          
                          {/* File input (hidden) */}
                          <input 
                            type="file" 
                            accept="image/*" 
                            capture="environment"
                            ref={deliveryFileInputRef} 
                            onChange={handleDeliveryFileChange} 
                            className="hidden" 
                          />

                          {deliveryPhoto && (
                            <button
                              type="button"
                              onClick={() => setDeliveryPhoto('')}
                              className="w-full py-1.5 text-center text-[9px] font-bold text-rose-700 hover:text-rose-800 bg-rose-50 border border-rose-200 rounded-lg hover:bg-rose-100 transition-all cursor-pointer"
                            >
                              Remover Foto Pós-Manutenção
                            </button>
                          )}
                        </div>

                        {/* Presets and details */}
                        <div className="space-y-3 flex flex-col justify-between">
                          <div className="space-y-1">
                            <span className="block text-[9px] font-black text-slate-700 uppercase tracking-widest">Importância do Registro</span>
                            <p className="text-[10px] text-slate-600 leading-relaxed font-sans">
                              O registro visual do equipamento após a manutenção comprova a qualidade dos acabamentos, ausência de vazamentos externos e integridade na entrega física ao cliente.
                            </p>
                          </div>

                          <div className="space-y-1.5 pt-2">
                            <span className="block text-[9px] font-black text-slate-700 uppercase tracking-widest">Fotos de Demonstração (Desktop):</span>
                            <div className="grid grid-cols-2 gap-2">
                              {PRESET_PHOTOS.slice(0, 2).map((p) => (
                                <button
                                  key={p.id}
                                  type="button"
                                  onClick={() => {
                                    setDeliveryPhoto(p.url);
                                    showFeedback('Foto de simulação pós-manutenção selecionada!', 'success');
                                  }}
                                  className={`p-1.5 bg-white hover:bg-slate-100 border-2 rounded-lg flex items-center gap-2 text-left cursor-pointer transition-all shadow-xs ${
                                    deliveryPhoto === p.url ? 'border-emerald-500 bg-emerald-50' : 'border-slate-300'
                                  }`}
                                >
                                  <img src={p.url} alt={p.name} className="w-6 h-6 object-cover rounded-md shrink-0" />
                                  <span className="text-[8px] text-slate-700 truncate block font-bold">{p.name}</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Part C: Financial Settlement (Billed amount & Payment confirm) */}
                    <div className="bg-slate-50 p-5 rounded-2xl border-2 border-slate-200 space-y-4">
                      <span className="text-[11px] font-black text-slate-900 uppercase tracking-wider block border-b-2 border-slate-200 pb-2 flex items-center gap-1.5">
                        <DollarSign className="w-4 h-4 text-emerald-600" />
                        3. Lançamento Financeiro & Meio de Pagamento
                      </span>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Valor Cobrado Final (R$)</label>
                          <div className="relative">
                            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-xs font-mono">R$</span>
                            <input
                              type="number"
                              step="0.01"
                              min="0"
                              placeholder="0,00"
                              value={actualCost || ''}
                              onChange={(e) => setActualCost(parseFloat(e.target.value) || 0)}
                              className="w-full pl-9 pr-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-slate-900 font-mono font-bold"
                            />
                          </div>
                          <span className="text-[8px] text-slate-600 block font-mono">Estimativa inicial: R$ {(activeOrder.estimatedCost || 0).toFixed(2)}</span>
                        </div>

                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Status do Recebimento *</label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setPaymentStatus('PAID')}
                              className={`py-2.5 px-3 rounded-lg text-[10px] font-black uppercase transition-all border-2 cursor-pointer text-center flex items-center justify-center gap-1.5 shadow-xs ${
                                paymentStatus === 'PAID' 
                                  ? 'bg-emerald-600 border-emerald-600 text-white shadow-sm' 
                                  : 'bg-white border-slate-300 text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                              }`}
                            >
                              <CheckCircle className="w-3.5 h-3.5" />
                              <span>Pago / Recebido</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setPaymentStatus('PENDING')}
                              className={`py-2.5 px-3 rounded-lg text-[10px] font-black uppercase transition-all border-2 cursor-pointer text-center flex items-center justify-center gap-1.5 shadow-xs ${
                                paymentStatus === 'PENDING' 
                                  ? 'bg-amber-500 border-amber-500 text-slate-950 shadow-sm' 
                                  : 'bg-white border-slate-300 text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                              }`}
                            >
                              <AlertTriangle className="w-3.5 h-3.5" />
                              <span>Pendente / Faturar</span>
                            </button>
                          </div>
                        </div>

                        <div className="space-y-1.5 col-span-2">
                          <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Meio de Pagamento Selecionado</label>
                          <div className="grid grid-cols-5 gap-2" id="payment-method-selector">
                            {['PIX', 'Cartão', 'Débito', 'Dinheiro', 'Boleto'].map((method) => (
                              <button
                                key={method}
                                type="button"
                                onClick={() => setPaymentMethod(method)}
                                className={`py-2 px-1.5 rounded-lg text-[9px] font-black uppercase transition-all border-2 cursor-pointer text-center shadow-xs ${
                                  paymentMethod === method 
                                    ? 'bg-[#003b7a] border-[#003b7a] text-white' 
                                    : 'bg-white border-slate-300 text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                                }`}
                              >
                                {method}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Part D: Warranty parameters */}
                    <div className="bg-slate-50 p-5 rounded-2xl border-2 border-slate-200 space-y-4">
                      <span className="text-[11px] font-black text-slate-900 uppercase tracking-wider block border-b-2 border-slate-200 pb-2 flex items-center gap-1.5">
                        <Shield className="w-4 h-4 text-emerald-600" />
                        4. Período de Garantia & Termos do Serviço
                      </span>

                      {(activeOrder.orderType === 'WARRANTY' || activeOrder.parentOSId) && (
                        <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-3 flex items-start gap-2.5 text-xs text-blue-900">
                          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                          <div className="space-y-0.5">
                            <span className="font-extrabold text-[10px] uppercase text-blue-900 block">Intervenção em Garantia Coberta ({activeOrder.parentOSNumber || 'OS Anterior'})</span>
                            <p className="text-[10px] text-blue-800 leading-normal">
                              Regra do Sistema: O prazo de garantia original ({activeOrder.originalWarrantyExpirationDate ? new Date(activeOrder.originalWarrantyExpirationDate + 'T12:00:00').toLocaleDateString('pt-BR') : 'mantido'}) permanece inalterado e NÃO é prorrogado ou renovado por este serviço corretivo.
                            </p>
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="space-y-1.5 col-span-1">
                          <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Prazo de Garantia *</label>
                          <select
                            value={warrantyDays}
                            onChange={(e) => setWarrantyDays(Number(e.target.value))}
                            className="w-full px-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold focus:border-cyan-500 shadow-xs cursor-pointer"
                          >
                            <option value={30} className="bg-white text-black font-bold">30 Dias (Legal)</option>
                            <option value={90} className="bg-white text-black font-bold">90 Dias (3 meses padrão)</option>
                            <option value={180} className="bg-white text-black font-bold">180 Dias (6 meses estendido)</option>
                            <option value={365} className="bg-white text-black font-bold">365 Dias (1 ano especial)</option>
                            <option value={0} className="bg-white text-black font-bold">Sem Garantia</option>
                          </select>
                        </div>

                        <div className="space-y-1.5 sm:col-span-2">
                          <label className="block text-[10px] font-black text-slate-900 uppercase tracking-wider">Termos Adicionais / Observações Técnicas</label>
                          <textarea
                            rows={1}
                            placeholder="Ex: A garantia cobre vedações trocadas. Exclui-se uso com óleo contaminado."
                            value={warrantyNotes}
                            onChange={(e) => setWarrantyNotes(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs text-black font-bold leading-relaxed font-mono focus:border-blue-600 focus:bg-white placeholder:text-slate-500 placeholder:font-normal shadow-xs"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end pt-3 border-t-2 border-slate-200">
                        <button
                          type="button"
                          onClick={handleSaveFinalization}
                          className="px-8 py-3.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-black text-xs uppercase tracking-widest rounded-xl transition-all cursor-pointer shadow-md flex items-center gap-2"
                          id="btn-save-finalization"
                        >
                          <CheckCircle2 className="w-4 h-4 text-white" />
                          <span>Concluir Etapa de Entrega & Fechar OS</span>
                        </button>
                      </div>
                    </div>

                    {/* Part E: Full Equipment Maintenance Timeline History */}
                    <div className="bg-slate-50 p-5 rounded-2xl border-2 border-slate-200 space-y-4">
                      <span className="text-[11px] font-black text-slate-900 uppercase tracking-wider block border-b-2 border-slate-200 pb-2 flex items-center gap-2">
                        <History className="w-4 h-4 text-[#003b7a]" />
                        Histórico Geral de Manutenções deste Equipamento
                      </span>

                      {equipmentLogs.length === 0 && otherOrdersForEquip.length === 0 ? (
                        <p className="text-[11px] text-slate-500 italic py-4 text-center">Nenhum registro anterior no histórico para este equipamento.</p>
                      ) : (
                        <div className="space-y-4" id="equipment-timeline-logs">
                          
                          {/* Active current completed order logged */}
                          <div className="border-l-2 border-blue-500 pl-4 ml-2 space-y-1.5 relative">
                            <span className="absolute -left-1.5 top-1.5 w-3.5 h-3.5 rounded-full bg-[#003b7a] border-2 border-white"></span>
                            <div className="flex items-center justify-between text-[9px] font-mono font-bold text-blue-700">
                              <span>{new Date().toLocaleDateString('pt-BR')} (Hoje)</span>
                              <span>{activeOrder.osNumber} (Atual)</span>
                            </div>
                            <h5 className="text-xs font-black text-slate-900">{activeOrder.title}</h5>
                            <p className="text-[10px] text-slate-600 leading-relaxed italic">"{activeOrder.actualServicesPerformed || 'Serviço executado registrado na etapa 3.'}"</p>
                          </div>

                          {/* Historical records */}
                          {equipmentLogs.map((log) => (
                            <div key={log.id} className="border-l-2 border-slate-300 pl-4 ml-2 space-y-1 relative">
                              <span className="absolute -left-1 top-1.5 w-2 h-2 rounded-full bg-slate-400 border border-white"></span>
                              <div className="flex items-center justify-between text-[9px] font-mono text-slate-600 font-bold">
                                <span>{new Date(log.date).toLocaleDateString('pt-BR')}</span>
                                <span>{log.serviceOrderId ? `Ref: OS` : 'Log Manual'}</span>
                              </div>
                              <h5 className="text-[11px] font-bold text-slate-800">{log.serviceType}</h5>
                              <p className="text-[9px] text-slate-600">Peças: {log.partsUsed} | Técnico: {log.technician}</p>
                            </div>
                          ))}

                          {otherOrdersForEquip.map((o) => (
                            <div key={o.id} className="border-l-2 border-slate-300 pl-4 ml-2 space-y-1 relative">
                              <span className="absolute -left-1 top-1.5 w-2 h-2 rounded-full bg-slate-400 border border-white"></span>
                              <div className="flex items-center justify-between text-[9px] font-mono text-slate-600 font-bold">
                                <span>{new Date(o.createdAt).toLocaleDateString('pt-BR')}</span>
                                <span>{o.osNumber} (Anterior)</span>
                              </div>
                              <h5 className="text-[11px] font-bold text-slate-800">{o.title}</h5>
                              <p className="text-[9px] text-slate-600">Resultado: {o.status} | Diagnosticado: {o.diagnostic || 'Não informado'}</p>
                            </div>
                          ))}

                        </div>
                      )}
                    </div>

                  </div>

                  {/* Right Column: PDF Reports & Shared Messages */}
                  <div className="space-y-4">
                    
                    {/* Live report summary */}
                    <div className="bg-slate-50 p-5 rounded-2xl border-2 border-slate-200 space-y-4 shadow-xs">
                      <div className="flex items-center gap-2 text-[#003b7a] border-b-2 border-slate-200 pb-2">
                        <FileText className="w-4 h-4" />
                        <span className="text-[10px] font-black uppercase tracking-wider text-slate-900">Relatório de Saída</span>
                      </div>

                      <div className="space-y-3">
                        <div className="space-y-0.5">
                          <span className="text-[8px] uppercase tracking-wider text-slate-500 font-black">Cliente</span>
                          <span className="block text-xs font-black text-slate-900">{activeClient?.name}</span>
                          <span className="block text-[9px] font-mono text-slate-600 font-bold">{activeClient?.phone}</span>
                        </div>

                        <div className="space-y-0.5">
                          <span className="text-[8px] uppercase tracking-wider text-slate-500 font-black">Equipamento</span>
                          <span className="block text-xs font-bold text-slate-800">{activeEquip?.name}</span>
                          <span className="block text-[9px] font-mono text-slate-600">Série: {activeEquip?.model || 'Não informado'}</span>
                        </div>

                        <div className="space-y-0.5">
                          <span className="text-[8px] uppercase tracking-wider text-slate-500 font-black">Serviço Executado</span>
                          <span className="block text-[11px] text-slate-800 leading-relaxed font-mono bg-white p-2.5 rounded-lg border-2 border-slate-200">
                            {activeOrder.actualServicesPerformed || 'Nenhum serviço registrado.'}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 pt-1">
                          <div className="bg-white p-2 rounded-xl border-2 border-slate-200">
                            <span className="block text-[8px] uppercase tracking-wider text-slate-500 font-black">Valor Cobrado</span>
                            <span className="block text-xs font-mono font-black text-emerald-700">R$ {(actualCost || activeOrder.actualCost || activeOrder.estimatedCost || 0).toFixed(2)}</span>
                          </div>
                          <div className="bg-white p-2 rounded-xl border-2 border-slate-200">
                            <span className="block text-[8px] uppercase tracking-wider text-slate-500 font-black">Status do Recebimento</span>
                            <span className={`block text-xs font-extrabold uppercase ${paymentStatus === 'PAID' ? 'text-emerald-700' : 'text-amber-700'}`}>
                              {paymentStatus === 'PAID' ? 'Recebido' : 'Pendente'}
                            </span>
                          </div>
                        </div>

                        {warrantyDays > 0 && isDelivered && (
                          <div className="bg-emerald-50 p-3 rounded-xl border-2 border-emerald-200 text-center space-y-1">
                            <span className="block text-[8px] uppercase tracking-widest text-emerald-900 font-black">
                              {activeOrder.originalWarrantyExpirationDate ? 'Vencimento da Garantia (Prazo Original Inalterado)' : 'Vencimento da Garantia'}
                            </span>
                            <span className="block font-mono text-xs font-black text-emerald-800">
                              {activeOrder.originalWarrantyExpirationDate 
                                ? new Date(activeOrder.originalWarrantyExpirationDate + 'T12:00:00').toLocaleDateString('pt-BR')
                                : new Date(new Date(deliveryDate).getTime() + warrantyDays * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR')}
                            </span>
                            <span className="block text-[8px] text-emerald-700 font-mono">
                              {activeOrder.originalWarrantyExpirationDate ? 'Garantia Unificada sem prorrogação' : `Período total de ${warrantyDays} dias`}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Report Download Actions */}
                    <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-3 text-center">
                      <span className="block text-[9px] font-black text-slate-900 uppercase tracking-wider border-b-2 border-slate-200 pb-1.5">
                        Relatório Técnico & Recibos (PDF)
                      </span>

                      <button
                        type="button"
                        onClick={() => handleDownloadPDF('RECIBO_ENTREGA')}
                        className="w-full py-2.5 px-3 bg-[#003b7a] hover:bg-[#002b59] text-white font-black rounded-xl text-[10px] uppercase flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all"
                      >
                        <FileText className="w-3.5 h-3.5 text-white stroke-[2.5]" />
                        <span>Baixar Recibo & Garantia (PDF)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownloadPDF('FICHA_ENTRADA')}
                        className="w-full py-2 px-3 bg-white hover:bg-slate-100 border-2 border-slate-300 text-slate-800 font-black rounded-xl text-[9px] uppercase flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-xs"
                      >
                        <FileSpreadsheet className="w-3.5 h-3.5 text-blue-600" />
                        <span>Baixar Ficha de Entrada (PDF)</span>
                      </button>
                    </div>

                    {/* WhatsApp/Email Sharing Controls */}
                    <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-3">
                      <span className="block text-[9px] font-black text-slate-900 uppercase tracking-wider border-b-2 border-slate-200 pb-1.5">
                        Compartilhar com o Cliente
                      </span>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => handleShareCheckOut('WHATSAPP')}
                          className="py-2.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl text-[10px] uppercase flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-xs"
                        >
                          <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                          <span>WhatsApp</span>
                        </button>
                        
                        <button
                          type="button"
                          onClick={() => handleShareCheckOut('EMAIL')}
                          className="py-2.5 px-2 bg-blue-600 hover:bg-blue-500 text-white font-black rounded-xl text-[10px] uppercase flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-xs"
                        >
                          <Mail className="w-3.5 h-3.5 shrink-0" />
                          <span>E-mail</span>
                        </button>
                      </div>
                      <span className="text-[8.5px] text-slate-500 block text-center font-mono">Gera e copia automaticamente a mensagem de conclusão</span>
                    </div>

                    {/* Brief checklist summary */}
                    <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-3">
                      <span className="block text-[9px] font-black text-slate-900 uppercase tracking-wider border-b-2 border-slate-200 pb-1.5">
                        Resumo do Ciclo de Vida da OS
                      </span>
                      
                      <div className="space-y-2 text-[10px]">
                        <div className="flex items-center gap-2 text-emerald-700 font-bold">
                          <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                          <span>01 - Check-in Rápido concluído</span>
                        </div>
                        <div className="flex items-center gap-2 text-emerald-700 font-bold">
                          <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                          <span>02 - Diagnóstico técnico finalizado</span>
                        </div>
                        <div className="flex items-center gap-2 text-emerald-700 font-bold">
                          <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                          <span>03 - Execução registrada com sucesso</span>
                        </div>
                        <div className={`flex items-center gap-2 ${isDelivered ? 'text-emerald-700 font-bold' : 'text-slate-500'}`}>
                          <CheckCircle className="w-4 h-4 shrink-0" />
                          <span>04 - Entrega {isDelivered ? 'efetuada' : 'pendente'}</span>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

              </div>
            )}

            {/* Step navigation actions at the bottom */}
            {selectedOrderId && (
              <div className="flex items-center justify-between pt-4 mt-6 border-t-2 border-slate-200">
                <button
                  type="button"
                  disabled={activeStepTab === 1}
                  onClick={() => setActiveStepTab(prev => (prev - 1) as any)}
                  className="px-4 py-2 bg-white hover:bg-slate-100 border-2 border-slate-300 disabled:opacity-30 disabled:pointer-events-none text-slate-700 hover:text-slate-900 font-black text-[10px] uppercase tracking-wider rounded-xl transition-all flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Anterior</span>
                </button>

                <button
                  type="button"
                  disabled={activeStepTab === 4}
                  onClick={() => setActiveStepTab(prev => (prev + 1) as any)}
                  className="px-4 py-2 bg-white hover:bg-slate-100 border-2 border-slate-300 disabled:opacity-30 disabled:pointer-events-none text-slate-700 hover:text-slate-900 font-black text-[10px] uppercase tracking-wider rounded-xl transition-all flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <span>Próximo</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

          </div>

        </div>
      )}

      {/* Browsing Complete Inventory Modal */}
      {isBrowsingInventory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="browse-inventory-modal">
          <div className="absolute inset-0 bg-[#000000]/80 backdrop-blur-xs" onClick={() => setIsBrowsingInventory(false)}></div>
          
          <div className="relative bg-[#11131c] rounded-2xl shadow-2xl w-full max-w-4xl max-h-[85vh] overflow-hidden border border-slate-800 p-6 flex flex-col space-y-4">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3 text-amber-400">
                <div className="p-2 bg-amber-950/30 rounded-xl border border-amber-500/15">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-100 text-sm uppercase tracking-wider">
                    Estoque de Materiais & Peças
                  </h3>
                  <span className="text-[10px] text-slate-500 block">Consulte, pesquise e selecione materiais para incluir na manutenção</span>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setIsBrowsingInventory(false)}
                className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Search Bar */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="Pesquisar por código, nome, categoria ou aplicação do material..."
                  value={materialSearchQuery}
                  onChange={(e) => setMaterialSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-[#0c0d10] border border-slate-800 rounded-xl text-xs text-white placeholder-slate-600 focus:outline-hidden focus:border-amber-500"
                />
              </div>
            </div>

            {/* Modal Content - Table / Grid of Stock Items */}
            <div className="flex-grow overflow-y-auto min-h-[300px] border border-slate-800/85 rounded-xl bg-[#0c0d10]">
              <table className="w-full text-left text-xs divide-y divide-slate-800">
                <thead className="bg-[#11131c] text-slate-400 text-[10px] font-bold uppercase tracking-wider sticky top-0 z-10">
                  <tr>
                    <th className="px-4 py-3 text-center">Foto</th>
                    <th className="px-4 py-3">Código & Nome</th>
                    <th className="px-4 py-3">Aplicações Recomendadas</th>
                    <th className="px-4 py-3 text-center">Estoque</th>
                    <th className="px-4 py-3 text-right">Preço</th>
                    <th className="px-4 py-3 text-center">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850/50">
                  {inventory
                    .filter(item => {
                      const query = materialSearchQuery.toLowerCase();
                      return !query || 
                             item.name.toLowerCase().includes(query) ||
                             item.code.toLowerCase().includes(query) ||
                             item.category.toLowerCase().includes(query) ||
                             (item.possibleApplications && item.possibleApplications.toLowerCase().includes(query));
                    })
                    .map(item => (
                      <tr key={item.id} className="hover:bg-slate-900/40 text-slate-300">
                        {/* Photo column */}
                        <td className="px-4 py-3 text-center">
                          {item.imageUrl ? (
                            <img 
                              src={item.imageUrl} 
                              alt={item.name} 
                              className="w-10 h-10 object-cover rounded-lg border border-slate-800/80 mx-auto"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-10 h-10 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-center mx-auto" title="Sem foto">
                              <Package className="w-5 h-5 text-slate-600" />
                            </div>
                          )}
                        </td>

                        {/* Name column */}
                        <td className="px-4 py-3">
                          <span className="font-mono text-[10px] text-amber-500 bg-amber-950/20 px-2 py-0.5 rounded-md border border-amber-500/10 font-bold uppercase tracking-wider">{item.code}</span>
                          <strong className="block text-slate-100 text-xs mt-1">{item.name}</strong>
                          <span className="text-[10px] text-slate-500 block">{item.category}</span>
                        </td>

                        {/* Applications column */}
                        <td className="px-4 py-3 text-slate-400 text-xs max-w-xs truncate leading-relaxed">
                          {item.possibleApplications ? (
                            <span title={item.possibleApplications}>{item.possibleApplications}</span>
                          ) : (
                            <span className="text-slate-600 italic">Não especificada</span>
                          )}
                        </td>

                        {/* Stock column */}
                        <td className="px-4 py-3 text-center font-semibold text-slate-200">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                            item.quantity <= item.minimumStock 
                              ? 'bg-red-950/30 text-red-400 border-red-500/15' 
                              : 'bg-slate-900/60 text-slate-300 border-slate-800'
                          }`}>
                            {item.quantity} {item.unit}
                          </span>
                        </td>

                        {/* Price column */}
                        <td className="px-4 py-3 text-right font-bold text-emerald-400 font-mono">
                          R$ {item.salePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </td>

                        {/* Actions column */}
                        <td className="px-4 py-3 text-center">
                          <button
                            type="button"
                            disabled={item.quantity <= 0}
                            onClick={() => {
                              setSelectedMaterialId(item.id);
                              setIsBrowsingInventory(false);
                            }}
                            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase transition-all duration-200 ${
                              item.quantity <= 0 
                                ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed' 
                                : 'bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-slate-950 hover:shadow-md cursor-pointer'
                            }`}
                          >
                            Selecionar
                          </button>
                        </td>
                      </tr>
                    ))}
                  {inventory.filter(item => {
                    const query = materialSearchQuery.toLowerCase();
                    return !query || 
                           item.name.toLowerCase().includes(query) ||
                           item.code.toLowerCase().includes(query) ||
                           item.category.toLowerCase().includes(query) ||
                           (item.possibleApplications && item.possibleApplications.toLowerCase().includes(query));
                  }).length === 0 && (
                    <tr>
                      <td colSpan={6} className="text-center py-10 text-slate-500">
                        <p className="font-bold">Nenhum material correspondente no estoque</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between border-t border-slate-800 pt-3">
              <span className="text-[10px] text-slate-500 font-bold">Total em estoque: {inventory.length} materiais cadastrados</span>
              <button
                type="button"
                onClick={() => setIsBrowsingInventory(false)}
                className="px-4 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white rounded-lg text-xs font-bold uppercase tracking-wider cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* State-based OS Deletion Confirmation */}
      {osToDelete && (
        <div className="fixed inset-0 z-55 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#11131c] border border-slate-800/80 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-left animate-slide-in">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-red-950/50 border border-red-500/30 text-red-400 rounded-xl">
                <AlertTriangle className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider">Excluir Ordem de Serviço?</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Tem certeza de que deseja excluir permanentemente a <strong className="text-white">{osToDelete.osNumber}</strong>? Esta ação é irreversível e ela não constará no histórico do sistema.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 justify-end border-t border-slate-850 pt-3.5">
              <button
                type="button"
                onClick={() => setOsToDelete(null)}
                className="px-4 py-2 bg-[#0c0d10] border border-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteOrder) {
                    onDeleteOrder(osToDelete.id);
                    showFeedback(`${osToDelete.osNumber} excluída com sucesso!`, 'success');
                    if (selectedOrderId === osToDelete.id) {
                      handleResetActiveOS();
                    }
                  } else {
                    showFeedback('Erro: Função de exclusão não configurada.', 'error');
                  }
                  setOsToDelete(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl transition-colors cursor-pointer text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-red-900/20"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Excluir Permanentemente</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Price Table Selection Modal */}
      {isPriceTableModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="price-table-attachment-modal">
          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs" onClick={() => setIsPriceTableModalOpen(false)}></div>
          
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-4xl border-2 border-slate-300 p-6 flex flex-col space-y-4 max-h-[90vh] overflow-hidden">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b-2 border-slate-200 pb-3 shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-100 rounded-xl border border-emerald-300 text-emerald-800">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base uppercase tracking-wider">
                    Tabela de Preços Predefinidos - Catálogo de Serviços
                  </h3>
                  <span className="text-xs text-slate-600 block font-medium">
                    Destino da inclusão: <strong className="text-emerald-800 font-bold uppercase">{priceTableTarget === 'STEP2' ? 'Etapa 2 - Diagnóstico & Orçamento' : 'Etapa 3 - Execução do Serviço'}</strong>
                  </span>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setIsPriceTableModalOpen(false)}
                className="p-1.5 hover:bg-slate-100 rounded-xl text-slate-500 hover:text-slate-800 transition-colors cursor-pointer border border-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Target Switcher & Search Bar & Category Filters */}
            <div className="space-y-3 shrink-0">
              <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between">
                <div className="relative flex-1">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Pesquisar por código, serviço, categoria ou escopo técnico..."
                    value={priceTableSearch}
                    onChange={(e) => setPriceTableSearch(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border-2 border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-500 focus:outline-none focus:border-emerald-600 font-bold"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-slate-500 uppercase">Inserir Em:</span>
                  <div className="inline-flex bg-slate-100 p-1 rounded-xl border border-slate-300">
                    <button
                      type="button"
                      onClick={() => setPriceTableTarget('STEP2')}
                      className={`px-3 py-1 text-xs font-black rounded-lg transition-all cursor-pointer ${
                        priceTableTarget === 'STEP2'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Orçamento (Etapa 2)
                    </button>
                    <button
                      type="button"
                      onClick={() => setPriceTableTarget('STEP3')}
                      className={`px-3 py-1 text-xs font-black rounded-lg transition-all cursor-pointer ${
                        priceTableTarget === 'STEP3'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Execução (Etapa 3)
                    </button>
                  </div>
                </div>
              </div>

              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
                <span className="text-[10px] font-black text-slate-500 uppercase shrink-0 mr-1">Categoria:</span>
                <button
                  type="button"
                  onClick={() => setSelectedPriceCategory('ALL')}
                  className={`px-2.5 py-1 rounded-lg font-black text-[11px] uppercase transition-all cursor-pointer shrink-0 border ${
                    selectedPriceCategory === 'ALL'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  Todas ({services.length})
                </button>
                {Array.from(new Set(services.map(s => s.category || 'Geral'))).map(cat => {
                  const count = services.filter(s => (s.category || 'Geral') === cat).length;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedPriceCategory(cat)}
                      className={`px-2.5 py-1 rounded-lg font-black text-[11px] uppercase transition-all cursor-pointer shrink-0 border ${
                        selectedPriceCategory === cat
                          ? 'bg-emerald-700 text-white border-emerald-700'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      {cat} ({count})
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Price Table Items Grid */}
            <div className="overflow-y-auto space-y-2.5 pr-1 max-h-[50vh] scrollbar-thin">
              {services.filter(s => {
                const q = priceTableSearch.toLowerCase();
                const matchCategory = selectedPriceCategory === 'ALL' || (s.category || 'Geral') === selectedPriceCategory;
                const matchQuery = !q || 
                       s.code.toLowerCase().includes(q) ||
                       s.name.toLowerCase().includes(q) ||
                       s.description.toLowerCase().includes(q) ||
                       (s.category && s.category.toLowerCase().includes(q));
                return matchCategory && matchQuery;
              }).length === 0 ? (
                <div className="text-center py-10 text-slate-500 bg-slate-50 rounded-xl border-2 border-dashed border-slate-300">
                  <p className="text-xs font-black text-slate-700">Nenhum serviço encontrado na tabela com os filtros aplicados</p>
                  <p className="text-[11px] text-slate-500 mt-1">Acesse a aba "Serviços" para cadastrar novos itens na tabela.</p>
                </div>
              ) : (
                services.filter(s => {
                  const q = priceTableSearch.toLowerCase();
                  const matchCategory = selectedPriceCategory === 'ALL' || (s.category || 'Geral') === selectedPriceCategory;
                  const matchQuery = !q || 
                         s.code.toLowerCase().includes(q) ||
                         s.name.toLowerCase().includes(q) ||
                         s.description.toLowerCase().includes(q) ||
                         (s.category && s.category.toLowerCase().includes(q));
                  return matchCategory && matchQuery;
                }).map(s => {
                  const isChecked = selectedPriceTableIds.includes(s.id);
                  return (
                    <div 
                      key={s.id}
                      className={`border-2 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all ${
                        isChecked 
                          ? 'bg-emerald-50/70 border-emerald-500 shadow-xs' 
                          : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                      }`}
                    >
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <label className="flex items-center gap-2 cursor-pointer pt-0.5 shrink-0" title="Selecionar para transferência múltipla">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedPriceTableIds(prev => [...prev, s.id]);
                              } else {
                                setSelectedPriceTableIds(prev => prev.filter(id => id !== s.id));
                              }
                            }}
                            className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
                          />
                        </label>

                        <div className="space-y-1 min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono text-[10px] font-black text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded uppercase">
                              {s.code}
                            </span>
                            {s.category && (
                              <span className="text-[9px] font-bold text-slate-700 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded uppercase">
                                {s.category}
                              </span>
                            )}
                            <span className="text-xs font-black text-slate-900">
                              {s.name}
                            </span>
                          </div>
                          {s.description && (
                            <p className="text-[11px] text-slate-600 leading-relaxed font-normal bg-slate-50/70 p-1.5 rounded-lg border border-slate-200/60 mt-1">
                              <strong className="font-bold text-slate-700">Descritivo: </strong>{s.description}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200">
                        <div className="text-right">
                          <span className="text-[9px] text-slate-500 block uppercase font-bold">Valor Unitário</span>
                          <span className="text-xs font-black text-emerald-700 font-mono">
                            R$ {s.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            handleAttachServiceFromPriceTable(s);
                            setIsPriceTableModalOpen(false);
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1 cursor-pointer shadow-xs"
                          title="Transferir este serviço e seu descritivo imediatamente"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Transferir</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Modal Footer with Multi-Select Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-t-2 border-slate-200 pt-3 shrink-0">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (selectedPriceTableIds.length === services.length) {
                      setSelectedPriceTableIds([]);
                    } else {
                      setSelectedPriceTableIds(services.map(s => s.id));
                    }
                  }}
                  className="text-[11px] font-bold text-slate-600 hover:text-slate-900 underline cursor-pointer"
                >
                  {selectedPriceTableIds.length === services.length ? 'Desmarcar todos' : 'Selecionar todos'}
                </button>
                <span className="text-slate-300">|</span>
                <span className="text-xs text-slate-700 font-bold">
                  {selectedPriceTableIds.length} de {services.length} selecionados
                </span>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                {selectedPriceTableIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => handleAttachBatchServicesFromPriceTable()}
                    className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer shadow-sm flex items-center justify-center gap-1.5 transition-all"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>
                      Transferir {selectedPriceTableIds.length} Selecionados (+ R$ {
                        services
                          .filter(s => selectedPriceTableIds.includes(s.id))
                          .reduce((acc, s) => acc + s.estimatedCost, 0)
                          .toLocaleString('pt-BR', { minimumFractionDigits: 2 })
                      })
                    </span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setIsPriceTableModalOpen(false)}
                  className="w-full sm:w-auto px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* MODAL: GERENCIAR RECEBEDORES / ATENDENTES */}
      {showReceiversModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border-2 border-slate-300 rounded-2xl max-w-md w-full p-6 shadow-2xl text-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                  <UserPlus className="w-5 h-5" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900">Gerenciar Recebedores / Atendentes</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowReceiversModal(false)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 font-medium">
              Cadastre os nomes dos atendentes que realizam a recepção de equipamentos na entrada ou remova cadastros desatualizados.
            </p>

            {/* FORMULARIO: NOVO RECEBEDOR */}
            <div className="space-y-2">
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wide">Novo Atendente / Recebedor</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Digite o nome do atendente..."
                  value={newReceiverInput}
                  onChange={(e) => setNewReceiverInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddReceiver(newReceiverInput);
                    }
                  }}
                  className="flex-1 px-3 py-2.5 bg-slate-50 border-2 border-slate-300 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 uppercase focus:outline-hidden focus:border-blue-600 focus:bg-white font-bold transition-all"
                />
                <button
                  type="button"
                  onClick={() => handleAddReceiver(newReceiverInput)}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar</span>
                </button>
              </div>
            </div>

            {/* LISTA DE RECEBEDORES */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <label className="block text-xs font-black text-slate-700 uppercase tracking-wide">
                Atendentes Cadastrados ({activeReceivers.length})
              </label>
              <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                {activeReceivers.map((rec) => (
                  <div
                    key={rec}
                    className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 hover:border-blue-300 hover:bg-blue-50/50 transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                      <span className="uppercase text-slate-900">{rec}</span>
                      {rec === receiverName && (
                        <span className="text-[9px] bg-blue-100 text-blue-800 border border-blue-300 px-1.5 py-0.5 rounded uppercase font-extrabold">
                          Selecionado
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteReceiver(rec)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                      title={`Excluir ${rec}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setShowReceiversModal(false)}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-lg cursor-pointer shadow-xs transition-colors"
              >
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STAGE COMPLETION CONFIRMATION MODAL */}
      {stageCompletionModal && stageCompletionModal.isOpen && (
        <div 
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-[110] flex items-center justify-center p-4"
          id="stage-completion-modal"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-3xl border-2 border-emerald-500 max-w-lg w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white p-6 relative">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-white/20 border border-white/30 flex items-center justify-center shrink-0 shadow-inner">
                  <CheckCircle2 className="w-7 h-7 text-white" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="inline-block px-2.5 py-0.5 rounded-full bg-white/25 border border-white/40 text-[10px] font-black uppercase tracking-wider text-white mb-1">
                    {stageCompletionModal.badge}
                  </span>
                  <h3 className="text-base sm:text-lg font-black tracking-tight text-white leading-snug">
                    {stageCompletionModal.title}
                  </h3>
                  <p className="text-xs font-mono font-bold text-emerald-100 truncate">
                    {stageCompletionModal.stepName} • OS: {stageCompletionModal.osNumber}
                  </p>
                </div>
              </div>
            </div>

            {/* Body Content */}
            <div className="p-6 space-y-4">
              <div className="bg-emerald-50/80 border-2 border-emerald-200 rounded-2xl p-4 text-emerald-950">
                <p className="text-xs font-medium leading-relaxed font-sans">
                  {stageCompletionModal.description}
                </p>
              </div>

              {/* Details Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2 text-xs">
                <div className="flex justify-between items-center py-1 border-b border-slate-200">
                  <span className="text-slate-500 font-bold uppercase text-[10px]">Cliente:</span>
                  <span className="text-slate-900 font-black truncate max-w-[240px]">{stageCompletionModal.clientName}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-200">
                  <span className="text-slate-500 font-bold uppercase text-[10px]">Equipamento:</span>
                  <span className="text-slate-900 font-black truncate max-w-[240px]">{stageCompletionModal.equipmentName}</span>
                </div>
                {stageCompletionModal.details?.map((d, i) => (
                  <div key={i} className="flex justify-between items-center py-1 border-b border-slate-200 last:border-b-0">
                    <span className="text-slate-500 font-bold uppercase text-[10px]">{d.label}:</span>
                    <span className="text-slate-900 font-mono font-black">{d.value}</span>
                  </div>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={stageCompletionModal.onPrimaryAction}
                  className="w-full sm:flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-md flex items-center justify-center gap-2"
                  id="btn-confirm-stage-completion"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>{stageCompletionModal.primaryActionLabel}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStageCompletionModal(null)}
                  className="w-full sm:w-auto py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs uppercase rounded-xl transition-colors cursor-pointer border border-slate-300"
                  id="btn-dismiss-stage-completion"
                >
                  Permanecer aqui
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Share Contact & Channel Override Modal */}
      {shareModalConfig && (
        <ShareContactModal
          isOpen={shareModalConfig.isOpen}
          onClose={() => setShareModalConfig(null)}
          title={shareModalConfig.title}
          subtitle={shareModalConfig.subtitle}
          docType={shareModalConfig.docType}
          clientName={shareModalConfig.clientName}
          clientPhone={shareModalConfig.clientPhone}
          clientEmail={shareModalConfig.clientEmail}
          defaultChannel={shareModalConfig.defaultChannel}
          defaultMessage={shareModalConfig.defaultMessage}
          subject={shareModalConfig.subject}
          onFeedback={(msg, type) => showFeedback(msg, type)}
        />
      )}

    </div>
  );
}
