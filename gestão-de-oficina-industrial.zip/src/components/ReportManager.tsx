import React, { useState, useMemo } from 'react';
import { Client, Equipment, ServiceOrder, OSStatus } from '../types';
import { 
  BarChart3, 
  Calendar, 
  Users, 
  Cpu, 
  Layers, 
  Download, 
  Printer, 
  Clock, 
  FileText, 
  DollarSign, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Info,
  Wrench,
  TrendingUp,
  Tag
} from 'lucide-react';

interface ReportManagerProps {
  clients: Client[];
  equipments: Equipment[];
  orders: ServiceOrder[];
}

export default function ReportManager({ clients, equipments, orders }: ReportManagerProps) {
  // Navigation mode: METRICS (Indicadores de Desempenho) vs RECORDS (Relatório OS)
  const [activeSubTab, setActiveSubTab] = useState<'METRICS' | 'RECORDS'>('METRICS');

  // Filter States
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [selectedClientId, setSelectedClientId] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [selectedEquipType, setSelectedEquipType] = useState('ALL');

  // Query search within reports
  const [searchQuery, setSearchQuery] = useState('');

  // Extract all unique equipment types for dropdown filter
  const equipmentTypes = useMemo(() => {
    const types = equipments.map(e => e.type.trim()).filter(Boolean);
    return Array.from(new Set(types)).sort();
  }, [equipments]);

  // Client mapping helper for fast lookup
  const clientMap = useMemo(() => {
    return new Map(clients.map(c => [c.id, c]));
  }, [clients]);

  // Equipment mapping helper for fast lookup
  const equipmentMap = useMemo(() => {
    return new Map(equipments.map(e => [e.id, e]));
  }, [equipments]);

  // Apply filters to Service Orders
  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      // 1. Period filter (by startDate)
      if (dateFrom && order.startDate < dateFrom) return false;
      if (dateTo && order.startDate > dateTo) return false;

      // 2. Client filter
      if (selectedClientId !== 'ALL' && order.clientId !== selectedClientId) return false;

      // 3. Status filter
      if (selectedStatus !== 'ALL' && order.status !== selectedStatus) return false;

      // 4. Equipment Type filter
      if (selectedEquipType !== 'ALL') {
        const equip = equipmentMap.get(order.equipmentId);
        if (!equip || equip.type !== selectedEquipType) return false;
      }

      // 5. Query Search inside report
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const client = clientMap.get(order.clientId);
        const equip = equipmentMap.get(order.equipmentId);
        
        const matchTitle = order.title.toLowerCase().includes(query);
        const matchOS = order.osNumber.toLowerCase().includes(query);
        const matchTech = order.technician.toLowerCase().includes(query);
        const matchClient = client ? client.name.toLowerCase().includes(query) : false;
        const matchEquip = equip ? `${equip.name} ${equip.model}`.toLowerCase().includes(query) : false;

        if (!matchTitle && !matchOS && !matchTech && !matchClient && !matchEquip) return false;
      }

      return true;
    });
  }, [orders, dateFrom, dateTo, selectedClientId, selectedStatus, selectedEquipType, searchQuery, equipmentMap, clientMap]);

  // Report Metrics Calculations
  const metrics = useMemo(() => {
    const totalOS = filteredOrders.length;
    
    // Total services cost (sum of estimatedCost)
    const totalCost = filteredOrders.reduce((sum, o) => sum + (o.estimatedCost || 0), 0);

    // Filter completed OS that have valid start and end dates to compute avg completion time
    const completedWithDates = filteredOrders.filter(
      o => o.status === 'COMPLETED' && o.startDate && o.endDate
    );

    let averageCompletionDays = 0;
    if (completedWithDates.length > 0) {
      const totalDays = completedWithDates.reduce((sum, o) => {
        const start = new Date(o.startDate);
        const end = new Date(o.endDate!);
        // Calculate difference in days (min 0)
        const diffTime = end.getTime() - start.getTime();
        const diffDays = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
        return sum + diffDays;
      }, 0);
      averageCompletionDays = Number((totalDays / completedWithDates.length).toFixed(1));
    }

    return {
      totalOS,
      totalCost,
      averageCompletionDays,
      completedCount: completedWithDates.length
    };
  }, [filteredOrders]);

  // Aggregate stats for visualizations
  // 1. Status distribution counter
  const statusDistribution = useMemo(() => {
    const counts = { PENDING: 0, IN_PROGRESS: 0, COMPLETED: 0, CANCELLED: 0 };
    filteredOrders.forEach(o => {
      if (counts[o.status] !== undefined) counts[o.status]++;
    });
    const total = filteredOrders.length || 1;
    return {
      PENDING: { count: counts.PENDING, pct: Math.round((counts.PENDING / total) * 100) },
      IN_PROGRESS: { count: counts.IN_PROGRESS, pct: Math.round((counts.IN_PROGRESS / total) * 100) },
      COMPLETED: { count: counts.COMPLETED, pct: Math.round((counts.COMPLETED / total) * 100) },
      CANCELLED: { count: counts.CANCELLED, pct: Math.round((counts.CANCELLED / total) * 100) }
    };
  }, [filteredOrders]);

  // 2. Costs by Client
  const clientCosts = useMemo(() => {
    const costs: Record<string, { name: string; cost: number; count: number }> = {};
    filteredOrders.forEach(o => {
      const clientName = clientMap.get(o.clientId)?.name || 'Desconhecido';
      if (!costs[o.clientId]) {
        costs[o.clientId] = { name: clientName, cost: 0, count: 0 };
      }
      costs[o.clientId].cost += o.estimatedCost || 0;
      costs[o.clientId].count += 1;
    });

    return Object.values(costs).sort((a, b) => b.cost - a.cost).slice(0, 5);
  }, [filteredOrders, clientMap]);

  // 3. Costs by Equipment Type
  const equipmentTypeCosts = useMemo(() => {
    const costs: Record<string, { type: string; cost: number; count: number }> = {};
    filteredOrders.forEach(o => {
      const equip = equipmentMap.get(o.equipmentId);
      const type = equip?.type || 'Sem Tipo';
      if (!costs[type]) {
        costs[type] = { type, cost: 0, count: 0 };
      }
      costs[type].cost += o.estimatedCost || 0;
      costs[type].count += 1;
    });

    return Object.values(costs).sort((a, b) => b.cost - a.cost);
  }, [filteredOrders, equipmentMap]);

  // 4. Technician performance indicators
  const technicianStats = useMemo(() => {
    const techMap: Record<string, { name: string; completedCount: number; totalRevenue: number }> = {};
    orders.forEach(o => {
      const techName = o.technician || 'Sem Técnico';
      if (!techMap[techName]) {
        techMap[techName] = { name: techName, completedCount: 0, totalRevenue: 0 };
      }
      if (o.status === 'COMPLETED') {
        techMap[techName].completedCount += 1;
        techMap[techName].totalRevenue += o.estimatedCost || 0;
      }
    });
    return Object.values(techMap).sort((a, b) => b.completedCount - a.completedCount);
  }, [orders]);

  // 5. Priority performance stats
  const priorityStats = useMemo(() => {
    const counts = { HIGH: 0, MEDIUM: 0, LOW: 0 };
    filteredOrders.forEach(o => {
      const p = o.priority === 'HIGH' || o.priority === 'MEDIUM' || o.priority === 'LOW' ? o.priority : 'MEDIUM';
      counts[p]++;
    });
    const total = filteredOrders.length || 1;
    return {
      HIGH: { count: counts.HIGH, pct: Math.round((counts.HIGH / total) * 100) },
      MEDIUM: { count: counts.MEDIUM, pct: Math.round((counts.MEDIUM / total) * 100) },
      LOW: { count: counts.LOW, pct: Math.round((counts.LOW / total) * 100) },
    };
  }, [filteredOrders]);

  // Export filtered orders to CSV
  const handleExportCSV = () => {
    if (filteredOrders.length === 0) return;

    // CSV header row
    const headers = [
      'OS',
      'Titulo',
      'Cliente',
      'Equipamento',
      'Modelo',
      'Prioridade',
      'Status',
      'Tecnico',
      'Custo Estimado (R$)',
      'Data Inicio',
      'Data Encerramento'
    ];

    // CSV content lines
    const rows = filteredOrders.map(o => {
      const client = clientMap.get(o.clientId);
      const equip = equipmentMap.get(o.equipmentId);
      
      return [
        o.osNumber,
        `"${o.title.replace(/"/g, '""')}"`,
        `"${(client?.name || 'Desconhecido').replace(/"/g, '""')}"`,
        `"${(equip?.name || 'Desconhecido').replace(/"/g, '""')}"`,
        `"${(equip?.model || 'Desconhecido').replace(/"/g, '""')}"`,
        o.priority,
        o.status,
        `"${o.technician.replace(/"/g, '""')}"`,
        o.estimatedCost.toFixed(2),
        o.startDate,
        o.endDate || ''
      ];
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `relatorio_oficina_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Printable screen trigger
  const handlePrint = () => {
    window.print();
  };

  // Reset all filters to default
  const handleResetFilters = () => {
    setDateFrom('');
    setDateTo('');
    setSelectedClientId('ALL');
    setSelectedStatus('ALL');
    setSelectedEquipType('ALL');
    setSearchQuery('');
  };

  return (
    <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="report-manager-container">
      {/* Report Header Controls */}
      <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-blue-900 print:hidden" id="report-header-banner">
        <div>
          <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-cyan-300" />
            <span>Relatórios Gerenciais</span>
          </h2>
          <p className="text-xs text-cyan-100 mt-0.5">
            Gere, filtre e exporte inteligência de custos, produtividade e ativos da oficina
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            id="btn-export-csv"
            onClick={handleExportCSV}
            disabled={filteredOrders.length === 0}
            className="flex items-center justify-center gap-2 px-3.5 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold rounded-lg tracking-wider uppercase transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4 text-cyan-300" />
            <span>Exportar CSV</span>
          </button>
          
          <button
            id="btn-print-report"
            onClick={handlePrint}
            disabled={filteredOrders.length === 0}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs tracking-wider uppercase transition-all shadow-md cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Printer className="w-4 h-4 text-slate-950" />
            <span>Imprimir Relatório</span>
          </button>
        </div>
      </div>

      <div className="p-4 sm:p-6 bg-[#e9edf2] space-y-4">
        {/* Sub-tab Navigation (Indicadores vs Relatórios) */}
        <div className="flex border-b border-slate-300 pb-1 gap-4 print:hidden">
          <button
            type="button"
            onClick={() => setActiveSubTab('METRICS')}
            className={`pb-2 text-xs font-black uppercase tracking-wider border-b-2 transition-all duration-200 cursor-pointer ${
              activeSubTab === 'METRICS' 
                ? 'text-[#1b365d] border-[#1b365d]' 
                : 'text-slate-600 border-transparent hover:text-slate-900'
            }`}
          >
            Indicadores de Desempenho (Dashboard)
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('RECORDS')}
            className={`pb-2 text-xs font-black uppercase tracking-wider border-b-2 transition-all duration-200 cursor-pointer ${
              activeSubTab === 'RECORDS' 
                ? 'text-[#1b365d] border-[#1b365d]' 
                : 'text-slate-600 border-transparent hover:text-slate-900'
            }`}
          >
            Relatório de OS (Tabela Detalhada)
          </button>
        </div>

        {/* Interactive Filtering Panel */}
        {activeSubTab === 'RECORDS' && (
          <div className="bg-white rounded-xl border border-slate-300 shadow-xs p-4 sm:p-5 space-y-3.5 print:hidden" id="report-filters-panel">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <span className="text-xs font-black text-slate-800 uppercase tracking-wider">Filtros Avançados</span>
              <button 
                id="btn-reset-filters"
                onClick={handleResetFilters}
                className="text-[10px] font-black text-blue-700 hover:text-blue-900 tracking-wider uppercase cursor-pointer"
              >
                Limpar Filtros
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
              {/* Period - From */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">De (Abertura)</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                  <input
                    id="filter-date-from"
                    type="date"
                    value={dateFrom}
                    onChange={(e) => setDateFrom(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  />
                </div>
              </div>

              {/* Period - To */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Até (Abertura)</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                  <input
                    id="filter-date-to"
                    type="date"
                    value={dateTo}
                    onChange={(e) => setDateTo(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                  />
                </div>
              </div>

              {/* Client Filter */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Cliente</label>
                <select
                  id="filter-client-select"
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                >
                  <option value="ALL">Todos os Clientes</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              {/* Status Filter */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Status da OS</label>
                <select
                  id="filter-status-select"
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                >
                  <option value="ALL">Todos os Status</option>
                  <option value="PENDING">Aguardando (Pendente)</option>
                  <option value="IN_PROGRESS">Em Execução (Andamento)</option>
                  <option value="COMPLETED">Concluída</option>
                  <option value="CANCELLED">Cancelada</option>
                </select>
              </div>

              {/* Equipment Type Filter */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700">Tipo de Equipamento</label>
                <select
                  id="filter-equip-type-select"
                  value={selectedEquipType}
                  onChange={(e) => setSelectedEquipType(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-bold focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 shadow-inner"
                >
                  <option value="ALL">Todos os Tipos</option>
                  {equipmentTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Live Search inside filters */}
            <div className="relative pt-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                id="report-search-query"
                type="text"
                placeholder="Buscar por Título, Número da OS, Técnico, Cliente ou Máquina dentro do relatório filtrado..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-500 transition-all shadow-inner"
              />
            </div>
          </div>
        )}

        {/* Print-only Header (Visible only on paper/PDF print) */}
        <div className="hidden print:block border-b border-slate-800 pb-5 mb-6 text-slate-900">
          <h1 className="text-xl font-bold uppercase tracking-wider">JC&F - MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA • RELATÓRIO EXECUTIVO</h1>
          <p className="text-xs mt-1">Gerado em: {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR', { hour12: false })}</p>
          
          {/* Applied filters list */}
          <div className="mt-4 grid grid-cols-2 gap-3 bg-slate-100 p-3 rounded-lg text-[11px]">
            <div>
              <strong>Período:</strong> {dateFrom || 'Início dos tempos'} até {dateTo || 'Hoje'}
            </div>
            <div>
              <strong>Cliente:</strong> {selectedClientId === 'ALL' ? 'Todos' : clients.find(c => c.id === selectedClientId)?.name}
            </div>
            <div>
              <strong>Status:</strong> {selectedStatus === 'ALL' ? 'Todos' : selectedStatus}
            </div>
            <div>
              <strong>Tipo de Equipamento:</strong> {selectedEquipType === 'ALL' ? 'Todos' : selectedEquipType}
            </div>
          </div>
        </div>

        {/* Metrics Summary Cards */}
        {activeSubTab === 'METRICS' && (
          <div className="space-y-4 print:block" id="report-metrics-dashboard">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5" id="report-summary-cards">
              {/* Metric 1: Total OS */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 shadow-xs flex items-center justify-between relative overflow-hidden print:bg-white print:text-black print:border-slate-300">
                <div className="space-y-0.5">
                  <span className="text-slate-500 text-[10px] uppercase font-black tracking-wider block print:text-slate-600">Total de Atendimentos (OS)</span>
                  <span className="font-mono text-2xl font-black text-slate-900 tracking-tight block print:text-black">
                    {metrics.totalOS}
                  </span>
                  <span className="text-[10px] text-slate-500 font-bold block print:text-slate-400">Ordens de serviço filtradas</span>
                </div>
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-700 print:hidden">
                  <FileText className="w-5 h-5" />
                </div>
              </div>

              {/* Metric 2: Total Cost */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 shadow-xs flex items-center justify-between relative overflow-hidden print:bg-white print:text-black print:border-slate-300">
                <div className="space-y-0.5">
                  <span className="text-slate-500 text-[10px] uppercase font-black tracking-wider block print:text-slate-600">Valor Total dos Serviços</span>
                  <span className="font-mono text-2xl font-black text-emerald-700 tracking-tight block print:text-black">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(metrics.totalCost)}
                  </span>
                  <span className="text-[10px] text-slate-500 font-bold block print:text-slate-400">Montante financeiro correspondente</span>
                </div>
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-600 print:hidden">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>

              {/* Metric 3: Avg Completion Time */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 shadow-xs flex items-center justify-between relative overflow-hidden print:bg-white print:text-black print:border-slate-300">
                <div className="space-y-0.5">
                  <span className="text-slate-500 text-[10px] uppercase font-black tracking-wider block print:text-slate-600">Tempo Médio de Conclusão</span>
                  <span className="font-mono text-2xl font-black text-amber-600 tracking-tight block print:text-black">
                    {metrics.averageCompletionDays > 0 ? `${metrics.averageCompletionDays} Dias` : 'N/A'}
                  </span>
                  <span className="text-[10px] text-slate-500 font-bold block print:text-slate-400">
                    {metrics.completedCount > 0 
                      ? `Baseado em ${metrics.completedCount} OS concluídas` 
                      : 'Nenhuma OS concluída no filtro'}
                  </span>
                </div>
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-600 print:hidden">
                  <Clock className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Visual Analytical Charts (Tailwind + SVG Bento layout) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 print:hidden" id="report-analytics-charts">
              
              {/* Status distribution bar */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 shadow-xs space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                  <TrendingUp className="w-4 h-4 text-blue-700" />
                  <h3 className="font-black text-slate-900 text-xs uppercase tracking-wider">Distribuição por Status</h3>
                </div>

                <div className="space-y-3 pt-1">
                  <div className="h-4 bg-slate-100 rounded-full overflow-hidden flex border border-slate-200">
                    <div 
                      style={{ width: `${statusDistribution.COMPLETED.pct}%` }} 
                      className="bg-emerald-500 hover:opacity-85 transition-opacity" 
                      title={`Concluídas: ${statusDistribution.COMPLETED.count}`}
                    ></div>
                    <div 
                      style={{ width: `${statusDistribution.IN_PROGRESS.pct}%` }} 
                      className="bg-blue-600 hover:opacity-85 transition-opacity" 
                      title={`Em Execução: ${statusDistribution.IN_PROGRESS.count}`}
                    ></div>
                    <div 
                      style={{ width: `${statusDistribution.PENDING.pct}%` }} 
                      className="bg-amber-500 hover:opacity-85 transition-opacity" 
                      title={`Aguardando: ${statusDistribution.PENDING.count}`}
                    ></div>
                    <div 
                      style={{ width: `${statusDistribution.CANCELLED.pct}%` }} 
                      className="bg-red-500 hover:opacity-85 transition-opacity" 
                      title={`Canceladas: ${statusDistribution.CANCELLED.count}`}
                    ></div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full"></span>
                        <span className="font-bold text-slate-700 uppercase text-[10px]">Concluídas</span>
                      </div>
                      <span className="font-mono font-black text-emerald-700 text-xs">
                        {statusDistribution.COMPLETED.count} ({statusDistribution.COMPLETED.pct}%)
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 bg-blue-600 rounded-full"></span>
                        <span className="font-bold text-slate-700 uppercase text-[10px]">Execução</span>
                      </div>
                      <span className="font-mono font-black text-blue-800 text-xs">
                        {statusDistribution.IN_PROGRESS.count} ({statusDistribution.IN_PROGRESS.pct}%)
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 bg-amber-500 rounded-full"></span>
                        <span className="font-bold text-slate-700 uppercase text-[10px]">Aguardando</span>
                      </div>
                      <span className="font-mono font-black text-amber-700 text-xs">
                        {statusDistribution.PENDING.count} ({statusDistribution.PENDING.pct}%)
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                        <span className="font-bold text-slate-700 uppercase text-[10px]">Canceladas</span>
                      </div>
                      <span className="font-mono font-black text-red-600 text-xs">
                        {statusDistribution.CANCELLED.count} ({statusDistribution.CANCELLED.pct}%)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Top Clients spending analysis */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 shadow-xs space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                  <Users className="w-4 h-4 text-emerald-700" />
                  <h3 className="font-black text-slate-900 text-xs uppercase tracking-wider">Top Clientes por Custo de Serviço</h3>
                </div>

                <div className="space-y-3 pt-1">
                  {clientCosts.length === 0 ? (
                    <p className="text-xs text-slate-500 text-center py-8 font-medium">Sem dados de custos para exibir.</p>
                  ) : (
                    clientCosts.map((item, idx) => {
                      const maxCost = clientCosts[0]?.cost || 1;
                      const ratio = Math.max(2, Math.min(100, Math.round((item.cost / maxCost) * 100)));

                      return (
                        <div key={idx} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-slate-900 truncate max-w-[200px]">{item.name}</span>
                            <span className="font-mono text-slate-700 font-bold">
                              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(item.cost)}
                              <span className="text-[10px] text-slate-500 font-sans font-bold ml-1.5">({item.count} OS)</span>
                            </span>
                          </div>
                          <div className="h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                            <div 
                              style={{ width: `${ratio}%` }} 
                              className="h-full bg-blue-700 rounded-full"
                            ></div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Priority Demands Chart */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 shadow-xs space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                  <Tag className="w-4 h-4 text-amber-600" />
                  <h3 className="font-black text-slate-900 text-xs uppercase tracking-wider">Demanda por Urgência (OS)</h3>
                </div>
                <div className="space-y-3 pt-1">
                  <div className="h-4 bg-slate-100 rounded-full overflow-hidden flex border border-slate-200">
                    <div style={{ width: `${priorityStats.HIGH.pct}%` }} className="bg-red-500" title={`Alta: ${priorityStats.HIGH.count}`}></div>
                    <div style={{ width: `${priorityStats.MEDIUM.pct}%` }} className="bg-amber-500" title={`Média: ${priorityStats.MEDIUM.count}`}></div>
                    <div style={{ width: `${priorityStats.LOW.pct}%` }} className="bg-slate-400" title={`Baixa: ${priorityStats.LOW.count}`}></div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[10px]">
                    <div className="bg-red-50 p-2 rounded-lg border border-red-200 text-center">
                      <span className="text-red-700 font-black block">ALTA</span>
                      <span className="text-slate-900 font-mono font-black mt-0.5 block">{priorityStats.HIGH.count} ({priorityStats.HIGH.pct}%)</span>
                    </div>
                    <div className="bg-amber-50 p-2 rounded-lg border border-amber-200 text-center">
                      <span className="text-amber-800 font-black block">MÉDIA</span>
                      <span className="text-slate-900 font-mono font-black mt-0.5 block">{priorityStats.MEDIUM.count} ({priorityStats.MEDIUM.pct}%)</span>
                    </div>
                    <div className="bg-slate-100 p-2 rounded-lg border border-slate-200 text-center">
                      <span className="text-slate-600 font-black block">BAIXA</span>
                      <span className="text-slate-900 font-mono font-black mt-0.5 block">{priorityStats.LOW.count} ({priorityStats.LOW.pct}%)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Technician Productivity Rank */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 shadow-xs space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                  <TrendingUp className="w-4 h-4 text-blue-700" />
                  <h3 className="font-black text-slate-900 text-xs uppercase tracking-wider">Desempenho dos Técnicos (OS Concluídas)</h3>
                </div>
                <div className="space-y-3 pt-1">
                  {technicianStats.length === 0 ? (
                    <p className="text-xs text-slate-500 text-center py-8 font-medium">Sem estatísticas acumuladas para técnicos.</p>
                  ) : (
                    technicianStats.slice(0, 4).map((tech, idx) => {
                      const maxCompleted = Math.max(1, Math.max(...technicianStats.map(t => t.completedCount)));
                      const ratio = Math.max(5, Math.min(100, Math.round((tech.completedCount / maxCompleted) * 100)));
                      return (
                        <div key={idx} className="space-y-1 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-900">{tech.name}</span>
                            <span className="font-mono text-blue-800 font-black">
                              {tech.completedCount} OS resolvidas
                              <span className="text-slate-500 text-[10px] ml-2">({new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(tech.totalRevenue)})</span>
                            </span>
                          </div>
                          <div className="h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                            <div style={{ width: `${ratio}%` }} className="h-full bg-blue-700 rounded-full"></div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Equipment Type aggregate spending chart */}
              <div className="bg-white rounded-xl border border-slate-300 p-4 shadow-xs space-y-3 lg:col-span-2">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                  <Layers className="w-4 h-4 text-blue-800" />
                  <h3 className="font-black text-slate-900 text-xs uppercase tracking-wider">Distribuição Financeira por Tipo de Ativo</h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
                  {equipmentTypeCosts.length === 0 ? (
                    <p className="col-span-full text-xs text-slate-500 text-center py-8 font-medium">Sem dados acumulados para exibir.</p>
                  ) : (
                    equipmentTypeCosts.map((item, idx) => (
                      <div key={idx} className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex flex-col justify-between space-y-2">
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase font-black tracking-wider text-slate-500 block">Tipo de Equipamento</span>
                          <span className="font-black text-slate-900 text-xs block truncate" title={item.type}>{item.type}</span>
                        </div>
                        <div className="flex items-baseline justify-between pt-1 border-t border-slate-200">
                          <span className="text-[10px] text-slate-600 font-bold">{item.count} {item.count === 1 ? 'OS' : 'OSs'}</span>
                          <span className="font-mono text-xs font-black text-blue-900">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.cost)}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Structured report data list table */}
        {activeSubTab === 'RECORDS' && (
          <div className="bg-white rounded-xl border border-slate-300 shadow-xs overflow-hidden print:border-slate-300 print:shadow-none print:bg-white" id="report-table-wrapper">
            <div className="px-4 py-3 bg-[#1b365d] text-white flex items-center justify-between print:border-b-2 print:border-slate-300 print:text-black">
              <span className="text-xs font-black uppercase tracking-wider flex items-center gap-2 print:text-black">
                <FileText className="w-4 h-4 text-cyan-300 print:text-slate-700" />
                <span>Dados Detalhados ({filteredOrders.length} Ordens)</span>
              </span>
              <span className="text-[10px] font-mono font-bold text-cyan-100 tracking-wider print:text-slate-600">
                Filtros Ativos
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse" id="report-data-table">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200 text-[10px] font-black text-slate-700 uppercase tracking-wider print:bg-slate-100 print:text-slate-700 print:border-slate-300">
                    <th className="py-2.5 px-3 font-mono">OS</th>
                    <th className="py-2.5 px-3">Título do Serviço</th>
                    <th className="py-2.5 px-3">Cliente</th>
                    <th className="py-2.5 px-3">Equipamento</th>
                    <th className="py-2.5 px-3">Prioridade</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Técnico</th>
                    <th className="py-2.5 px-3">Custo</th>
                    <th className="py-2.5 px-3">Abertura</th>
                    <th className="py-2.5 px-3">Conclusão</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-800 print:divide-slate-200 print:text-black">
                  {filteredOrders.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-12 text-center text-slate-500 font-medium">
                        Nenhuma Ordem de Serviço corresponde aos filtros aplicados neste relatório.
                      </td>
                    </tr>
                  ) : (
                    filteredOrders.map((order) => {
                      const client = clientMap.get(order.clientId);
                      const equip = equipmentMap.get(order.equipmentId);
                      
                      return (
                        <tr 
                          id={`report-row-${order.id}`} 
                          key={order.id} 
                          className="hover:bg-blue-50/50 transition-colors print:hover:bg-transparent"
                        >
                          <td className="py-2.5 px-3 font-mono font-bold text-blue-900 print:text-black">{order.osNumber}</td>
                          <td className="py-2.5 px-3 font-bold text-slate-900 truncate max-w-xs print:text-black" title={order.title}>
                            {order.title}
                          </td>
                          <td className="py-2.5 px-3 text-slate-700 truncate max-w-xs font-medium print:text-black">{client ? client.name : 'Desconhecido'}</td>
                          <td className="py-2.5 px-3 text-slate-600 print:text-black">
                            {equip ? `${equip.name} (${equip.model})` : 'Desconhecido'}
                          </td>
                          <td className="py-2.5 px-3">
                            {order.priority === 'HIGH' && <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-red-50 border border-red-200 text-red-700 text-[10px] font-black print:border-none print:bg-transparent print:text-red-700">ALTA</span>}
                            {order.priority === 'MEDIUM' && <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-black print:border-none print:bg-transparent print:text-amber-700">MÉDIA</span>}
                            {order.priority === 'LOW' && <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-slate-700 text-[10px] font-black print:border-none print:bg-transparent print:text-slate-700">BAIXA</span>}
                          </td>
                          <td className="py-2.5 px-3">
                            {order.status === 'PENDING' && <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-100 border border-slate-300 text-slate-700 font-black text-[10px] print:border-none print:bg-transparent print:text-slate-600">Aguardando</span>}
                            {order.status === 'IN_PROGRESS' && <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-blue-50 border border-blue-200 text-blue-700 font-black text-[10px] print:border-none print:bg-transparent print:text-blue-700">Andamento</span>}
                            {order.status === 'COMPLETED' && <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-700 font-black text-[10px] print:border-none print:bg-transparent print:text-emerald-700">Concluída</span>}
                            {order.status === 'CANCELLED' && <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-red-50 border border-red-200 text-red-700 font-black text-[10px] print:border-none print:bg-transparent print:text-red-700">Cancelada</span>}
                          </td>
                          <td className="py-2.5 px-3 text-slate-700 font-bold print:text-black">{order.technician}</td>
                          <td className="py-2.5 px-3 font-mono font-black text-slate-900 print:text-black">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(order.estimatedCost)}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-600 print:text-black">
                            {new Date(order.startDate + 'T12:00:00').toLocaleDateString('pt-BR')}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-600 print:text-black">
                            {order.endDate 
                              ? new Date(order.endDate + 'T12:00:00').toLocaleDateString('pt-BR') 
                              : '-'}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
