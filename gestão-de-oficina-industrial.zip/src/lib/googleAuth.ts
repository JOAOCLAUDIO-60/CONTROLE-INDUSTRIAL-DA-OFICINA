import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
// Request full Google Sheets and Drive permissions as authorized by the user
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/drive.file');

let isSigningIn = false;
let cachedAccessToken: string | null = null;

// Read cached token from session memory to preserve state during hot-reload or sub-component mounting
try {
  const savedToken = sessionStorage.getItem('google_sheets_oauth_token');
  if (savedToken) {
    cachedAccessToken = savedToken;
  }
} catch (e) {
  console.error('Session storage reading error:', e);
}

// Initialize auth state listener. Call this on app load.
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      sessionStorage.removeItem('google_sheets_oauth_token');
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// Must be called from a button click or user interaction
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token from Google Auth Provider');
    }

    cachedAccessToken = credential.accessToken;
    sessionStorage.setItem('google_sheets_oauth_token', cachedAccessToken);
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
  sessionStorage.removeItem('google_sheets_oauth_token');
};

// --- Google Sheets API Helpers ---

export interface SyncData {
  clients: any[];
  equipments: any[];
  orders: any[];
  transactions: any[];
  inventory?: any[];
}

/**
 * Auxiliar para garantir que todas as abas necessárias existam na planilha selecionada
 */
export const ensureSheetsExist = async (token: string, spreadsheetId: string, requiredTitles: string[]): Promise<void> => {
  try {
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties.title`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    if (!response.ok) return;

    const data = await response.json();
    const existingTitles = (data.sheets || []).map((s: any) => s.properties.title);
    
    const missingTitles = requiredTitles.filter(t => !existingTitles.includes(t));
    if (missingTitles.length === 0) return;

    // Adicionar abas faltantes de forma segura
    const requests = missingTitles.map(title => ({
      addSheet: {
        properties: { title }
      }
    }));

    await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ requests }),
    });
  } catch (e) {
    console.error("Erro ao verificar ou criar abas faltantes no Sheets:", e);
  }
};

/**
 * Creates a brand new Google Sheet in the user's Drive with tabs for JC&F data
 */
export const createJCFSpreadsheet = async (token: string, title: string = 'JC&F Manutenção - Banco de Dados'): Promise<string> => {
  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: title,
      },
      sheets: [
        { properties: { title: 'Ordens de Serviço' } },
        { properties: { title: 'Clientes' } },
        { properties: { title: 'Equipamentos' } },
        { properties: { title: 'Financeiro' } },
        { properties: { title: 'Estoque' } },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro ao criar planilha: ${response.status} - ${errText}`);
  }

  const data = await response.json();
  return data.spreadsheetId;
};

/**
 * Lists spreadsheets from the user's Google Drive matching a search query
 */
export const listSpreadsheetsInDrive = async (token: string): Promise<{ id: string; name: string }[]> => {
  const query = encodeURIComponent("mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false");
  const response = await fetch(`https://www.googleapis.com/drive/v3/files?q=${query}&orderBy=name&pageSize=20&fields=files(id,name)`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro ao listar planilhas: ${response.status} - ${errText}`);
  }

  const data = await response.json();
  return data.files || [];
};

/**
 * Sincroniza todos os dados das tabelas para o Google Sheet usando batchUpdate
 */
export const syncDataToSpreadsheet = async (
  token: string,
  spreadsheetId: string,
  data: SyncData
): Promise<void> => {
  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(val);
  };

  // 1. Map orders to rows
  const ordersHeaders = [
    'ID OS',
    'Número OS',
    'Título / Equipamento',
    'Descrição / Reclamação',
    'Cliente ID',
    'Equipamento ID',
    'Situação OS',
    'Prioridade',
    'Técnico Responsável',
    'Custo Estimado (R$)',
    'Início',
    'Término',
    'Status Orçamento',
    'Laudo Técnico / Diagnóstico',
    'Serviços/Peças Planejadas',
    'Entregue ao Cliente',
    'Data de Entrega',
    'Criado em',
  ];
  const ordersRows = [
    ordersHeaders,
    ...data.orders.map((o) => [
      o.id || '',
      o.osNumber || '',
      o.title || '',
      o.description || '',
      o.clientId || '',
      o.equipmentId || '',
      o.status || '',
      o.priority || '',
      o.technician || '',
      o.estimatedCost ? formatMoney(o.estimatedCost) : '0,00',
      o.startDate || '',
      o.endDate || '',
      o.budgetStatus || 'PENDING_APPROVAL',
      o.diagnostic || '',
      o.plannedServices || '',
      o.isDelivered ? 'SIM' : 'NÃO',
      o.deliveryDate || '',
      o.createdAt || '',
    ]),
  ];

  // 2. Map clients to rows
  const clientsHeaders = ['ID Cliente', 'Nome do Cliente', 'CPF / CNPJ', 'Telefone', 'E-mail', 'Endereço', 'Criado em'];
  const clientsRows = [
    clientsHeaders,
    ...data.clients.map((c) => [
      c.id || '',
      c.name || '',
      c.document || '',
      c.phone || '',
      c.email || '',
      c.address || '',
      c.createdAt || '',
    ]),
  ];

  // 3. Map equipments to rows
  const equipmentsHeaders = ['ID Equipamento', 'Nome / Descrição', 'Modelo ou Série', 'Tipo', 'Cliente Associado ID', 'Criado em'];
  const equipmentsRows = [
    equipmentsHeaders,
    ...data.equipments.map((e) => [
      e.id || '',
      e.name || '',
      e.model || '',
      e.type || '',
      e.clientId || '',
      e.createdAt || '',
    ]),
  ];

  // 4. Map transactions to rows
  const transactionsHeaders = ['ID Lançamento', 'Tipo', 'Descrição', 'Valor (R$)', 'Data Vencimento', 'Data Pagamento', 'Categoria', 'Status', 'ID OS Associada', 'Criado em'];
  const transactionsRows = [
    transactionsHeaders,
    ...data.transactions.map((t) => [
      t.id || '',
      t.type === 'RECEIVABLE' ? 'RECEITA' : 'DESPESA',
      t.description || '',
      t.amount ? formatMoney(t.amount) : '0,00',
      t.dueDate || '',
      t.paymentDate || '',
      t.category || '',
      t.status || '',
      t.serviceOrderId || '',
      t.createdAt || '',
    ]),
  ];

  // Garantir que todas as abas existam antes de atualizar
  await ensureSheetsExist(token, spreadsheetId, ['Clientes', 'Equipamentos', 'Ordens de Serviço', 'Financeiro', 'Estoque']);

  // Make batchUpdate call to Sheets API
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      valueInputOption: 'USER_ENTERED',
      data: [
        {
          range: "'Ordens de Serviço'!A1",
          values: ordersRows,
        },
        {
          range: "'Clientes'!A1",
          values: clientsRows,
        },
        {
          range: "'Equipamentos'!A1",
          values: equipmentsRows,
        },
        {
          range: "'Financeiro'!A1",
          values: transactionsRows,
        },
        {
          range: "'Estoque'!A1",
          values: [
            [
              'ID Item',
              'Código',
              'Nome da Peça',
              'Categoria',
              'Quantidade',
              'Estoque Mínimo',
              'Preço de Compra (R$)',
              'Preço de Venda (R$)',
              'Unidade',
              'Localização',
              'Fornecedor',
              'Descrição',
              'Aplicações Possíveis',
              'Criado em'
            ],
            ...(data.inventory || []).map((i) => [
              i.id || '',
              i.code || '',
              i.name || '',
              i.category || '',
              i.quantity !== undefined ? String(i.quantity) : '0',
              i.minimumStock !== undefined ? String(i.minimumStock) : '0',
              i.purchasePrice ? formatMoney(i.purchasePrice) : '0,00',
              i.salePrice ? formatMoney(i.salePrice) : '0,00',
              i.unit || 'un',
              i.location || '',
              i.supplier || '',
              i.description || '',
              i.possibleApplications || '',
              i.createdAt || '',
            ])
          ],
        },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro ao sincronizar dados na planilha: ${response.status} - ${errText}`);
  }
};

/**
 * Busca todos os dados das tabelas salvos no Google Sheets
 */
export const fetchDataFromSpreadsheet = async (
  token: string,
  spreadsheetId: string
): Promise<SyncData> => {
  const parseMoney = (val: string): number => {
    if (!val) return 0;
    const cleaned = val.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleaned) || 0;
  };

  // Garantir que todas as abas existam antes de buscar os dados
  await ensureSheetsExist(token, spreadsheetId, ['Clientes', 'Equipamentos', 'Ordens de Serviço', 'Financeiro', 'Estoque']);

  const ranges = [
    encodeURIComponent("'Clientes'!A2:G1000"),
    encodeURIComponent("'Equipamentos'!A2:F1000"),
    encodeURIComponent("'Ordens de Serviço'!A2:R1000"),
    encodeURIComponent("'Financeiro'!A2:J1000"),
    encodeURIComponent("'Estoque'!A2:N1000")
  ];
  
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchGet?ranges=${ranges.join('&ranges=')}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro ao buscar dados do Google Sheets: ${response.status} - ${errText}`);
  }

  const result = await response.json();
  const valueRanges = result.valueRanges || [];

  // Parse Clients (Index 0)
  const clientRows = valueRanges[0]?.values || [];
  const clients = clientRows.map((row: any[]) => ({
    id: row[0] || '',
    name: row[1] || '',
    document: row[2] || '',
    phone: row[3] || '',
    email: row[4] || '',
    address: row[5] || '',
    createdAt: row[6] || '',
  }));

  // Parse Equipments (Index 1)
  const equipmentRows = valueRanges[1]?.values || [];
  const equipments = equipmentRows.map((row: any[]) => ({
    id: row[0] || '',
    name: row[1] || '',
    model: row[2] || '',
    type: row[3] || '',
    clientId: row[4] || '',
    createdAt: row[5] || '',
  }));

  // Parse Orders (Index 2)
  const parseOrderStatus = (raw: string, isDeliv: boolean): 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED' => {
    if (!raw) return isDeliv ? 'COMPLETED' : 'PENDING';
    const s = raw.trim().toUpperCase();
    if (s.includes('COMPLET') || s.includes('CONCLU') || s.includes('FINALIZ') || s.includes('ENTREG') || s.includes('FECH')) {
      return 'COMPLETED';
    }
    if (s.includes('PROGRESS') || s.includes('ANDAMENTO') || s.includes('EXECU') || s.includes('OFICINA')) {
      return 'IN_PROGRESS';
    }
    if (s.includes('CANCEL') || s.includes('RECUS')) {
      return 'CANCELLED';
    }
    return isDeliv ? 'COMPLETED' : 'PENDING';
  };

  const orderRows = valueRanges[2]?.values || [];
  const orders = orderRows.map((row: any[]) => {
    const isDeliv = row[15] === 'SIM';
    const resolvedStatus = parseOrderStatus(row[6] || '', isDeliv);
    return {
      id: row[0] || '',
      osNumber: row[1] || '',
      title: row[2] || '',
      description: row[3] || '',
      clientId: row[4] || '',
      equipmentId: row[5] || '',
      status: resolvedStatus,
      priority: row[7] || 'MEDIUM',
      technician: row[8] || '',
      estimatedCost: row[9] ? parseMoney(row[9]) : 0,
      startDate: row[10] || '',
      endDate: row[11] || '',
      budgetStatus: row[12] || 'PENDING_APPROVAL',
      diagnostic: row[13] || '',
      plannedServices: row[14] || '',
      isDelivered: isDeliv || resolvedStatus === 'COMPLETED',
      deliveryDate: row[16] || '',
      createdAt: row[17] || '',
      updatedAt: new Date().toISOString(),
    };
  });

  // Parse Transactions (Index 3)
  const transactionRows = valueRanges[3]?.values || [];
  const transactions = transactionRows.map((row: any[]) => ({
    id: row[0] || '',
    type: row[1] === 'RECEITA' ? 'RECEIVABLE' : 'PAYABLE',
    description: row[2] || '',
    amount: row[3] ? parseMoney(row[3]) : 0,
    dueDate: row[4] || '',
    paymentDate: row[5] || '',
    category: row[6] || '',
    status: row[7] || '',
    serviceOrderId: row[8] || '',
    createdAt: row[9] || '',
  }));

  // Parse Inventory (Index 4)
  const inventoryRows = valueRanges[4]?.values || [];
  const inventory = inventoryRows.map((row: any[]) => ({
    id: row[0] || '',
    code: row[1] || '',
    name: row[2] || '',
    category: row[3] || '',
    quantity: row[4] ? parseInt(row[4], 10) || 0 : 0,
    minimumStock: row[5] ? parseInt(row[5], 10) || 0 : 0,
    purchasePrice: row[6] ? parseMoney(row[6]) : 0,
    salePrice: row[7] ? parseMoney(row[7]) : 0,
    unit: row[8] || 'un',
    location: row[9] || '',
    supplier: row[10] || '',
    description: row[11] || '',
    possibleApplications: row[12] || '',
    createdAt: row[13] || '',
  }));

  return {
    clients,
    equipments,
    orders,
    transactions,
    inventory
  };
};
