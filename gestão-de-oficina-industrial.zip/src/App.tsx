/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, ChangeEvent } from 'react';
import { Client, Equipment, ServiceOrder, MaintenanceHistoryEntry, OSStatus, FinancialTransaction, TechnicalDiagnostic, PlannedService, Technician, InventoryItem, Quote, PostMaintenanceFeedback, EquipmentCatalog } from './types';
import { 
  INITIAL_CLIENTS, 
  INITIAL_EQUIPMENTS, 
  INITIAL_SERVICE_ORDERS, 
  INITIAL_MAINTENANCE_HISTORY,
  INITIAL_FINANCIALS,
  INITIAL_DIAGNOSTICS,
  INITIAL_SERVICES,
  INITIAL_TECHNICIANS,
  INITIAL_INVENTORY,
  INITIAL_QUOTES,
  INITIAL_POST_MAINTENANCE_FEEDBACKS
} from './data/mockData';
import { INITIAL_EQUIPMENT_CATALOGS } from './data/initialCatalogs';
import EquipmentEntryRegistry from './components/EquipmentEntryRegistry';
import DashboardStats from './components/DashboardStats';
import ClientManager from './components/ClientManager';
import EquipmentManager from './components/EquipmentManager';
import ServiceOrderManager from './components/ServiceOrderManager';
import ReportManager from './components/ReportManager';
import FinancialManager from './components/FinancialManager';
import DiagnosticManager from './components/DiagnosticManager';
import ServiceManager from './components/ServiceManager';
import MaintenanceLifecycle from './components/MaintenanceLifecycle';
import GoogleSheetsSync from './components/GoogleSheetsSync';
import TechnicianManager from './components/TechnicianManager';
import InventoryManager from './components/InventoryManager';
import TechnicalCertificate from './components/TechnicalCertificate';
import WarrantyManager from './components/WarrantyManager';
import MobileOrderCreator from './components/MobileOrderCreator';
import QuoteManager from './components/QuoteManager';
import PostMaintenanceManager from './components/PostMaintenanceManager';
import EquipmentCatalogManager from './components/EquipmentCatalogManager';
import { UserManual } from './components/UserManual';
import QuickNewClientModal from './components/QuickNewClientModal';
import QuickNewServiceModal from './components/QuickNewServiceModal';
import QuickNewEquipmentModal from './components/QuickNewEquipmentModal';
import PriceTableModal from './components/PriceTableModal';
import { 
  Cpu, Users, UserPlus, FileText, LayoutDashboard, Wrench, Clock, ShieldAlert, CheckCircle, BarChart3, DollarSign,
  ClipboardList, Briefcase, Smartphone, FileSpreadsheet, UserCheck, Package, ShieldCheck, Award,
  Share2, Copy, ExternalLink, Check, Link2, Globe, X, Settings, Info, HelpCircle, ChevronDown, ChevronUp,
  RefreshCw, Database, AlertTriangle, Cloud, Download, Upload, Server, Wifi, BookOpen, Layers
} from 'lucide-react';

const JCFLogoIcon = () => (
  <svg 
    viewBox="0 0 390 340" 
    className="w-9 h-9 text-cyan-400"
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    {/* Gear partial outer ring */}
    <path 
      d="M 113.1 102.6 A 100 100 0 0 1 252.4 241.9" 
      className="stroke-cyan-500/10" 
      strokeWidth="24" 
      strokeLinecap="square"
    />
    <path 
      d="M 113.1 102.6 A 100 100 0 0 1 252.4 241.9" 
      className="stroke-cyan-400" 
      strokeWidth="12" 
      strokeLinecap="square"
    />
    
    {/* Gear teeth */}
    {[-135, -105, -75, -45, -15, 15, 45].map((angle, idx) => (
      <rect 
        key={idx}
        x="184" 
        y="42" 
        width="22" 
        height="18" 
        rx="1"
        transform={`rotate(${angle}, 195, 160)`} 
        fill="currentColor" 
      />
    ))}

    {/* J C & F Letters */}
    <g fill="currentColor" fontFamily="Georgia, Cambria, 'Times New Roman', Times, serif" fontWeight="bold">
      <text x="145" y="170" fontSize="100" textAnchor="middle">J</text>
      <text x="210" y="170" fontSize="100" textAnchor="middle">C</text>
      <text x="175" y="235" fontSize="62" textAnchor="middle">&amp;</text>
      <text x="215" y="240" fontSize="100" textAnchor="middle">F</text>
    </g>

    {/* Subtitle banner */}
    <text 
      x="195" 
      y="295" 
      fill="currentColor" 
      fontFamily="Georgia, Cambria, 'Times New Roman', Times, serif" 
      fontWeight="bold" 
      fontSize="11" 
      letterSpacing="2" 
      textAnchor="middle"
    >
      MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA
    </text>
  </svg>
);

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'ENTRY_REGISTRY' | 'DASHBOARD' | 'OS' | 'EQUIPMENTS' | 'CLIENTS' | 'REPORTS' | 'FINANCE' | 'DIAGNOSTICS' | 'SERVICES' | 'MOBILE_OS' | 'GOOGLE_SHEETS' | 'TECHNICIANS' | 'INVENTORY' | 'TECHNICAL_REPORT' | 'WARRANTY_CONTROL' | 'QUOTES' | 'POST_MAINTENANCE' | 'MANUAL' | 'CATALOGS'>('ENTRY_REGISTRY');

  // Share & Check-In states
  const [isCheckInOnly, setIsCheckInOnly] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState<'app' | 'checkin' | null>(null);
  const [isLinksPanelExpanded, setIsLinksPanelExpanded] = useState(false);
  const [showCheckInSyncModal, setShowCheckInSyncModal] = useState(false);
  const [isQuickClientModalOpen, setIsQuickClientModalOpen] = useState(false);
  const [isQuickServiceModalOpen, setIsQuickServiceModalOpen] = useState(false);
  const [isQuickEquipmentModalOpen, setIsQuickEquipmentModalOpen] = useState(false);
  const [isPriceTableModalOpen, setIsPriceTableModalOpen] = useState(false);
  
  const [systemBaseUrl, setSystemBaseUrl] = useState(() => {
    if (typeof window !== 'undefined' && window.location) {
      const origin = window.location.origin;
      if (origin && origin !== 'null' && origin.startsWith('http') && !origin.includes('googleusercontent.com') && !origin.includes('iframe') && !origin.includes('localhost:3000')) {
        let path = window.location.pathname;
        if (path.endsWith('/index.html')) {
          path = path.slice(0, -11);
        }
        return origin + path;
      }
    }
    // Live Shared App URL provided in additional metadata
    return 'https://ais-pre-uui46xcks4jbkdqr5qq5uj-326553559827.us-east1.run.app';
  });

  // Parse URL query parameter for check-in mode
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('mode') === 'checkin' || params.get('checkin') === 'true') {
      setIsCheckInOnly(true);
    }
  }, []);

  const handleCopyLink = (url: string, type: 'app' | 'checkin') => {
    navigator.clipboard.writeText(url)
      .then(() => {
        setCopyFeedback(type);
        setTimeout(() => setCopyFeedback(null), 3000);
      })
      .catch((err) => {
        console.error('Falha ao copiar link: ', err);
      });
  };

  // Real-time Clock State
  const [currentTime, setCurrentTime] = useState(new Date());

  // Database States
  const [clients, setClients] = useState<Client[]>([]);
  const [equipments, setEquipments] = useState<Equipment[]>([]);
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  const [history, setHistory] = useState<MaintenanceHistoryEntry[]>([]);
  const [transactions, setTransactions] = useState<FinancialTransaction[]>([]);
  const [diagnostics, setDiagnostics] = useState<TechnicalDiagnostic[]>([]);
  const [services, setServices] = useState<PlannedService[]>([]);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [postMaintenanceFeedbacks, setPostMaintenanceFeedbacks] = useState<PostMaintenanceFeedback[]>([]);
  const [catalogs, setCatalogs] = useState<EquipmentCatalog[]>([]);
  const [catalogEquipmentFilter, setCatalogEquipmentFilter] = useState<string | null>(null);

  // Recebedores / Atendentes State
  const DEFAULT_RECEIVERS = [
    'Atendimento Balcão',
    'JOÃO CLAUDIO'
  ];

  const cleanReceiversList = (list: any[]): string[] => {
    if (!Array.isArray(list)) return DEFAULT_RECEIVERS;
    const cleaned = list
      .filter((r) => typeof r === 'string' && r.trim().length > 0)
      .map((r) => r.trim());
    return cleaned.length > 0 ? Array.from(new Set(cleaned)) : DEFAULT_RECEIVERS;
  };

  const [receivers, setReceivers] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('oficina_receivers');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return cleanReceiversList(parsed);
        }
      }
    } catch (e) {
      console.error('Erro ao carregar oficina_receivers:', e);
    }
    return DEFAULT_RECEIVERS;
  });

  // Load from local storage or fallback to mock data, then pull from server DB
  useEffect(() => {
    const storedClients = localStorage.getItem('oficina_clients');
    const storedEquipments = localStorage.getItem('oficina_equipments');
    const storedOrders = localStorage.getItem('oficina_orders');
    const storedHistory = localStorage.getItem('oficina_history');
    const storedFinancials = localStorage.getItem('oficina_financials');
    const storedDiagnostics = localStorage.getItem('oficina_diagnostics');
    const storedServices = localStorage.getItem('oficina_services');
    const storedTechnicians = localStorage.getItem('oficina_technicians');
    const storedInventory = localStorage.getItem('oficina_inventory');
    const storedQuotes = localStorage.getItem('oficina_quotes');
    const storedPostMaint = localStorage.getItem('oficina_post_maintenance');
    const storedCatalogs = localStorage.getItem('oficina_catalogs');

    if (storedClients) {
      setClients(JSON.parse(storedClients));
    } else {
      setClients(INITIAL_CLIENTS);
      localStorage.setItem('oficina_clients', JSON.stringify(INITIAL_CLIENTS));
    }

    if (storedEquipments) {
      setEquipments(JSON.parse(storedEquipments));
    } else {
      setEquipments(INITIAL_EQUIPMENTS);
      localStorage.setItem('oficina_equipments', JSON.stringify(INITIAL_EQUIPMENTS));
    }

    if (storedOrders) {
      setOrders(JSON.parse(storedOrders));
    } else {
      setOrders(INITIAL_SERVICE_ORDERS);
      localStorage.setItem('oficina_orders', JSON.stringify(INITIAL_SERVICE_ORDERS));
    }

    if (storedHistory) {
      setHistory(JSON.parse(storedHistory));
    } else {
      setHistory(INITIAL_MAINTENANCE_HISTORY);
      localStorage.setItem('oficina_history', JSON.stringify(INITIAL_MAINTENANCE_HISTORY));
    }

    if (storedFinancials) {
      setTransactions(JSON.parse(storedFinancials));
    } else {
      setTransactions(INITIAL_FINANCIALS);
      localStorage.setItem('oficina_financials', JSON.stringify(INITIAL_FINANCIALS));
    }

    if (storedDiagnostics) {
      setDiagnostics(JSON.parse(storedDiagnostics));
    } else {
      setDiagnostics(INITIAL_DIAGNOSTICS);
      localStorage.setItem('oficina_diagnostics', JSON.stringify(INITIAL_DIAGNOSTICS));
    }

    if (storedServices) {
      setServices(JSON.parse(storedServices));
    } else {
      setServices(INITIAL_SERVICES);
      localStorage.setItem('oficina_services', JSON.stringify(INITIAL_SERVICES));
    }

    if (storedTechnicians) {
      setTechnicians(JSON.parse(storedTechnicians));
    } else {
      setTechnicians(INITIAL_TECHNICIANS);
      localStorage.setItem('oficina_technicians', JSON.stringify(INITIAL_TECHNICIANS));
    }

    if (storedInventory) {
      setInventory(JSON.parse(storedInventory));
    } else {
      setInventory(INITIAL_INVENTORY);
      localStorage.setItem('oficina_inventory', JSON.stringify(INITIAL_INVENTORY));
    }

    if (storedQuotes) {
      setQuotes(JSON.parse(storedQuotes));
    } else {
      setQuotes(INITIAL_QUOTES);
      localStorage.setItem('oficina_quotes', JSON.stringify(INITIAL_QUOTES));
    }

    if (storedPostMaint) {
      setPostMaintenanceFeedbacks(JSON.parse(storedPostMaint));
    } else {
      setPostMaintenanceFeedbacks(INITIAL_POST_MAINTENANCE_FEEDBACKS);
      localStorage.setItem('oficina_post_maintenance', JSON.stringify(INITIAL_POST_MAINTENANCE_FEEDBACKS));
    }

    if (storedCatalogs) {
      setCatalogs(JSON.parse(storedCatalogs));
    } else {
      setCatalogs(INITIAL_EQUIPMENT_CATALOGS);
      localStorage.setItem('oficina_catalogs', JSON.stringify(INITIAL_EQUIPMENT_CATALOGS));
    }

    const storedReceivers = localStorage.getItem('oficina_receivers');
    if (storedReceivers) {
      try {
        const parsed = JSON.parse(storedReceivers);
        const cleaned = cleanReceiversList(parsed);
        setReceivers(cleaned);
        localStorage.setItem('oficina_receivers', JSON.stringify(cleaned));
      } catch (e) {
        setReceivers(DEFAULT_RECEIVERS);
        localStorage.setItem('oficina_receivers', JSON.stringify(DEFAULT_RECEIVERS));
      }
    } else {
      setReceivers(DEFAULT_RECEIVERS);
      localStorage.setItem('oficina_receivers', JSON.stringify(DEFAULT_RECEIVERS));
    }

    // Immediately pull latest server database on mount to sync all devices!
    pullLatestFromServer(false);
  }, []);

  // Sync clock seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Teclas de Atalho Globais:
  // F2 (ou Alt+C): Novo Cliente
  // F3 (ou Alt+S): Novo Serviço
  // F4 (ou Alt+E): Novo Equipamento
  // F7 (ou Alt+P): Tabela de Preços
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F2' || (e.altKey && (e.key === 'c' || e.key === 'C'))) {
        e.preventDefault();
        setIsQuickClientModalOpen(true);
      } else if (e.key === 'F3' || (e.altKey && (e.key === 's' || e.key === 'S'))) {
        e.preventDefault();
        setIsQuickServiceModalOpen(true);
      } else if (e.key === 'F4' || (e.altKey && (e.key === 'e' || e.key === 'E'))) {
        e.preventDefault();
        setIsQuickEquipmentModalOpen(true);
      } else if (e.key === 'F7' || (e.altKey && (e.key === 'p' || e.key === 'P'))) {
        e.preventDefault();
        setIsPriceTableModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, []);

  // Sync states for multi-device / multi-account
  const [syncStatus, setSyncStatus] = useState<'IDLE' | 'SYNCING' | 'SUCCESS' | 'ERROR'>('IDLE');
  const [syncMessage, setSyncMessage] = useState<string>('');
  const [showCloudSyncModal, setShowCloudSyncModal] = useState<boolean>(false);
  const [lastServerSyncTimestamp, setLastServerSyncTimestamp] = useState<string>('');
  const [serverStats, setServerStats] = useState<{ clients?: number; orders?: number; equipments?: number; history?: number; inventory?: number } | null>(null);
  const [isInitialServerLoaded, setIsInitialServerLoaded] = useState<boolean>(false);

  // Global Toast for System Events (such as OS closing / completion)
  const [globalToast, setGlobalToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showGlobalToast = (message: string, type: 'success' | 'info' | 'error' = 'success', duration = 5000) => {
    setGlobalToast({ message, type });
    setTimeout(() => {
      setGlobalToast((curr) => (curr?.message === message ? null : curr));
    }, duration);
  };

  // Pull latest data from cloud server
  const pullLatestFromServer = async (showFeedback = false) => {
    try {
      if (showFeedback) setSyncStatus('SYNCING');
      const res = await fetch(`/api/sync?t=${Date.now()}`, {
        headers: { 'Cache-Control': 'no-cache' }
      });
      if (!res.ok) throw new Error('Falha ao consultar servidor central.');
      const resData = await res.json();
      if (resData && resData.initialized && resData.data) {
        const d = resData.data;
        if (Array.isArray(d.clients) && d.clients.length > 0) {
          setClients(d.clients);
          localStorage.setItem('oficina_clients', JSON.stringify(d.clients));
        }
        if (Array.isArray(d.equipments) && d.equipments.length > 0) {
          setEquipments(d.equipments);
          localStorage.setItem('oficina_equipments', JSON.stringify(d.equipments));
        }
        if (Array.isArray(d.orders) && d.orders.length > 0) {
          setOrders(d.orders);
          localStorage.setItem('oficina_orders', JSON.stringify(d.orders));
        }
        if (Array.isArray(d.history)) {
          setHistory(d.history);
          localStorage.setItem('oficina_history', JSON.stringify(d.history));
        }
        if (Array.isArray(d.transactions)) {
          setTransactions(d.transactions);
          localStorage.setItem('oficina_financials', JSON.stringify(d.transactions));
        }
        if (Array.isArray(d.diagnostics)) {
          setDiagnostics(d.diagnostics);
          localStorage.setItem('oficina_diagnostics', JSON.stringify(d.diagnostics));
        }
        if (Array.isArray(d.services)) {
          setServices(d.services);
          localStorage.setItem('oficina_services', JSON.stringify(d.services));
        }
        if (Array.isArray(d.technicians)) {
          setTechnicians(d.technicians);
          localStorage.setItem('oficina_technicians', JSON.stringify(d.technicians));
        }
        if (Array.isArray(d.inventory)) {
          setInventory(d.inventory);
          localStorage.setItem('oficina_inventory', JSON.stringify(d.inventory));
        }
        if (Array.isArray(d.quotes)) {
          setQuotes(d.quotes);
          localStorage.setItem('oficina_quotes', JSON.stringify(d.quotes));
        }
        if (Array.isArray(d.postMaintenance)) {
          setPostMaintenanceFeedbacks(d.postMaintenance);
          localStorage.setItem('oficina_post_maintenance', JSON.stringify(d.postMaintenance));
        }
        if (Array.isArray(d.catalogs)) {
          setCatalogs(d.catalogs);
          localStorage.setItem('oficina_catalogs', JSON.stringify(d.catalogs));
        }
        if (Array.isArray(d.clientActivities) && d.clientActivities.length > 0) {
          localStorage.setItem('oficina_client_activities', JSON.stringify(d.clientActivities));
        }
        if (Array.isArray(d.receivers) && d.receivers.length > 0) {
          const serverList = cleanReceiversList(d.receivers);
          setReceivers((prev) => {
            const merged = Array.from(new Set([...prev, ...serverList]));
            const isSame = prev.length === merged.length && prev.every((v, i) => v === merged[i]);
            if (isSame) return prev;
            localStorage.setItem('oficina_receivers', JSON.stringify(merged));
            return merged;
          });
        }

        if (resData.stats) {
          setServerStats(resData.stats);
        }
        setLastServerSyncTimestamp(new Date().toLocaleTimeString('pt-BR'));
        setIsInitialServerLoaded(true);

        if (showFeedback) {
          setSyncStatus('SUCCESS');
          setSyncMessage('Nuvem Sincronizada!');
          setTimeout(() => setSyncStatus('IDLE'), 3000);
        }
      }
    } catch (err) {
      console.warn('Sync poll check:', err);
      if (showFeedback) {
        setSyncStatus('ERROR');
        setSyncMessage('Erro de conexão');
        setTimeout(() => setSyncStatus('IDLE'), 4000);
      }
    }
  };

  // Push updates to cloud server with smart merging
  const triggerServerSync = async (forceData?: {
    clients?: Client[];
    equipments?: Equipment[];
    orders?: ServiceOrder[];
    history?: MaintenanceHistoryEntry[];
    transactions?: FinancialTransaction[];
    diagnostics?: TechnicalDiagnostic[];
    services?: PlannedService[];
    technicians?: Technician[];
    inventory?: InventoryItem[];
    quotes?: Quote[];
    postMaintenance?: PostMaintenanceFeedback[];
    catalogs?: EquipmentCatalog[];
    receivers?: string[];
    clientActivities?: string[];
  }, mode: 'merge' | 'replace' = 'merge') => {
    setSyncStatus('SYNCING');
    try {
      const currentClients = forceData?.clients || (clients.length > 0 ? clients : JSON.parse(localStorage.getItem('oficina_clients') || '[]'));
      const currentEquipments = forceData?.equipments || (equipments.length > 0 ? equipments : JSON.parse(localStorage.getItem('oficina_equipments') || '[]'));
      const currentOrders = forceData?.orders || (orders.length > 0 ? orders : JSON.parse(localStorage.getItem('oficina_orders') || '[]'));
      const currentHistory = forceData?.history || (history.length > 0 ? history : JSON.parse(localStorage.getItem('oficina_history') || '[]'));
      const currentFinancials = forceData?.transactions || (transactions.length > 0 ? transactions : JSON.parse(localStorage.getItem('oficina_financials') || '[]'));
      const currentDiagnostics = forceData?.diagnostics || (diagnostics.length > 0 ? diagnostics : JSON.parse(localStorage.getItem('oficina_diagnostics') || '[]'));
      const currentServices = forceData?.services || (services.length > 0 ? services : JSON.parse(localStorage.getItem('oficina_services') || '[]'));
      const currentTechnicians = forceData?.technicians || (technicians.length > 0 ? technicians : JSON.parse(localStorage.getItem('oficina_technicians') || '[]'));
      const currentInventory = forceData?.inventory || (inventory.length > 0 ? inventory : JSON.parse(localStorage.getItem('oficina_inventory') || '[]'));
      const currentQuotes = forceData?.quotes || (quotes.length > 0 ? quotes : JSON.parse(localStorage.getItem('oficina_quotes') || '[]'));
      const currentPostMaint = forceData?.postMaintenance || (postMaintenanceFeedbacks.length > 0 ? postMaintenanceFeedbacks : JSON.parse(localStorage.getItem('oficina_post_maintenance') || '[]'));
      const currentCatalogs = forceData?.catalogs || (catalogs.length > 0 ? catalogs : JSON.parse(localStorage.getItem('oficina_catalogs') || '[]'));
      
      const clientActivities = forceData?.clientActivities || JSON.parse(localStorage.getItem('oficina_client_activities') || '[]');
      const currentReceivers = forceData?.receivers || (receivers.length > 0 ? receivers : JSON.parse(localStorage.getItem('oficina_receivers') || '[]'));

      // When forceData is provided, send only the targeted collections to prevent stale overwrite of other tables
      let payload: any;
      if (forceData && mode === 'merge') {
        payload = {
          mode,
          ...(forceData.clients !== undefined && { clients: forceData.clients }),
          ...(forceData.equipments !== undefined && { equipments: forceData.equipments }),
          ...(forceData.orders !== undefined && { orders: forceData.orders }),
          ...(forceData.history !== undefined && { history: forceData.history }),
          ...(forceData.transactions !== undefined && { transactions: forceData.transactions }),
          ...(forceData.diagnostics !== undefined && { diagnostics: forceData.diagnostics }),
          ...(forceData.services !== undefined && { services: forceData.services }),
          ...(forceData.technicians !== undefined && { technicians: forceData.technicians }),
          ...(forceData.inventory !== undefined && { inventory: forceData.inventory }),
          ...(forceData.quotes !== undefined && { quotes: forceData.quotes }),
          ...(forceData.postMaintenance !== undefined && { postMaintenance: forceData.postMaintenance }),
          ...(forceData.catalogs !== undefined && { catalogs: forceData.catalogs }),
          ...(forceData.receivers !== undefined && { receivers: forceData.receivers }),
          ...(forceData.clientActivities !== undefined && { clientActivities: forceData.clientActivities }),
        };
      } else {
        payload = {
          mode,
          clients: currentClients,
          equipments: currentEquipments,
          orders: currentOrders,
          history: currentHistory,
          transactions: currentFinancials,
          diagnostics: currentDiagnostics,
          services: currentServices,
          technicians: currentTechnicians,
          inventory: currentInventory,
          quotes: currentQuotes,
          postMaintenance: currentPostMaint,
          catalogs: currentCatalogs,
          clientActivities,
          receivers: currentReceivers
        };
      }

      const res = await fetch('/api/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        throw new Error('Falha ao conectar com o servidor.');
      }

      const result = await res.json();
      if (result.success && result.data) {
        const d = result.data;
        if (d.clients) {
          setClients(d.clients);
          localStorage.setItem('oficina_clients', JSON.stringify(d.clients));
        }
        if (d.equipments) {
          setEquipments(d.equipments);
          localStorage.setItem('oficina_equipments', JSON.stringify(d.equipments));
        }
        if (d.orders) {
          setOrders(d.orders);
          localStorage.setItem('oficina_orders', JSON.stringify(d.orders));
        }
        if (d.history) {
          setHistory(d.history);
          localStorage.setItem('oficina_history', JSON.stringify(d.history));
        }
        if (d.transactions) {
          setTransactions(d.transactions);
          localStorage.setItem('oficina_financials', JSON.stringify(d.transactions));
        }
        if (d.diagnostics) {
          setDiagnostics(d.diagnostics);
          localStorage.setItem('oficina_diagnostics', JSON.stringify(d.diagnostics));
        }
        if (d.services) {
          setServices(d.services);
          localStorage.setItem('oficina_services', JSON.stringify(d.services));
        }
        if (d.technicians) {
          setTechnicians(d.technicians);
          localStorage.setItem('oficina_technicians', JSON.stringify(d.technicians));
        }
        if (d.inventory) {
          setInventory(d.inventory);
          localStorage.setItem('oficina_inventory', JSON.stringify(d.inventory));
        }
        if (d.quotes) {
          setQuotes(d.quotes);
          localStorage.setItem('oficina_quotes', JSON.stringify(d.quotes));
        }
        if (d.postMaintenance) {
          setPostMaintenanceFeedbacks(d.postMaintenance);
          localStorage.setItem('oficina_post_maintenance', JSON.stringify(d.postMaintenance));
        }
        if (d.receivers && Array.isArray(d.receivers) && d.receivers.length > 0) {
          const serverList = cleanReceiversList(d.receivers);
          setReceivers((prev) => {
            const merged = Array.from(new Set([...prev, ...serverList]));
            const isSame = prev.length === merged.length && prev.every((v, i) => v === merged[i]);
            if (isSame) return prev;
            localStorage.setItem('oficina_receivers', JSON.stringify(merged));
            return merged;
          });
        }
        setSyncStatus('SUCCESS');
        setSyncMessage('Nuvem Sincronizada!');
        setLastServerSyncTimestamp(new Date().toLocaleTimeString('pt-BR'));
        setTimeout(() => setSyncStatus('IDLE'), 3000);
      } else {
        throw new Error(result.message || 'Erro de sincronização.');
      }
    } catch (err: any) {
      console.error('Sync error:', err);
      setSyncStatus('ERROR');
      setSyncMessage('Erro de rede');
      setTimeout(() => setSyncStatus('IDLE'), 5000);
    }
  };

  // Auto-sync effect: runs on mount and every 6 seconds across all devices/accounts
  useEffect(() => {
    const interval = setInterval(() => {
      pullLatestFromServer(false);
    }, 6000);

    return () => {
      clearInterval(interval);
    };
  }, []);

  // Handlers for JSON Backup Download & Restore
  const handleDownloadBackup = () => {
    window.location.href = '/api/sync/backup';
  };

  const handleRestoreBackupFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          const content = event.target?.result as string;
          const parsed = JSON.parse(content);
          const res = await fetch('/api/sync/restore', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(parsed)
          });
          const result = await res.json();
          if (result.success) {
            await pullLatestFromServer(true);
            alert('Backup restaurado com sucesso no servidor central!');
          } else {
            alert('Erro ao restaurar backup: ' + (result.message || 'Falha no processamento.'));
          }
        } catch (err) {
          alert('Arquivo de backup inválido. Certifique-se de que é um arquivo JSON válido.');
        }
      };
      reader.readAsText(file);
    } catch (err) {
      console.error('Erro ao ler arquivo de backup:', err);
    }
  };

  // Persistent Setters helper functions
  const saveClients = (newClients: Client[]) => {
    setClients(newClients);
    localStorage.setItem('oficina_clients', JSON.stringify(newClients));
    triggerServerSync({ clients: newClients });
  };

  const saveEquipments = (newEquipments: Equipment[]) => {
    setEquipments(newEquipments);
    localStorage.setItem('oficina_equipments', JSON.stringify(newEquipments));
    triggerServerSync({ equipments: newEquipments });
  };

  const saveOrders = (newOrders: ServiceOrder[]) => {
    setOrders(newOrders);
    localStorage.setItem('oficina_orders', JSON.stringify(newOrders));
    triggerServerSync({ orders: newOrders });
  };

  const saveHistory = (newHistory: MaintenanceHistoryEntry[]) => {
    setHistory(newHistory);
    localStorage.setItem('oficina_history', JSON.stringify(newHistory));
    triggerServerSync({ history: newHistory });
  };

  const saveTransactions = (newTransactions: FinancialTransaction[]) => {
    setTransactions(newTransactions);
    localStorage.setItem('oficina_financials', JSON.stringify(newTransactions));
    triggerServerSync({ transactions: newTransactions });
  };

  const saveDiagnostics = (newDiagnostics: TechnicalDiagnostic[]) => {
    setDiagnostics(newDiagnostics);
    localStorage.setItem('oficina_diagnostics', JSON.stringify(newDiagnostics));
    triggerServerSync({ diagnostics: newDiagnostics });
  };

  const saveServices = (newServices: PlannedService[]) => {
    setServices(newServices);
    localStorage.setItem('oficina_services', JSON.stringify(newServices));
    triggerServerSync({ services: newServices });
  };

  const saveTechnicians = (newTechnicians: Technician[]) => {
    setTechnicians(newTechnicians);
    localStorage.setItem('oficina_technicians', JSON.stringify(newTechnicians));
    triggerServerSync({ technicians: newTechnicians });
  };

  const saveReceivers = (newReceivers: string[]) => {
    const cleaned = cleanReceiversList(newReceivers);
    setReceivers(cleaned);
    localStorage.setItem('oficina_receivers', JSON.stringify(cleaned));
    
    // Save to dedicated server endpoint immediately
    try {
      fetch('/api/receivers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receivers: cleaned })
      }).catch(err => console.warn('Receivers endpoint sync notice:', err));
    } catch (e) {
      console.warn('Receivers endpoint sync error:', e);
    }

    triggerServerSync({ receivers: cleaned });
  };

  const saveInventory = (newInventory: InventoryItem[]) => {
    setInventory(newInventory);
    localStorage.setItem('oficina_inventory', JSON.stringify(newInventory));
    triggerServerSync({ inventory: newInventory });
  };

  const saveQuotes = (newQuotes: Quote[]) => {
    setQuotes(newQuotes);
    localStorage.setItem('oficina_quotes', JSON.stringify(newQuotes));
    triggerServerSync({ quotes: newQuotes });
  };

  const savePostMaintenanceFeedbacks = (newFeedbacks: PostMaintenanceFeedback[]) => {
    setPostMaintenanceFeedbacks(newFeedbacks);
    localStorage.setItem('oficina_post_maintenance', JSON.stringify(newFeedbacks));
    triggerServerSync({ postMaintenance: newFeedbacks });
  };

  const saveCatalogs = (newCatalogs: EquipmentCatalog[]) => {
    setCatalogs(newCatalogs);
    localStorage.setItem('oficina_catalogs', JSON.stringify(newCatalogs));
    triggerServerSync({ catalogs: newCatalogs });
  };

  const handleSaveCatalog = (catalog: EquipmentCatalog) => {
    const exists = catalogs.some(c => c.id === catalog.id);
    const updated = exists 
      ? catalogs.map(c => c.id === catalog.id ? { ...catalog, updatedAt: new Date().toISOString() } : c)
      : [{ ...catalog, updatedAt: new Date().toISOString() }, ...catalogs];
    saveCatalogs(updated);
  };

  const handleDeleteCatalog = (catalogId: string) => {
    const updated = catalogs.filter(c => c.id !== catalogId);
    saveCatalogs(updated);
  };

  const handleOpenCatalogForEquipment = (equipmentId: string) => {
    setCatalogEquipmentFilter(equipmentId);
    setActiveTab('CATALOGS');
  };

  // POST MAINTENANCE CRUD HANDLERS
  const handleAddPostMaintenanceFeedback = (fbData: Omit<PostMaintenanceFeedback, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newFb: PostMaintenanceFeedback = {
      ...fbData,
      id: `pmf-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    savePostMaintenanceFeedbacks([...postMaintenanceFeedbacks, newFb]);
  };

  const handleUpdatePostMaintenanceFeedback = (updatedFb: PostMaintenanceFeedback) => {
    savePostMaintenanceFeedbacks(postMaintenanceFeedbacks.map(f => f.id === updatedFb.id ? updatedFb : f));
  };

  const handleDeletePostMaintenanceFeedback = (id: string) => {
    savePostMaintenanceFeedbacks(postMaintenanceFeedbacks.filter(f => f.id !== id));
  };

  // QUOTE CRUD HANDLERS
  const handleAddQuote = (newQuote: Quote) => {
    saveQuotes([...quotes, newQuote]);
  };

  const handleUpdateQuote = (updatedQuote: Quote) => {
    saveQuotes(quotes.map(q => q.id === updatedQuote.id ? updatedQuote : q));
  };

  const handleDeleteQuote = (id: string) => {
    saveQuotes(quotes.filter(q => q.id !== id));
  };

  // TECHNICIAN CRUD HANDLERS
  const handleAddTechnician = (techData: Omit<Technician, 'id' | 'createdAt'>) => {
    const newTech: Technician = {
      ...techData,
      id: `tech-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    saveTechnicians([...technicians, newTech]);
  };

  const handleEditTechnician = (updatedTech: Technician) => {
    saveTechnicians(technicians.map(t => t.id === updatedTech.id ? updatedTech : t));
  };

  const handleDeleteTechnician = (id: string) => {
    saveTechnicians(technicians.filter(t => t.id !== id));
  };

  // INVENTORY CRUD HANDLERS
  const handleAddInventoryItem = (itemData: Omit<InventoryItem, 'id' | 'createdAt'>) => {
    const newItem: InventoryItem = {
      ...itemData,
      id: `inv-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    saveInventory([...inventory, newItem]);
  };

  const handleAddInventoryItems = (itemsData: Omit<InventoryItem, 'id' | 'createdAt'>[]) => {
    const newItems: InventoryItem[] = itemsData.map((item, index) => ({
      ...item,
      id: `inv-${Date.now()}-${index}`,
      createdAt: new Date().toISOString()
    }));
    saveInventory([...inventory, ...newItems]);
  };

  const handleEditInventoryItem = (updatedItem: InventoryItem) => {
    saveInventory(inventory.map(i => i.id === updatedItem.id ? updatedItem : i));
  };

  const handleDeleteInventoryItem = (id: string) => {
    saveInventory(inventory.filter(i => i.id !== id));
  };

  // DIAGNOSTIC CRUD HANDLERS
  const handleAddDiagnostic = (diagData: Omit<TechnicalDiagnostic, 'id' | 'createdAt'>) => {
    const newDiag: TechnicalDiagnostic = {
      ...diagData,
      id: `diag-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setDiagnostics((prev) => {
      const updated = [...prev, newDiag];
      localStorage.setItem('oficina_diagnostics', JSON.stringify(updated));
      return updated;
    });
  };

  const handleEditDiagnostic = (updatedDiag: TechnicalDiagnostic) => {
    setDiagnostics((prev) => {
      const updated = prev.map(d => d.id === updatedDiag.id ? updatedDiag : d);
      localStorage.setItem('oficina_diagnostics', JSON.stringify(updated));
      return updated;
    });
  };

  const handleDeleteDiagnostic = (id: string) => {
    setDiagnostics((prev) => {
      const updated = prev.filter(d => d.id !== id);
      localStorage.setItem('oficina_diagnostics', JSON.stringify(updated));
      return updated;
    });
  };

  // SERVICE CRUD HANDLERS
  const handleAddService = (serviceData: Omit<PlannedService, 'id' | 'createdAt'>): PlannedService => {
    const newService: PlannedService = {
      ...serviceData,
      id: `serv-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    saveServices([...services, newService]);
    return newService;
  };

  const handleEditService = (updatedService: PlannedService) => {
    saveServices(services.map(s => s.id === updatedService.id ? updatedService : s));
  };

  const handleDeleteService = (id: string) => {
    saveServices(services.filter(s => s.id !== id));
  };

  // CLIENT CRUD HANDLERS
  const handleAddClient = (clientData: Omit<Client, 'id' | 'createdAt'>): Client => {
    const newClient: Client = {
      activity: 'PARTICULAR',
      ...clientData,
      id: `cli-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    saveClients([...clients, newClient]);
    return newClient;
  };

  const handleEditClient = (updatedClient: Client) => {
    saveClients(clients.map((c) => (c.id === updatedClient.id ? updatedClient : c)));
  };

  const handleDeleteClient = (id: string) => {
    saveClients(clients.filter((c) => c.id !== id));
    // Cascade NULL client or delete associated? Let's keep associated equipments but warn in the UI
  };

  // EQUIPMENT CRUD HANDLERS
  const handleAddEquipment = (equipData: Omit<Equipment, 'id' | 'createdAt'>): Equipment => {
    const newEquip: Equipment = {
      ...equipData,
      id: `eq-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    saveEquipments([...equipments, newEquip]);
    return newEquip;
  };

  const handleEditEquipment = (updatedEquip: Equipment) => {
    saveEquipments(equipments.map((e) => (e.id === updatedEquip.id ? updatedEquip : e)));
  };

  const handleDeleteEquipment = (id: string) => {
    saveEquipments(equipments.filter((e) => e.id !== id));
    // Remove associated maintenance history
    saveHistory(history.filter((h) => h.equipmentId !== id));
  };

  // SERVICE ORDER CRUD HANDLERS
  const handleAddOrder = (orderData: Omit<ServiceOrder, 'id' | 'osNumber' | 'createdAt'>): ServiceOrder => {
    const existingNums = orders.map((o) => {
      if (!o || !o.osNumber) return 0;
      const digits = o.osNumber.replace(/\D/g, '');
      const parsed = parseInt(digits, 10);
      return isNaN(parsed) ? 0 : parsed;
    });

    const maxNum = existingNums.length > 0 ? Math.max(1000, ...existingNums) : 1000;
    const nextOSNum = `OS-${maxNum + 1}`;
    const now = new Date().toISOString();

    const newOrder: ServiceOrder = {
      ...orderData,
      id: `os-${Date.now()}`,
      osNumber: nextOSNum,
      createdAt: now,
      updatedAt: now,
    };
    saveOrders([...orders, newOrder]);
    showGlobalToast('✅ Equipamento recebido, registrado com sucesso no sistema da JC&F e encaminhado para avaliação técnica.', 'success', 7000);
    return newOrder;
  };

  const handleEditOrder = (updatedOrder: ServiceOrder) => {
    const stampedOrder: ServiceOrder = {
      ...updatedOrder,
      updatedAt: new Date().toISOString()
    };

    // Detect when an OS is closed / completed and emit confirmation message
    const prev = orders.find((o) => o.id === updatedOrder.id);
    const wasClosed = prev ? (prev.status === 'COMPLETED' || Boolean(prev.isDelivered)) : false;
    const isNowClosed = updatedOrder.status === 'COMPLETED' || Boolean(updatedOrder.isDelivered);

    if (!wasClosed && isNowClosed) {
      showGlobalToast('Ordem de Serviço Concluída e fechada!', 'success');
    }

    saveOrders(orders.map((o) => (o.id === stampedOrder.id ? stampedOrder : o)));
  };

  const handleDeleteOrder = (idOrNumber: string) => {
    if (!idOrNumber) return;
    const target = idOrNumber.trim().toLowerCase();
    const targetClean = target.replace(/^os-?/i, '');

    const remaining = orders.filter((o) => {
      const oId = (o.id || '').trim().toLowerCase();
      const oNum = (o.osNumber || '').trim().toLowerCase();
      const oNumClean = oNum.replace(/^os-?/i, '');

      if (oId === target) return false;
      if (oNum === target) return false;
      if (targetClean.length > 0 && oNumClean === targetClean) return false;

      return true;
    });

    setOrders(remaining);
    localStorage.setItem('oficina_orders', JSON.stringify(remaining));
    triggerServerSync({ orders: remaining }, 'replace');
  };

  // FINANCIAL TRANSACTION CRUD HANDLERS
  const handleAddTransaction = (txData: Omit<FinancialTransaction, 'id' | 'createdAt'>) => {
    // If associated with a service order, check if a transaction for this service order already exists to prevent duplicates
    if (txData.serviceOrderId) {
      const existingOSIndex = transactions.findIndex(t => t.serviceOrderId === txData.serviceOrderId);
      if (existingOSIndex !== -1) {
        const updatedList = [...transactions];
        updatedList[existingOSIndex] = {
          ...updatedList[existingOSIndex],
          amount: txData.amount || updatedList[existingOSIndex].amount,
          description: txData.description || updatedList[existingOSIndex].description,
          dueDate: txData.dueDate || updatedList[existingOSIndex].dueDate,
          notes: txData.notes || updatedList[existingOSIndex].notes,
        };
        saveTransactions(updatedList);
        return;
      }
    }

    const newTx: FinancialTransaction = {
      ...txData,
      id: `fin-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString()
    };
    saveTransactions([...transactions, newTx]);
  };

  const handleEditTransaction = (updatedTx: FinancialTransaction) => {
    saveTransactions(transactions.map((t) => (t.id === updatedTx.id ? updatedTx : t)));
  };

  const handleDeleteTransaction = (id: string) => {
    saveTransactions(transactions.filter((t) => t.id !== id));
  };

  // MAINTENANCE HISTORY CRUD HANDLERS
  const handleAddHistoryEntry = (historyData: Omit<MaintenanceHistoryEntry, 'id' | 'createdAt'>) => {
    const newEntry: MaintenanceHistoryEntry = {
      ...historyData,
      id: `hist-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    saveHistory([...history, newEntry]);
  };

  const handleDeleteHistoryEntry = (id: string) => {
    saveHistory(history.filter((h) => h.id !== id));
  };

  // AUTOMATIC INTEGRATION: CREATE EQUIPMENT LOG ENTRY ON OS COMPLETION
  const handleAutoAddHistoryFromOS = (completedOS: ServiceOrder) => {
    // Check if entry already registered to avoid duplication
    const alreadyExists = history.some(h => h.serviceOrderId === completedOS.id);
    if (alreadyExists) return;

    const equip = equipments.find(e => e.id === completedOS.equipmentId);
    if (!equip) return;

    const newHistoryEntry: MaintenanceHistoryEntry = {
      id: `hist-auto-${Date.now()}`,
      equipmentId: completedOS.equipmentId,
      serviceOrderId: completedOS.id,
      date: completedOS.endDate || new Date().toISOString().split('T')[0],
      serviceType: completedOS.title + ' - ' + completedOS.description,
      partsUsed: 'Verificado no diagnóstico da OS',
      technician: completedOS.technician,
      createdAt: new Date().toISOString(),
    };

    saveHistory([...history, newHistoryEntry]);
  };

  // Check-In Only Fullscreen Layout
  if (isCheckInOnly) {
    return (
      <div className="min-h-screen bg-[#eef2f6] text-slate-800 font-sans p-4 sm:p-6 md:p-10 flex flex-col items-center justify-center selection:bg-cyan-500 selection:text-white relative">
        {/* Global System Feedback Toast */}
        {globalToast && (
          <div 
            id="global-system-toast-checkin"
            className="fixed top-5 left-1/2 -translate-x-1/2 z-[9999] px-6 py-3.5 rounded-2xl shadow-2xl font-black text-xs sm:text-sm flex items-center gap-3 border bg-emerald-600 text-white border-emerald-400 shadow-emerald-950/50 ring-4 ring-emerald-500/25 animate-in fade-in slide-in-from-top-4 duration-200 text-center"
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-white" />
            <span className="tracking-wide">{globalToast.message}</span>
          </div>
        )}

        {/* Background Image Layer of Industrial Equipment for Check-In */}
        <div 
          className="absolute inset-0 z-0 opacity-[0.08] mix-blend-multiply pointer-events-none bg-cover bg-center bg-no-repeat" 
          style={{ backgroundImage: `url('/src/assets/images/industrial_equipment_bg_1783953137970.jpg')` }}
        />
        <div className="w-full max-w-4xl bg-[#0c0d14]/95 backdrop-blur-md rounded-2xl border border-slate-800/90 shadow-[0_15px_40px_rgba(0,0,0,0.4)] overflow-hidden relative z-10" id="checkin-panel">
          {/* Top caution striped bar accent */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-[repeating-linear-gradient(45deg,#eab308,#eab308_8px,#0f172a_8px,#0f172a_16px)]"></div>
          
          {/* Header */}
          <div className="p-6 border-b border-slate-800/80 bg-slate-950/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-1 relative">
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-[#151824] rounded-xl border border-slate-800 shadow-[0_0_20px_rgba(6,182,212,0.15)] flex items-center justify-center shrink-0">
                <JCFLogoIcon />
              </div>
              <div>
                <h1 className="font-black text-sm tracking-widest text-white uppercase leading-none">JC&F</h1>
                <p className="text-[10px] text-cyan-400 font-bold uppercase tracking-widest mt-1">CHECK-IN & ORDEM DE SERVIÇO</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2 flex-wrap">
              {/* Local network / Central Server Instant Sync Button */}
              <button
                type="button"
                onClick={() => triggerServerSync()}
                disabled={syncStatus === 'SYNCING'}
                className={`flex items-center gap-1.5 font-bold text-[10px] uppercase tracking-wider px-3.5 py-2 rounded-lg border transition-all duration-300 cursor-pointer shadow-md ${
                  syncStatus === 'SYNCING'
                    ? 'bg-amber-600/30 border-amber-500/50 text-amber-300'
                    : syncStatus === 'SUCCESS'
                    ? 'bg-emerald-600/30 border-emerald-500/50 text-emerald-300'
                    : syncStatus === 'ERROR'
                    ? 'bg-rose-600/30 border-rose-500/50 text-rose-300 animate-bounce'
                    : 'bg-cyan-950/40 border-cyan-500/30 text-cyan-300 hover:bg-cyan-900/60'
                }`}
              >
                {syncStatus === 'SYNCING' ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                ) : syncStatus === 'SUCCESS' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                ) : syncStatus === 'ERROR' ? (
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                ) : (
                  <RefreshCw className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                )}
                <span>
                  {syncStatus === 'SYNCING'
                    ? 'Sincronizando...'
                    : syncStatus === 'SUCCESS'
                    ? 'Sincronizado!'
                    : syncStatus === 'ERROR'
                    ? 'Erro de Conexão'
                    : 'Sincronizar Dados'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setShowCloudSyncModal(true)}
                className="flex items-center gap-1.5 bg-[#0284c7]/30 hover:bg-[#0284c7]/50 text-cyan-200 font-bold text-[10px] uppercase tracking-wider px-3 py-2 rounded-lg border border-cyan-500/40 transition-all duration-300 cursor-pointer shadow-md"
              >
                <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                <span>Nuvem & Contas</span>
              </button>

              <button
                type="button"
                onClick={() => setShowCheckInSyncModal(true)}
                className="flex items-center gap-1.5 bg-[#151824] hover:bg-[#1a1e2d] text-slate-300 font-bold text-[10px] uppercase tracking-wider px-3 py-2 rounded-lg border border-slate-800 transition-all duration-300 cursor-pointer shadow-md"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>Nuvem / Sheets</span>
              </button>

              <div className="flex items-center gap-2 text-slate-400 font-mono text-[10px] bg-slate-900/60 px-3 py-2 rounded-lg border border-slate-800/80">
                <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0 animate-pulse" />
                <span className="font-semibold tracking-wider text-cyan-300">
                  {currentTime.toLocaleTimeString('pt-BR', { hour12: false })}
                </span>
                <span className="text-slate-600">|</span>
                <span className="font-semibold">{currentTime.toLocaleDateString('pt-BR')}</span>
              </div>
            </div>
          </div>

          {/* Form Content */}
          <div className="p-6 md:p-8">
            <MobileOrderCreator
              clients={clients}
              equipments={equipments}
              orders={orders}
              technicians={technicians}
              diagnostics={diagnostics}
              onAddClient={handleAddClient}
              onAddEquipment={handleAddEquipment}
              onAddOrder={handleAddOrder}
              onEditOrder={handleEditOrder}
            />
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-slate-800/50 bg-slate-950/30 text-center text-[10px] text-slate-500 font-mono">
            JC&F SISTEMAS HIDRÁULICOS E PNEUMÁTICOS • PORTAL DE CHECK-IN RÁPIDO DO CLIENTE
          </div>
        </div>

        {/* Google Sheets Sync Modal overlay for check-in terminal (mobile or second pc) */}
        {showCheckInSyncModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
            <div className="relative w-full max-w-2xl bg-[#0c0d14] rounded-2xl border border-slate-800 shadow-[0_0_50px_rgba(0,0,0,0.9)] p-6 space-y-6 animate-fade-in my-8 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-[#151824] rounded-xl border border-slate-800 text-cyan-400">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-sm font-black text-white uppercase tracking-wider">Sincronização de Dados</h2>
                    <p className="text-[10px] text-slate-400">Sincronize o Check-In com o computador principal e Google Sheets</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowCheckInSyncModal(false)}
                  className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg border border-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-4.5 h-4.5" />
                </button>
              </div>

              <div className="text-xs text-slate-300 leading-relaxed space-y-2 bg-slate-900/40 p-4 border border-slate-800/60 rounded-xl">
                <p className="font-bold text-cyan-400">Como Sincronizar o seu Celular para o Check-In:</p>
                <ol className="list-decimal pl-4 space-y-1 text-slate-400 font-medium">
                  <li>Clique no botão <span className="text-white font-bold">Fazer login com o Google</span> abaixo.</li>
                  <li>Use a mesma conta Google e selecione a <span className="text-white font-bold">mesma planilha</span> utilizada no computador do Desenvolvedor/Escritório.</li>
                  <li>Clique no botão <span className="text-amber-500 font-bold font-black">"IMPORTAR DA PLANILHA"</span> para trazer todos os Clientes, Peças e Equipamentos cadastrados para este celular.</li>
                  <li>Sempre que fizer novos check-ins de clientes ou equipamentos no celular, clique em <span className="text-emerald-500 font-bold font-black">"EXPORTAR PARA PLANILHA"</span> para enviar tudo de volta para a nuvem.</li>
                </ol>
              </div>

              <div className="border border-slate-800/80 rounded-xl overflow-hidden bg-[#07080c]/50">
                <GoogleSheetsSync
                  clients={clients}
                  equipments={equipments}
                  orders={orders}
                  transactions={transactions}
                  inventory={inventory}
                  onImportData={(imported) => {
                    if (imported.clients && imported.clients.length > 0) saveClients(imported.clients);
                    if (imported.equipments && imported.equipments.length > 0) saveEquipments(imported.equipments);
                    if (imported.orders && imported.orders.length > 0) saveOrders(imported.orders);
                    if (imported.transactions && imported.transactions.length > 0) saveTransactions(imported.transactions);
                    if (imported.inventory && imported.inventory.length > 0) saveInventory(imported.inventory);
                  }}
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowCheckInSyncModal(false)}
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-black uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Concluir e Voltar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Calculate some urgent items for Dashboard overview
  const urgentOrders = orders.filter(o => o.priority === 'HIGH' && (o.status === 'PENDING' || o.status === 'IN_PROGRESS'));

  // Lista de abas do sistema ordenadas rigorosamente em ORDEM ALFABÉTICA (A - Z)
  const navigationTabs = [
    { id: 'MOBILE_OS' as const, label: 'Ciclo da OS', shortLabel: 'Ciclo OS', icon: Clock, color: 'text-emerald-300' },
    { id: 'CLIENTS' as const, label: 'Clientes', shortLabel: 'Clientes', icon: Users, color: 'text-emerald-300' },
    { id: 'WARRANTY_CONTROL' as const, label: 'Controle de Garantia', shortLabel: 'Garantias', icon: ShieldCheck, color: 'text-amber-300' },
    { id: 'DIAGNOSTICS' as const, label: 'Diagnósticos', shortLabel: 'Diag.', icon: ClipboardList, color: 'text-cyan-300' },
    { id: 'ENTRY_REGISTRY' as const, label: 'Entrada / Check-In', shortLabel: 'Check-In', icon: FileText, color: 'text-cyan-300' },
    { id: 'EQUIPMENTS' as const, label: 'Equipamentos', shortLabel: 'Equipamentos', icon: Cpu, color: 'text-cyan-200' },
    { id: 'INVENTORY' as const, label: 'Estoque / Peças', shortLabel: 'Estoque', icon: Package, color: 'text-amber-300', badge: inventory.filter(i => i.quantity <= i.minimumStock).length },
    { id: 'FINANCE' as const, label: 'Financeiro', shortLabel: 'Finanças', icon: DollarSign, color: 'text-emerald-300' },
    { id: 'GOOGLE_SHEETS' as const, label: 'Google Sheets', shortLabel: 'Sheets', icon: FileSpreadsheet, color: 'text-emerald-300' },
    { id: 'TECHNICAL_REPORT' as const, label: 'Laudo Técnico', shortLabel: 'Laudos', icon: ShieldCheck, color: 'text-cyan-300' },
    { id: 'MANUAL' as const, label: 'Manual de Operação', shortLabel: 'Manual', icon: BookOpen, color: 'text-amber-300' },
    { id: 'QUOTES' as const, label: 'Orçamentos', shortLabel: 'Orçamentos', icon: FileSpreadsheet, color: 'text-cyan-300' },
    { id: 'OS' as const, label: 'Ordens (OS)', shortLabel: 'Ordens', icon: FileText, color: 'text-amber-300', badge: orders.filter(o => o.status === 'PENDING' || o.status === 'IN_PROGRESS').length },
    { id: 'DASHBOARD' as const, label: 'Painel Geral', shortLabel: 'Painel', icon: LayoutDashboard, color: 'text-cyan-300' },
    { id: 'POST_MAINTENANCE' as const, label: 'Pós-Manutenção', shortLabel: 'Pós-Manut.', icon: Award, color: 'text-emerald-400' },
    { id: 'REPORTS' as const, label: 'Relatórios', shortLabel: 'Relatórios', icon: BarChart3, color: 'text-cyan-300' },
    { id: 'SERVICES' as const, label: 'Tabela de Preços', shortLabel: 'Tab. Preços', icon: Briefcase, color: 'text-emerald-300' },
    { id: 'TECHNICIANS' as const, label: 'Técnicos', shortLabel: 'Técnicos', icon: UserCheck, color: 'text-cyan-300' },
    { id: 'CATALOGS' as const, label: 'Vistas Explodidas', shortLabel: 'Vistas Explodidas', icon: Layers, color: 'text-cyan-400', badge: catalogs.length },
  ];

  return (
    <div className="min-h-screen bg-[#d5dbe3] text-slate-800 flex flex-col md:flex-row font-sans selection:bg-cyan-500 selection:text-white relative" id="app-root-container">
      
      {/* Global System Feedback Toast (e.g. OS Fechada e Concluída ou OS Cadastrada) */}
      {globalToast && (
        <div 
          id="global-system-toast"
          className="fixed top-5 left-1/2 -translate-x-1/2 z-[9999] px-6 py-3.5 rounded-2xl shadow-2xl font-black text-xs sm:text-sm flex items-center gap-3 border bg-emerald-600 text-white border-emerald-400 shadow-emerald-950/50 ring-4 ring-emerald-500/25 animate-in fade-in slide-in-from-top-4 duration-200 text-center"
        >
          <CheckCircle className="w-5 h-5 shrink-0 text-white" />
          <span className="tracking-wide">{globalToast.message}</span>
        </div>
      )}

      {/* Background Image Layer of Industrial Equipment */}
      <div 
        className="fixed inset-0 z-0 opacity-[0.03] mix-blend-multiply pointer-events-none bg-cover bg-center bg-no-repeat" 
        style={{ backgroundImage: `url('/src/assets/images/industrial_equipment_bg_1783953137970.jpg')` }}
      />
      
      {/* Desktop Left Sidebar Panel - Royal Blue System Theme */}
      <aside className="hidden md:flex flex-col w-64 lg:w-72 bg-[#1b365d] backdrop-blur-md border-r-2 border-blue-950 h-screen sticky top-0 flex-shrink-0 justify-between select-none relative z-10 shadow-xl" id="desktop-sidebar-panel">
        
        {/* Upper Brand / Logo Section with Royal Blue Accent */}
        <div className="flex flex-col">
          <div className="p-5 border-b border-blue-900 bg-[#004a99] relative shadow-md">
            {/* Top caution striped bar accent */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-[repeating-linear-gradient(45deg,#eab308,#eab308_8px,#003b7a_8px,#003b7a_16px)]"></div>
            
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-[#1b365d] rounded-xl border border-blue-700 shadow-md flex items-center justify-center shrink-0">
                <JCFLogoIcon />
              </div>
              <div className="overflow-hidden">
                <h1 className="font-black text-xs lg:text-sm tracking-wider text-white uppercase leading-tight drop-shadow-xs">
                  JC&F
                </h1>
                <p className="text-[10px] text-cyan-200 font-extrabold uppercase tracking-widest leading-normal">
                  Sistemas Hidráulicos
                </p>
                <div className="flex items-center gap-1.5 mt-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span className="text-[9px] text-cyan-200 font-mono font-extrabold uppercase tracking-widest">SISTEMA ATIVO</span>
                </div>
              </div>
            </div>
          </div>

          {/* Teclas de Atalho Rápido (F2, F3, F4, F7) */}
          <div className="px-3 pt-3 pb-1 space-y-1.5">
            <button
              type="button"
              id="sidebar-btn-quick-new-client"
              onClick={() => setIsQuickClientModalOpen(true)}
              className="w-full flex items-center justify-between px-3 py-2 bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-slate-950 font-black text-xs rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer uppercase tracking-wider group"
              title="Cadastrar Novo Cliente (Tecla de Atalho F2)"
            >
              <div className="flex items-center gap-2">
                <UserPlus className="w-3.5 h-3.5 text-slate-950 shrink-0 group-hover:scale-110 transition-transform" />
                <span>Novo Cliente</span>
              </div>
              <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1.5 py-0.5 rounded border border-amber-600 shadow-2xs">
                F2
              </span>
            </button>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                id="sidebar-btn-quick-new-service"
                onClick={() => setIsQuickServiceModalOpen(true)}
                className="flex items-center justify-between px-2 py-1.5 bg-blue-800 hover:bg-blue-700 text-white font-black text-[10px] rounded-lg border border-blue-600 shadow-2xs transition-all cursor-pointer uppercase tracking-wider group"
                title="Cadastrar Novo Serviço (Tecla de Atalho F3)"
              >
                <div className="flex items-center gap-1 truncate">
                  <Briefcase className="w-3 h-3 text-cyan-300 shrink-0" />
                  <span className="truncate">Serviço</span>
                </div>
                <span className="bg-slate-950 text-cyan-300 font-mono text-[8px] font-black px-1 rounded ml-0.5">
                  F3
                </span>
              </button>

              <button
                type="button"
                id="sidebar-btn-quick-new-equipment"
                onClick={() => setIsQuickEquipmentModalOpen(true)}
                className="flex items-center justify-between px-2 py-1.5 bg-blue-800 hover:bg-blue-700 text-white font-black text-[10px] rounded-lg border border-blue-600 shadow-2xs transition-all cursor-pointer uppercase tracking-wider group"
                title="Cadastrar Novo Equipamento (Tecla de Atalho F4)"
              >
                <div className="flex items-center gap-1 truncate">
                  <Cpu className="w-3 h-3 text-amber-300 shrink-0" />
                  <span className="truncate">Equip.</span>
                </div>
                <span className="bg-slate-950 text-amber-300 font-mono text-[8px] font-black px-1 rounded ml-0.5">
                  F4
                </span>
              </button>
            </div>

            <button
              type="button"
              id="sidebar-btn-quick-price-table"
              onClick={() => setIsPriceTableModalOpen(true)}
              className="w-full flex items-center justify-between px-3 py-1.5 bg-[#1b365d] hover:bg-blue-900 text-cyan-100 hover:text-white font-black text-[10px] rounded-lg border border-blue-700 shadow-2xs transition-all cursor-pointer uppercase tracking-wider group"
              title="Pesquisar Tabela de Preços (Tecla de Atalho F7)"
            >
              <div className="flex items-center gap-1.5">
                <FileSpreadsheet className="w-3.5 h-3.5 text-amber-300 shrink-0 group-hover:scale-110 transition-transform" />
                <span>Tabela de Preços</span>
              </div>
              <span className="bg-slate-950 text-amber-300 font-mono text-[8px] font-black px-1.5 py-0.5 rounded">
                F7
              </span>
            </button>
          </div>

          {/* Navigation Links Area - Royal Blue System Style */}
          <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-210px)] scrollbar-none">
            <span className="text-[11px] font-mono font-black tracking-widest text-white block mb-2 uppercase pl-2 drop-shadow-xs">
              PAINEL DE CONTROLE
            </span>

            {/* Tab Links Ordenados Alfabeticamente (A - Z) */}
            {navigationTabs.map((tabItem) => {
              const IconComp = tabItem.icon;
              const isActive = activeTab === tabItem.id;
              return (
                <button
                  key={tabItem.id}
                  id={`sidebar-tab-${tabItem.id}`}
                  onClick={() => {
                    if (tabItem.id === 'CATALOGS') {
                      setCatalogEquipmentFilter(null);
                    }
                    setActiveTab(tabItem.id);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer text-left group ${
                    isActive 
                      ? 'bg-[#0052cc] text-white border border-cyan-300 shadow-md font-extrabold' 
                      : 'text-slate-100 hover:text-white hover:bg-blue-800/80 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {/* Active vertical indicator */}
                    <span className={`w-1.5 h-3.5 rounded-full transition-all duration-200 ${isActive ? 'bg-cyan-300 shadow-xs' : 'bg-transparent group-hover:bg-blue-400'}`} />
                    <IconComp className={`w-4 h-4 transition-transform duration-200 shrink-0 ${isActive ? 'text-white' : tabItem.color}`} />
                    <span className="truncate">{tabItem.label}</span>
                  </div>
                  {tabItem.badge && tabItem.badge > 0 ? (
                    <span className={`px-2 py-0.5 rounded-full font-mono text-[9px] font-black ${tabItem.id === 'INVENTORY' ? 'bg-red-500 text-white' : 'bg-amber-400 text-amber-950'} shadow-2xs`}>
                      {tabItem.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer/System Status Panel */}
        <div className="p-3 border-t-2 border-blue-950 bg-[#112847] space-y-2.5">
          {/* Clock Info with real-time feedback */}
          <div className="flex items-center justify-between px-2.5 py-1.5 bg-[#1b365d] rounded-lg border border-blue-800">
            <div className="flex items-center gap-1.5 font-mono text-[10px]">
              <Clock className="w-3.5 h-3.5 text-cyan-300 shrink-0 animate-pulse" />
              <span className="font-bold tracking-wider text-white">
                {currentTime.toLocaleTimeString('pt-BR', { hour12: false })}
              </span>
            </div>
            <span className="text-[9px] text-cyan-200 font-bold font-mono">
              {currentTime.toLocaleDateString('pt-BR')}
            </span>
          </div>

          {/* System ID / Tech Specs */}
          <div className="text-[9px] font-mono text-cyan-100 space-y-1 px-1 font-bold">
            <div className="flex justify-between"><span>SYS MODEL:</span> <span className="text-white font-extrabold">HYDRA-2.6</span></div>
            <div className="flex justify-between"><span>PORT STATUS:</span> <span className="text-emerald-300 font-black flex items-center gap-1">● ONLINE</span></div>
            <div className="flex justify-between items-center">
              <span>SINC NUVEM:</span>
              <button 
                type="button"
                onClick={() => setShowCloudSyncModal(true)}
                title="Abrir Central de Sincronismo Nuvem e Multi-Dispositivos"
                className="hover:underline cursor-pointer focus:outline-hidden text-right"
              >
                {syncStatus === 'SYNCING' && <span className="text-amber-300 font-black flex items-center gap-1">● SINCRONIZANDO</span>}
                {syncStatus === 'SUCCESS' && <span className="text-emerald-300 font-black flex items-center gap-1">● NUVEM CONECTADA</span>}
                {syncStatus === 'ERROR' && <span className="text-rose-300 font-black flex items-center gap-1">● ERRO DE REDE</span>}
                {syncStatus === 'IDLE' && <span className="text-cyan-300 font-black flex items-center gap-1">● ATIVO (CLIQUE)</span>}
              </button>
            </div>
          </div>

          {/* Sync & Multi-Accounts Button */}
          <button
            type="button"
            onClick={() => setShowCloudSyncModal(true)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-[#0284c7] hover:bg-[#0369a1] text-white font-black text-xs rounded-lg border border-cyan-400 shadow-md cursor-pointer transition-all uppercase tracking-wider"
            id="sidebar-btn-cloud-sync"
          >
            <Cloud className="w-4 h-4 shrink-0" />
            <span>Sincronismo Nuvem</span>
          </button>

          {/* Share Links Button */}
          <button
            type="button"
            onClick={() => setShowShareModal(true)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-[#059669] hover:bg-[#047857] text-white font-black text-xs rounded-lg border border-emerald-400 shadow-md cursor-pointer transition-all uppercase tracking-wider"
            id="sidebar-btn-share-links"
          >
            <Share2 className="w-4 h-4 shrink-0" />
            <span>Compartilhar Links</span>
          </button>

          {/* User Manual Button */}
          <button
            type="button"
            onClick={() => setActiveTab('MANUAL')}
            className={`w-full flex items-center justify-center gap-2 px-3 py-2 ${activeTab === 'MANUAL' ? 'bg-[#0052cc] text-white border-cyan-300 shadow-md font-black' : 'bg-[#1b365d] hover:bg-[#004a99] text-cyan-200 hover:text-white border-blue-700'} font-bold text-xs rounded-lg border cursor-pointer transition-all uppercase tracking-wider`}
            id="sidebar-btn-manual-direct"
          >
            <BookOpen className="w-4 h-4 shrink-0 text-amber-300" />
            <span>Manual do Sistema</span>
          </button>
        </div>
      </aside>

      {/* Main Workspace Frame */}
      <div className="flex-grow flex flex-col min-w-0 md:h-screen md:overflow-y-auto" id="main-workspace-wrapper">
        
        {/* Mobile-Only Header */}
        <header className="md:hidden bg-[#1b365d] text-white border-b-2 border-blue-950 sticky top-0 z-40 px-4 py-3 flex items-center justify-between shadow-md" id="mobile-app-header">
          <div className="flex items-center gap-2">
            <div className="p-1 bg-[#004a99] rounded-xl border border-blue-700 shadow-xs flex items-center justify-center shrink-0">
              <svg viewBox="0 0 390 340" className="w-6 h-6 text-cyan-200" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M 113.1 102.6 A 100 100 0 0 1 252.4 241.9" className="stroke-cyan-300" strokeWidth="12" strokeLinecap="square" />
                <g fill="currentColor" fontFamily="Georgia, Cambria, 'Times New Roman', Times, serif" fontWeight="bold">
                  <text x="145" y="170" fontSize="100" textAnchor="middle">J</text>
                  <text x="210" y="170" fontSize="100" textAnchor="middle">C</text>
                  <text x="175" y="235" fontSize="62" textAnchor="middle">&amp;</text>
                  <text x="215" y="240" fontSize="100" textAnchor="middle">F</text>
                </g>
              </svg>
            </div>
            <div>
              <h1 className="font-black text-xs tracking-wider text-white">JC&F SISTEMAS</h1>
              <p className="text-[8px] text-cyan-200 font-extrabold uppercase tracking-widest">Painel Conectado</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              id="mobile-btn-quick-new-client"
              onClick={() => setIsQuickClientModalOpen(true)}
              className="flex items-center gap-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider px-2 py-1 rounded-lg shadow-xs transition-all cursor-pointer"
              title="Cadastrar Novo Cliente (F2)"
            >
              <UserPlus className="w-3.5 h-3.5 text-slate-950" />
              <span>+ Cliente</span>
            </button>
            <div className="flex items-center gap-1.5 bg-[#004a99] px-2.5 py-1 rounded-lg border border-blue-700 font-mono text-[10px] text-white font-bold">
              {currentTime.toLocaleTimeString('pt-BR', { hour12: false, hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>
        </header>

        {/* Mobile Navigation Bar - Ordenado Alfabeticamente (A - Z) */}
        <div className="md:hidden bg-[#112847] border-b-2 border-blue-950 text-white flex items-center justify-start gap-2 py-2.5 px-3 sticky top-[53px] z-40 overflow-x-auto scrollbar-none shadow-md" id="mobile-navigation-bar">
          {navigationTabs.map((tabItem) => {
            const IconComp = tabItem.icon;
            const isActive = activeTab === tabItem.id;
            return (
              <button
                key={`mobile-${tabItem.id}`}
                id={`mobile-nav-${tabItem.id.toLowerCase().replace(/_/g, '-')}`}
                onClick={() => {
                  if (tabItem.id === 'CATALOGS') {
                    setCatalogEquipmentFilter(null);
                  }
                  setActiveTab(tabItem.id);
                }}
                className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-extrabold tracking-wide transition-all ${
                  isActive 
                    ? 'bg-[#0052cc] text-white border border-cyan-300 shadow-xs' 
                    : 'text-slate-200 hover:text-white'
                }`}
              >
                <IconComp className={`w-4 h-4 ${isActive ? 'text-white' : tabItem.color}`} />
                <span>{tabItem.shortLabel || tabItem.label}</span>
                {tabItem.badge && tabItem.badge > 0 ? (
                  <span className={`px-1.5 py-0.5 rounded-full font-mono text-[8px] font-black ${tabItem.id === 'INVENTORY' ? 'bg-red-500 text-white' : 'bg-amber-400 text-amber-950'}`}>
                    {tabItem.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

        {/* Main Content Body */}
        <main className="flex-grow p-3 sm:p-5 lg:p-6 w-full max-w-[1800px] mx-auto relative z-10">
          
          {/* Quick Action Top Bar */}
          <div className="mb-4 bg-white border-2 border-[#b0bec5] rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-xs" id="workspace-quick-top-bar">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-black uppercase tracking-wider text-slate-800">
                JC&F Manutenção Hidráulica e Pneumática
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                id="topbar-btn-quick-new-client"
                onClick={() => setIsQuickClientModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg shadow-xs hover:shadow-sm transition-all cursor-pointer"
                title="Cadastrar Novo Cliente (Tecla de Atalho F2)"
              >
                <UserPlus className="w-3.5 h-3.5 text-slate-950" />
                <span>+ Cliente</span>
                <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1.5 py-0.5 rounded border border-amber-600 ml-0.5">
                  F2
                </span>
              </button>

              <button
                type="button"
                id="topbar-btn-quick-new-service"
                onClick={() => setIsQuickServiceModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1b365d] hover:bg-blue-900 active:scale-[0.98] text-cyan-200 hover:text-white font-black text-xs uppercase tracking-wider rounded-lg border border-blue-700 shadow-xs hover:shadow-sm transition-all cursor-pointer"
                title="Cadastrar Novo Serviço (Tecla de Atalho F3)"
              >
                <Briefcase className="w-3.5 h-3.5 text-cyan-300" />
                <span>+ Serviço</span>
                <span className="bg-slate-950 text-cyan-300 font-mono text-[9px] font-black px-1.5 py-0.5 rounded border border-blue-600 ml-0.5">
                  F3
                </span>
              </button>

              <button
                type="button"
                id="topbar-btn-quick-new-equipment"
                onClick={() => setIsQuickEquipmentModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1b365d] hover:bg-blue-900 active:scale-[0.98] text-amber-200 hover:text-white font-black text-xs uppercase tracking-wider rounded-lg border border-blue-700 shadow-xs hover:shadow-sm transition-all cursor-pointer"
                title="Cadastrar Novo Equipamento (Tecla de Atalho F4)"
              >
                <Cpu className="w-3.5 h-3.5 text-amber-300" />
                <span>+ Equipamento</span>
                <span className="bg-slate-950 text-amber-300 font-mono text-[9px] font-black px-1.5 py-0.5 rounded border border-amber-600 ml-0.5">
                  F4
                </span>
              </button>

              <button
                type="button"
                id="topbar-btn-quick-price-table"
                onClick={() => setIsPriceTableModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-black text-xs uppercase tracking-wider rounded-lg border border-emerald-400 shadow-xs hover:shadow-sm transition-all cursor-pointer"
                title="Pesquisar Tabela de Preços (Tecla de Atalho F7)"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-white" />
                <span>Tabela de Preços</span>
                <span className="bg-slate-950 text-emerald-300 font-mono text-[9px] font-black px-1.5 py-0.5 rounded border border-emerald-500 ml-0.5">
                  F7
                </span>
              </button>

              <button
                type="button"
                id="topbar-btn-quick-warranty"
                onClick={() => setActiveTab('WARRANTY_CONTROL')}
                className={`flex items-center gap-1.5 px-3 py-1.5 ${
                  activeTab === 'WARRANTY_CONTROL' 
                    ? 'bg-amber-600 text-white border-amber-300 ring-2 ring-amber-400/50' 
                    : 'bg-amber-500 hover:bg-amber-400 text-slate-950 border-amber-600'
                } active:scale-[0.98] font-black text-xs uppercase tracking-wider rounded-lg border shadow-xs hover:shadow-sm transition-all cursor-pointer`}
                title="Acessar Controle de Garantia da Oficina"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Controle de Garantia</span>
              </button>
            </div>
          </div>

          {/* Dynamic statistics section */}
          <DashboardStats clients={clients} equipments={equipments} orders={orders} />

        {/* Tab Router Switch */}
        <div className="space-y-6">
          {activeTab === 'ENTRY_REGISTRY' && (
            <EquipmentEntryRegistry
              clients={clients}
              equipments={equipments}
              orders={orders}
              services={services}
              receivers={receivers}
              onSaveReceivers={saveReceivers}
              onAddClient={handleAddClient}
              onAddEquipment={handleAddEquipment}
              onAddOrder={handleAddOrder}
              onEditOrder={handleEditOrder}
              onDeleteOrder={handleDeleteOrder}
              onEditEquipment={handleEditEquipment}
              onOpenPriceTableTab={() => setActiveTab('SERVICES')}
              onOpenWarrantyTab={() => setActiveTab('WARRANTY_CONTROL')}
            />
          )}

          {activeTab === 'DASHBOARD' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="dashboard-tab-content">
              
              {/* Urgent alerts Column */}
              <div className="lg:col-span-2 space-y-6">
                
                {/* Link Sharing Panel */}
                <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm transition-all duration-300" id="share-links-dashboard-card">
                  <div className="bg-[#1b365d] text-white px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-blue-900">
                    <div className="flex items-center gap-2.5">
                      <span className="p-1.5 bg-white/10 rounded-lg border border-white/20 text-cyan-300 shadow-sm">
                        <Share2 className="w-4 h-4 text-cyan-300" />
                      </span>
                      <div>
                        <h2 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">Links de Compartilhamento</h2>
                        <p className="text-[10px] text-cyan-100 mt-0.5">Acesso externo ao painel e check-in rápido</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono font-bold bg-white/10 border border-white/20 text-cyan-200 px-2.5 py-1 rounded-md uppercase tracking-widest shrink-0 hidden sm:inline-block">
                        INTEGRAÇÃO 4.0
                      </span>
                      <button
                        type="button"
                        onClick={() => setIsLinksPanelExpanded(!isLinksPanelExpanded)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white text-[10px] font-black uppercase tracking-wider rounded-lg border border-white/20 transition-all cursor-pointer select-none"
                      >
                        <span>{isLinksPanelExpanded ? 'Ocultar Links' : 'Visualizar Links'}</span>
                        {isLinksPanelExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5 text-cyan-300" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5 text-cyan-300" />
                        )}
                      </button>
                    </div>
                  </div>

                  {isLinksPanelExpanded && (
                    <div className="p-4 sm:p-5 bg-[#f4f7fa] space-y-4 animate-fade-in">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        
                        {/* Link 1: Program Access */}
                        <div className="bg-white p-4 rounded-xl border border-slate-300 shadow-2xs flex flex-col justify-between hover:border-blue-500 transition-colors duration-200">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Globe className="w-4 h-4 text-[#1b365d]" />
                              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">Acesso ao Sistema Completo</h3>
                            </div>
                            <p className="text-[10px] text-slate-600 leading-relaxed font-medium">
                              Link para acessar o painel administrativo de controle, estoque, ordens e relatórios.
                            </p>
                          </div>
                          
                          <div className="mt-4 space-y-2">
                            <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-2 rounded-lg border border-slate-300 text-[10px] font-mono text-slate-800 overflow-hidden select-all font-bold">
                              <Link2 className="w-3.5 h-3.5 shrink-0 text-[#1b365d]" />
                              <span className="truncate flex-grow">{systemBaseUrl.replace(/\/+$/, '')}</span>
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => handleCopyLink(systemBaseUrl.replace(/\/+$/, ''), 'app')}
                                className="flex-grow flex items-center justify-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-[10px] uppercase tracking-wider transition-all cursor-pointer shadow-xs"
                              >
                                {copyFeedback === 'app' ? (
                                  <>
                                    <Check className="w-3.5 h-3.5 text-slate-950" />
                                    <span>Copiado!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3.5 h-3.5 text-slate-950" />
                                    <span>Copiar Link</span>
                                  </>
                                )}
                              </button>
                              <a
                                href={systemBaseUrl.replace(/\/+$/, '')}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 hover:text-slate-900 rounded-lg flex items-center justify-center transition-all cursor-pointer"
                                title="Abrir em Nova Aba"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          </div>
                        </div>

                        {/* Link 2: Customer Check-In */}
                        <div className="bg-white p-4 rounded-xl border border-slate-300 shadow-2xs flex flex-col justify-between hover:border-blue-500 transition-colors duration-200">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Smartphone className="w-4 h-4 text-emerald-600" />
                              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">Portal de Check-In do Cliente</h3>
                            </div>
                            <p className="text-[10px] text-slate-600 leading-relaxed font-medium">
                              Link direto isolado para clientes realizarem check-in e abertura de OS via celular/tablet.
                            </p>
                          </div>

                          <div className="mt-4 space-y-2">
                            <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-2 rounded-lg border border-slate-300 text-[10px] font-mono text-slate-800 overflow-hidden select-all font-bold">
                              <Link2 className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                              <span className="truncate flex-grow">{systemBaseUrl.replace(/\/+$/, '') + '?mode=checkin'}</span>
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => handleCopyLink(systemBaseUrl.replace(/\/+$/, '') + '?mode=checkin', 'checkin')}
                                className="flex-grow flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg text-[10px] uppercase tracking-wider transition-all cursor-pointer shadow-xs"
                              >
                                {copyFeedback === 'checkin' ? (
                                  <>
                                    <Check className="w-3.5 h-3.5 text-white" />
                                    <span>Copiado!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3.5 h-3.5 text-white" />
                                    <span>Copiar Link</span>
                                  </>
                                )}
                              </button>
                              <a
                                href={systemBaseUrl.replace(/\/+$/, '') + '?mode=checkin'}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 hover:text-slate-900 rounded-lg flex items-center justify-center transition-all cursor-pointer"
                                title="Abrir em Nova Aba"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          </div>
                        </div>

                      </div>

                      {/* Guia Importante de Compartilhamento */}
                      <div className="p-4 bg-white border border-slate-300 rounded-xl space-y-3 text-xs text-slate-700 shadow-2xs">
                        <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                          <HelpCircle className="w-4 h-4 text-amber-500 shrink-0" />
                          <h4 className="font-black uppercase tracking-wider text-slate-900 text-[10px]">
                            Guia Importante de Compartilhamento, Acesso e Sincronização
                          </h4>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {/* Item 1 */}
                          <div className="space-y-1">
                            <span className="text-[9px] font-black tracking-widest text-amber-600 uppercase flex items-center gap-1.5">
                              <ShieldAlert className="w-3.5 h-3.5 shrink-0" /> 1. Autorização de Acesso
                            </span>
                            <p className="text-[10px] text-slate-600 leading-relaxed font-medium">
                              Os links gerados pertencem ao ambiente seguro de testes do Google AI Studio. 
                              Se outra pessoa receber um aviso de <strong className="text-amber-600 font-bold">"Sem Autorização"</strong>, clique em <strong className="text-slate-900 font-bold">"Share" (Compartilhar)</strong> no topo superior direito e adicione o e-mail dela.
                            </p>
                          </div>

                          {/* Item 2 */}
                          <div className="space-y-1">
                            <span className="text-[9px] font-black tracking-widest text-[#1b365d] uppercase flex items-center gap-1.5">
                              <Users className="w-3.5 h-3.5 shrink-0" /> 2. Clientes Diferentes?
                            </span>
                            <p className="text-[10px] text-slate-600 leading-relaxed font-medium">
                              O editor de testes roda em uma URL separada. Abra o link de <strong className="text-slate-900 font-bold">Acesso ao Sistema Completo</strong> em uma aba externa e cadastre seus clientes lá. Assim, todos os portais compartilharão a mesma lista!
                            </p>
                          </div>

                          {/* Item 3 */}
                          <div className="space-y-1">
                            <span className="text-[9px] font-black tracking-widest text-emerald-700 uppercase flex items-center gap-1.5">
                              <FileSpreadsheet className="w-3.5 h-3.5 shrink-0" /> 3. Sincronização em Nuvem
                            </span>
                            <p className="text-[10px] text-slate-600 leading-relaxed font-medium">
                              Por padrão, o banco de dados é local. Para compartilhar os dados definitivamente entre múltiplos aparelhos, acesse a aba <strong className="text-emerald-700 font-bold">Sincronização Google Sheets</strong> no menu e conecte sua planilha!
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Settings section to adjust Base URL */}
                      <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-300 shadow-2xs">
                        <div className="space-y-0.5">
                          <span className="text-[10px] font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                            <Settings className="w-3.5 h-3.5 text-[#1b365d]" /> Ajustar Domínio / URL Base
                          </span>
                          <p className="text-[9px] text-slate-500 leading-normal font-medium">
                            Caso esteja visualizando em um frame de testes e o link copiado não funcione, digite seu domínio principal abaixo:
                          </p>
                        </div>
                        <input
                          type="text"
                          value={systemBaseUrl}
                          onChange={(e) => setSystemBaseUrl(e.target.value)}
                          placeholder="Ex: https://jcfsistemas.com"
                          className="w-full sm:w-80 px-3 py-1.5 bg-slate-50 border border-slate-300 focus:border-[#1b365d] rounded-lg text-slate-800 font-mono text-[10px] focus:outline-hidden font-bold"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Attention notice */}
                <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="urgent-reparations-box">
                  <div className="bg-[#1b365d] text-white px-4 py-3 flex items-center gap-2.5 border-b border-blue-900">
                    <ShieldAlert className="w-5 h-5 text-red-400 shrink-0" />
                    <h2 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">Ordens de Alta Prioridade Ativas</h2>
                  </div>

                  <div className="p-4 sm:p-5 bg-white space-y-3">
                    {urgentOrders.length === 0 ? (
                      <div className="text-center py-8 text-slate-500 border border-dashed border-slate-300 rounded-xl bg-slate-50">
                        <CheckCircle className="w-8 h-8 mx-auto text-emerald-600 mb-2 opacity-90" />
                        <p className="text-xs font-black text-slate-800 uppercase">Nenhum atendimento crítico pendente</p>
                        <p className="text-[11px] text-slate-500 mt-1 max-w-sm mx-auto font-medium">Excelente trabalho! Todas as ordens de alta prioridade estão resolvidas.</p>
                      </div>
                    ) : (
                      <div className="divide-y divide-slate-200 space-y-3">
                        {urgentOrders.map(order => {
                          const client = clients.find(c => c.id === order.clientId);
                          const equip = equipments.find(e => e.id === order.equipmentId);
                          return (
                            <div id={`urgent-os-${order.id}`} key={order.id} className="pt-3 first:pt-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-slate-100/60 transition-colors">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[9px] font-black tracking-widest text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded-md uppercase">CRÍTICO</span>
                                  <span className="text-xs font-mono font-black text-[#1b365d]">{order.osNumber}</span>
                                </div>
                                <h4 className="font-black text-slate-900 text-sm leading-snug">{order.title}</h4>
                                <p className="text-xs text-slate-600 font-medium">
                                  {equip?.name} ({equip?.model}) — Cliente: <strong className="text-slate-800 font-bold">{client?.name}</strong>
                                </p>
                              </div>

                              <div className="flex items-center gap-3 shrink-0">
                                <span className="text-[10px] font-mono font-black text-amber-800 bg-amber-50 border border-amber-300 px-2.5 py-1 rounded-lg uppercase tracking-wider">
                                  {order.status === 'PENDING' ? 'Aguardando' : 'Em Execução'}
                                </span>
                                <button
                                  id={`btn-urgent-goto-${order.id}`}
                                  onClick={() => setActiveTab('OS')}
                                  className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition-all cursor-pointer shadow-xs"
                                >
                                  Visualizar OS
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>

                {/* General Workshop Instructions Card */}
                <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm flex flex-col justify-between" id="workshop-welcome-banner">
                  <div className="bg-[#1b365d] text-white px-4 py-3 border-b border-blue-900">
                    <h3 className="text-xs sm:text-sm font-black tracking-wider text-white uppercase flex items-center gap-2">
                      <Wrench className="w-4 h-4 text-cyan-300" />
                      Ficha Técnica & Automação 4.0
                    </h3>
                  </div>
                  <div className="p-4 sm:p-5 bg-[#f8fafc] text-slate-700 space-y-4">
                    <p className="text-xs text-slate-600 leading-relaxed font-medium">
                      Este painel integra a ficha cadastral de seus clientes industriais aos seus respectivos ativos em produção. Ao mudar o status de qualquer Ordem de Serviço para <strong className="text-[#1b365d] font-bold">"Concluída"</strong>, o sistema cria automaticamente um log de histórico de manutenção permanente no equipamento correspondente.
                    </p>
                    <div className="flex flex-wrap gap-3">
                      <div className="bg-white px-4 py-2.5 rounded-lg border border-slate-300 shadow-2xs flex flex-col">
                        <span className="text-slate-500 text-[9px] uppercase font-bold tracking-widest block mb-0.5">Última OS Aberta</span>
                        <span className="font-mono text-xs font-black text-[#1b365d]">
                          {orders.length > 0 ? orders[orders.length - 1].osNumber : 'NENHUMA'}
                        </span>
                      </div>
                      <div className="bg-white px-4 py-2.5 rounded-lg border border-slate-300 shadow-2xs flex flex-col">
                        <span className="text-slate-500 text-[9px] uppercase font-bold tracking-widest block mb-0.5">Total Investido em Reparos</span>
                        <span className="font-mono text-xs font-black text-emerald-700">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
                            orders.filter(o => o.status === 'COMPLETED').reduce((s, o) => s + o.estimatedCost, 0)
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Sidebar stats & quick logs */}
              <div className="space-y-6" id="dashboard-sidebar">
                
                {/* Recent Maintenance Actions */}
                <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="recent-maintenance-list">
                  <div className="bg-[#1b365d] text-white px-4 py-3 border-b border-blue-900 flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-cyan-300" />
                    <h3 className="font-black text-white text-xs uppercase tracking-wider">Últimas Manutenções</h3>
                  </div>

                  <div className="p-4 space-y-3 bg-white">
                    {history.length === 0 ? (
                      <p className="text-xs text-slate-500 text-center py-6 font-medium">Nenhum registro de manutenção inserido.</p>
                    ) : (
                      <div className="space-y-2.5">
                        {history
                          .slice()
                          .sort((a, b) => new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime())
                          .slice(0, 4)
                          .map(item => {
                            const equip = equipments.find(e => e.id === item.equipmentId);
                            return (
                              <div id={`recent-hist-${item.id}`} key={item.id} className="text-xs border-l-4 border-[#1b365d] pl-3 py-1.5 space-y-0.5 bg-slate-50 rounded-r-lg border-y border-r border-slate-200">
                                <p className="font-black text-slate-900 leading-snug">{item.serviceType}</p>
                                <div className="flex flex-col text-[10px] text-slate-600 font-medium">
                                  <span>Equipamento: <strong className="text-slate-800 font-bold">{equip?.name || 'Desconhecido'}</strong></span>
                                  <span className="text-[9px] font-mono text-slate-500 mt-0.5">{new Date(item.date + 'T12:00:00').toLocaleDateString('pt-BR')}</span>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    )}
                  </div>
                </div>

                {/* Quick Add Launcher shortcut buttons */}
                <div className="bg-white border-2 border-[#b0bec5] rounded-xl overflow-hidden shadow-sm" id="quick-launcher-box">
                  <div className="bg-[#1b365d] text-white px-4 py-3 border-b border-blue-900">
                    <h3 className="font-black text-white text-xs uppercase tracking-wider">Acesso Rápido</h3>
                  </div>
                  <div className="p-4 bg-[#f8fafc]">
                    <div className="grid grid-cols-2 gap-2.5">
                      <button
                        id="quick-launch-checkin"
                        onClick={() => setActiveTab('MOBILE_OS')}
                        className="p-3.5 text-center bg-amber-500 hover:bg-amber-400 rounded-xl transition-all text-xs font-black text-slate-950 uppercase tracking-wider col-span-2 shadow-sm cursor-pointer"
                      >
                        <Smartphone className="w-4 h-4 text-slate-950 mx-auto mb-1.5" />
                        <span>Check-In Rápido (Celular / Tablet)</span>
                      </button>
                      <button
                        id="quick-launch-clients"
                        onClick={() => setActiveTab('CLIENTS')}
                        className="p-3 text-center bg-white hover:bg-slate-50 rounded-xl transition-all text-xs font-bold text-slate-800 border border-slate-300 shadow-2xs hover:border-slate-400 cursor-pointer"
                      >
                        <Users className="w-4 h-4 text-[#1b365d] mx-auto mb-1.5" />
                        <span>Clientes</span>
                      </button>
                      <button
                        id="quick-launch-equipments"
                        onClick={() => setActiveTab('EQUIPMENTS')}
                        className="p-3 text-center bg-white hover:bg-slate-50 rounded-xl transition-all text-xs font-bold text-slate-800 border border-slate-300 shadow-2xs hover:border-slate-400 cursor-pointer"
                      >
                        <Cpu className="w-4 h-4 text-[#1b365d] mx-auto mb-1.5" />
                        <span>Máquinas</span>
                      </button>
                      <button
                        id="quick-launch-os"
                        onClick={() => setActiveTab('OS')}
                        className="p-3 text-center bg-white hover:bg-slate-50 rounded-xl transition-all text-xs font-bold text-slate-800 border border-slate-300 shadow-2xs hover:border-slate-400 cursor-pointer col-span-2 flex items-center justify-center gap-2"
                      >
                        <FileText className="w-4 h-4 text-amber-600" />
                        <span>Ordens de Serviço (Kanban)</span>
                      </button>
                      <button
                        id="quick-launch-warranty"
                        onClick={() => setActiveTab('WARRANTY_CONTROL')}
                        className="p-3 text-center bg-white hover:bg-slate-50 rounded-xl transition-all text-xs font-bold text-slate-800 border border-slate-300 shadow-2xs hover:border-slate-400 cursor-pointer col-span-2 flex items-center justify-center gap-2"
                      >
                        <ShieldCheck className="w-4 h-4 text-amber-600" />
                        <span>Auditoria & Controle de Garantias</span>
                      </button>
                      <button
                        id="quick-launch-reports"
                        onClick={() => setActiveTab('REPORTS')}
                        className="p-3 text-center bg-white hover:bg-slate-50 rounded-xl transition-all text-xs font-bold text-slate-800 border border-slate-300 shadow-2xs hover:border-slate-400 cursor-pointer col-span-2 flex items-center justify-center gap-2"
                      >
                        <BarChart3 className="w-4 h-4 text-[#1b365d]" />
                        <span>Relatórios Gerenciais</span>
                      </button>
                      <button
                        id="quick-launch-finance"
                        onClick={() => setActiveTab('FINANCE')}
                        className="p-3 text-center bg-white hover:bg-slate-50 rounded-xl transition-all text-xs font-bold text-slate-800 border border-slate-300 shadow-2xs hover:border-slate-400 cursor-pointer col-span-2 flex items-center justify-center gap-2"
                      >
                        <DollarSign className="w-4 h-4 text-emerald-700" />
                        <span>Controle Financeiro (A Pagar / Receber)</span>
                      </button>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          )}

          {activeTab === 'OS' && (
            <ServiceOrderManager
              orders={orders}
              clients={clients}
              equipments={equipments}
              diagnostics={diagnostics}
              services={services}
              technicians={technicians}
              receivers={receivers}
              onSaveReceivers={saveReceivers}
              onAddOrder={handleAddOrder}
              onEditOrder={handleEditOrder}
              onDeleteOrder={handleDeleteOrder}
              onAutoAddHistoryFromOS={handleAutoAddHistoryFromOS}
              onAddTransaction={handleAddTransaction}
            />
          )}

          {activeTab === 'EQUIPMENTS' && (
            <EquipmentManager
              equipments={equipments}
              clients={clients}
              history={history}
              orders={orders}
              onAddEquipment={handleAddEquipment}
              onEditEquipment={handleEditEquipment}
              onDeleteEquipment={handleDeleteEquipment}
              onAddHistoryEntry={handleAddHistoryEntry}
              onDeleteHistoryEntry={handleDeleteHistoryEntry}
              onOpenCatalog={handleOpenCatalogForEquipment}
            />
          )}

          {activeTab === 'CATALOGS' && (
            <EquipmentCatalogManager
              catalogs={catalogs}
              equipments={equipments}
              inventory={inventory}
              orders={orders}
              onSaveCatalog={handleSaveCatalog}
              onDeleteCatalog={handleDeleteCatalog}
              onAddInventoryItem={(newItem) => {
                const created: InventoryItem = {
                  ...newItem,
                  id: `inv-${Date.now()}`,
                  createdAt: new Date().toISOString()
                };
                saveInventory([...inventory, created]);
              }}
              onUpdateServiceOrderMaterials={(orderId, material) => {
                const updatedOrders = orders.map(o => {
                  if (o.id === orderId) {
                    const list = o.materialsUsedList || [];
                    return {
                      ...o,
                      materialsUsedList: [...list, material],
                      updatedAt: new Date().toISOString()
                    };
                  }
                  return o;
                });
                saveOrders(updatedOrders);
              }}
              onNavigateToOS={() => {
                setActiveTab('OS');
              }}
              initialSelectedEquipmentId={catalogEquipmentFilter}
            />
          )}

          {activeTab === 'CLIENTS' && (
            <ClientManager
              clients={clients}
              equipments={equipments}
              orders={orders}
              onAddClient={handleAddClient}
              onEditClient={handleEditClient}
              onDeleteClient={handleDeleteClient}
            />
          )}

          {activeTab === 'REPORTS' && (
            <ReportManager
              clients={clients}
              equipments={equipments}
              orders={orders}
            />
          )}

          {activeTab === 'FINANCE' && (
            <FinancialManager
              transactions={transactions}
              clients={clients}
              orders={orders}
              onAddTransaction={handleAddTransaction}
              onEditTransaction={handleEditTransaction}
              onDeleteTransaction={handleDeleteTransaction}
            />
          )}

          {activeTab === 'DIAGNOSTICS' && (
            <DiagnosticManager
              diagnostics={diagnostics}
              onAddDiagnostic={handleAddDiagnostic}
              onEditDiagnostic={handleEditDiagnostic}
              onDeleteDiagnostic={handleDeleteDiagnostic}
            />
          )}

          {activeTab === 'SERVICES' && (
            <ServiceManager
              services={services}
              onAddService={handleAddService}
              onEditService={handleEditService}
              onDeleteService={handleDeleteService}
            />
          )}

          {activeTab === 'MOBILE_OS' && (
            <MaintenanceLifecycle
              orders={orders}
              clients={clients}
              equipments={equipments}
              history={history}
              technicians={technicians}
              diagnostics={diagnostics}
              services={services}
              receivers={receivers}
              onSaveReceivers={saveReceivers}
              onAddOrder={handleAddOrder}
              onEditOrder={handleEditOrder}
              onAddClient={handleAddClient}
              onAddEquipment={handleAddEquipment}
              onAutoAddHistoryFromOS={handleAutoAddHistoryFromOS}
              onAddTransaction={handleAddTransaction}
              onDeleteOrder={handleDeleteOrder}
              onEditEquipment={handleEditEquipment}
              inventory={inventory}
              onEditInventoryItem={handleEditInventoryItem}
            />
          )}

          {activeTab === 'TECHNICIANS' && (
            <TechnicianManager
              technicians={technicians}
              receivers={receivers}
              onSaveReceivers={saveReceivers}
              onAddTechnician={handleAddTechnician}
              onEditTechnician={handleEditTechnician}
              onDeleteTechnician={handleDeleteTechnician}
            />
          )}

          {activeTab === 'GOOGLE_SHEETS' && (
            <GoogleSheetsSync
              clients={clients}
              equipments={equipments}
              orders={orders}
              transactions={transactions}
              inventory={inventory}
              onImportData={(imported) => {
                if (imported.clients && imported.clients.length > 0) saveClients(imported.clients);
                if (imported.equipments && imported.equipments.length > 0) saveEquipments(imported.equipments);
                if (imported.orders && imported.orders.length > 0) saveOrders(imported.orders);
                if (imported.transactions && imported.transactions.length > 0) saveTransactions(imported.transactions);
                if (imported.inventory && imported.inventory.length > 0) saveInventory(imported.inventory);
              }}
            />
          )}

          {activeTab === 'INVENTORY' && (
            <InventoryManager
              inventory={inventory}
              onAddItem={handleAddInventoryItem}
              onAddItems={handleAddInventoryItems}
              onEditItem={handleEditInventoryItem}
              onDeleteItem={handleDeleteInventoryItem}
            />
          )}

          {activeTab === 'TECHNICAL_REPORT' && (
            <TechnicalCertificate
              orders={orders}
              clients={clients}
              equipments={equipments}
              technicians={technicians}
            />
          )}

          {activeTab === 'WARRANTY_CONTROL' && (
            <WarrantyManager
              orders={orders}
              clients={clients}
              equipments={equipments}
              onAddOrder={handleAddOrder}
              setActiveTab={setActiveTab}
            />
          )}

          {activeTab === 'QUOTES' && (
            <QuoteManager
              quotes={quotes}
              clients={clients}
              equipments={equipments}
              technicians={technicians}
              services={services}
              inventory={inventory}
              orders={orders}
              onAddQuote={handleAddQuote}
              onUpdateQuote={handleUpdateQuote}
              onDeleteQuote={handleDeleteQuote}
              onAddOrder={handleAddOrder}
              onAddClient={handleAddClient}
              onAddService={handleAddService}
              onAddEquipment={handleAddEquipment}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'POST_MAINTENANCE' && (
            <PostMaintenanceManager
              feedbacks={postMaintenanceFeedbacks}
              orders={orders}
              clients={clients}
              equipments={equipments}
              technicians={technicians}
              onAddFeedback={handleAddPostMaintenanceFeedback}
              onUpdateFeedback={handleUpdatePostMaintenanceFeedback}
              onDeleteFeedback={handleDeletePostMaintenanceFeedback}
              setActiveTab={setActiveTab}
            />
          )}

          {activeTab === 'MANUAL' && (
            <UserManual onNavigateTab={(tab) => setActiveTab(tab)} />
          )}
        </div>

      </main>

      {/* Humble Footer */}
      <footer className="bg-white border-t-2 border-[#b0bec5] py-6 mt-12 text-center text-xs text-slate-600 shadow-xs" id="main-app-footer">
        <p className="font-mono tracking-wider font-bold">JC&F - MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA © 2026 • Soluções de Alta Performance</p>
      </footer>

      </div>

      {/* Global Share Links Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="share-links-global-modal">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs" onClick={() => setShowShareModal(false)}></div>
          
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl border-2 border-[#b0bec5] p-6 flex flex-col space-y-5">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b-2 border-slate-200 pb-3">
              <div className="flex items-center gap-3 text-[#1b365d]">
                <div className="p-2.5 bg-blue-50 rounded-xl border border-blue-200">
                  <Share2 className="w-5 h-5 text-[#1b365d]" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider">
                    Compartilhar Links de Acesso
                  </h3>
                  <span className="text-[10px] text-slate-500 font-medium block">Copie e envie os links abaixo para os respectivos destinatários</span>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setShowShareModal(false)}
                className="p-1 hover:bg-slate-100 rounded text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="space-y-4">
              {/* Link 1: Complete App Access */}
              <div className="bg-[#f8fafc] p-4 rounded-xl border border-slate-300 space-y-3 shadow-2xs">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-[#1b365d]" />
                      <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">Acesso Administrativo ao Sistema</h4>
                    </div>
                    <p className="text-[10px] text-slate-600 leading-normal font-medium">
                      Link para acesso completo ao painel administrativo (estoque, financeiro, relatórios, ordens). Envie para gestores e técnicos.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 bg-white px-3 py-2 rounded-lg border border-slate-300 text-[10px] font-mono text-[#1b365d] overflow-hidden shadow-inner">
                  <Link2 className="w-3.5 h-3.5 shrink-0 text-[#1b365d]" />
                  <span className="truncate flex-grow font-bold">{systemBaseUrl.replace(/\/+$/, '')}</span>
                  <button
                    type="button"
                    onClick={() => handleCopyLink(systemBaseUrl.replace(/\/+$/, ''), 'app')}
                    className="ml-2 shrink-0 px-2 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded text-[10px] uppercase transition-colors cursor-pointer shadow-xs flex items-center gap-1"
                    title="Copiar Link"
                  >
                    {copyFeedback === 'app' ? <Check className="w-3.5 h-3.5 text-slate-950" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copiar</span>
                  </button>
                </div>
              </div>

              {/* Link 2: Customer Check-In Portal */}
              <div className="bg-[#f8fafc] p-4 rounded-xl border border-slate-300 space-y-3 shadow-2xs">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-emerald-600" />
                      <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">Portal de Check-In do Cliente</h4>
                    </div>
                    <p className="text-[10px] text-slate-600 leading-normal font-medium">
                      Link isolado onde clientes e motoristas podem fazer check-in de ativos e abrir ordens de serviço diretamente.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 bg-white px-3 py-2 rounded-lg border border-slate-300 text-[10px] font-mono text-emerald-700 overflow-hidden shadow-inner">
                  <Link2 className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                  <span className="truncate flex-grow font-bold">{systemBaseUrl.replace(/\/+$/, '') + '?mode=checkin'}</span>
                  <button
                    type="button"
                    onClick={() => handleCopyLink(systemBaseUrl.replace(/\/+$/, '') + '?mode=checkin', 'checkin')}
                    className="ml-2 shrink-0 px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded text-[10px] uppercase transition-colors cursor-pointer shadow-xs flex items-center gap-1"
                    title="Copiar Link"
                  >
                    {copyFeedback === 'checkin' ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copiar</span>
                  </button>
                </div>
              </div>

              {/* IMPORTANTE: Instruções de Autorização e Alinhamento de Banco de Dados */}
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl space-y-2.5 text-[11px] text-slate-700 shadow-2xs">
                <div className="flex items-center gap-1.5 border-b border-amber-200 pb-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <h4 className="font-black uppercase tracking-wider text-amber-900 text-[9px]">
                    INSTRUÇÕES DE ACESSO & SINCRONIZAÇÃO
                  </h4>
                </div>
                <div className="space-y-2 leading-relaxed text-slate-600 font-medium">
                  <p>
                    ⚠️ <strong className="text-amber-800">Autorização de Acesso:</strong> Os links gerados são do ambiente protegido do Google AI Studio. Para convidar outras pessoas e autorizar o acesso delas ao sistema, clique no botão <strong className="text-slate-900">"Share" (Compartilhar)</strong> no canto superior direito do seu editor e adicione o e-mail Google delas.
                  </p>
                  <p>
                    👥 <strong className="text-[#1b365d]">Clientes Diferentes?</strong> Se você cadastrou clientes dentro do painel do editor, eles estão no banco temporário do editor. Para sincronizar, abra o link de <strong className="text-slate-900">Acesso Administrativo ao Sistema</strong> em uma nova aba do navegador e cadastre os clientes definitivos lá. Assim, tanto o painel administrativo quanto o portal de check-in usarão o mesmo banco de dados local!
                  </p>
                  <p>
                    ☁️ <strong className="text-emerald-700">Sincronização entre Dispositivos:</strong> Para usar o sistema ao mesmo tempo em computadores, celulares e tablets de funcionários ou clientes, utilize o menu lateral <strong className="text-emerald-800">Sincronização Google Sheets</strong> para espelhar todos os dados em nuvem via Google Drive automaticamente!
                  </p>
                </div>
              </div>

              {/* Modal Settings section to adjust Base URL */}
              <div className="mt-2 pt-3 border-t border-slate-200 flex flex-col gap-1.5 bg-[#f8fafc] p-3 rounded-xl border border-slate-300">
                <span className="text-[10px] font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Settings className="w-3.5 h-3.5 text-[#1b365d] animate-spin-slow" /> Ajustar Domínio / URL Base
                </span>
                <p className="text-[9px] text-slate-500 leading-normal font-medium">
                  Ajuste a URL base se os links acima copiarem como "null" ou usarem um domínio incorreto:
                </p>
                <input
                  type="text"
                  value={systemBaseUrl}
                  onChange={(e) => setSystemBaseUrl(e.target.value)}
                  placeholder="Ex: https://jcfsistemas.com"
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 focus:border-[#1b365d] rounded-lg text-slate-800 font-mono text-[10px] focus:outline-hidden shadow-inner"
                />
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between border-t border-slate-200 pt-3">
              <span className="text-[10px] text-slate-500 font-bold font-mono">JC&F INTEGRADO</span>
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-lg text-xs font-black uppercase tracking-wider cursor-pointer transition-colors"
              >
                Fechar
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Cloud & Multi-Account Synchronization Central Modal */}
      {showCloudSyncModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150" id="cloud-sync-modal">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs" onClick={() => setShowCloudSyncModal(false)}></div>

          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl border-2 border-[#b0bec5] p-6 flex flex-col space-y-5 my-6 max-h-[90vh] overflow-y-auto">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b-2 border-slate-200 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-blue-50 rounded-xl border border-blue-200 text-[#1b365d]">
                  <Cloud className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
                    <span>Sincronismo em Nuvem & Multi-Contas</span>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 border border-emerald-300 text-emerald-800">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      CONECTADO
                    </span>
                  </h3>
                  <span className="text-[10px] text-slate-500 font-medium block mt-0.5">
                    Banco de dados centralizado em nuvem sem alterar sua estrutura original
                  </span>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setShowCloudSyncModal(false)}
                className="p-1 hover:bg-slate-100 rounded text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Cloud Status Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="bg-[#f8fafc] p-3 rounded-xl border border-slate-300 flex flex-col justify-between shadow-2xs">
                <span className="text-[9px] font-black uppercase tracking-wider text-slate-500">Clientes Salvos</span>
                <span className="text-lg font-black text-[#1b365d] mt-1 font-mono">{clients.length}</span>
              </div>
              <div className="bg-[#f8fafc] p-3 rounded-xl border border-slate-300 flex flex-col justify-between shadow-2xs">
                <span className="text-[9px] font-black uppercase tracking-wider text-slate-500">Ordens de Serviço</span>
                <span className="text-lg font-black text-amber-600 mt-1 font-mono">{orders.length}</span>
              </div>
              <div className="bg-[#f8fafc] p-3 rounded-xl border border-slate-300 flex flex-col justify-between shadow-2xs">
                <span className="text-[9px] font-black uppercase tracking-wider text-slate-500">Equipamentos</span>
                <span className="text-lg font-black text-emerald-700 mt-1 font-mono">{equipments.length}</span>
              </div>
              <div className="bg-[#f8fafc] p-3 rounded-xl border border-slate-300 flex flex-col justify-between shadow-2xs">
                <span className="text-[9px] font-black uppercase tracking-wider text-slate-500">Último Sinc.</span>
                <span className="text-xs font-black text-slate-700 mt-1 font-mono">{lastServerSyncTimestamp || 'Agora'}</span>
              </div>
            </div>

            {/* Multi-Account & Multi-Device Access Link */}
            <div className="bg-[#f8fafc] p-4 rounded-xl border border-slate-300 space-y-2.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-[#1b365d]" />
                  <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                    Link de Acesso Global (Qualquer Conta ou Computador)
                  </h4>
                </div>
                <span className="text-[9px] bg-blue-100 text-[#1b365d] px-2 py-0.5 rounded border border-blue-300 font-mono font-bold">
                  Sincronizado
                </span>
              </div>
              <p className="text-[10px] text-slate-600 leading-normal font-medium">
                Para abrir este mesmo sistema e banco de dados em outro computador, celular ou conta diferente, acesse o link abaixo:
              </p>
              <div className="flex items-center gap-2 bg-white p-2.5 rounded-lg border border-slate-300 shadow-inner">
                <span className="text-[10px] font-mono text-[#1b365d] font-bold truncate flex-grow">
                  {systemBaseUrl.replace(/\/+$/, '')}
                </span>
                <button
                  type="button"
                  onClick={() => handleCopyLink(systemBaseUrl.replace(/\/+$/, ''), 'app')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase rounded cursor-pointer transition-all shadow-xs shrink-0"
                >
                  {copyFeedback === 'app' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-slate-950" />
                      <span>Copiado!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copiar Link</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Direct Sync Actions */}
            <div className="space-y-2">
              <span className="text-[10px] font-black text-slate-800 uppercase tracking-wider block">
                Ações de Sincronismo Imediato
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => pullLatestFromServer(true)}
                  disabled={syncStatus === 'SYNCING'}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 bg-white hover:bg-slate-50 border border-slate-300 text-[#1b365d] font-black text-xs rounded-xl cursor-pointer transition-all uppercase tracking-wider shadow-xs"
                >
                  <RefreshCw className={`w-4 h-4 text-[#1b365d] ${syncStatus === 'SYNCING' ? 'animate-spin' : ''}`} />
                  <span>Puxar Dados da Nuvem</span>
                </button>

                <button
                  type="button"
                  onClick={() => triggerServerSync(undefined, 'merge')}
                  disabled={syncStatus === 'SYNCING'}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl cursor-pointer transition-all uppercase tracking-wider shadow-xs"
                >
                  <Upload className="w-4 h-4 text-white" />
                  <span>Enviar Alterações para Nuvem</span>
                </button>
              </div>
            </div>

            {/* Backup & Recovery */}
            <div className="bg-[#f8fafc] p-4 rounded-xl border border-slate-300 space-y-3 shadow-2xs">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-amber-600" />
                <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                  Cópia de Segurança & Restauração (.JSON)
                </h4>
              </div>
              <p className="text-[10px] text-slate-600 leading-normal font-medium">
                Você pode fazer o download de uma cópia de segurança completa de todo o seu banco de dados ou restaurar um backup a qualquer momento.
              </p>
              <div className="flex flex-wrap gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={handleDownloadBackup}
                  className="flex items-center gap-2 px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 text-[10px] font-black uppercase rounded-lg cursor-pointer transition-all shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-[#1b365d]" />
                  <span>Baixar Backup Completo (.JSON)</span>
                </button>

                <label className="flex items-center gap-2 px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 text-[10px] font-black uppercase rounded-lg cursor-pointer transition-all shadow-2xs">
                  <Upload className="w-3.5 h-3.5 text-amber-600" />
                  <span>Restaurar de Arquivo JSON</span>
                  <input
                    type="file"
                    accept=".json,application/json"
                    onChange={handleRestoreBackupFile}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Multi-Account Guide */}
            <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl space-y-1.5 text-[10px] text-slate-700 shadow-2xs">
              <div className="flex items-center gap-1.5 text-[#1b365d] font-black uppercase text-[10px]">
                <Info className="w-3.5 h-3.5" />
                <span>Como funciona o sincronismo multi-contas:</span>
              </div>
              <ul className="list-disc pl-4 space-y-1 text-slate-600 font-medium">
                <li>O servidor central armazena todos os clientes, ordens e histórico de forma permanente no arquivo de banco de dados em nuvem.</li>
                <li>Qualquer pessoa ou computador que abrir o link compartilhado receberá imediatamente todas as ordens e clientes atualizados.</li>
                <li>O sistema faz verificação automática a cada poucos segundos, garantindo que novos cadastros e mudanças de status apareçam em tempo real para todos os usuários.</li>
              </ul>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between border-t border-slate-200 pt-3">
              <span className="text-[10px] text-slate-500 font-bold font-mono">JC&F SISTEMA DE GESTÃO INTEGRADA</span>
              <button
                type="button"
                onClick={() => setShowCloudSyncModal(false)}
                className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-lg text-xs font-black uppercase tracking-wider cursor-pointer transition-colors"
              >
                Fechar
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Quick New Client Modal (Tecla F2) */}
      <QuickNewClientModal
        isOpen={isQuickClientModalOpen}
        onClose={() => setIsQuickClientModalOpen(false)}
        onSaveClient={handleAddClient}
      />

      {/* Quick New Service Modal (Tecla F3) */}
      <QuickNewServiceModal
        isOpen={isQuickServiceModalOpen}
        onClose={() => setIsQuickServiceModalOpen(false)}
        onSaveService={handleAddService}
        existingServices={services}
      />

      {/* Quick New Equipment Modal (Tecla F4) */}
      <QuickNewEquipmentModal
        isOpen={isQuickEquipmentModalOpen}
        onClose={() => setIsQuickEquipmentModalOpen(false)}
        clients={clients}
        onSaveEquipment={handleAddEquipment}
      />

      {/* Price Table Modal (Tecla F7) */}
      <PriceTableModal
        isOpen={isPriceTableModalOpen}
        onClose={() => setIsPriceTableModalOpen(false)}
        services={services}
        inventory={inventory}
        onOpenNewService={() => {
          setIsPriceTableModalOpen(false);
          setIsQuickServiceModalOpen(true);
        }}
      />

    </div>
  );
}

