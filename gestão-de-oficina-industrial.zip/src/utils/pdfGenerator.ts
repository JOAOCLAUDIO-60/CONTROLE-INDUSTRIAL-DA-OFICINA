import { jsPDF } from 'jspdf';
import { Client, Equipment, ServiceOrder, PlannedService, Quote } from '../types';
import { JCF_COMPANY_INFO } from '../data/companyConfig';

export type PDFDocType = 'FICHA_ENTRADA' | 'ORCAMENTO' | 'LAUDO_TECNICO' | 'RECIBO_ENTREGA';

interface GeneratePDFParams {
  docType: PDFDocType;
  order: ServiceOrder;
  client: Client;
  equipment: Equipment;
}

/**
 * Draws the authentic JC&F brand logo faithfully matching image.png:
 * - Industrial gear arc in upper-right quadrant with 7 protruding radial teeth
 * - Monogram in classic serif typography with initials "J", "C", ampersand "&", and "F"
 * - Subtitle centered directly underneath: "MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA"
 */
export function drawJCFLogoVector(doc: jsPDF, cx: number, cy: number, scale: number = 1.0) {
  doc.setFillColor(0, 0, 0);
  doc.setDrawColor(0, 0, 0);

  const rOuter = 7.5 * scale;
  const rTooth = 9.8 * scale;

  // 1. Teeth (7 radial teeth along the top & right arc from ~10:30 to ~4:30)
  // Angles relative to top (-90°): -35°, -5°, +25°, +55°, +85°, +115°, +145°
  const toothAngles = [-35, -5, 25, 55, 85, 115, 145].map(deg => (deg - 90) * Math.PI / 180);
  
  toothAngles.forEach(angle => {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const x1 = cx + rOuter * cos;
    const y1 = cy + rOuter * sin;
    const x2 = cx + rTooth * cos;
    const y2 = cy + rTooth * sin;
    doc.setLineWidth(2.0 * scale);
    doc.line(x1, y1, x2, y2);
  });

  // 2. Solid Curved Gear Rim Arc
  doc.setLineWidth(2.4 * scale);
  const steps = 36;
  const startAng = (-38 - 90) * Math.PI / 180;
  const endAng = (150 - 90) * Math.PI / 180;
  for (let i = 0; i < steps; i++) {
    const a1 = startAng + (endAng - startAng) * (i / steps);
    const a2 = startAng + (endAng - startAng) * ((i + 1) / steps);
    doc.line(
      cx + rOuter * Math.cos(a1), 
      cy + rOuter * Math.sin(a1), 
      cx + rOuter * Math.cos(a2), 
      cy + rOuter * Math.sin(a2)
    );
  }

  // 3. Monogram (JC & F) in classic serif typography
  doc.setTextColor(0, 0, 0);
  doc.setFont('Times', 'bold');
  doc.setFontSize(10 * scale);
  doc.text('J', cx - (4.2 * scale), cy - (0.3 * scale));
  doc.text('C', cx + (0.2 * scale), cy - (0.5 * scale));

  doc.setFont('Times', 'italic');
  doc.setFontSize(6.2 * scale);
  doc.text('&', cx - (1.8 * scale), cy + (3.6 * scale));

  doc.setFont('Times', 'bold');
  doc.setFontSize(9.8 * scale);
  doc.text('F', cx + (1.4 * scale), cy + (4.0 * scale));

  // 4. Subtitle: MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(3.6 * scale);
  const subText = 'MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA';
  const subWidth = doc.getTextWidth(subText);
  doc.text(subText, cx - (subWidth / 2), cy + (11.8 * scale));
}

/**
 * Generates and downloads a highly styled PDF document with JC&F brand styling.
 */
export function generatePDF({ docType, order, client, equipment }: GeneratePDFParams) {
  // Create a new A4 document in portrait mode
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Margins & Dimensions
  const startX = 15;
  let currentY = 15;
  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const usableWidth = pageWidth - (startX * 2); // 180mm

  // Helper to draw horizontal dividers
  const drawDivider = (y: number, color = [200, 200, 200], thickness = 0.5) => {
    doc.setDrawColor(color[0], color[1], color[2]);
    doc.setLineWidth(thickness);
    doc.line(startX, y, pageWidth - startX, y);
  };

  // Helper to draw a solid section header
  const drawSectionHeader = (title: string, y: number) => {
    doc.setFillColor(241, 245, 249); // light slate background
    doc.rect(startX, y, usableWidth, 7, 'F');
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85); // slate-700
    doc.text(title.toUpperCase(), startX + 3, y + 5);
    return y + 11;
  };

  // 1. BRAND HEADER (OFFICIAL LOGO & ADDRESS)
  drawJCFLogoVector(doc, 26, 18, 1.05);

  // Corporate Text Info (Right Side of Header)
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(12.5);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text('JC&F – MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA', 48, 18);

  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105); // slate-600
  doc.text('Rua Luís Bom, Nº 16 – Campo Grande – Rio de Janeiro – RJ', 48, 23);
  doc.text('CNPJ: 25.452.856/0001-29  |  Tel: (21) 98369-9728  |  E-mail: jcfrj2017@gmail.com', 48, 28);

  currentY = 38;
  drawDivider(currentY, [148, 163, 184], 0.8); // elegant slate divider
  currentY += 6;

  // 2. DOCUMENT TITLE & GENERAL METADATA
  let docTitle = '';
  switch (docType) {
    case 'FICHA_ENTRADA':
      docTitle = 'FICHA DE ENTRADA DE EQUIPAMENTO (CHECK-IN)';
      break;
    case 'ORCAMENTO':
      docTitle = 'ORÇAMENTO TÉCNICO DE MANUTENÇÃO';
      break;
    case 'LAUDO_TECNICO':
      docTitle = 'LAUDO TÉCNICO & RELATÓRIO DE SERVIÇO';
      break;
    case 'RECIBO_ENTREGA':
      docTitle = 'COMPROVANTE DE ENTREGA & CERTIFICADO DE GARANTIA';
      break;
  }

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text(docTitle, startX, currentY);

  // Document Number & Date on right
  const formattedDate = new Date().toLocaleDateString('pt-BR');
  doc.setFont('Helvetica', 'mono');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  const osText = `Nº OS: ${order.osNumber}`;
  const dateText = `Data de Emissão: ${formattedDate}`;
  doc.text(osText, pageWidth - startX - doc.getTextWidth(osText), currentY - 1);
  doc.text(dateText, pageWidth - startX - doc.getTextWidth(dateText), currentY + 3.5);

  currentY += 8;
  drawDivider(currentY, [226, 232, 240], 0.5);
  currentY += 5;

  // 3. CLIENT INFO BLOCK
  currentY = drawSectionHeader('Dados do Cliente', currentY);
  
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text('Cliente / Razão Social:', startX + 3, currentY);
  doc.text('CPF / CNPJ:', startX + 110, currentY);

  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(client.name || 'N/A', startX + 38, currentY);
  doc.text(client.document || 'N/A', startX + 132, currentY);

  currentY += 5.5;

  doc.setFont('Helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Endereço completo:', startX + 3, currentY);
  doc.text('Telefone:', startX + 110, currentY);

  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(client.address || 'Não Informado', startX + 38, currentY);
  doc.text(client.phone || 'N/A', startX + 127, currentY);

  currentY += 9;

  // 4. EQUIPMENT INFO BLOCK
  currentY = drawSectionHeader('Identificação do Equipamento', currentY);

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text('Equipamento:', startX + 3, currentY);
  doc.text('Série / Modelo:', startX + 110, currentY);

  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(equipment.name || 'N/A', startX + 28, currentY);
  doc.text(equipment.model || 'N/A', startX + 136, currentY);

  currentY += 5.5;

  doc.setFont('Helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Tipo de Sistema:', startX + 3, currentY);
  doc.text('Recebedor Entrada:', startX + 110, currentY);

  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(equipment.type || 'Hidráulico', startX + 33, currentY);
  doc.text(order.receiverName || order.technician || 'João Carlos', startX + 145, currentY);

  currentY += 9;

  // Helper to draw formatted paragraphs in a styled card container
  const drawContentCard = (label: string, text: string, boxHeightEstimate: number) => {
    // Avoid page overflow
    if (currentY + boxHeightEstimate + 12 > pageHeight) {
      doc.addPage();
      currentY = 20;
    }

    currentY = drawSectionHeader(label, currentY);
    
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(15, 23, 42);

    const splitText = doc.splitTextToSize(text || 'Nenhum registro cadastrado.', usableWidth - 6);
    let lineY = currentY;
    
    // Draw text lines
    splitText.forEach((line: string) => {
      if (lineY + 5 > pageHeight - 25) {
        doc.addPage();
        lineY = 20;
      }
      doc.text(line, startX + 3, lineY);
      lineY += 4.5;
    });

    currentY = lineY + 5;
  };

  // 5. SPECIFIC DOCUMENT TYPE SECTIONS
  if (docType === 'FICHA_ENTRADA') {
    // Problem details
    drawContentCard('Reclamação Relatada / Estado Geral na Entrada', order.description, 30);

    // Initial estimation or costs
    if (currentY + 25 > pageHeight) {
      doc.addPage();
      currentY = 20;
    }
    
    doc.setFillColor(248, 250, 252);
    doc.rect(startX, currentY, usableWidth, 14, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(startX, currentY, usableWidth, 14, 'S');

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text('Estimativa de Custo Inicial:', startX + 5, currentY + 8);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(22, 101, 52); // emerald-800
    const costText = order.estimatedCost > 0 
      ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(order.estimatedCost)
      : 'Sob Orçamento (Análise Detalhada)';
    doc.text(costText, startX + 52, currentY + 8.5);

    currentY += 22;

  } else if (docType === 'ORCAMENTO') {
    // Technical diagnostics (Laudo Técnico)
    drawContentCard('Diagnóstico Técnico Detalhado', order.diagnostic || 'Análise física concluída, equipamento desmontado e avaliado.', 25);
    
    // Services and Parts Planned (Serviços Planejados)
    drawContentCard('Peças & Serviços Propostos', order.plannedServices || 'Substituição do kit de vedação, brunimento e banho químico.', 35);

    // Cost details and status
    if (currentY + 25 > pageHeight) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFillColor(248, 250, 252);
    doc.rect(startX, currentY, usableWidth, 16, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(startX, currentY, usableWidth, 16, 'S');

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(71, 85, 105);
    doc.text('VALOR TOTAL DO ORÇAMENTO:', startX + 5, currentY + 10);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42); // dark
    const cost = order.estimatedCost || 0;
    const costText = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cost);
    doc.text(costText, startX + 63, currentY + 10.5);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('* Orçamento válido por 10 dias úteis. Sujeito à aprovação formal do cliente.', startX + 5, currentY + 14.5);

    currentY += 24;

    // CONDIÇÕES GERAIS DE SERVIÇO
    if (currentY + 45 > pageHeight) {
      doc.addPage();
      currentY = 20;
    }

    currentY = drawSectionHeader('Condições Gerais de Serviço', currentY);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105); // slate-600

    const conditions = [
      "1. O orçamento será executado somente após a autorização do cliente.",
      "2. Os equipamentos serão entregues mediante a quitação integral dos serviços, peças e demais despesas relacionadas.",
      "3. A garantia cobre exclusivamente os serviços executados e as peças fornecidas pela JC&F Manutenção, não abrangendo mau uso, quedas, sobrecargas, instalações inadequadas ou intervenções de terceiros.",
      "4. Após a comunicação da conclusão do serviço, o cliente deverá retirar o equipamento em até 90 (noventa) dias.",
      "5. Equipamentos não retirados dentro do prazo de 90 (noventa) dias estarão sujeitos à cobrança de taxa de armazenagem no valor de R$ 0,50 (cinquenta centavos) por dia, por equipamento.",
      "6. Os valores de armazenagem deverão ser pagos juntamente com os demais débitos existentes antes da retirada do equipamento.",
      "7. Ao autorizar o serviço, o cliente declara estar ciente e de acordo com as condições acima."
    ];

    conditions.forEach((cond) => {
      const splitLines = doc.splitTextToSize(cond, usableWidth - 6);
      splitLines.forEach((line: string) => {
        if (currentY + 5 > pageHeight - 25) {
          doc.addPage();
          currentY = 20;
        }
        doc.text(line, startX + 3, currentY);
        currentY += 3.8;
      });
      currentY += 1.2; // space between items
    });

    currentY += 5;

  } else if (docType === 'LAUDO_TECNICO') {
    // Technical Diagnostics
    drawContentCard('Diagnóstico Técnico Inicial', order.diagnostic || 'Avaliado desgaste mecânico e perda de eficiência.', 20);

    // Performed Services
    drawContentCard('Serviços Efetivamente Executados', order.actualServicesPerformed || 'Nenhum registro cadastrado.', 30);

    // Consumed Materials
    drawContentCard('Materiais / Peças de Reposição Utilizadas', order.materialsUsed || 'Nenhum registro cadastrado.', 30);

    // Financial detail
    if (currentY + 20 > pageHeight) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFillColor(248, 250, 252);
    doc.rect(startX, currentY, usableWidth, 14, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(startX, currentY, usableWidth, 14, 'S');

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(71, 85, 105);
    doc.text('CUSTO TOTAL DA MANUTENÇÃO:', startX + 5, currentY + 8.5);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    const finalCost = order.actualCost || order.estimatedCost || 0;
    const costText = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(finalCost);
    doc.text(costText, startX + 63, currentY + 9);

    currentY += 22;

  } else if (docType === 'RECIBO_ENTREGA') {
    // Performed Services & Materials
    drawContentCard('Resumo Técnico dos Serviços Efetuados', order.actualServicesPerformed || 'Serviço de manutenção mecânica.', 20);
    drawContentCard('Materiais Utilizados', order.materialsUsed || 'Peças e vedações de reposição.', 20);

    // Cost
    if (currentY + 16 > pageHeight) {
      doc.addPage();
      currentY = 20;
    }
    doc.setFillColor(248, 250, 252);
    doc.rect(startX, currentY, usableWidth, 10, 'F');
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text('VALOR PAGO DA OS:', startX + 5, currentY + 6.5);
    doc.setFont('Helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    const finalCost = order.actualCost || order.estimatedCost || 0;
    const costText = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(finalCost);
    doc.text(costText, startX + 42, currentY + 6.5);
    currentY += 14;

    // Termo de Garantia Card
    if (currentY + 45 > pageHeight) {
      doc.addPage();
      currentY = 20;
    }

    currentY = drawSectionHeader('Certificado de Garantia do Serviço', currentY);

    doc.setFillColor(240, 253, 244); // light green bg
    doc.rect(startX, currentY, usableWidth, 26, 'F');
    doc.setDrawColor(187, 247, 208);
    doc.rect(startX, currentY, usableWidth, 26, 'S');

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(21, 128, 61); // green-700
    doc.text('Prazo Legal/Técnico de Garantia:', startX + 5, currentY + 7);
    doc.text('Vencimento do Termo:', startX + 110, currentY + 7);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    const wDays = order.warrantyDays !== undefined ? order.warrantyDays : 90;
    doc.text(`${wDays} Dias`, startX + 60, currentY + 7);

    const delDate = order.deliveryDate || new Date().toISOString().split('T')[0];
    const expiryDate = order.originalWarrantyExpirationDate 
      ? new Date(order.originalWarrantyExpirationDate + 'T12:00:00').toLocaleDateString('pt-BR')
      : new Date(new Date(delDate).getTime() + wDays * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR');
    
    doc.text(expiryDate, startX + 148, currentY + 7);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text('Termos e condições de garantia:', startX + 5, currentY + 13.5);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    
    const baseNotes = order.warrantyNotes ? `${order.warrantyNotes} ` : '';
    const policyClause = 'Garantia concedida sobre o serviço. Se o equipamento retornar em garantia, o prazo original permanece inalterado, não sendo prorrogado, renovado ou reiniciado por intervenções corretivas cobertas.';
    const fullText = baseNotes + policyClause;
    const splitNotes = doc.splitTextToSize(fullText, usableWidth - 10);
    
    let noteY = currentY + 17.5;
    splitNotes.slice(0, 2).forEach((line: string) => {
      doc.text(line, startX + 5, noteY);
      noteY += 3.5;
    });

    currentY += 34;
  }

  // 6. OFFICIAL SIGNATURE BLOCKS
  if (currentY + 35 > pageHeight) {
    doc.addPage();
    currentY = 20;
  } else {
    currentY += 6;
  }

  const sigY = currentY + 20;
  doc.setLineWidth(0.5);
  doc.setDrawColor(148, 163, 184); // slate-300

  // Line 1: JC&F Representative
  doc.line(startX + 10, sigY, startX + 75, sigY);
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text('JC&F MANUTENÇÃO', startX + 22, sigY + 4);
  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text('Assinatura do Técnico Responsável', startX + 18, sigY + 8);

  // Line 2: Client/Owner
  doc.line(pageWidth - startX - 75, sigY, pageWidth - startX - 10, sigY);
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text(client.name.substring(0, 30).toUpperCase(), pageWidth - startX - 68, sigY + 4);
  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text('Assinatura do Cliente / Recebedor', pageWidth - startX - 65, sigY + 8);

  // Footer metadata
  doc.setFont('Helvetica', 'italic');
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  const systemFooter = 'Documento oficial gerado eletronicamente por JC&F Manutenção. Obrigado!';
  doc.text(systemFooter, (pageWidth - doc.getTextWidth(systemFooter)) / 2, pageHeight - 8);

  // Save/Download File
  const cleanDocName = docTitle.toLowerCase().replace(/[^a-z0-9]/g, '_');
  doc.save(`${order.osNumber}_${cleanDocName}.pdf`);
}

/**
 * Generates and downloads a clean A4 PDF of the pre-defined Maintenance Price Table.
 */
export function generatePriceTablePDF(services: PlannedService[]) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const startX = 15;
  let currentY = 15;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const usableWidth = pageWidth - (startX * 2);

  // Corporate Header with Official Logo
  drawJCFLogoVector(doc, 26, 18, 0.95);

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text('JC&F - MANUTENÇÃO HIDRÁULICA E PNEUMÁTICA', 48, 17);

  doc.setFontSize(8.5);
  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Tabela Oficial de Preços de Serviços de Manutenção • Tabela Vigente', 48, 22);
  doc.text(`Data da Emissão: ${new Date().toLocaleDateString('pt-BR')}`, 48, 27);

  currentY = 34;

  // Divider line
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.5);
  doc.line(startX, currentY, pageWidth - startX, currentY);
  currentY += 6;

  // Table Header
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(startX, currentY, usableWidth, 8, 'F');
  
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text('CÓDIGO', startX + 3, currentY + 5.5);
  doc.text('SERVIÇO DE MANUTENÇÃO / ESCOPO TÉCNICO', startX + 28, currentY + 5.5);
  doc.text('PREÇO (R$)', startX + usableWidth - 25, currentY + 5.5);

  currentY += 10;

  services.forEach((s, idx) => {
    // Check page overflow
    if (currentY + 22 > pageHeight - 15) {
      doc.addPage();
      currentY = 20;

      // Repeat Table Header
      doc.setFillColor(30, 41, 59);
      doc.rect(startX, currentY, usableWidth, 8, 'F');
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(255, 255, 255);
      doc.text('CÓDIGO', startX + 3, currentY + 5.5);
      doc.text('SERVIÇO DE MANUTENÇÃO / ESCOPO TÉCNICO', startX + 28, currentY + 5.5);
      doc.text('PREÇO (R$)', startX + usableWidth - 25, currentY + 5.5);
      currentY += 10;
    }

    // Row background toggle
    if (idx % 2 === 0) {
      doc.setFillColor(248, 250, 252);
      doc.rect(startX, currentY - 2, usableWidth, 18, 'F');
    }

    // Border line
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.2);
    doc.rect(startX, currentY - 2, usableWidth, 18, 'S');

    // Service Code
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(16, 185, 129); // emerald green
    doc.text(s.code, startX + 3, currentY + 3);

    // Category / Unit if available
    if (s.category) {
      doc.setFontSize(7);
      doc.setTextColor(100, 116, 139);
      doc.text(`[${s.category}]`, startX + 3, currentY + 7.5);
    }

    // Service Name & Description
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(15, 23, 42);
    doc.text(s.name, startX + 28, currentY + 3);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    const splitDesc = doc.splitTextToSize(s.description, 115);
    doc.text(splitDesc.slice(0, 2), startX + 28, currentY + 7.5);

    // Price
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    const priceText = `R$ ${s.estimatedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    doc.text(priceText, startX + usableWidth - 25, currentY + 5);

    currentY += 20;
  });

  // Footer
  doc.setFont('Helvetica', 'italic');
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  const footerText = 'Tabela de preços de manutenção predefinida - JC&F Manutenção Hidráulica e Pneumática';
  doc.text(footerText, (pageWidth - doc.getTextWidth(footerText)) / 2, pageHeight - 8);

  doc.save('tabela_de_precos_manutencao_jcf.pdf');
}

/**
 * Generates an official, highly calibrated single-page (or clean multi-page) A4 PDF
 * for commercial quotes / proposals with vector logo, compact table, totals, conditions and signatures.
 */
export function generateQuotePDF(quote: Quote) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const startX = 12;
  const usableWidth = pageWidth - (startX * 2); // 186mm
  let currentY = 10;
  let pageNumber = 1;

  const drawHeader = () => {
    // Official JC&F Brand Logo (Gear Arc + Serif Monogram + Subtitle)
    drawJCFLogoVector(doc, 22, 15.5, 0.88);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text(JCF_COMPANY_INFO.name, 36, 14);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    doc.text(JCF_COMPANY_INFO.address, 36, 18);
    doc.text(`CNPJ: ${JCF_COMPANY_INFO.cnpj}  |  Tel: ${JCF_COMPANY_INFO.phone}  |  E-mail: ${JCF_COMPANY_INFO.email}`, 36, 22);

    // Right side: Proposal Number & Dates
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(27, 54, 93);
    const numText = quote.quoteNumber;
    doc.text(numText, pageWidth - startX - doc.getTextWidth(numText), 14);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(7.5);
    const typeLabel = {
      VENDA: 'VENDA DE PEÇAS',
      MANUTENCAO_CORRETIVA: 'MANUTENÇÃO CORRETIVA',
      MANUTENCAO_PREVENTIVA: 'MANUTENÇÃO PREVENTIVA',
      REVISAO_GERAL: 'REFORMA / REVISÃO',
      OUTROS: 'SERVIÇOS TÉCNICOS'
    }[quote.quoteType || 'MANUTENCAO_CORRETIVA'];
    doc.setTextColor(100, 116, 139);
    doc.text(typeLabel, pageWidth - startX - doc.getTextWidth(typeLabel), 18);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(7.5);
    const dateStr = `Emissão: ${new Date(quote.date + 'T12:00:00').toLocaleDateString('pt-BR')}  |  Validade: ${new Date(quote.validUntil + 'T12:00:00').toLocaleDateString('pt-BR')}`;
    doc.text(dateStr, pageWidth - startX - doc.getTextWidth(dateStr), 22);

    // Divider
    doc.setDrawColor(27, 54, 93);
    doc.setLineWidth(0.8);
    doc.line(startX, 28, pageWidth - startX, 28);
    currentY = 31;
  };

  drawHeader();

  // 2. Client & Target Asset (2 boxes side by side)
  const boxWidth = (usableWidth - 4) / 2; // 91mm
  const boxHeight = 22;

  // Client Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.rect(startX, currentY, boxWidth, boxHeight, 'FD');

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text('DADOS DO CLIENTE / SOLICITANTE', startX + 3, currentY + 4);

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  const splitClient = doc.splitTextToSize(quote.clientName, boxWidth - 6);
  doc.text(splitClient[0] || '', startX + 3, currentY + 8.5);

  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  let cY = currentY + 12.5;
  if (quote.clientDocument) {
    doc.text(`CNPJ/CPF: ${quote.clientDocument}`, startX + 3, cY);
    cY += 3.8;
  }
  const contactText = [quote.clientPhone ? `Tel: ${quote.clientPhone}` : '', quote.clientEmail ? `E-mail: ${quote.clientEmail}` : ''].filter(Boolean).join('  |  ');
  if (contactText) {
    doc.text(contactText, startX + 3, cY);
    cY += 3.8;
  }
  if (quote.clientAddress && cY <= currentY + boxHeight - 2) {
    doc.text(doc.splitTextToSize(`End: ${quote.clientAddress}`, boxWidth - 6)[0] || '', startX + 3, cY);
  }

  // Equipment Box
  const equipX = startX + boxWidth + 4;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.rect(equipX, currentY, boxWidth, boxHeight, 'FD');

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text('ATIVO AVALIADO / APLICAÇÃO', equipX + 3, currentY + 4);

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  const equipName = quote.equipmentName || 'Venda Direta / Balcão de Peças';
  doc.text(doc.splitTextToSize(equipName, boxWidth - 6)[0] || '', equipX + 3, currentY + 8.5);

  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Responsável Técnico: ${quote.technicianName || 'Depto. Técnico JC&F'}`, equipX + 3, currentY + 13);
  doc.text('Equipamento testado em bancada de alta pressão', equipX + 3, currentY + 17);

  currentY += boxHeight + 4;

  // 3. Table of Items
  const colW = {
    idx: 8,
    type: 18,
    desc: 88,
    qty: 14,
    unit: 12,
    price: 23,
    total: 23
  };

  const drawTableHeader = (y: number) => {
    doc.setFillColor(241, 245, 249);
    doc.setDrawColor(203, 213, 225);
    doc.rect(startX, y, usableWidth, 6, 'FD');

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(51, 65, 85);
    doc.text('#', startX + 3, y + 4.2);
    doc.text('TIPO', startX + colW.idx + 2, y + 4.2);
    doc.text('DESCRIÇÃO DO ITEM / SERVIÇO', startX + colW.idx + colW.type + 2, y + 4.2);
    doc.text('QTD', startX + colW.idx + colW.type + colW.desc + 2, y + 4.2);
    doc.text('UNID', startX + colW.idx + colW.type + colW.desc + colW.qty + 2, y + 4.2);
    doc.text('UNITÁRIO', startX + colW.idx + colW.type + colW.desc + colW.qty + colW.unit + colW.price - 2 - doc.getTextWidth('UNITÁRIO'), y + 4.2);
    doc.text('TOTAL (R$)', startX + usableWidth - 2 - doc.getTextWidth('TOTAL (R$)'), y + 4.2);
    return y + 6;
  };

  currentY = drawTableHeader(currentY);

  // Rows
  quote.items.forEach((item, index) => {
    // Check page overflow
    if (currentY + 12 > pageHeight - 65) {
      doc.addPage();
      pageNumber++;
      drawHeader();
      currentY = drawTableHeader(currentY);
    }

    const rowBg = index % 2 === 0 ? [255, 255, 255] : [248, 250, 252];
    doc.setFillColor(rowBg[0], rowBg[1], rowBg[2]);
    doc.setDrawColor(226, 232, 240);

    const descLines = doc.splitTextToSize(item.description || '', colW.desc - 4);
    const rowHeight = Math.max(5.5, descLines.length * 3.5 + 2);

    doc.rect(startX, currentY, usableWidth, rowHeight, 'FD');

    // #
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(String(index + 1), startX + 3, currentY + 3.8);

    // Tipo
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(item.type === 'PECA' ? 180 : 30, item.type === 'PECA' ? 83 : 64, item.type === 'PECA' ? 9 : 175);
    doc.text(item.type || 'ITEM', startX + colW.idx + 2, currentY + 3.8);

    // Desc
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(15, 23, 42);
    doc.text(descLines, startX + colW.idx + colW.type + 2, currentY + 3.8);

    // Qtd & Unid
    doc.setFont('Helvetica', 'bold');
    doc.text(String(item.quantity), startX + colW.idx + colW.type + colW.desc + 4, currentY + 3.8);
    doc.setFont('Helvetica', 'normal');
    doc.text(item.unit || 'UN', startX + colW.idx + colW.type + colW.desc + colW.qty + 3, currentY + 3.8);

    // Prices
    const priceText = item.unitPrice.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const totalText = item.total.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    doc.text(priceText, startX + colW.idx + colW.type + colW.desc + colW.qty + colW.unit + colW.price - 2 - doc.getTextWidth(priceText), currentY + 3.8);

    doc.setFont('Helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(totalText, startX + usableWidth - 2 - doc.getTextWidth(totalText), currentY + 3.8);

    currentY += rowHeight;
  });

  currentY += 2.5;

  // Check if totals + conditions + signatures fit on this page, else break cleanly
  if (currentY + 55 > pageHeight - 15) {
    doc.addPage();
    pageNumber++;
    drawHeader();
  }

  // 4. Totals Box (Right Aligned)
  const totalsWidth = 68;
  const totalsX = startX + usableWidth - totalsWidth;
  const totalsHeight = quote.discount > 0 ? 16 : 12;

  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.rect(totalsX, currentY, totalsWidth, totalsHeight, 'FD');

  let totY = currentY + 3.6;
  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text('Subtotal Bruto:', totalsX + 3, totY);
  const subText = `R$ ${quote.subtotal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  doc.text(subText, totalsX + totalsWidth - 3 - doc.getTextWidth(subText), totY);

  if (quote.discount > 0) {
    totY += 3.8;
    doc.setTextColor(22, 101, 52);
    doc.text('Desconto Comercial:', totalsX + 3, totY);
    const descText = `- R$ ${quote.discount.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    doc.text(descText, totalsX + totalsWidth - 3 - doc.getTextWidth(descText), totY);
  }

  totY += 4.2;
  doc.setDrawColor(203, 213, 225);
  doc.line(totalsX + 3, totY - 1.2, totalsX + totalsWidth - 3, totY - 1.2);
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text('TOTAL LÍQUIDO:', totalsX + 3, totY + 0.8);
  const finalTotText = `R$ ${quote.total.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  doc.setFontSize(9.5);
  doc.setTextColor(27, 54, 93);
  doc.text(finalTotText, totalsX + totalsWidth - 3 - doc.getTextWidth(finalTotText), totY + 0.8);

  currentY += totalsHeight + 3.5;

  // 5. Commercial Conditions (4 boxes side-by-side)
  const condW = (usableWidth - 6) / 4; // ~45mm each
  const condH = 17;

  const conditions = [
    { title: 'CONDIÇÕES DE PAGAMENTO', val: quote.paymentTerms, sub: `PIX: ${JCF_COMPANY_INFO.pixKey}` },
    { title: 'PRAZO DE ENTREGA', val: quote.deliveryTime, sub: 'Após aprovação formal' },
    { title: 'GARANTIA CONTRATUAL', val: quote.warrantyTerms, sub: 'Conforme termo da oficina' },
    { title: 'OBSERVAÇÕES', val: quote.notes || 'Equipamento testado em bancada.', sub: '' }
  ];

  conditions.forEach((c, idx) => {
    const cX = startX + idx * (condW + 2);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.rect(cX, currentY, condW, condH, 'FD');

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(c.title, cX + 2.5, currentY + 3.5);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(15, 23, 42);
    const splitVal = doc.splitTextToSize(c.val || '', condW - 5);
    doc.text(splitVal.slice(0, 2), cX + 2.5, currentY + 7.2);

    if (c.sub) {
      doc.setFont('Helvetica', 'normal');
      doc.setFontSize(6);
      doc.setTextColor(71, 85, 105);
      doc.text(doc.splitTextToSize(c.sub, condW - 5)[0] || '', cX + 2.5, currentY + 14);
    }
  });

  currentY += condH + 5;

  // 6. Signatures (2 columns)
  const sigW = 75;
  const sig1X = startX + 10;
  const sig2X = startX + usableWidth - sigW - 10;

  doc.setDrawColor(148, 163, 184);
  doc.setLineWidth(0.4);
  doc.line(sig1X, currentY + 7, sig1X + sigW, currentY + 7);
  doc.line(sig2X, currentY + 7, sig2X + sigW, currentY + 7);

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  const jcfSignTitle = JCF_COMPANY_INFO.name;
  doc.text(jcfSignTitle, sig1X + (sigW - doc.getTextWidth(jcfSignTitle)) / 2, currentY + 10.5);
  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Departamento Técnico & Comercial', sig1X + (sigW - doc.getTextWidth('Departamento Técnico & Comercial')) / 2, currentY + 13.8);

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  const clientSignTitle = quote.clientName;
  doc.text(clientSignTitle, sig2X + (sigW - doc.getTextWidth(clientSignTitle)) / 2, currentY + 10.5);
  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Aceite do Cliente / Assinatura em ___/___/______', sig2X + (sigW - doc.getTextWidth('Aceite do Cliente / Assinatura em ___/___/______')) / 2, currentY + 13.8);

  // Footer: page numbers
  const totalPages = pageNumber;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(148, 163, 184);
    const footText = `Documento emitido eletronicamente - JC&F Manutenção Hidráulica e Pneumática  |  Página ${i} de ${totalPages}`;
    doc.text(footText, (pageWidth - doc.getTextWidth(footText)) / 2, pageHeight - 6);
  }

  // Download file
  const safeClient = (quote.clientName || 'Cliente').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 20);
  doc.save(`Orcamento_${quote.quoteNumber}_${safeClient}.pdf`);
}
