export interface Client {
  id: string;
  name: string;
  document: string; // CPF or CNPJ
  address: string;
  phone: string;
  email?: string;
  activity?: string; // Ramo / Atividade de atuação do cliente
  createdAt: string;
  updatedAt?: string;
}

export interface Equipment {
  id: string;
  name: string;
  model: string;
  type: string;
  clientId?: string; // Owner of the equipment
  patrimonyNumber?: string; // Número de Patrimônio (Asset Tag)
  createdAt: string;
  updatedAt?: string;
}

export type OSStatus = 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';

export interface ServiceOrder {
  id: string;
  osNumber: string; // e.g. "OS-1001"
  clientId: string;
  equipmentId: string;
  patrimonyNumber?: string; // Número de Patrimônio / Tag / Filial do equipamento na entrada
  title: string;
  description: string;
  status: OSStatus;
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  technician: string;
  attendanceType?: string; // Característica do Atendimento: Oficina Interna, Em Campo/Externo, Garantia, Emergencial, etc.
  receiverName?: string; // Nome da pessoa/atendente recebedora do equipamento na entrada
  estimatedCost: number;
  startDate: string;
  endDate?: string;
  equipmentPhoto?: string; // Base64 or URL representation of the arriving equipment
  warrantyDays?: number; // Warranty period in days (e.g. 30, 90, 180)
  warrantyNotes?: string; // Optional warranty details or terms
  budgetStatus?: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED'; // Status of the budget approval
  budgetDate?: string; // Date when budget/diagnostic was generated or updated
  diagnostic?: string; // Checked condition of the equipment
  plannedServices?: string; // Services and parts that will be executed
  actualServicesPerformed?: string; // What was actually performed during execution (Step 3)
  materialsUsed?: string; // Materials/parts consumed during execution (Step 3)
  materialsUsedList?: { itemId: string; name: string; code: string; quantity: number; salePrice: number }[];
  actualCost?: number; // Real cost of the maintenance (Step 3)
  executionDate?: string; // Date when maintenance execution was recorded
  isDelivered?: boolean; // Whether the equipment was delivered to the client
  deliveryDate?: string; // Date when the equipment was delivered
  deliveryPhoto?: string; // Photo of the equipment after maintenance (checkout photo)
  paymentMethod?: string; // Payment method (e.g., PIX, Cartão, Dinheiro, Boleto)
  paymentStatus?: 'PENDING' | 'PAID'; // Receipt status
  orderType?: 'SERVICE' | 'WARRANTY'; // Type of service order: Serviço or Garantia
  parentOSId?: string; // ID of primary OS if this is a warranty return
  parentOSNumber?: string; // Number of primary OS (e.g. OS-1001)
  originalWarrantyStartDate?: string; // Start date of original warranty (does not reset)
  originalWarrantyExpirationDate?: string; // Original expiration date (remains unchanged on warranty returns)
  isDuplicateAuthorized?: boolean; // Flag indicating explicit user authorization for duplicate equipment OS
  duplicateNote?: string; // Authorization note when client brings 2 identical machines
  createdAt: string;
  updatedAt?: string;
}

export interface MaintenanceHistoryEntry {
  id: string;
  equipmentId: string;
  serviceOrderId?: string; // Optional reference to the OS
  date: string; // Date of the service
  serviceType: string; // Type of service performed
  partsUsed: string; // Parts used
  technician: string; // Responsible technician
  createdAt: string;
  updatedAt?: string;
}

export type FinancialType = 'PAYABLE' | 'RECEIVABLE';
export type FinancialStatus = 'PENDING' | 'PAID' | 'OVERDUE';

export interface FinancialTransaction {
  id: string;
  type: FinancialType;
  description: string;
  amount: number;
  dueDate: string;
  paymentDate?: string;
  category: string; // e.g., 'Peças', 'Mão de Obra', 'Aluguel', 'Salário', 'Utilidades', 'Outros'
  status: FinancialStatus;
  notes?: string;
  serviceOrderId?: string; // Optional reference to a Service Order if applicable
  createdAt: string;
  updatedAt?: string;
}

export interface TechnicalDiagnostic {
  id: string;
  code: string; // e.g. "DIAG-001"
  title: string; // e.g. "Vazamento no Cilindro Hidráulico"
  description: string; // Pre-filled description template
  createdAt: string;
  updatedAt?: string;
}

export interface PlannedService {
  id: string;
  code: string; // e.g. "SERV-001"
  name: string; // e.g. "Brunimento e Troca de Selos"
  description: string; // Action description
  estimatedCost: number; // Suggested default cost
  category?: string; // e.g. "Hidráulica", "Pneumática", "Mecânica", "Usinagem"
  unit?: string; // e.g. "UN", "Hora", "Serviço", "Verba"
  createdAt: string;
  updatedAt?: string;
}

export interface Technician {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  email: string;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  updatedAt?: string;
}

export interface InventoryItem {
  id: string;
  code: string; // e.g., 'PART-1001'
  name: string;
  category: string; // e.g., 'Retentores', 'Óleo Hidráulico', 'Válvulas', 'Mangueiras', 'Outros'
  quantity: number;
  minimumStock: number;
  purchasePrice: number;
  salePrice: number;
  unit: string; // e.g., 'un', 'litro', 'metro', 'jogo'
  location?: string; // e.g., 'Estante B, Prateleira 3'
  supplier?: string;
  description?: string;
  possibleApplications?: string; // e.g., 'Cilindros de retro, prensa hidráulica Parker, etc'
  imageUrl?: string; // e.g., URL or base64 image data
  createdAt: string;
}

export interface MaterialGroup {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  cnpjOrCpf?: string;
  phone?: string;
  email?: string;
  address?: string;
  createdAt: string;
}

export interface InventoryMovement {
  id: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  type: 'INPUT' | 'OUTPUT'; // INPUT = Entrada, OUTPUT = Saída
  quantity: number;
  price: number; // Purchase price for INPUT, sale price/cost for OUTPUT
  description?: string; // Reason / order reference
  supplier?: string; // Relevant for inputs
  date: string;
  createdAt: string;
}

export interface PhysicalInventory {
  id: string;
  title: string;
  date: string;
  status: 'DRAFT' | 'COMPLETED';
  items: {
    itemId: string;
    itemName: string;
    itemCode: string;
    expectedQty: number;
    actualQty: number;
    difference: number;
    adjusted: boolean;
  }[];
  createdAt: string;
}

export type QuoteStatus = 'SENT' | 'ACCEPTED' | 'REJECTED' | 'DRAFT';
export type QuoteType = 'VENDA' | 'MANUTENCAO_CORRETIVA' | 'MANUTENCAO_PREVENTIVA' | 'REVISAO_GERAL' | 'OUTROS';
export type QuoteItemType = 'PECA' | 'SERVICO' | 'PRODUTO' | 'OUTRO';

export interface QuoteItem {
  id: string;
  type?: QuoteItemType;
  description: string;
  quantity: number;
  unit?: string;
  unitPrice: number;
  total: number;
}

export interface Quote {
  id: string;
  quoteNumber: string; // e.g. "ORC-1001"
  quoteType?: QuoteType;
  clientId: string; // reference to Client
  clientName: string; // snapshot for safety
  clientDocument?: string;
  clientAddress?: string;
  clientPhone?: string;
  clientEmail?: string;
  equipmentId?: string; // optional reference to Equipment
  equipmentName?: string;
  date: string;
  validUntil: string;
  status: QuoteStatus;
  items: QuoteItem[];
  subtotal: number;
  discount: number;
  total: number;
  paymentTerms: string;
  deliveryTime: string;
  warrantyTerms: string;
  notes?: string;
  pixKey?: string;
  technicianId?: string;
  technicianName?: string;
  createdAt: string;
  updatedAt: string;
}

export type PostMaintenanceStatus = 'PENDING_CONTACT' | 'CONTACTED' | 'EXCELLENT' | 'NEEDS_ADJUSTMENT' | 'WARRANTY_CLAIM';
export type EquipmentSourceType = 'REPAIRED' | 'SOLD';

export interface PostMaintenanceFeedback {
  id: string;
  serviceOrderId?: string;
  osNumber?: string;
  clientId: string;
  clientName: string;
  clientPhone: string;
  equipmentId?: string;
  equipmentName: string;
  sourceType: EquipmentSourceType; // 'REPAIRED' (Consertado) or 'SOLD' (Vendido)
  deliveryDate: string; // Date equipment was delivered / sold
  contactDate?: string; // Date post-maintenance survey was conducted
  status: PostMaintenanceStatus;
  rating: number; // 1 to 5 stars
  performanceStatus: 'EXCELLENT' | 'OPERATING_NORMAL' | 'MINOR_ADJUSTMENT' | 'NEEDS_INSPECTION' | 'CRITICAL_DEFECT';
  feedbackNotes: string; // Comments from client regarding performance
  technicianNotes?: string; // Observations by the quality control team
  npsScore?: number; // 0 to 10 Net Promoter Score
  contactedBy?: string; // Responsible person for follow up
  nextFollowUpDate?: string; // Optional future check-in date
  createdAt: string;
  updatedAt: string;
}

export interface ExplodedPartItem {
  id: string;
  position: string; // e.g. "1", "2", "3", "5.1", "6.1", "6.2"
  buyCode?: string; // COD. COMPRA
  factoryDescription: string; // DESCRIÇÃO FÁBRICA
  warehouseCode?: string; // COD. ALMOX (Código no Almoxarifado / Estoque)
  inventoryItemId?: string; // Reference to linked InventoryItem in the system
  quantityRecommended?: number; // Quantity used in this assembly (e.g. 1, 3 for triplex valves, etc.)
  notes?: string;
  // Hotspot / pin coordinates on the exploded diagram (percentage 0-100)
  hotspot?: {
    x: number; // percentage from left
    y: number; // percentage from top
  };
}

export interface EquipmentCatalog {
  id: string;
  title: string; // e.g. "Lava Jato Kärcher K 3.10 - Cabeçote de Pressão"
  equipmentModel: string; // e.g. "Kärcher K 3.10"
  equipmentId?: string; // Optional reference to registered Equipment
  category: string; // e.g. "Lavadoras de Alta Pressão", "Bombas Hidráulicas", etc.
  subassembly: string; // e.g. "Cabeçote / Válvulas", "Guia de Pistões e By-Pass", etc.
  diagramImageUrl?: string; // Custom uploaded diagram or image URL/base64
  diagramType: 'SVG_SCHEMATIC' | 'IMAGE';
  schematicId?: 'KARCHER_CABECOTE' | 'KARCHER_PISTOES' | 'BOMBA_TRIPLEX' | 'CILINDRO_HIDRAULICO' | 'CUSTOM';
  description?: string;
  parts: ExplodedPartItem[];
  isDraft?: boolean; // Se foi salvo como rascunho
  status?: 'PUBLISHED' | 'DRAFT'; // Status explícito do catálogo
  createdAt: string;
  updatedAt?: string;
}
