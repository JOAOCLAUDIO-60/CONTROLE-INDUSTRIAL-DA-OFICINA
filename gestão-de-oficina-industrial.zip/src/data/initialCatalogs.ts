import { EquipmentCatalog } from '../types';

export const INITIAL_EQUIPMENT_CATALOGS: EquipmentCatalog[] = [
  {
    id: 'cat-karcher-cabecote',
    title: 'Lava Jato Kärcher K 3.10 - Cabeçote de Pressão',
    equipmentModel: 'K 3.10',
    equipmentId: 'eq-karcher-310',
    category: 'Lavadoras de Alta Pressão',
    subassembly: 'Cabeçote de Válvulas, Gaxetas e Vedações',
    diagramType: 'SVG_SCHEMATIC',
    schematicId: 'KARCHER_CABECOTE',
    description: 'Vista explodida técnica do cabeçote de pressão de água, válvulas de pressão e sucção, bucha de ligação, anéis O-Ring e gaxetas de alta pressão da lavadora Kärcher K 3.10.',
    createdAt: '2026-04-01T10:00:00Z',
    parts: [
      {
        id: 'pt-cab-1',
        position: '1',
        buyCode: '9.001-111.0',
        factoryDescription: 'CONJ. TAMPA LATERAL VAL.',
        warehouseCode: '9.001-111.0',
        quantityRecommended: 3,
        notes: 'Tampa sextavada com rosca para acesso às válvulas laterais de pressão.',
        hotspot: { x: 14, y: 38 }
      },
      {
        id: 'pt-cab-2',
        position: '2',
        buyCode: '9.001-109.0',
        factoryDescription: 'VAL. DE PRESSÃO',
        warehouseCode: '9.001-109.0',
        quantityRecommended: 3,
        notes: 'Válvula de retenção cônica de saída de alta pressão com mola de retorno.',
        hotspot: { x: 14, y: 46 }
      },
      {
        id: 'pt-cab-3',
        position: '3',
        buyCode: '9.001-115.0',
        factoryDescription: 'CONJ. TAMPA CENTRAL VALVULA',
        warehouseCode: '9.001-115.0',
        quantityRecommended: 1,
        notes: 'Tampa de vedação central do compartimento das válvulas.',
        hotspot: { x: 23, y: 42 }
      },
      {
        id: 'pt-cab-4',
        position: '4',
        buyCode: '9.001-116.0',
        factoryDescription: "O'RING 75,87 X 2,62",
        warehouseCode: 'N70-2151',
        inventoryItemId: 'inv-karch-1',
        quantityRecommended: 1,
        notes: "Anel O'Ring de grande diâmetro para selagem entre cabeçote e carcaça do motor.",
        hotspot: { x: 49, y: 31 }
      },
      {
        id: 'pt-cab-5',
        position: '5',
        buyCode: '9.001-112.0',
        factoryDescription: 'BUCHA DE LIGAÇÃO',
        warehouseCode: '9.001-112.0',
        quantityRecommended: 3,
        notes: 'Bucha de interligação hidráulica entre os alojamentos internos.',
        hotspot: { x: 67, y: 64 }
      },
      {
        id: 'pt-cab-5-1',
        position: '5.1',
        buyCode: '9.001-117.0',
        factoryDescription: "O'RING DA BUCHA DE LIGAÇÃO 8 X 2",
        warehouseCode: 'N90E5726',
        inventoryItemId: 'inv-karch-2',
        quantityRecommended: 6,
        notes: "O'Ring de alta densidade 90 Shore para vedação estanque da bucha.",
        hotspot: { x: 69, y: 72 }
      },
      {
        id: 'pt-cab-6',
        position: '6',
        buyCode: '9.001-110.0',
        factoryDescription: 'VAL. DE SUCÇÃO',
        warehouseCode: '9.001-110.0',
        quantityRecommended: 3,
        notes: 'Conjunto de válvula de sucção de água da câmara de entrada.',
        hotspot: { x: 38, y: 56 }
      },
      {
        id: 'pt-cab-6-1',
        position: '6.1',
        buyCode: '9.001-118.0',
        factoryDescription: "O'RING DA VAL. SUCÇÃO 10 X 2",
        warehouseCode: 'N70E-6047',
        inventoryItemId: 'inv-karch-3',
        quantityRecommended: 3,
        notes: "O'ring externo de vedação no assento da câmara de sucção.",
        hotspot: { x: 42, y: 62 }
      },
      {
        id: 'pt-cab-6-2',
        position: '6.2',
        buyCode: '9.001-119.0',
        factoryDescription: "O'RING DA VAL. SUCÇÃO 9 X 2",
        warehouseCode: 'N70E-6023',
        inventoryItemId: 'inv-karch-4',
        quantityRecommended: 3,
        notes: "O'ring secundário da válvula de sucção.",
        hotspot: { x: 44, y: 69 }
      },
      {
        id: 'pt-cab-7',
        position: '7',
        buyCode: '9.001-113.0',
        factoryDescription: 'GUIA DA GAXETA',
        warehouseCode: '9.001-113.0',
        quantityRecommended: 3,
        notes: 'Anel suporte guia em polímero técnico usinado para assento da gaxeta de pressão.',
        hotspot: { x: 74, y: 74 }
      },
      {
        id: 'pt-cab-8',
        position: '8',
        buyCode: '9.001-120.0',
        factoryDescription: 'GAXETA 20 X 12 X 5',
        warehouseCode: '1500',
        inventoryItemId: 'inv-karch-5',
        quantityRecommended: 3,
        notes: 'Gaxeta de pressão alta vazão em borracha reforçada com lona/tecido emborrachado.',
        hotspot: { x: 67, y: 77 }
      },
      {
        id: 'pt-cab-9',
        position: '9',
        buyCode: '9.001-101.0',
        factoryDescription: 'CONJ. CABEÇOTE',
        warehouseCode: '9.001-101.0',
        quantityRecommended: 1,
        notes: 'Corpo principal fundido usinado com conexões de sucção, saída e guias.',
        hotspot: { x: 23, y: 71 }
      },
      {
        id: 'pt-cab-10',
        position: '10',
        buyCode: '9.001-114.0',
        factoryDescription: 'PARAFUSO M8 X 50',
        warehouseCode: '9.001-114.0',
        quantityRecommended: 4,
        notes: 'Parafuso Allen cabeça cilíndrica com sextavado interno M8x50 em aço zincado.',
        hotspot: { x: 16, y: 88 }
      }
    ]
  },
  {
    id: 'cat-karcher-pistoes',
    title: 'Lava Jato Kärcher K 3.10 - Guia de Pistões e By-Pass',
    equipmentModel: 'K 3.10',
    equipmentId: 'eq-karcher-310',
    category: 'Lavadoras de Alta Pressão',
    subassembly: 'Guia de Pistões, Válvula By-Pass, Filtro e Engate',
    diagramType: 'SVG_SCHEMATIC',
    schematicId: 'KARCHER_PISTOES',
    description: 'Vista explodida técnica dos pistões mecânicos com molas, anéis raspadores de óleo/água, válvula de alívio/by-pass, filtro de sucção Micra 90 e engate rápido 3/4 da lavadora Kärcher K 3.10.',
    createdAt: '2026-04-01T10:30:00Z',
    parts: [
      {
        id: 'pt-pst-1',
        position: '1',
        buyCode: '9.001-102.0',
        factoryDescription: 'GUIA PISTÕES PRÉ MONTADO',
        warehouseCode: '9.001-102.0',
        quantityRecommended: 1,
        notes: 'Carcaça intermediária guia dos três pistões axiais com guarnições internas.',
        hotspot: { x: 19, y: 31 }
      },
      {
        id: 'pt-pst-2',
        position: '2',
        buyCode: '9.001-104.0',
        factoryDescription: 'VAL. RETENÇÃO CPL',
        warehouseCode: '9.001-104.0',
        quantityRecommended: 1,
        notes: 'Válvula de retenção e dosagem de detergente/química completa.',
        hotspot: { x: 23, y: 35 }
      },
      {
        id: 'pt-pst-3',
        position: '3',
        buyCode: '9.001-103.0',
        factoryDescription: 'MOLA',
        warehouseCode: '9.001-103.0',
        quantityRecommended: 3,
        notes: 'Mola helicoidal de aço mola temperado de alta pressão para retorno do pistão.',
        hotspot: { x: 61, y: 50 }
      },
      {
        id: 'pt-pst-4',
        position: '4',
        buyCode: '9.001-105.0',
        factoryDescription: 'PISTÃO COMPLETO',
        warehouseCode: '9.001-105.0',
        inventoryItemId: 'inv-karch-9',
        quantityRecommended: 3,
        notes: 'Pistão usinado em aço inoxidável retificado de alta durabilidade com prato de apoio.',
        hotspot: { x: 74, y: 38 }
      },
      {
        id: 'pt-pst-5',
        position: '5',
        buyCode: '63653930',
        factoryDescription: 'ANEL RASPADOR 12 X 20 X 4/6',
        warehouseCode: '63653930',
        inventoryItemId: 'inv-karch-6',
        quantityRecommended: 3,
        notes: 'Anel raspador de perfil duplo para barreira estanque entre cárter e câmara d’água.',
        hotspot: { x: 28, y: 80 }
      },
      {
        id: 'pt-pst-6',
        position: '6',
        buyCode: '9.001-121.0',
        factoryDescription: 'VALVULA COMPLETA',
        warehouseCode: 'XX',
        quantityRecommended: 1,
        notes: 'Corpo da válvula de alívio e controle de pressão.',
        hotspot: { x: 27, y: 114 }
      },
      {
        id: 'pt-pst-6-1',
        position: '6.1',
        buyCode: 'N90E6047',
        factoryDescription: "O'RING MAIOR VALVULA",
        warehouseCode: 'N90E6047',
        inventoryItemId: 'inv-karch-7',
        quantityRecommended: 1,
        notes: "Anel O'Ring de maior diâmetro para sede da válvula de retenção.",
        hotspot: { x: 27, y: 125 }
      },
      {
        id: 'pt-pst-6-2',
        position: '6.2',
        buyCode: 'N90-2007',
        factoryDescription: "O'RING MENOR VALVULA",
        warehouseCode: 'N90-2007',
        inventoryItemId: 'inv-karch-8',
        quantityRecommended: 1,
        notes: "Anel O'Ring de menor diâmetro para bico da válvula.",
        hotspot: { x: 27, y: 133 }
      },
      {
        id: 'pt-pst-7',
        position: '7',
        buyCode: '9.001-106.0',
        factoryDescription: 'VALVULA BY PASS',
        warehouseCode: '9.001-106.0',
        inventoryItemId: 'inv-karch-10',
        quantityRecommended: 1,
        notes: 'Conjunto regulador de by-pass automático com pistão piloto e sede usinada.',
        hotspot: { x: 27, y: 153 }
      },
      {
        id: 'pt-pst-8',
        position: '8',
        buyCode: '9.001-122.0',
        factoryDescription: "O'RING",
        warehouseCode: 'XX',
        quantityRecommended: 1,
        notes: "Anel O'Ring de vedação intermediária da haste do by-pass.",
        hotspot: { x: 27, y: 140 }
      },
      {
        id: 'pt-pst-9',
        position: '9',
        buyCode: '9.001-123.0',
        factoryDescription: "O'RING",
        warehouseCode: 'XX',
        quantityRecommended: 1,
        notes: "Anel O'Ring de vedação da ponta da agulha de alívio.",
        hotspot: { x: 27, y: 147 }
      },
      {
        id: 'pt-pst-10',
        position: '10',
        buyCode: '9.001-107.0',
        factoryDescription: 'FILTRO MICRA 90',
        warehouseCode: '9.001-107.0',
        inventoryItemId: 'inv-karch-11',
        quantityRecommended: 1,
        notes: 'Filtro cônico em nylon com malha de 90 micras para retenção de areia e sólidos.',
        hotspot: { x: 67, y: 105 }
      },
      {
        id: 'pt-pst-11',
        position: '11',
        buyCode: '9.001-108.0',
        factoryDescription: 'ENGATE RAPIDO DE 3/4',
        warehouseCode: '9.001-108.0',
        inventoryItemId: 'inv-karch-12',
        quantityRecommended: 1,
        notes: 'Bocal de engate de conexão rápida 3/4" com trava de esfera para mangueira de jardim.',
        hotspot: { x: 86, y: 145 }
      }
    ]
  },
  {
    id: 'cat-karcher-hd585',
    title: 'Lavadora Kärcher HD 585 Prof S - Cabeçote de Latão',
    equipmentModel: 'HD 585 Prof S',
    equipmentId: 'eq-karcher-hd585',
    category: 'Lavadoras de Alta Pressão',
    subassembly: 'Cabeçote de Latão & Válvulas Triplex',
    diagramType: 'SVG_SCHEMATIC',
    schematicId: 'BOMBA_TRIPLEX',
    description: 'Vista explodida do cabeçote forjado em latão maciço da lavadora de linha profissional Kärcher HD 585 com conjunto de 6 válvulas (3 de sucção e 3 de pressão), retentores de óleo e gaxetas de alta temperatura.',
    createdAt: '2026-04-05T11:00:00Z',
    parts: [
      {
        id: 'pt-hd-1',
        position: '1',
        buyCode: '4.580-281.0',
        factoryDescription: 'VÁLVULA DE PRESSÃO TRIPLEX CPL',
        warehouseCode: '4.580-281.0',
        quantityRecommended: 3,
        notes: 'Válvula de alta pressão com gaiola e mola inox.',
        hotspot: { x: 25, y: 35 }
      },
      {
        id: 'pt-hd-2',
        position: '2',
        buyCode: '4.580-280.0',
        factoryDescription: 'VÁLVULA DE SUCÇÃO TRIPLEX CPL',
        warehouseCode: '4.580-280.0',
        quantityRecommended: 3,
        notes: 'Válvula de aspiração com anel de vedação reforçado.',
        hotspot: { x: 45, y: 35 }
      },
      {
        id: 'pt-hd-3',
        position: '3',
        buyCode: '6.362-875.0',
        factoryDescription: "O'RING 18 X 2 NBR 80",
        warehouseCode: 'N70E-6047',
        inventoryItemId: 'inv-karch-3',
        quantityRecommended: 6,
        notes: 'Vedação das tampas roscadas das válvulas.',
        hotspot: { x: 65, y: 35 }
      },
      {
        id: 'pt-hd-4',
        position: '4',
        buyCode: '6.365-393.0',
        factoryDescription: 'RETENTOR DE ÓLEO 14 X 22 X 5/7',
        warehouseCode: '63653930',
        inventoryItemId: 'inv-karch-6',
        quantityRecommended: 3,
        notes: 'Retentor do cárter de óleo para pistão cerâmico.',
        hotspot: { x: 30, y: 65 }
      },
      {
        id: 'pt-hd-5',
        position: '5',
        buyCode: '6.365-394.0',
        factoryDescription: 'KIT GAXETA ALTA PRESSÃO 14 X 22 X 5',
        warehouseCode: '1500',
        inventoryItemId: 'inv-karch-5',
        quantityRecommended: 3,
        notes: 'Jogo de gaxetas de alta pressão compactadas em borracha nitrílica especial.',
        hotspot: { x: 50, y: 65 }
      },
      {
        id: 'pt-hd-6',
        position: '6',
        buyCode: '5.060-983.0',
        factoryDescription: 'CABEÇOTE DE LATÃO USINADO',
        warehouseCode: '5.060-983.0',
        quantityRecommended: 1,
        notes: 'Bloco de latão forjado de alta resistência a corrosão e choques hidráulicos.',
        hotspot: { x: 70, y: 65 }
      }
    ]
  },
  {
    id: 'cat-cilindro-100t',
    title: 'Prensa Hidráulica 100T - Cilindro Principal de Dupla Ação',
    equipmentModel: 'PH-100 Caravelas',
    equipmentId: 'eq-2',
    category: 'Cilindros Hidráulicos',
    subassembly: 'Haste, Êmbolo, Camisa e Vedações',
    diagramType: 'SVG_SCHEMATIC',
    schematicId: 'CILINDRO_HIDRAULICO',
    description: 'Vista explodida técnica das vedações internas do cilindro hidráulico de prensagem: camisa brunida, haste cromada, êmbolo com anéis guias, gaxeta chevron e anel raspador.',
    createdAt: '2026-04-10T09:00:00Z',
    parts: [
      {
        id: 'pt-cil-1',
        position: '1',
        buyCode: 'PARK-HASTE-100',
        factoryDescription: 'HASTE DE AÇO 1045 CROMO DURO Ø90mm',
        warehouseCode: 'HASTE-90-CR',
        quantityRecommended: 1,
        notes: 'Haste temperada e retificada com camada de cromo duro de 30 micras.',
        hotspot: { x: 20, y: 40 }
      },
      {
        id: 'pt-cil-2',
        position: '2',
        buyCode: 'PARK-RASP-90',
        factoryDescription: 'ANEL RASPADOR D-90 EM POLIURETANO (PU)',
        warehouseCode: 'RASP-PU-90',
        quantityRecommended: 1,
        notes: 'Evita a entrada de poeira e cavacos no cabeçote guia.',
        hotspot: { x: 35, y: 40 }
      },
      {
        id: 'pt-cil-3',
        position: '3',
        buyCode: 'PARK-GAX-90',
        factoryDescription: 'JOGO DE GAXETA EM CHEVRON 90 X 110 X 22.5',
        warehouseCode: 'EST-HID01',
        inventoryItemId: 'inv-1',
        quantityRecommended: 1,
        notes: 'Jogo de vedação de alta pressão para haste em tecido emborrachado.',
        hotspot: { x: 50, y: 40 }
      },
      {
        id: 'pt-cil-4',
        position: '4',
        buyCode: 'PARK-EMB-180',
        factoryDescription: 'ÊMBOLO DE DUPLA AÇÃO Ø180mm',
        warehouseCode: 'EMB-DUPLA-180',
        quantityRecommended: 1,
        notes: 'Pistão êmbolo com alojamento para anéis guias de bronze/PTFE.',
        hotspot: { x: 65, y: 40 }
      },
      {
        id: 'pt-cil-5',
        position: '5',
        buyCode: 'PARK-VED-EMB',
        factoryDescription: 'VEDAÇÃO DO ÊMBOLO SPGO Ø180mm COM ENERGIZADOR NBR',
        warehouseCode: 'VED-SPGO-180',
        quantityRecommended: 2,
        notes: 'Vedação bi-direcional para cilindros de alta ciclagem e pressão até 350 bar.',
        hotspot: { x: 80, y: 40 }
      }
    ]
  }
];
