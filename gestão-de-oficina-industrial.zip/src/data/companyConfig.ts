/**
 * Dados Institucionais Oficiais da Empresa JC&F
 * Utilizados para emissão de Orçamentos, Ordens de Serviço, Laudos Técnicos,
 * Recibos, Certificados de Garantia e Comunicação via WhatsApp / E-mail.
 */
export const JCF_COMPANY_INFO = {
  name: 'JC&F – Manutenção Hidráulica e Pneumática',
  tradeName: 'JC&F Manutenção',
  shortName: 'JC&F',
  address: 'Rua Luís Bom, Nº 16 – Campo Grande – Rio de Janeiro – RJ',
  street: 'Rua Luís Bom, Nº 16',
  neighborhood: 'Campo Grande',
  city: 'Rio de Janeiro',
  state: 'RJ',
  cnpj: '25.452.856/0001-29',
  email: 'jcfrj2017@gmail.com',
  phone: '(21) 98369-9728',
  phoneRaw: '5521983699728', // Para links do WhatsApp
  pixKey: '25.452.856/0001-29', // Chave PIX (CNPJ)
  pixType: 'CNPJ',
  tagline: 'Soluções de Alta Performance em Hidráulica e Pneumática Industrial',
  bankInfo: 'Banco Inter (077) / Chave PIX: 25.452.856/0001-29'
};
